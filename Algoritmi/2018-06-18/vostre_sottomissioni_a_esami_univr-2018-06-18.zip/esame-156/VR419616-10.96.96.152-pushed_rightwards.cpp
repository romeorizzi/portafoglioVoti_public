#include <iostream>
#include <cstdio>

#define NMAX 100000

int N;
int G[NMAX];
int T[NMAX];
int memo[NMAX];

int maxGems(int i){
    if(i>=N)
        return 0;
    else if(memo[i]!=-1){
        return memo[i];
    }
    else{
        int x,y;

        //prendo la gemma
        x = G[i] + maxGems(i+1+T[i]);
        y = maxGems(i+1);

        memo[i] = std::max(x,y);
        return memo[i];
    }
}

int main(){

    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    std::cin>>N;

    for(int i=0; i<N; i++){
        std::cin>>G[i];
        memo[i] = -1;
    }

    for(int i=0; i<N; i++){
        std::cin>>T[i];
    }


    std::cout<<maxGems(0);
    


    return 0;
}
