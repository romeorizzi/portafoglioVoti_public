#include <cstdlib>
#include <ctime>
#include <cassert>
#include <fstream>
#include <iostream>

using namespace std;

#define MAXM 500

int M, N, B;
int pirellone[MAXM][MAXM];
int sr[MAXM];
int sc[MAXM];

void setRiga(int riga){
    for(int i=0; i< N; i++){
        pirellone[riga][i] = (pirellone[riga][i] + 1) % B; 
    }
}

void setColonna(int col){
    for(int i=0; i< M; i++){
        pirellone[i][col] = (pirellone[i][col] + 1) % B; 
    }
}


int main(){

    ifstream r("input.txt");
    ofstream w("output.txt");
    r >> M;
    r >> N;
    r >> B;

    for(int i=0; i< M; i++){
        for(int j=0; j < N; j++){
            r >> pirellone[i][j];
        }
    }

/////////////////////////////////////////////////////////////////////
    for(int i=0; i< N; i++){
        if(pirellone[0][i] == (B-1)){
            cout << "i: "<< i << endl; 
            setColonna(i);
            sr[i] = 1;
        }else if(pirellone[0][i] == 1 && B == 3 ){
            setColonna(i);
            setColonna(i);
            sr[i] = 2;
        }
        
    }

    for(int j=0; j< M; j++){
        if(pirellone[j][0] == (B-1)){
            setRiga(j);
            sc[j] = 1;
        }else if(pirellone[j][0] == 1 && B == 3 ){
            setRiga(j);
            setRiga(j);
            sc[j] = 2;
        }
        
    }






    int flag = 0;

    for(int i=0; i< M; i++){
        for(int j=0; j< N; j++){
            cout << pirellone[i][j] << "\t";
        }
        cout << endl;
    } 
    
    for(int i=0; i< M; i++){
        for(int j=0; j< N; j++){
            if(pirellone[i][j] != 0){
                //cout << "flag " << pirellone[i][j] << endl;
                flag = 1;
                break;
            }        
        }
        
    }

    if (flag == 0){
            for(int i= 0; i< M; i++)
                w << sc[i] << "\t";
            w << endl;
            for(int i= 0; i< N; i++)
                w << sr[i] << "\t";
        }else{
            for(int i=0; i<M; i++)
                w << 0;
            w << endl;
            for(int i=0; i< N; i++)
                w << 0;
        }
    

    
return 0;
}