#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN+1]; // g[i] = numero celle in cella i-esima.
int t[MAXN+1]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN+1];

int max_g(int partenza){
    if (partenza <= N){
        if(max_sum_g[partenza] != 0){
            return max_sum_g[partenza];
        }
        max_sum_g[partenza] += max_g(partenza + t[partenza] + 1) + g[partenza];
        return max_sum_g[partenza];
    }
    return 0;
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 1; i <= N; i++)
       scanf("%d", &g[i]);
    for(int i = 1; i <= N; i++)
       scanf("%d", &t[i]);
    
    int max = -1;
    int result = -1;

    for (int i = 1; i <= N; i++){
        result = max_g(i);
        if (result > max){
            max = result;
        }
    }
    printf("%d", max);
}