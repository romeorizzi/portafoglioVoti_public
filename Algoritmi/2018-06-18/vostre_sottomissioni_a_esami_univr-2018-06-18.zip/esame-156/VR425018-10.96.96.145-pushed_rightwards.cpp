#include<bits/stdc++.h>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

#define MAX_N 100000

int N;

int g[MAX_N];
int t[MAX_N];

int memo[MAX_N];


int risolvi(int pos){
    if(pos>=N){
        return 0;
    }
    if(memo[pos]!=-1){
        return memo[pos];
    }
    int prendo = g[pos] + risolvi(pos+1+t[pos]);
    int salto = risolvi(pos+1);
    memo[pos] = max(prendo,salto);
    return memo[pos];
}


int main(){

    in >> N;


    for(int i=0;i<N;i++){
        in >> g[i];
        memo[i]=-1;
    }

    for(int i=0;i<N;i++){
        in >> t[i];
    }

    int ris = risolvi(0);
    
    out<<ris<<endl;

    return 0;
}
