#include<bits/stdc++.h>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

#define MAX_N 1000000

int N;
int mod;


pair<int,int> ris[MAX_N];
int stampaTemp[MAX_N];

int cont=0;
int contStampa=0;

int make1(){
    int val;
    in>>val;
    N++;
    if(val==0){
        ris[cont].first=1;
        ris[cont].second=val;
        cont++;
        //ris[N-1]=1;
        return 1;
    }
    
    int somma=1;
    for(int i=0;i<val;i++){
        somma += make1();
    }
    ris[cont].first=somma;
    ris[cont].second=val;
    cont++;
    //ris[N-1]=somma;
    return somma;
}


void stampaRis1(){
    auto val = ris[cont--];
    if(val.second==0){
        stampaTemp[contStampa++] = val.first;
        return;
    }
    
    for(int i=0;i<val.second;i++){
        stampaRis1();
    }
    stampaTemp[contStampa++] = val.first;
}

int risTemp2[MAX_N];

int make2(){
    int val;
    in>>val;
    N++;
    if(val==1){
        //cout<<"0 ";
        //ris[cont].first=1;
        risTemp2[cont]=0;
        cont++;
        return 1;
    }
    if(val<0){
        return 0;
    }

    int numFigli = 0;
    for(int i=val;i>1;){
        i -= make2();
        numFigli++;
    }
    //cout << numFigli << " ";
    //ris[cont].first=1;
    risTemp2[cont]=numFigli;
    cont++;
    return val;
}



void stampaRis2(){
    auto val = risTemp2[cont--];
    if(val==0){
        stampaTemp[contStampa++] = val;
        return;
    }
    
    for(int i=0;i<val;i++){
        stampaRis2();
    }
    stampaTemp[contStampa++] = val;
}




int main(){

    in >> mod;

    N=0;
    
    /*
    for(int i=0;i<11;i++){
        in >> letto[i];
        //cout<<letto[i]<<endl;
        N++;
    }
    */

    if(mod==1){
        N=0;
        cont=0;
        make1();
        cont=N-1;
        contStampa=0;
        stampaRis1();
        out << "2 ";
        for(int i=N-1; i>=0; i--){
            out<<stampaTemp[i]<<" ";
        }
        out<<"\n";
    } else if(mod==2){
        N=0;
        cont=0;
        make2();
        cont=N-1;
        contStampa=0;
        stampaRis2();
        out << "1 ";
        for(int i=N-1; i>=0; i--){
            out<<stampaTemp[i]<<" ";
        }
        out<<"\n";
    }



    //cout<<"N:"<<N<<endl;

    return 0;
}