#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;


int input[1000000];
int output[1000000];

int main(){
    fstream fIn;
    fstream fOut;
    fIn.open("input.txt",ios::in);
    int N=0;
    int type;
    fIn>>type;
    //cout<<type;
    int prossimo=fIn.peek();
    while(prossimo!=-1){
        fIn>>input[N];
        cout<<input[N]<<",";
        N++;
        prossimo=fIn.peek();
    }
    cout<<N;
    cout<<" ";
    fIn.close();
    
    if(type==1){
        fOut.open("output.txt",ios::out);
        output[0]=2;
        cout<<"Operazione 1 a 2";
        cout<<" ";
        for(int i=N-2;i>=0;i--){
            int contenuto=input[i];
            cout <<contenuto;
             cout<<" ";
            if (contenuto==0){
                output[i+1]=1;
            }else{
                cout<<"else";
                int numeroDiscendenti=1;
                int indiceProssimoFiglio=i+2;
                while(contenuto>0){
                    numeroDiscendenti+=output[indiceProssimoFiglio];
                    indiceProssimoFiglio+=output[indiceProssimoFiglio];
                    contenuto--;
                    
                }
                cout<<"Ndisc: "<<numeroDiscendenti<<" ";
                output[i+1]=numeroDiscendenti;
            }
        }


    }else{
         fOut.open("output.txt",ios::out);
        output[0]=1;
        cout<<"Operazione 2 a 1";
        
        for(int i=0;i<N-1;i++){
          int contenuto=input[i];
          if(contenuto==1){
              output[i+1]=0;
          }else{
              int numeroFigli=0;
              int count=contenuto-1;
              int indiceProssimoFiglio=i+1;
              while(count>0){
                  numeroFigli++;
                  count-=input[indiceProssimoFiglio];
                  indiceProssimoFiglio+=input[indiceProssimoFiglio];
              }
              output[i+1]=numeroFigli;
          }
        }
    }

     for (int i=0;i<N;i++){
            fOut<<output[i];
            fOut<<" ";
            }
    fOut.close();
    return 0;
}
