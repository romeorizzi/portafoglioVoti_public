#include <cstdio>

int max_guadagno(int result[], int k, int N){
    int max=-1;
    for(int i=k; i<=N; i++){
        if(result[i]>max)
            max = result[k];        
    }
    return max;
}
            

int main(){
    
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    
    int N;
    //leggo N
    scanf("%d", &N);

    int gemme[N+1];
    int troll[N+1];

    //leggo gemme
    for(int i=1; i<=N; i++)
        scanf("%d", &gemme[i]);
        
    //leggo troll
    for(int i=1; i<=N; i++)
        scanf("%d", &troll[i]);
        
    int result[N+1];
    
    result[N] = gemme[N];
    
    int gemme_future = 0;
    for(int i=N-1; i>=1; i--){
        //se l'indice a cui il troll mi fa saltare è maggiore dell limite
        //dell'array allora il guadagno è 0
        if(troll[i]+i+1 > N)
            gemme_future = 0;
            
        else{
            if(troll[i] == 0){
                //se non ho vincoli in cui saltare salto io dove più mi conviene
                gemme_future = max_guadagno(result, i+1, N) ;         
            }
            else{
                gemme_future = max_guadagno(result, troll[i]+i+1, N);
            }

        }
            
        result[i] = gemme[i] + gemme_future;
    
    }
    
    
    #if 0  
    //stampe di prova
    for(int i=0; i<=N; i++)
        printf("%d ", gemme[i]);
     
    printf("\n");   
    for(int i=0; i<=N; i++)
        printf("%d ", troll[i]);
    
    
    for(int i=1; i<=N; i++)
        printf("%d ", result[i]);
    
    printf("\n")
    
    #endif
        
    int max = -1;
    for(int i=1; i<=N; i++){
        if(result[i] > max)
            max = result[i];
    }
    
    printf("%d", max);
       
   
    
    

    return 0;
}
