#include <cstdio>
#include <vector>

using std::vector;

vector<int> figli[1000000];
int num_nodi = 1;   //la radice esiste sempre
int prossimo_nodo = 0;

//procedura di lettura grafo simile a quella svolta a lezione per specchio
//lettura formato1
void leggi_albero1(){
    int nodo = prossimo_nodo;
    prossimo_nodo++;
    
    int num_figli;
    scanf("%d", &num_figli);
    
    num_nodi += num_figli;
    
    figli[nodo].resize(num_figli);
    
    for(int i=0; i<figli[nodo].size(); i++){
        figli[nodo][i] = prossimo_nodo;
        leggi_albero1();
    }
    
}


void stampa_formato2(int radice, int vettDiscendenti[]){
    
    //se non ho figli stampo 1
    if(figli[radice].size() == 0){
        vettDiscendenti[radice] = 1;
    }
    
    else{
        vettDiscendenti[radice] = 0;
        for(int i=0; i<figli[radice].size(); i++){
           stampa_formato2(figli[radice][i],vettDiscendenti);
           vettDiscendenti[radice] += vettDiscendenti[figli[radice][i]];
        }
        vettDiscendenti[radice] ++;
    }
       

}


int main(){
    
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    
    int formato;
    //leggo il formato
    scanf("%d", &formato);
    
    
    if(formato == 1){
        leggi_albero1();
    
        int vettDiscendenti[num_nodi];
        stampa_formato2(0, vettDiscendenti);
        
        
        printf("2 ");
        for(int i=0; i<num_nodi; i++){
            printf("%d ",vettDiscendenti[i]);
        }
    }
    
    else{
        
        //leggo il valore del primo nodo cioè radice
        int num_nodi;
        scanf("%d", &num_nodi);
        //alloco il vettore lungo num_nodi
        int vettDiscendenti[num_nodi];
        
        vettDiscendenti[0] = num_nodi;
        
        //leggo il resto del vettore
        for(int i=1; i<num_nodi; i++)
           scanf("%d", &vettDiscendenti[i]);
           
        int vettFigli[num_nodi];
        
        for(int i=num_nodi-1; i>=0; i--){
            if(vettDiscendenti[i] == 1){
                //se ho valore 1 allora non ho figli e metto 0 
                vettFigli[i] = 0;
            }
            
            else{
                //salvo i suoi discendenti meno lui stesso
                int num_discendenti = vettDiscendenti[i]-1;
                int num_figli = 0;
                int z = i+1;   //secondo contatore
                while(num_discendenti>0 ){
                       
                    if(vettDiscendenti[z]<0){
                        z++;    //il -1 indica che l ho già considerato, quindi incremento z e passo avanti
                        continue;
                    }
                        
                    num_discendenti -= vettDiscendenti[z];
                    vettDiscendenti[z] = -1;
                    z++;
                    
                    num_figli++;    //incremento il numero di figli
                }
                
                vettFigli[i]=num_figli;
                
                
            }
         }
         
        //stampo
        printf("1 ");
        for(int i=0; i<num_nodi; i++){
            printf("%d ",vettFigli[i]);
        }
         
           
    }
    
    
    
    #if 0
    //stampe di prova
    for(int i=0; i<=10; i++){
        printf("figli[%d]=",i);
        for(int j=0; j<figli[i].size(); j++)
            printf("%d ",figli[i][j]);
        printf("\n");
    }
    
    printf("\nNumNodi=%d", num_nodi);
    #endif   
   
    
    

    return 0;
}
