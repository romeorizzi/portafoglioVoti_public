#include <cassert>
#include <algorithm>
#include <cstdio>
#include <iostream>

#define MAXN 1000000

using namespace std;

int N;

int troll[MAXN];

int gemme[MAXN];


int somma_gemme[MAXN];

int main () {

  assert(freopen("input.txt","r", stdin));
  assert(freopen("output.txt","w", stdout));

    
    int max = 0;

    scanf("%d", &N);

    assert(N>0);

    for (int i = 0; i < N; i++){
        scanf("%d", &gemme[i]);
}
    for (int k = 0; k < N; k++){
        scanf("%d", &troll[k]);
}
    for(int j = N-1; j >= 0; j--){
        if((troll[j]+1+j) > N)
           somma_gemme[j] = gemme[j];   
        else {
            if (max > gemme[j] + somma_gemme[troll[j]+1+j])
                somma_gemme[j] = max;
            else {
                somma_gemme[j] = gemme[j] + somma_gemme[troll[j]+1+j];
                max = gemme[j] + somma_gemme[troll[j]+1+j];    
            }
        }
    }
    cout << max;
  return 0;
}
