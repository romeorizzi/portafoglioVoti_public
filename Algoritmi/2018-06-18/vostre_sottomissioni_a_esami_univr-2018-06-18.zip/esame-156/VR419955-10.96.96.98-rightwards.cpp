#include <cassert>
#include <cstdio>

int max3(int result[], int A, int B){
    int max = 0;
    for (int i = A; i<=B; i++)
        max = result[i];
    return max;
}

int main(){
#ifdef EVAL
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
#endif

    int N;
    scanf("%d", &N);
    int gemme[N+1];
    int troll[N+1];

    for(int i = 1; i<=N; i++)
        scanf("%d", &gemme[i]);    

    for(int i = 1; i<=N; i++)
        scanf("%d", &troll[i]);    

    int result[N+1];
    int gemme_ft = 0;

    for (int i = N; i>=1; i--){
        gemme_ft = max3(result,troll[i]+i+1,N);
        result[i] = gemme[i]+gemme_ft;
    }

    printf("%d\n", result[1]);
    return 0;
}
