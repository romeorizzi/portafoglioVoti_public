#include<iostream>
#include<fstream>
using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");
void from1_to_2(char[] tree1){
    int i,j;
    char[tree1.length()] tree2;
    tree2[0] = 2;
    for (i = 1; i < tree1.length(); i++){
        discendenti = tree1[i];
        if (tree1[i] == 0){
                tree2[i] = 1;
                continue;
            } else{
                for (j = i+1; j < tree1.length(); j++)
                    discendenti+=tree1[j];
                tree2[i] = discendenti+1;
    }
}

void from2_to_1(char[] tree2){
    char[tree2.length()] tree1;
    tree1[0] = 1;
    int i,j;
    for (i = 1; i < tree2.length(); i++){
        if(tree2[i] == 1 || tree2[i] == 2)
            tree1[i] = tree2[i] - 1;
        else{
            for(j=i+1; j < tree2.length(); j++){
                if(tree2[j] == 1)
                    continue;
                tree1[i] = tree2[i] - tree2[j];
                break;            
            }        
        }    
    }
}

