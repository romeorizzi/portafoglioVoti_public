/* pirelloneGFB *
   filename: farlocca
   Romeo Rizzi 2005-02-25

   contiene una soluzione farlocca con le seguenti funzionalità:
   1. offre allo studente un meccanismo semplice e fidato per la gestione dell' input/output
   2. quando sottomessa, consente di andare a comprendere il costo in tempo macchina di tale approccio alla lettura dell'input
   3. quando sottomessa, consente di farsi una mappa precisa di quali istanze siano non risolvibili
   4. consente di monitorare che le varie assunzioni e limiti sulle istanze siano tutti rispettati. 
*/

#include <cassert>
#include <cstdio>
#include <cstdlib>

// #define EVAL // define EVAL to input/output from file also in local

const int MaxM = 502;
const int MaxN = 502;

int P[MaxM][MaxN];     // Luci del Pirellone
int row[MaxM];
int col[MaxM];
int M, N, B;

void setRiga(int riga){
    for(int i = 0 ; i < N; i++)
        P[riga][i] = (P[riga][i] + 1) % B;
}

void setColonna(int colonna){
    for(int i = 0 ; i < M; i++)
        P[i][colonna] = (P[i][colonna] + 1) % B;
}

int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
  if( scanf("%d %d %d", &M, &N, &B) != 3 )  return 1;
  assert( 1 <= M && M <= MaxM );
  assert( 1 <= N && N <= MaxN );
  assert( 2 <= B && B <= 10 );
  
  int non_zero_row = -1;
  for(int i = 0 ; i < M ; i++ )
    for(int j = 0 ; j < N ; j++ ) {
      if( scanf("%d", &P[i][j] ) != 1 )
	return 1;
      if( P[i][j] )
	non_zero_row = i;
    }
  assert ( non_zero_row >= 0 );  // verifica l'assunzione del testo che almeno una luce sia accesa.


    // SOL.
    for (int j = 0; j < N; j++){
        if(P[0][j] == (B-1)){
            setColonna(j);
            row[j]=1;
        }
        else if(P[0][j] == 1 && B == 3){
          setColonna(j);
          setColonna(j);
          row[j]=2;
        }
    }

    for (int i = 0; i < M; i++){
        if(P[i][0] == (B-1)){
            setRiga(i);
            col[i]=1;
        }
        else if(P[i][0] == 1 && B == 3){
          setRiga(i);
          setRiga(i);
          col[i]=2;
        }
    }

    int x = 0;
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            if(P[i][j] != 0){
                x = 1;
                break;
            }

    if (x==0){
        for (int i = 0; i < M; i++)
            printf("%d", col[i]);
        printf("\n");
        for (int j = 0; j < N; j++)
            printf("%d", row[j]);
        printf("\n");
    }
    else{
        printf("0");
        for(int i=1; i < M; i++)
            printf(" 0");
        printf("\n");
        printf("0");
        for(int j=1; j < N; j++)
            printf(" 0");
        printf("\n");
    }
  
    return 0;
}
