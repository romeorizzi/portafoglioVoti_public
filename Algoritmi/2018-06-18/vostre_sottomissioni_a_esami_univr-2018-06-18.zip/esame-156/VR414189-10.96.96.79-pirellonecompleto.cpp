#include <stdlib.h>
#include <stdio.h>

#define N 500
#define M 500

int grid[N][M];
int raws[N];
int cols[M];
int n, m, colors;
bool is_solvable;

void Exe_switch_on_raw( int i )
{
    for (int j = 0; j < m; j++)
    {
        grid[i][j] = (grid[i][j] + 1) % colors;
    }
}

void Exe_switch_on_col(int j)
{
    for (int i = 0; i < n; i++)
    {
        grid[i][j] = (grid[i][j] + 1) % colors;
    }
}

bool Check_solvability()
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (grid[i][j] != 0)
            {
                return false;
            }
        }
    }
    return true;
}

int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d %d %d", &n, &m, &colors);

    int tmp;

    //input
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            scanf("%d", &tmp) ;
            grid[i][j] = tmp;
        }
    }

    is_solvable = true;

    //init
    for (int i = 0; i < n; i++) { raws[i] = 0; }
    for (int j = 0; j < m; j++) { cols[j] = 0; }

    for (int k=0; k < colors; k++)
    {        
        for (int j = 0; j < m; j++)
        {
            if (grid[0][j] != 0)
            {
                cols[j] += 1;
                Exe_switch_on_col(j);
            }
        }
    }
        
    for ( int k=0; k < colors; k++)
    {
        for (int i = 0; i < n; i++)
        {
            if (grid[i][0])
            {
                raws[i] += 1;
                Exe_switch_on_raw(i);
            }
        }
    }

    is_solvable = Check_solvability();

    if (!is_solvable)
    {
        //exit and return
        printf("0");
        for (int i = 1; i < n; i++)
        {
            printf(" 0");
        }
        printf("\n");
        printf("0");
        for (int j = 1; j < m; j++)
        {
            printf(" 0");
        }
        printf("\n");
        return 0;
    }

    printf("%d", raws[0]);
    for (int i = 1; i < n; i++)
    {
        printf(" %d", raws[i]);
    }
    printf("\n");
    printf("%d", cols[0]);
    for (int j = 1; j < m; j++)
    {
        printf(" %d", cols[j]);
    }
    printf("\n");

    return 0;
}   
