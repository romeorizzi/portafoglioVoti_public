/* pirelloneGFB *
   filename: farlocca
   Romeo Rizzi 2005-02-25

   contiene una soluzione farlocca con le seguenti funzionalità:
   1. offre allo studente un meccanismo semplice e fidato per la gestione dell' input/output
   2. quando sottomessa, consente di andare a comprendere il costo in tempo macchina di tale approccio alla lettura dell'input
   3. quando sottomessa, consente di farsi una mappa precisa di quali istanze siano non risolvibili
   4. consente di monitorare che le varie assunzioni e limiti sulle istanze siano tutti rispettati. 
*/

#include <cassert>
#include <cstdio>
#include <cstdlib>

// #define EVAL // define EVAL to input/output from file also in local

const int MaxM = 5000;
const int MaxN = 5000;

int prima[MaxN];
int colonna[MaxN];
int P[MaxN];     // Luci del Pirellone
int M, N, B;

int main(int argc, char *argv[]) {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
  if( scanf("%d %d %d", &M, &N, &B) != 3 )  return 1;
  assert( 1 <= M && M <= MaxM );
  assert( 1 <= N && N <= MaxN );
  assert( 2 <= B && B <= 10 );
  
  int sbagliato = false;
  //prima riga
  for(int j = 0 ; j < N ; j++ ) {
    if( scanf("%d", &prima[j] ) != 1 )
	      return 1;

    if(prima[j]==0)
      prima[j] = 0;
    else
      prima[j] = B-prima[j];
  }
  
  //altre righe
  for(int i = 1 ; i < M && !sbagliato ; i++ ) {
    int sas;
    for(int j = 0 ; j < N && !sbagliato; j++ ) {
      if( scanf("%d", &P[j] ) != 1 )
	      return 1;
      
      P[j] = (P[j] + prima[j])%B;
      if(j==0) {
        if(P[0] == 0) {
          sas = 0;
        } else {
          sas = B-P[0];
        }
      } else {
        if((P[j] + sas)%B!=0) {
          sbagliato = true;
        }
      }      

      if(j==N-1) {
        if(P[0] == 0) {
          colonna[i] = 0;
        } else {
          colonna[i] = B-P[0];
        }
      }
    }
  }

  for(int j=0 ; j<M ; j++) {
    if(!sbagliato)
      printf("%d ", colonna[j]);
    else {
      printf("0 ");
    }
  }
  printf("\n");
  for(int j=0 ; j<N ; j++) {
    if(!sbagliato)
      printf("%d ", prima[j]);
    else {
      printf("0 ");
    }
  }
  printf("\n");

  /* Risoluzione farlocca (assume che tutte le istanze siano non risolvibili) */
  /*
  for(int i=0 ; i<M ; i++) {
    if(P[i][0] == 0) {
      printf("0 ");
    } else {
      printf("%d ", B-P[i][0]);
    }
  }
  printf("\n");

  int sas = 0;
  if(P[0][0] != 0) {
      sas = B-P[0][0];
  }
  for(int i=0 ; i<N ; i++) {
    P[0][i] = (P[0][i]+ sas)%B;
  }
  for(int i=0 ; i<N ; i++) {
    if(P[0][i] == 0) {
      printf("0 ");
    } else {
      printf("%d ", B-P[0][i]);
    }
  }
  printf("\n");

  /*

  printf("0");
  for(int i=1; i < M; i++)
    printf(" 0");
  printf("\n");
  printf("0");
  for(int j=1; j < N; j++)
    printf(" 0");
  printf("\n");
  */
  return 0;
}
