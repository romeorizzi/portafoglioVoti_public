#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>
using namespace std;

int pirellone[500][500];
int up[500];
int down[500];

ifstream in("input.txt");
ofstream out("output.txt");

void printZeros(int M, int N){
    for(int i=0; i < M; i++){
        out << 0 << " ";
    }
    out << "\n";
    for(int j=0; j < N; j++){
        out << 0 << " ";
    }
}

int main(){
    int M,N,B;
    in >> M;
    in >> N;
    in >> B;
    
    //cout << "PARTO";
    //cout << N << B << M;
    auto flag = 0;
    for(int i =0; i < M; i++){
        for(int j=0; j < N; j++){
            in >> pirellone[i][j];
            if(pirellone[i][j] > flag)
                flag = 1;
        }
    }
   
    //cout << "salvato matrice";
    if(flag){
        for(int i=0; i < N; i++){
            if(pirellone[0][i] >= 1){
                down[i] += 1;
                for(int j =0; j <M;j++){
                    pirellone[i][j] = (pirellone[i][j]+1)%B;
                }
                if(pirellone[0][i] >= 1)    // la ricambio
                    i--;
            }
        }
        //cout << "controllato colonne";
        for(int i =0; i < M; i++){
            if(pirellone[i][0] >= 1){
                up[i] += 1;
                for(int j=0; j < N; j++){
                    pirellone[i][j] = (pirellone[i][j]+1)%B;
                }
                if(pirellone[i][0] >= 1)    // la ricambio
                    i--;
            }
        }
        //cout << "controllato righe";

        int sum =0;
        for(int i=0; i < M; i++){
            for(int j=0; j < N; j++){
                sum += pirellone[i][j];
            }
        }
        //cout << "verifico la somma";
        if(sum == 0){
            for(int i=0; i < M; i++){
                out << up[i] << " ";
            }
            out << "\n";
            for(int j=0; j < N; j++){
                out << down[j] << " ";
            }

        }else{
            printZeros(M, N);
        }
    }else{
        printZeros(M, N);
    }
}