/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];
int max_gemme(int controllo){
    
    if(controllo<=N){
        if (max_sum_g[controllo]==0){
            max_sum_g[controllo]+=max_gemme(controllo +t[controllo]+1)+g[controllo];
            return max_sum_g[controllo];
        }
        else
            return max_sum_g[controllo];

    }
    return 0;
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    assert(N>0);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);
    
    int max=-1;
    int risultato=-1;
    for (int i=0;i<N;i++){
        risultato=max_gemme(i);
        if(risultato>max)
            max=risultato;
    }
    printf("%d\n",max);
    return 0;
}

