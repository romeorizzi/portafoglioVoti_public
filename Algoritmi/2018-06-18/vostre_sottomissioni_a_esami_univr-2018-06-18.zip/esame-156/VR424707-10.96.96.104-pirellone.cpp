#include <cassert>
#include <cstdio>
#include <cstdlib>

int M, N, B;
const int MaxM = 500;
const int MaxN = 500;
int pirellone[MaxM][MaxN];

int main(){

#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    scanf(" %d %d %d", &M, &N, &B );

    for (int i=0; i< M; i++){
        for (int j=0; j< M; j++){
            scanf(" %d", &pirellone[i][j]);
        }
    }

    int row[M];
    int col[N];
    for (int i=0; i< M; i++)
        row[i]=0;
    for (int i=0; i< N; i++)
        col[i]=0;
    for (int i=0; i< M; i++){
            while (pirellone[i][0]!=0){
                //premo interrutore riga
                row[i]++;
                for (int k=0; k< N; k++){
                    pirellone[i][k]=(pirellone[i][k]+1)%B;
                }
            }
    }

    for (int j=0; j< N; j++){
            while (pirellone[0][j]!=0){
                //premo interrutore riga
                col[j]++;
                for (int k=0; k< M; k++){
                    pirellone[k][j]=(pirellone[k][j]+1)%B;
                }
            }
    }
    int risolvibile=1;
    for (int i=0; i< M; i++){
        for (int j=0; j< N; j++){
            if (pirellone[i][j]!=0){
                risolvibile=0;
            }
        }
    }
    if(risolvibile==1){
        for (int i=0; i< M; i++){
            printf ("%d ", row[i]);
        }
        printf("\n");
        for (int j=0; j< N; j++){
            printf ("%d ", col[j]);
        }
    } else{
        for (int i=0; i< M; i++){
            printf("0 ");
        }
        printf("\n");
        for (int i=0; i< N; i++){
            printf("0 ");
        }
    }
}


