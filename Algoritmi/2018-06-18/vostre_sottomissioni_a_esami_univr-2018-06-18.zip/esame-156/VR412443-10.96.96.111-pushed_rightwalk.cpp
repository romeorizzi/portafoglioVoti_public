/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


//#include <cassert>
//#include <cstdio>
//#include <algorithm>
//#include <fstream>
//#include <iostream>

using namespace std;

#define MAXN 100000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];
int memo_visited[MAXN];

int raccolta_gemme(int cella){

    //CASI BASE
        // se la cella è già stata visitata
    if(memo_visited[cella])
        return max_sum_g[cella];

    // CASO RICORSIVO
    int max = 0, x;
    if(cella + t[cella] + 1<= N){
        for(int i = cella + t[cella] +1; i <= N; i++){
                x = raccolta_gemme(i);
                if(x>max)
                    max = x;
        }
    }

    max_sum_g[cella] = max + g[cella];
    memo_visited[cella] = true;

    return max_sum_g[cella];

}

int main() {
    
    // RACCOLTA DATI
    ifstream inputf("input.txt");
    
    inputf >> N;

    for(int i = 1; i <= N; i++)
       inputf >> g[i];
    for(int i = 1; i <= N; i++)
       inputf >> t[i];

    inputf.close();

    //CALCOLO
    int res = 0,x;

    res = raccolta_gemme(0);


    //STAMPA RISULTATO
    ofstream outputf("output.txt");

    outputf << res;

    outputf.close();

    return 0;
}

