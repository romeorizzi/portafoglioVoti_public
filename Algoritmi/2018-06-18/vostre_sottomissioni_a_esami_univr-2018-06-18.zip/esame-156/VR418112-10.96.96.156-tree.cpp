#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

vector<int> tree;
vector<int> saw;
vector<int> convertedTree;
int t_length;

//int ric(int node, int pos, int count){
//    if (node == 0) return count+1;  // tutti i precedenti piu` me stesso
//    return ric(tree[pos+1], pos+1, count+node+1);
//}

int ric(int pos, int count, int salta)
{
    int node = tree[pos];
    // manca decrementare il valore di salta
    if(pos == t_length-1) return count;
    if(node == 0) return ric(pos-1, count + 1, salta+1);
    if(salta > 0)
    {
        pos += salta;
        salta = 0;
    }
    if(saw[pos])
    {
        cout << "Saw pos: " << pos << " of value: " << node << "\n\t New Count: " << count << "\n";

        return ric(pos+1, count, salta);
    }
    else
    {
        cout << "Never saw pos: " << pos << " of value: " << node << "\n\t New Count: " << count+node << " + 1\n";

        saw[pos] = true;
        return ric(pos+1, count + node + 1, salta);
    }
}

void convTypeOne()
{
    saw.resize(t_length);
    //cout << convertedTree[0] << " ";
    //cout << "Counting: \n";
    //cout << ric(0,0,0);
    
    for(int i = 1; i < t_length; i++){
        std::fill(saw.begin(), saw.end(), 0);
        //memset(saw, 0,sizeof(saw[0])*t_length);
        // per ogni nodo, conto i figli
        cout << ric(tree[i-1], i-1, 0, 0) << " ";
        //convertedTree[i] = ric(tree[i-1], i-1, 0);
        //out << convertedTree[i] << " ";
    }
}

void convTypeTwo()
{

}

int main()
{
    int type, element, i;
    in >> type;
    tree.resize(1000000);

    i = 0;
    while(in >> element)
    {
        tree[i] = element;
        i++;
    }
    t_length = i+1;
    convertedTree.resize(t_length);
    if (type == 1)
    {
        convertedTree[0] = 2;
        convTypeOne();
    }
    else
    {
        convertedTree[0] = 1;
        convTypeTwo();
    }

    return 0;
}
