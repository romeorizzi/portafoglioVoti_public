#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>


int main() {
//#ifdef EVAL
  //  assert( freopen("input.txt", "r", stdin) );
    //assert( freopen("output.txt", "w", stdout) );
//#endif
    
    FILE *fo = fopen("output.txt", "w");
    FILE *fi = fopen("input.txt", "r"); 
    std::vector<int> array;
   
    int coding = 0;    
    fscanf(fi , "%d " , &coding);
      fprintf(fo, "%d ", coding == 1? 2 : 1);
    

    int reader = 0;
    fscanf(fi , "%d " , &reader); 
    //printf("reader = %d\n", reader);
    
    if(coding == 1){

        int start = reader;
        array.push_back(start);    

        for(int i = 0 ; i < start ;  i++){
            fscanf(fi , "%d " , &reader);
            //printf("reader = %d\n", reader);
            start += reader;        
            array.push_back(reader);
        }

        array[0] = start + 1;
        //printf("Sono arrivato\n");

        for(int i = 1 ; i < array.size() ; i++){
            int limit = array[i];
            int counter = array[i];
                    
           // printf("%d\n", counter);
            for(int j = 1 ; j <= limit ; j++){
                limit += array[i+j];
                counter += array[i+j];
            }
            array[i] = counter+1;
        } 

        for(int i=0 ; i < array.size() ; i++)
            fprintf(fo, "%d ", array[i]);

    } else {
        array.push_back(reader);
        int limit = reader-1;
    
        int i = 0;
        int child = 0;
        while(i < limit){
            fscanf(fi , "%d " , &reader);
            i += reader;
            if(i < limit){
                child++;
                for(int j = 1 ; j < reader ; j++) {
                    fscanf(fi , "%d " , &reader);
                    array.push_back(reader);  
                }
            }                              
        }

        array[0] = child;
        child = 0;
        for(int i = 1 ; i < array.size() ; i++){
            limit = array[i]-1;

            int j = 1;
            while(j+i < limit){
                child++;
                j += array[i+j];                        
            }
            array[i] = child;
            child = 0;
        }

        for(int i=0 ; i < array.size() ; i++)
            fprintf(fo, "%d ", array[i]);
    }
        

/*
    while(!feof(fi)){
        fscanf(fi , "%d" , &reader);    
        array.push_back(reader);          
    }
*/

    
    fclose(fo);

    return 0;
} 
