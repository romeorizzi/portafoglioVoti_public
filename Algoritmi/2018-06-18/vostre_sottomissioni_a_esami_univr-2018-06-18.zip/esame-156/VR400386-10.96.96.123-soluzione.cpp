#include <cstdio>
#include <algorithm>
//#include <iostream>
#include <stdio.h>
//#include <fstream>
//#include <cstdlib>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int tipiui[MAXN]; // tipiui[i] = i + t[i], ovvero il per ogni casella salvo il suo indice e la temibilità del suo troll.
int max_sum_g[MAXN];

int main() { 
    
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &N);

    for(int i = 0; i < N; i++){
       scanf("%d", &g[i]);
       max_sum_g[i] = g[i];
    }

    for(int i = 0; i < N; i++){
       scanf("%d", &tipiui[i]);
       tipiui[i] += i;

        // Creo una variabile che mi salvi il massimo locale.
        int local_max = 0;

        // Ciclo su tutte le celle prima di quella che sto analizzando.
        for (int b = 0; b < i; b++){
            // Se dalla cella di partenza posso arrivare in questa ed il local_max è più alto dell'attuale lo salvo.
            if (tipiui[b] < i && max_sum_g[b] > local_max)
                    local_max = max_sum_g[b];
        }  

        // Salvo local_max in max_sum_g[a] + le sue gemme
        max_sum_g[i] += local_max;
    }

    int max_abs = *std::max_element(&max_sum_g[0],&max_sum_g[N]);

    printf("%d\n", max_abs);
    
    return 0;
}

