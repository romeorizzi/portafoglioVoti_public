#include<iostream>
#include<fstream>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
int pirellone [600][600];
int verticalButtons[600];
int horizontalButtons[600];
int M,N,B;
int main(){
    in >> M;
    in >> N;
    in >> B;
    bool max = false;
    for (int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            in >> pirellone[i][j];
            if(pirellone[i][j] > max)
                max = true;        
        }    
    }
    if(max){
        for(int i = 0; i < M; i++){
            if(pirellone[i][0]>=1){
                verticalButtons[i]+=1;
                for(int j = 0; j < N; j++){
                    pirellone[i][j] = (pirellone[i][j] + 1)%B;                
                }
                if(pirellone[i][0]>=1)
                    i--;            
            }    
       }
       
       for(int i = 0; i < N; i++ ){
            if(pirellone[0][i] >= 1){
                horizontalButtons[i]+=1;
                for(int j = 0; j < M; j++){
                    pirellone[j][i]=(pirellone[j][i]+1)%B;                
                }
                if(pirellone[0][i] >= 1)
                    i--;            
            } 
       }
       
       int sum = 0;
       for(int i = 0; i < M; i++){
            for(int j = 0; j < N; j++){
                sum+=pirellone[i][j];
            }        
       }
       if(sum == 0){
            for(int i = 0; i < M; i++){
                out << verticalButtons[i]<<" ";            
            }
            out << endl;
            for(int i = 0; i < N; i++){
                out << horizontalButtons[i]<<" ";
            }        
        }
        else{
            for(int i = 0; i < M; i++){
                out << 0;            
            }
            out << endl;
            for(int i = 0; i < N; i++){
                out << 0;
            }        
        }
    }
    else{
         for(int i = 0; i < M; i++){
            out << 0;
         }
         out << endl;
         for(int i = 0; i < N; i++){
            out << 0;
         }
    }
    return 0;
}































