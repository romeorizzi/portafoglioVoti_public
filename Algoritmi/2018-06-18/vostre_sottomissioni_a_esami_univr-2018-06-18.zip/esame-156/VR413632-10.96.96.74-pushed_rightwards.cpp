#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int gemme[100000];
int troll[100000];
int sum[100000];
fstream fin;
fstream fout;


 int main(){

     fin.open("input.txt",ios::in);
     fout.open("output.txt",ios::out);
    int N;
     fin>>N;
     for(int i=0;i<N;i++){
         fin>>gemme[i];
     }
     for(int i=0;i<N;i++){
         fin>>troll[i];
     }

     int result=0;

     for(int i=N;i>=0;i--){
         sum[i]=gemme[i];
         if(troll[i]+i+1<N){
             sum[i]+=sum[troll[i]+i+1];
         }
         if(sum[i]>result){
             result=sum[i];
         }
     }
     fout<<result;
    fin.close();
    fout.close();


     return 0;

 }