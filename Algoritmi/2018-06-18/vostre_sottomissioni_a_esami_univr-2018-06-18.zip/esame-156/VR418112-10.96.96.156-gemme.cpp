#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

vector<int> gemme;
vector<int> troll;

vector<int> supporto;

int maxGemme(int pos, int max, int n){
    if (pos == n) return max;
    if(troll[pos] == 0){
        return maxGemme(pos+1,max + gemme[pos], n);
    }
    else{
        int a = maxGemme(pos+1,max, n);
        int j = pos + troll[pos] + 1;
        int b = maxGemme(pos+j,max + gemme[pos], n);
        if (a > b){
            return a;
        }
        else{
            return b;
        }
    }
}
int argmax(vector<int> supporto, int from, int to){
    int max = 0;
    int arg = 0;
    for(int i = from; i < to; i++){
        if(supporto[i] > max){
            max = supporto[i];
            arg = i;
        }
    }
    return arg;
}
int main()
{
    int n, tmp, j;
    in >> n;
    gemme.resize(n+1);
    troll.resize(n+1);
    supporto.resize(n+1);

    for(int i = 1; i < n; i++){
        in >> tmp;
        gemme[i] = tmp;
    }
    for(int i = 1; i < n; i++){
        in >> tmp;
        troll[i] = tmp;
    }

    for(int i = n; i > 0; i--){
        int j = i;
        int cumsum = 0;
        while(j > 0){
            cumsum += gemme[j];
            j = j -1 -troll[j];
        }
        supporto[i] = cumsum;
    }
    
    int gemmeTot = 0;
    int max = argmax(supporto,0, supporto.size());
    for(int i = 0; i < n; i++){
        gemmeTot += gemme[max];
        max = argmax(supporto,0, max);
    }
    /*
    int maxGemme = 0;
    for(int i = 1; i < n; i++){
        if(troll[i] == 0){
           maxGemme += gemme[i];
        }
        else{
            maxGemme += gemme[i];
            j = i + troll[i] + 1;    // maggiore, non maggiore uguale
            i = j;
        }
    }
    */
    //int gemmeTot = maxGemme(0,0,n);
    cout << gemmeTot;
    return 0;
}
