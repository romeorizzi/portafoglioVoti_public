#include <fstream>
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstring>

using namespace std;

//ifstream in("input.txt");
//ofstream out("output.txt");

vector<int> gemme;
vector<int> troll;

vector<int> supporto;

int getMaxGems(int currEl, int n){
    if(currEl > n) return 0;
    if(supporto[currEl] != 0)
        return supporto[currEl];
    supporto[currEl] += getMaxGems(currEl+troll[currEl]+1,n) + gemme[currEl];
    return supporto[currEl];
}

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");

    int n, tmp;
    int gemmeTot = 0;
    in >> n;
    gemme.resize(n+1);
    troll.resize(n+1);
    supporto.resize(n+1);

    for(int i = 1; i < n+1; i++){
        in >> tmp;
        gemme[i] = tmp;
    }
    for(int i = 1; i < n+1; i++){
        in >> tmp;
        troll[i] = tmp;
    }
    
    for(int i =1; i <n+1; i++){
        int m = getMaxGems(i, n);
        if(m >= gemmeTot)
            gemmeTot = m;

    }
    out << gemmeTot;
    return 0;
}

