
#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000
using namespace std;

int N;
int gemme[MAXN+1]; // gemme[i] = numero celle in cella i-esima.
int t[MAXN+1]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN+1];

int max_gems(int from){


    if(from <=N){
        if(max_sum_g[from] != 0)
            return max_sum_g[from];

        max_sum_g[from] += max_gems(from + t[from] + 1) + gemme[from];
        return max_sum_g[from];
    }
    return 0;


}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    assert(N>0);

    for(int i = 1; i <= N; i++)
       scanf("%d", &gemme[i]);
    for(int i = 1; i <= N; i++){
       scanf("%d", &t[i]);
    }

    int maxr = -1;
    int result = -1;


    for(int i=1; i<=N; i++){
        result = max_gems(i);
        if(result > maxr){
            maxr = result;
        }
    }


    printf("%d\n", maxr);

    return 0;
}


