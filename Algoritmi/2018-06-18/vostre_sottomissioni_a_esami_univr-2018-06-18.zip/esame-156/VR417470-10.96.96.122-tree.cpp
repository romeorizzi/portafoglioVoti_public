#include <cstdio>
#include <cassert>
#include <vector>

using std::vector;

vector<int> read;

vector<int> nodi[1000000];
vector<int> soluzione;

int uno_to_due(int i);
void stampa(int i);

int main() {
    int tipo_albero;

    assert( freopen("input.txt", "r", stdin) );
    //assert( freopen("output.txt", "w", stdout) );

    scanf("%d ", &tipo_albero);
    
    if(tipo_albero == 1) {
        int temp, root;
        scanf("%d ", &root);
        read.push_back(root);
        for(int i = 0; i < root; i++) {
            scanf("%d ", &temp);
            read.push_back(temp);
            root += temp;
        }

        for(auto a : read)
            printf("%d ", a);
        printf("\n");
        int count;
        for(int j = 0; j < read.size(); j++) {
            count = 0;
            root = read[j];
            for(int i = j+1; i <= j+root; i++) {
                temp = read[i];
                root += temp;        
                if(count == 0) {
                    nodi[j].push_back(i);
                    count += temp;
                }
                else if(count != 0 && read[i] != 0) {
                    count += temp-1;
                } else if(read[i] == 0 && count != 0) {
                    count--;
                }
            }
        }
        /*
        for(int i = 0; i < read.size(); i++) {
            printf("%d: ", i);
            if(nodi[i].empty())
                printf("vuoto");
            for(int a : nodi[i])
                printf("%d ", a);
            printf("\n");
        }*/
        printf("2 ");
        uno_to_due(0);
        for(auto a : read)
            printf("%d ", a);
    } else {
        int root, temp;
        scanf("%d ", &root);
        read.push_back(root);
        for(int i = 0; i < root-1; i++) {
            scanf("%d ", &temp);
            read.push_back(temp);
        }

        for(int j = 0; j < read.size(); j++) {
            if(read[j] != 1) {
                for(int i = j+1; i < read[j]+j;) {
                    nodi[j].push_back(i);
                    i += read[i];
                }
            }
        }
            /*for(int i = 0; i < read.size(); i++) {
                printf("%d: ", i);
                if(nodi[i].empty())
                    printf("vuoto");
                for(int a : nodi[i])
                    printf("%d ", a);
                printf("\n");
            }*/
            printf("1 ");
            stampa(0);
            
    }
    return 0;
}

int uno_to_due(int n) {
    if(nodi[n].empty()) {
        read[n] = 1;
        return 1;
    }
    read[n] = 0;
    for(int i : nodi[n]) {
        read[n] += uno_to_due(i);
    }
    read[n] += 1;
    return read[n];
}

void stampa(int i) {
    if(nodi[i].empty()) {
       printf("0 ");
        return;
    }
    int size = nodi[i].size();
    //soluzione.push_back(size);*/
    printf("%d ", size);
    for(int n : nodi[i]) {
        stampa(n);
    
    }
    
}
        

