#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero gemme in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

void rightwards(int start){
    int jump = start + t[start] + 1;
    if(jump < N){
        for(int i = jump; i < N; i++){
            int gems_after = max_sum_g[start] + g[i];
            if(gems_after > max_sum_g[i]){
                max_sum_g[i] = gems_after;
                rightwards(i);
            }
        }
    }
}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);
    
    for(int i = 0; i < N; i++)
        max_sum_g[i] = g[0];

    rightwards(0);
    int max = max_sum_g[0];

    for(int i = 1; i < N; i++)
        max = (max < max_sum_g[i])?max_sum_g[i]:max;

    printf("%d", max);
    return 0;
}

