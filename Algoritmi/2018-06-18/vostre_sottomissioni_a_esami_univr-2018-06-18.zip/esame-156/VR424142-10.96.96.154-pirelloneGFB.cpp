#include<iostream>
#include<stdio.h>

using namespace std;

int M,N,B;

void outputUnsolvable() {
    for(int i=0;i<M;i++) {
        //cout << 0 << " ";
        printf("0 ");
    }
    printf("\n");
    for(int j=0;j<N;j++) {
        //cout << 0 << " ";
        printf("0 ");
    }
    //cout << endl;
    printf("\n");
}

void outputSol(int R[], int C[]) {
    for(int i=0;i<M;i++) {
        //cout << R[i] << " ";
        printf("%d ",R[i]);
    }
    //cout << endl;
    printf("\n");
    for(int j=0;j<N;j++) {
        //cout << C[j] << " ";
        printf("%d ",C[j]);
    }
    //cout << endl;
    printf("\n");
} 

int main() {
    #ifdef EVAL
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    
    cin >> M >> N >> B;
    int luci[2][N];
    int R[M];
    int C[N];

    for(int i=0;i<M;i++) {
        R[i] = 0;
    }
    for(int j=0;j<N;j++) {
        C[j] = 0;
    }

    for(int j=0;j<N;j++) {
        cin >> luci[0][j];
    }
    int delta=0;

    for(int i=1;i<M;i++) {
        cin >> luci[1][0];
        delta = (B - (luci[1][0] - luci[0][0])) % B;
        R[i] = delta;
        for(int j=1;j<N;j++) {
            int t;
            cin >> t;
            if((B - (t - luci[0][j])) % B != delta) {
                outputUnsolvable();
                return 0;
            }
            luci[1][j] = t;
        }
    }

    delta=0;
    for(int j=0;j<N;j++) {
        C[j] = (B - luci[0][j]) % B;
    }
    outputSol(R,C);

    return 0;
}