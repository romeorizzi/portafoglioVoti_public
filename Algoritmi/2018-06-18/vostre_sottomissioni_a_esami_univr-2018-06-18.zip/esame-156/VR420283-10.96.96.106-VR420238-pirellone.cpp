/* pirelloneGFB *
   filename: farlocca
   Romeo Rizzi 2005-02-25

   contiene una soluzione farlocca con le seguenti funzionalità:
   1. offre allo studente un meccanismo semplice e fidato per la gestione dell' input/output
   2. quando sottomessa, consente di andare a comprendere il costo in tempo macchina di tale approccio alla lettura dell'input
   3. quando sottomessa, consente di farsi una mappa precisa di quali istanze siano non risolvibili
   4. consente di monitorare che le varie assunzioni e limiti sulle istanze siano tutti rispettati. 
*/

#include <cassert>
#include <cstdio>
#include <cstdlib>

// #define EVAL // define EVAL to input/output from file also in local

const int MaxM = 600;
const int MaxN = 600;

int P[MaxM][MaxN];     // Luci del Pirellone
int M, N, B;
int riga[MaxM];
int colonna[MaxN];

void interruttore_riga(int r, int volte){
    for(int v =0; v<volte; v++){
        for(int j=0; j<N; j++){
            P[r][j] = (P[r][j]+1) % B;
        }
    }
    riga[r]=volte;
}

void interruttore_colonna(int c, int volte){
    for(int v =0; v<volte; v++){
        for(int i=0; i<M; i++){
            P[i][c] = (P[i][c]+1) % B;
        }
    }
    colonna[c] = volte;
}

void risolvi(){
    for(int i=0; i<M; i++){
        riga[i]=0;
    }
    for(int j=0; j<N; j++){
        colonna[j]=0;
    }

    for(int i=0; i<M; i++){ //scorro sulle righe del pirellone
        int val = P[i][0];
        if(val!=0){
             interruttore_riga(i, (B-val)%B);
        }
    }
    for(int j=0; j<N; j++){ //scorro quindi sulle colonne
        int val = P[0][j];
        if(val!=0){
            interruttore_colonna(j, (B-val)%B); //agisco sull'interruttore di colonna finchè non spengo tutto
            val = P[0][j];
        }
    }
    //A questo punto se la matrice rimanente non ha tutto spento allora è non risolvibile
    bool risolvibile=true;
    for(int i=0; i<M; i++){
        for(int j=0; j<N; j++){
            if(P[i][j]!=0){
                risolvibile = false;
            }
        }
    }
    if(risolvibile){ //RISOLVIBILE
        for(int i=0; i<M; i++){ //stampo le righe
            printf("%d ", riga[i]);
        }
        printf("\n");
        for(int j=0; j<N; j++){ //stampo le righe
            printf("%d ", colonna[j]);
        }
    }else{ //NON RISOLVIBILE
        for(int i=0; i<M; i++){ //stampo le righe
            printf("%d ", 0);
        }
        printf("\n");
        for(int j=0; j<N; j++){ //stampo le righe
            printf("%d ", 0);
        }
    }
}

int main(int argc, char *argv[]) {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
  if( scanf("%d %d %d", &M, &N, &B) != 3 )  return 1;
  assert( 1 <= M && M <= MaxM );
  assert( 1 <= N && N <= MaxN );
  assert( 2 <= B && B <= 10 );
  
  int non_zero_row = -1;
  for(int i = 0 ; i < M ; i++ )
    for(int j = 0 ; j < N ; j++ ) {
      if( scanf("%d", &P[i][j] ) != 1 )
	return 1;
      if( P[i][j] )
	non_zero_row = i;
    }
  assert ( non_zero_row >= 0 );  // verifica l'assunzione del testo che almeno una luce sia accesa.


  /* Risoluzione */
  risolvi();
  return 0;
}
