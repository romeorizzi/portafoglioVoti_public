#include <cstdio>

int MAX = 100000;
int N;
int max_somma[100001];
int t[100001];
int gemme[100001];

int massimoGemme(int from){
    if (from <= N){
        if(max_somma[from] !=0)
            return max_somma[from];
        max_somma[from] = max_somma[from] + gemme [from] + massimoGemme(from +t[from] +1);
        return max_somma[from];
    }
    return 0;
}

int main(){

    int max = -1;
    int res = -1;
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &N);

    for (int i=1;i<=N;i++)
        scanf("%d", &gemme[i]);
    for (int i=1;i<=N;i++)
        scanf("%d", &t[i]);
    
    for (int i=1;i<=N;i++){
        res = massimoGemme(i);
        if(res > max)
            max =res;
    }
    
    printf("%d",max);


}
