
#include <cassert>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <cstdlib>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
int pirellone[600][600];
int pulsantiverticali[600];
int pulsantiorizzontali[600];
int M,N,B;

int main(){
    in >> M;
    in >> N;
    in >> B;

    bool max = false;

    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            in >> pirellone[i][j];
            if(pirellone[i][j] > max)
            max = true;

        }

    }

    if(max){
        for(int i = 0; i < M ; i++){
            if(pirellone[i][0]>=1){
                pulsantiverticali[i] +=1;
                for(int j =0; j < N; j++){
                    pirellone[i][j] += (pirellone[i][j] +1)%B;

                }
                if(pirellone[i][0] >=1)
                    i--;

            }

        }

        for(int i = 0; i < N ; i++){
            if(pirellone[0][i]>=1){
                pulsantiorizzontali[i] +=1;
                for(int j =0; j < N; j++){
                    pirellone[i][j] += (pirellone[i][j] +1)%B;

                }
                if(pirellone[0][i] >=1)
                    i--;

            }

        }



    int sum = 0;

    for(int i = 0; i < N ; i++){
        for(int j =0; j <N; j++){
            sum+=pirellone[i][j];
        }

    }
    if(sum == 0){
        for(int i = 0; i < M; i++){
            out << pulsantiverticali[i]<<" ";
        }
        out << endl;
        for(int i = 0; i < N; i++){
            out << pulsantiorizzontali[i]<<" ";
        }


    }else{
        for(int i = 0; i < M; i++){
            out << 0;
        }
        out << endl;
        for(int i = 0; i < N; i++){
            out << 0;
        }



    }
    }else{

        for(int i = 0; i < M; i++){
            out << 0;
        }
        out << endl;
        for(int i = 0; i < N; i++){
            out << 0;
        }

    }
    return 0;



}
