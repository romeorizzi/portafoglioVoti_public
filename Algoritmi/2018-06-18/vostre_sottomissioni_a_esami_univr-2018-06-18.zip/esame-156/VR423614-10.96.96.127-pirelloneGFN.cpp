#include <cstdio>

const int MaxM = 500;
const int MaxN = 500;
int pirellone[MaxM][MaxN];
int M, N, B;

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d %d %d", &M, &N, &B);
    
    
    int non_zero_row = -1;
    for(int i = 0 ; i < M ; i++ )
        for(int j = 0 ; j < N ; j++ ) {
            scanf("%d", &pirellone[i][j]);
            if( pirellone[i][j] )
	        non_zero_row = i;
        }
    if(non_zero_row <= 0) return 1;

    int row [M] , col[N];
    for(int j =0; j<N;j++)
        col[j] = pirellone[0][j];
    
    row[0]=0;
    for(int j =1; j<M;j++)
        row[j] = pirellone[j][0] ^ col[0];

    int ok=1;
    for(int i=0;i<M;i++)
        for(int j=0;j<N;j++)
            if(pirellone[i][j] ^ col[j] ^ row[i])
                ok=0;

    if(ok==1){
        
        for(int i=0; i<M; i++)
            printf("%d ", row[i]);
        printf("\n");
        for(int i=0; i<N; i++)
            printf("%d ", col[i]);
    }
    else{
        for(int i=0; i<M; i++)
            printf("0 ");
        printf("\n");
        for(int i=0; i<N; i++)
            printf("0 ");
    }

    return 0;


}
