#include <iostream>
#include <cstdio>
#include <vector>

int codifica;
std::vector<int> A;


int main(){


    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    std::cin>>codifica;

    if(codifica==1){
        int c = 1;

        for(int i=0; i<c ; i++){
            int temp;
            std::cin>>temp;
            A.push_back(temp);

            c += temp;
        }

        std::cout<<"2 ";

        for(int i=0; i<A.size();i++){
            int c = 1;

            int j=i;

            for(int k=1; k<c; k++){
                c += A[j];
                j++;
            }

            std::cout<< c << " ";
        }

        printf("\n");
        
    }else{
        int num;
        std::cin>>num;
        int temp;
        A.push_back(num);

        for(int i=1; i<num;i++){
            std::cin>>temp;

            A.push_back(temp);
        }

         std::cout<<"1 ";

        for(int i=0; i<A.size();i++){
            int c = A[i] - 1;

            int j=i+1;

            int f = 0;

            while( c>0){
                c -= A[j];
                f++;
                j+=A[j]; 
            }

            std::cout<< f << " ";
        }

        printf("\n");
    }


    return 0;

}