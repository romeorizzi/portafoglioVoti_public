#include <cstdio>
#include <cassert>
int main(){


    #ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
    #endif


    int M;
    scanf("%d", &M);

    int gemme[M];
    int tem[M];
    int mass[M];

    for(int i = 0; i < M; i++)
       scanf("%d", &gemme[i]);
    for(int i = 0; i < M; i++)
       scanf("%d", &tem[i]);

    mass[M-1] = gemme[M-1];
    for(int i=M-2; i>=0; i--){
        if (i+tem[i]+1<M){
            if(mass[i+tem[i]+1]+gemme[i]>mass[i+1]){
                mass[i]=mass[i+tem[i]+1]+gemme[i];
            }
            else {
                mass[i]=mass[i+1];
                }
        }
        else {
            if (gemme[i]>mass[i+1]){
                mass[i]=gemme[i];
            }
            else {
                mass[i]=mass[i+1];
               }
        }
    }
    if (M==1){
        printf("%d", gemme[0]);
    } else{
        printf("%d", gemme[0]+mass[tem[0]+1]);
    }
}


