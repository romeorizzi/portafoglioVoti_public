#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define N 100000

//a array con gemme
//b array con troll
//c array con il massimo ottenibile da quel punto in poi (progressivo)

int a[N];
int b[N];
int c[N];

int main()
{
    //variabile usata per leggere da file
    int tmp;

    //dimensione degli array (letto da file)
    int n;

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &n);

    //lettura dell'array con le gemme
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &tmp);
        a[i] = tmp;
    }
    
    //lettura dell'array con i livelli dei troll
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &tmp);
        b[i] = tmp;
    }

    //il massimo ottenibile nell'ultima cella è il valore delle gemme nell'ultima cella
    c[n-1] = a[n-1];

    //per tutte le altre celle fino a 0 (escluso):
    for (int i = n-2; i>0; i--)
    {
        // calcolo l'eventuale nuovo indice minimo in cui finirei scappando dal troll
        // (controllo inserito per evitare casi particolari, dopo l'ennesimo risultato a 0)
        int newindex = i + b[i] + 1;
        if (newindex > N)
        {
            //se finissi fuori da ogni limite, il massimo ottenibile, è nuovamente solo il valore della cella in considerazione
            c[i] = a[i];
        }
        else
        {
            //altrimenti è il valore della cella in considerazione SOMMATO al valore massimo che potrò ottenere una volta scappato
            //salvato nella cella dell'array c in cui capiterò
            c[i] = a[i] + c[newindex];
        }

        //nel caso questa cella contenga un valore inferiore a celle successive, vuol dire che la scelta migliore è non prendere questa
        //cella ma prendere le successive. Quindi in questo punto il massimo ottenibile è comunque quello delle celle successive
        if (c[i] < c[i+1])
        {
            c[i] = c[i+1];
        }
    }

    //la cella 0 ha il valore delle gemme nella cella 0, più quelle ottenibili dopo la fuga.
    //la differenza è che qui nel caso mi convenga prendere celle successive, non mi è possibile, dal momento che la prima cella è d'obbligo
    c[0] = a[0] + c[b[0] + 1];

    //la soluzione è stivata direttamente nella prima cella dell'array c
    printf("%d\n", c[0]);
    return 0;
}
