/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

int result[1000];

int fn(int n){

    if(n>=N) return 0;
    if(result[n]!= -1){
        return result[n];
    }
return result[n] = g[n]+fn(n+1+t[n]);

}

int main() {
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);

    for(int i=0;i<N;i++)
        result[i]=-1;
    for(int i=N;i>0;i--){
    fn(i-1);
    }

int max=0;
    for(int i=0;i<N;i++)
    {
        if(max<result[i])
        {
            max=result[i];
    }
}
    printf("%d", max);
    return 0;
}
