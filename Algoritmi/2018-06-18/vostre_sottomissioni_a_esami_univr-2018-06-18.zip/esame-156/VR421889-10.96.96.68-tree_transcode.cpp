/**
 *  Soluzione  di pushed_rightwards 
 *
 *  Autore: Adriano Tumminelli
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm> 
 
const int MAXN = 1000000;
int T[MAXN];
int N = 0;
int idx = 0;

int readTree1()
{
    int myidx = idx;
    idx++;
    int childs;
    scanf("%d", &childs); //11
    N++;

    T[myidx] = 1;

     
    for(int i = 0; i < childs; i++)
    {
        T[myidx] += readTree1();
    }

    return T[myidx];
     
}

int readTree2( )
{
    int myidx = idx;
    idx++;
    int val;
    scanf("%d", &val); //11
    N++;
    
    if(val == 1)
    {
        T[myidx] = 0;
        return 1;
    }
    else
    {
        int count = 0;
        int n = 0;
        while(count < val - 1)
        { 
            count += readTree2();
            T[myidx]++; 
        }
        return val;
    }
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    int type;
    scanf("%d", &type);


    if(type == 1)
    {
        readTree1();
        printf("2 ");
        for(int i = 0; i < N; i++)
        {
            printf("%d ", T[i]);
        }

    }
    else
    { 
        readTree2();
        printf("1 ");
        for(int i = 0; i < N; i++)
        {
            printf("%d ", T[i]);
        }

    }
    
    return 0;
}

