/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

int max(int x){
    if (x <= N){
        if(max_sum_g[x] != 0)
            return max_sum_g[x];

        max_sum_g[x] += max(x+t[x]+1) + g[x];
        return max_sum_g[x];
    }
    return 0;
}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    assert(N > 0);

    for(int i = 0; i < N; i++){
        g[i] = 0;
        t[i] = 0;
    }

    for(int i = 1; i <= N; i++){
        scanf("%d", &g[i]);
    }

    for(int i = 1; i <= N; i++){
        scanf("%d", &t[i]);
    }


    int res = -1;
    int tot = -1;
    for (int i = 1; i <= N; i++){
            res = max(i);
            if(res > tot)
                tot = res;
    }
        printf("%d\n", tot);
    
    
    return 0;
}

