#include<bits/stdc++.h>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

#define MAX_N 5000
#define MAX_M 5000
#define MAX_B 10

int M,N,B;
//M: righe
//N: colonne




int main(){

    in >> M >> N >> B;

    bool possibile = true;

    int prec[N];
    int attu[N];

    int solM[M];
    int solN[N];
    for(int i=0;i<MAX_N;i++){
        solM[M]=0;
        solN[N]=0;
    }

    int distPrimaCol = 0;

    //prima riga
    for(int j=0; j<N; j++){
        in >> attu[j];

        int k=0;
        for(k=0;k<MAX_B;k++){
            if((attu[j]+k)%B==0){
                break;
            }
        }
        if(j==0)
            distPrimaCol = k;
        solN[j]=k;
    }

    solM[0]=0;
    for(int i=1;i<M && possibile;i++){
        
        int dis = -1;
        for(int j=0; j<N && possibile; j++){
            prec[j]=attu[j];
            in >> attu[j];

            //calcolo la distanza
            if(j==0){
                for(int k=0;k<MAX_B;k++){
                    if((prec[j]+k)%B==attu[j]){
                        dis = k;
                        break;
                    }
                }
            //se la distanza non e rispettata nelle altre colonne
            } else if (j>0){
                if((prec[j]+dis)%B!=attu[j])
                    possibile = false;
            }

            //se "valido" guardo la mossa da fare:
            if(j==0){
                int k=0;
                for(k=0;k<MAX_B;k++){
                    if((attu[j]+k+distPrimaCol)%B==0){
                        break;
                    }
                }
                solM[i]=k;
            }

        }

    }

    if(!possibile){
        //cout << "scartato"<<endl;
        for(int j=0; j<M; j++){
            out<<"0 ";
        }
        out<<"\n";
        for(int j=0; j<N; j++){
            out<<"0 ";
        }
        out<<"\n";
    } else {
        //cout << "valido"<<endl;
        for(int j=0; j<M; j++){
            out<<solM[j]<<" ";
        }
        out<<"\n";
        for(int j=0; j<N; j++){
            out<<solN[j]<<" ";
        }
        out<<"\n";
    }
    
    
    //for(int i=0;i<M;i++){for(int j=0; j<N; j++){cout << d[i][j];}cout << "\n";}


    return 0;
}