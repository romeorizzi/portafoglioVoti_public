#include <cassert>
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <fstream>

#include <vector>

#define MAXN 1000000

int array[MAXN];

int print[MAXN];

using namespace std;

vector<int> vec;
/*
void recursive_read() {
    
    int local_value = 1;
    
    if ( value == 0 ){
        print[pos] = 1;
        return 1;
    }    

    int Q;
    scanf("%d", &Q);
    vec.push_back(Q);   
    for (unsigned int k = 0; k < Q; k++ )
        recursive_read();

    
    print
    
}
*/

int elements_value;

int general_position = 0;

int to2 () {

    int this_node_value = 1;

   int a;
   scanf("%d", &a);

    // Se sono a zero
    if ( a == 0 ){
        //cout << "Ho appena letto uno zero" << endl;
        print[general_position] = 1;
        //cout << "Ho appena salvato in print[" << general_position << "] un 1" << endl;
        general_position++;
        //cout << "Ho appena incrementato general_position di 1" << endl;
        return 1;
    }
    else {

        //cout << "Ho appena letto a:" << a << endl;
        int this_position = general_position;
        //cout << "La posizione di value:" << a << " è " << this_position << endl;
        general_position++;
        for ( int j = 0; j < a; j++ ){
            this_node_value += to2();
        }
        //cout << "La posizione di value:" << a << " è " << this_position << endl;
        print[this_position] = this_node_value;
        //cout << "Ho appena salvato in print[" << this_position << "]:" << this_node_value << endl;
        return this_node_value;
    }

}

int to1 () {

   int this_node_loss = -1;

   int a;
   scanf("%d", &a);

    if (general_position == 0)
        elements_value = a;

    // Se sono a uno
    if ( a == 1 ){
        cout << "Ho appena letto un uno" << endl;
        print[general_position] = 0;
        cout << "Ho appena salvato in print[" << general_position << "] uno 0" << endl;
        general_position++;
        cout << "Ho appena incrementato general_position di 1" << endl;
        return -1;
    }
    else {

        cout << "Ho appena letto a:" << a << endl;
        int this_position = general_position;
        cout << "La posizione di value:" << a << " è " << this_position << endl;
        general_position++;
        for ( int j = 0; j < a; j++ ){
            a += to1();            
            //this_node_loss += to1();
            //a -=
        }
        cout << "La posizione di value:" << a << " è " << this_position << endl;
        print[this_position] = this_node_loss;
        cout << "Ho appena salvato in print[" << this_position << "]:" << this_node_loss << endl;
        return this_node_loss;
    }
}

int main() {
    
    freopen("input.txt", "r", stdin);

    int tree_version;

    //input >> tree_version;

    scanf("%d", &tree_version);

    //cout << "Versione albero:" << tree_version <<  endl;

    // Se è 1 vado da 1 a due, altrimenti è l'opposto.

    if ( tree_version == 1 ) {

        int root;

        
        //input >> root;
        //scanf("%d", &root);

        to2 ();

        freopen("output.txt", "w", stdout);

        printf("2 ");

        for (int i = 0; i < print[0]; i++){
            printf("%d ", print[i]);        
        }

        printf("\n");
        

        /*
        recursive_read();

        for(int j = 0; j < vec.size(); j++)
            cout << "vec(" << j << "):" << vec.at(j) << endl; 
        */
    }

    else {
    
        int root;

        

        
        //input >> root;
        //scanf("%d", &root);

        to1 ();

        freopen("output.txt", "w", stdout);

        printf("1 ");

        for (int i = 0; i < elements_value; i++){
            printf("%d ", print[i]);        
        }

        printf("\n");




    }






}
