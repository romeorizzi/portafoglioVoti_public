/* pirelloneGFB *
   filename: farlocca
   Romeo Rizzi 2005-02-25

   contiene una soluzione farlocca con le seguenti funzionalità:
   1. offre allo studente un meccanismo semplice e fidato per la gestione dell' input/output
   2. quando sottomessa, consente di andare a comprendere il costo in tempo macchina di tale approccio alla lettura dell'input
   3. quando sottomessa, consente di farsi una mappa precisa di quali istanze siano non risolvibili
   4. consente di monitorare che le varie assunzioni e limiti sulle istanze siano tutti rispettati. 
*/

#include <cassert>
#include <cstdio>
#include <cstdlib>

// #define EVAL // define EVAL to input/output from file also in local

const int MaxM = 800;
const int MaxN = 800;

int P[MaxM][MaxN];     // Luci del Pirellone
int M, N, B;

int rows[MaxM];
int cols[MaxN];

void SwapRow(int r)
{ 
  int swaps = (B - P[r][0]) % B;
  rows[r] = swaps;
  
  if(swaps == 0)
    return;

  for(int c = 0; c < N; c++)
  {
    P[r][c] = ( P[r][c] + swaps) % B;
  }

}

void SwapColumn(int c)
{ 
  int swaps = (B - P[0][c]) % B;
  cols[c] = swaps;

  if(swaps == 0)
    return;

  for(int r = 0; r < M; r++)
  {
    P[r][c] = ( P[r][c] + swaps) % B;
  }

}

int main(int argc, char *argv[]) {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
  if( scanf("%d %d %d", &M, &N, &B) != 3 )  return 1;
  assert( 1 <= M && M <= MaxM );
  assert( 1 <= N && N <= MaxN );
  assert( 2 <= B && B <= 10 );
  
  int non_zero_row = -1;
  for(int i = 0 ; i < M ; i++ )
    for(int j = 0 ; j < N ; j++ ) {
      int val;
      if( scanf("%d", &val) != 1 )
	      return 1;
      P[i][j] = val;
      if( P[i][j] )
	      non_zero_row = i;
    }
  assert ( non_zero_row >= 0 );  // verifica l'assunzione del testo che almeno una luce sia accesa.


  for(int c = 0; c < N; c++)
  {
    SwapColumn(c);
  }


  // Risoluzione
  for(int r = 1; r < M; r++)
  { 
    SwapRow(r); 
  }

  
  for(int r = 0; r < M; r++)  
  for(int c = 0; c < N; c++)
  {
    if(P[r][c] != 0)
    {
       printf("0");
      for(int i=1; i < M; i++)
        printf(" 0");
      printf("\n");
      printf("0");
      for(int j=1; j < N; j++)
        printf(" 0");
      printf("\n");

      return 0;
    }

  }
   
   
   
   
  printf("%i", rows[0]);
  for(int i=1; i < M; i++)
    printf(" %i", rows[i]);

  printf("\n");

  printf("%i", cols[0]);
  for(int j=1; j < N; j++)
    printf(" %i", cols[j]);

  printf("\n");

  /* Risoluzione farlocca (assume che tutte le istanze siano non risolvibili) */
/*
  printf("0");
  for(int i=1; i < M; i++)
    printf(" 0");
  printf("\n");
  printf("0");
  for(int j=1; j < N; j++)
    printf(" 0");
  printf("\n");
*/
  return 0;
}
