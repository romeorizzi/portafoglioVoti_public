/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>
#include <iostream>
#define MAXN 1000000
using namespace std;

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

int calcolo_gemme(int i){
int res=0;

 if(max_sum_g[i]!=0)
  return max_sum_g[i]; 

 if(i==0){
   //cout<<"caso base"<<endl;
   //cout<<"res: "<< g[i];
   max_sum_g[i]= g[i];
   return g[i];
 }
 else {
   //cout<<"caso ric"<<endl;
   int salto= t[i]+1;
   if(i-salto<0){
     //cout<<"caso ric supero limite"<<endl;
     res=g[i];
     max_sum_g[i]=res;
   }
   else { 
    res=calcolo_gemme(i-salto) + g[i];
   // cout<<"res: "<< res<<endl;
    max_sum_g[i]=res;
  }
 }

return res;
}

int main() {
 //assert( freopen("input0.txt", "r", stdin) );
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);

    int res=0,r_tmp=0;
    for(int i=N-1;i>=0; i--) {
        r_tmp=calcolo_gemme(i);
        if(r_tmp>res)
          res=r_tmp;
     //cout<<"---------------"<<endl;
    }
    
    printf("%d\n", res); // giusto ad esempio quando non ci sono gemme 
    
    return 0;
}

