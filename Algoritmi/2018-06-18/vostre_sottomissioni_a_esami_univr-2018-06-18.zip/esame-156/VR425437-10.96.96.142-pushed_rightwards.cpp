/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

int solve(int n) {
    if(n>=N) {
        return 0;
    }
    if(n==N-1) {
        return g[n];
    }
    if(max_sum_g[n] != -1) {
        return max_sum_g[n];
    }

    int prendi = g[n] + solve(n + t[n] + 1);
    max_sum_g[n] = std::max(solve(n+1),  prendi);
    return max_sum_g[n];
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);
    
    for(int i=0 ; i<N ; i++) {
        max_sum_g[i] = -1;
    }
    printf("%d\n", solve(0));
    
    /*
    printf("%d\n", 0); // giusto ad esempio quando non ci sono gemme
    */ 
    
    return 0;
}

