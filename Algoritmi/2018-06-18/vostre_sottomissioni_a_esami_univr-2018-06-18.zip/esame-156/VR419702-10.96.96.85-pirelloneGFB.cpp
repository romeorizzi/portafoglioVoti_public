#include<fstream>
#include<cassert>
#include<iostream>
#include<ctime>
#include<cstdio>
#include<algorithm>
#include<cstdlib>

using namespace std;

#define MAXM 500

int M,N,B;

int GFB[MAXM][MAXM];
int Row[MAXM];
int Col[MAXM];

void Riga(int riga){
    for(int i = 0; i < N; i++){
        GFB[riga][i] = (GFB[riga][i] + 1) % B;
    }
}

void Colonna(int col){
    for(int i = 0; i < M; i++){
        GFB[i][col] = (GFB[i][col] + 1) % B;
    }
}

int main(){
    ifstream r("input2.txt");
    ofstream w("output.txt");
    r >> M;
    r >> N;
    r >> B;
    for (int i = 0; i < M; i++){
        for (int j = 0; j < M; j++){
            r >> GFB[i][j];
        }
    }
    for (int i = 0; i < N; i++){
        if (GFB[0][i] == (B -1)){
            Colonna(i);
            Row[i] = 1;       
        } else
            if (GFB[0][i] == 1 && B == 3){
                Colonna(i);
                Colonna(i);
                Row[i] = 2;
            }
    }
    for (int j = 0; j < M; j++){
        if (GFB[j][0] == (B -1)){
            Riga(j);
            Col[j] = 1;       
        } else
            if (GFB[j][0] == 1 && B == 3){
                Riga(j);
                Riga(j);
                Col[j] = 2;
            }
    }
    int flag = 0;
    for (int i = 0; i < M; i++){
        for (int j = 0; j < N; j++){
            cout << GFB[i][j] << "\t";
        }
        cout << endl;
    }
    for (int i = 0; i < M; i++){
        for (int j = 0; j < N; j++){
            if (GFB[i][j] != 0){
                flag = 1;
                break;
            }
        }
    }
    if (flag == 0){
        for (int i = 0; i < M; i++)
            w << Col[i] << "\t";
        w << endl;
        for (int i = 0; i < N; i++)
            w << Row[i] << "\t";
    } else {
        for (int i = 0; i < M; i++)
            w << 0;
        w << endl;
        for (int i = 0; i < N; i++)
            w << 0;
    }
    return 0;
}
