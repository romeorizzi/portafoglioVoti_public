#include <cassert>
#include <fstream>
using namespace std;

int pirellone[800][800];
int pulsanti_vert[800];
int pulsanti_oriz[800];
int M,N,B;
/*
ifstream in ("input.txt");
ifstream out ("output.txt");
*/
int main(){
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d %d %d", &M, &N, &B);
    bool max = false;
    for(int i = 0; i < M; i++){
        for(int j = 0; j < N; j++){
            scanf("%d", &pirellone[i][j]);
            if (pirellone[i][j]>max){
                max = true;
            }
        }
    }
    if (max){
        for (int i = 0; i< M; i++){
            if (pirellone[i][0]>=1){
                pulsanti_vert[i]+=1;
                for(int j = 0; j < N; j++){
                    pirellone[i][j] =(pirellone[i][j]+1)%B;
                }
                if (pirellone[i][0]>=1){
                    i--;
                }
            }
        }

        for (int i = 0; i< N; i++){
            if (pirellone[0][i]>=1){
                pulsanti_oriz[i]+=1;
                for(int j = 0; j < M; j++){
                    pirellone[j][i] =(pirellone[j][i]+1)%B;
                }
                if (pirellone[0][i]>=1){
                    i--;
                }
            }
        }

        int sum = 0;
        for(int i = 0; i < M; i++){
            for(int j = 0; j < N; j++){
                sum = sum + pirellone[i][j];
            }
        }

        if (sum == 0){
            for(int i = 0; i < M; i++){
                printf("%d ", pulsanti_vert[i]);
            }
            printf("\n");
            for(int i = 0; i < N; i++){
               printf("%d ", pulsanti_oriz[i]);
            }
        } else{
            for(int i = 0; i < M; i++){
                printf("0 ");
            }
            printf("\n");
            for(int i = 0; i < N; i++){
                printf("0 ");
            }
        }
    } else {
        for(int i = 0; i < M; i++){
            printf("0 ");
        }
        printf("\n");
        for(int i = 0; i < N; i++){
            printf("0 ");
        }
    }
}