#include <iostream>
#include <cstdio>

#define NMAX 5000
#define MMAX 5000

int N,M,B;
int** pirellone;
int* righe;
int* colonne;


int main(){

    freopen("input.txt", "r", stdin);
    freopen("output.txt","w",stdout);

    std::cin>>M>>N>>B;
    pirellone= new int*[M];
    for(int i=0; i<M; i++){
        pirellone[i] = new int[N];
    }

    righe = new int[M];
    colonne = new int [N];
    //leggo la prima riga
    for(int j=0; j<N; j++)
        std::cin>>pirellone[0][j];

    int x = 0;
    bool solvable = true;

    for(int i=1; i<M; i++){
        std::cin>>pirellone[i][0];

        x = (B - ( pirellone[i][0] - pirellone[0][0]))%B;
        righe[i] = x;

        for(int j=1; j<N; j++){
            int temp;
            std::cin>>temp;

            if( (B - ( temp - pirellone[0][j])) % B != x ){
                solvable = false;
                break;
            }

            pirellone[i][j] = temp;
        }
    }


    if(solvable){

        for(int j=0; j<N; j++)
            colonne[j] = (B - pirellone[0][j])%B;

        //stampo soluzione
        for(int i=0; i<M; i++){
            std::cout<<righe[i]<<" ";
        }
        printf("\n");

        for(int i=0; i<N; i++){
            std::cout<<colonne[i]<<" ";
        }
    }else{
        //stampo soluzione con 0
        for(int i=0; i<M; i++){
            std::cout<<"0"<<" ";
        }
        printf("\n");

        for(int i=0; i<N; i++){
            std::cout<<"0"<<" ";
        }
    }


    return 0;

}
