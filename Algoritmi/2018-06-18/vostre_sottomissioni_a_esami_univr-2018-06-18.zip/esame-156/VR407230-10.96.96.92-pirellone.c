#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#define MaxM 600
#define MaxN 600

int P[MaxN][MaxM];
int R[MaxN],C[MaxM];
int N, M, B, solvable;

void compriga(int i){
    int j;
    for (j=0; j<M; j++)
        P[i][j] = (P[i][j] + 1) % B;
}

void compcol(int j){
    int i;
    for (i=0; i<N; i++)
        P[i][j] = (P[i][j] + 1) % B;
}
   
int main(int argc, char *argv[]){
    int i, j;
    FILE *in, *out;

    in = fopen("input.txt","r");
    out = fopen("output.txt", "w");

    if ( in == NULL || out == NULL)
        return 1;

    if ( fscanf(in, "%d %d %d", &N, &M, &B) != 3 )
        return 1;

    assert( 1 <= N && N <= MaxN);
    assert( 1 <= M && M <= MaxM);
    assert( 2 <= B && B <= 10 );

    int row = -1;
    for (i=0; i<N; i++)
        for (j=0; j<M; j++){
            if (fscanf(in, "%d", &P[i][j]) != 1)
                return 1;
            if ((P[i][j]))
                row = i;
        }
        assert (row>=0);
    solvable = 1;

    for(i=0; i<N; i++)
        R[i] = 0;
    for(j=0; j<M; j++)
        C[j] = 0;

    for(j=0; j<M; j++)
        if(P[row][j]!=0){
            C[j] = 1;
            compcol(j);
        }

    for (i=0; i<N; i++)
        if(P[i][0]!=0){
            R[i]=1;
            compriga(i);
        }

    for(i=0; i<N; i++)
        for(j=0; j<M; j++)
            if(P[i][j] != 0)
                solvable = 0;

    if(!solvable){
        printf("0");
        for(i=1; i<N; i++)
            printf(" 0");
        printf("\n");
        printf("0");
        for(j=1; j<M; j++)
            printf(" 0");
        printf("\n");
    }else{
        printf("%d",R[0]);
        for(i=1; i<N; i++)
             printf(" %d",R[i]);
        printf("\n");
        printf("%d",C[0]);
        for(j=1; j<M; j++)
            printf(" %d",C[j]);
        printf("\n");
    }

    return 0;
}
