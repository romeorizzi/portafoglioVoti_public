/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero gemme in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN]; // memoizzazione
bool visited[MAXN];
int max_val = 0;


void visita(int i){ // i: indice pos attuale


    if(i >= N)
        return;

    int sum = 0;
    for(int k = i; k < N; k+=t[k]+1){
        // se questa cella non è mai stata visitata, visitala
        if(!visited[k]) {
            visited[k] = true;
            sum += g[k];
            visita(i+1);
        }
        // altrimenti ritorna il max ottenuto visitando quella cella
        else{
            sum += max_sum_g[k];    // qua forse ci va un break
            break;
        }


    }

    max_sum_g[i] = sum;

    if(max_val < sum){
        max_val = sum;
    }

}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);

    for(int i = 0; i < N; i++){
        visited[i] = false;
    }


    visita(0);
    
    printf("%d\n", max_val);


    //printf("%d\n", 0); // giusto ad esempio quando non ci sono gemme
    
    return 0;
}

