#include <cassert>
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <fstream>

#define MAXN 1000000

using namespace std;

int N;

int vet[MAXN];


int main () {
  
  ifstream in("input.txt");
  ofstream out("output.txt");
  
  in >> N;

  reverse(N);
  int tmp = 1;
  //calcolo discendenti
  if(N == 1){
    while(in >> N){    
    in >> N;
        if (N == 0){
            N == 1;
            out << N;          
        }    
        if (N == 1){ 
            tmp += N;            
            N == 2;
            out << N;
        }    
        if (N > 1){
            tmp += N;            
            N == tmp;        
            out << N;    
        }
    } 
  }
  //calcolo figli
  if(N == 2){
    
  }
  return 0;
}

