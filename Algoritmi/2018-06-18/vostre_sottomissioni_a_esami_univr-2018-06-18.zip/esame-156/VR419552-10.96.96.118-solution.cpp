#include <cassert>
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <fstream>

using namespace std;

int pirellone [600][600];
int pv[600];
int po[600];

int m, n, b;

int main () {

    ifstream in("input.txt");
    ofstream out("output.txt");
 
    in >> m;
    in >> n;
    in >> b;
    bool max = false;
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            in >> pirellone[i][j];
            if(pirellone[i][j]>max){
                max=true;
            }        
        }    
    }
    if(max){
        for(int i = 0; i < m; i++){
            if(pirellone[i][0]>=1){
                pv[i]+=1;
                for(int j=0; j<n; j++){
                    pirellone[i][j] =(pirellone[i][j]+1)%b;                
                }  
            if(pirellone[i][0]>=1)
            i--;            
            }           
        }        
        for(int i = 0; i < m; i++){
            if(pirellone[0][i]>=1){
                po[i]+=1;
                for(int j=0; j<n; j++){
                    pirellone[j][i] =(pirellone[j][i]+1)%b;                
                }          
            if(pirellone[i][0]>=1)
            i--;            
            }             
        }    
        int sum=0;
        for(int i = 0; i < m; i++){
            for(int j = 0; j < n; j++){
                sum=sum+pirellone[i][j];
            }      
        }   
        if(sum==0){
            for(int i= 0; i < m; i++){
                out << pv[i] << " ";
            }
            out << endl;
            for(int i= 0; i < n; i++){
                out << po[i] << " ";
            }     
        }
        else{
            for(int i= 0; i < m; i++){
                out << 0;
            }        
            out << endl;
            for(int i= 0; i < n; i++){
                out << 0;
            }
        }
        }
        else{
            for(int i= 0; i < m; i++){
                out << 0;
            }      
            out << endl;
            for(int i= 0; i < n; i++){
                out << 0;
            }           
        }
    return 0;
}
