#include <cstdio>



int main(){
    
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    
    int M, N, B;
    
    scanf("%d %d %d", &M,&N,&B);
    
    int pirellone[M][N];
    
    for(int i=0; i<M; i++){
        for(int j=0; j<N; j++)
            scanf("%d", &pirellone[i][j]);
    }
            
    int row[M], col[N];
    
    for(int j=0; j<N; j++)
        col[j] = pirellone[0][j];
        
    row[0]=0;
    for(int i=0; i<M; i++)
        row[i] = (pirellone[i][0]^col[0]);
    
    
    int ok=1;
    
    for(int i=0; i<M; i++)
        for(int j=0; j<N; j++)
            if(pirellone[i][j]^col[j]^row[i])
                ok=0;
    
    if(ok){
        
        for(int i=0; i<M; i++)
            printf("%d ", row[i]);
        printf("\n");
        for(int j=0; j<N; j++)
            printf("%d ", col[j]);
        
    }       
    
    else{
    
        for(int i=0; i<M; i++)
            printf("0 ");
            
        printf("\n");
        
        for(int j=0; j<N; j++)
            printf("0 ");
    
    }
    
    
    return 0;   
}
