/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */


#include <cassert>
#include <cstdio>
#include <algorithm>

#define MAXN 1000000

using namespace std;

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.

int max_sum_g[MAXN];

int main() {
    int max = 0;
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++)
       scanf("%d", &g[i]);
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);
    
    for(int i = N-1; i >= 0;i--){
        max_sum_g[i] = 0;
    }
    for(int i = N-1; i >= 0;i--){
        max_sum_g[i] = max_sum_g[i] + g[i];
        if(i+t[i]+1 < N){
            
            max_sum_g[i] = max_sum_g[i] + max_sum_g[i+t[i]+1];
        }
    }
    max = 0;
    for(int i = N-1; i >= 0;i--){
        if(max_sum_g[i] > max){
          max = max_sum_g[i];
        }
    }
    printf("%d\n", max); // giusto ad esempio quando non ci sono gemme 
    
    return 0;
}

