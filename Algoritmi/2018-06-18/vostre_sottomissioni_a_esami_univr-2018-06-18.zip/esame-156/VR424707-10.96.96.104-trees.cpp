#include <cstdio>
#include std::vector

next = 0;
vector figli1 [1000]
vector figli2 [1000]

void lettura1(){
    int i= next;
    scanf("%d", &num_f)
    figli1[i].resize(num_f)
    figli2[i].resize(num_f)
    next++;

    for (int j =0; j < n_figli; j++){
        figli[i][j]= prossimo;
        lettura();
    }
}

int main(){

#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    lettura1();
    for (int j =next-1; j >=0; j--){
        for (int k =1; k < figli[j].size; k++){
            figli2[j][k]+=1+figli1[j][k]
    }
