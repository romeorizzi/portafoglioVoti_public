#include<iostream>
#include<stdio.h>
#include<vector>

using namespace std;

void secondToFirst(vector<int> &tree) {
    cout << 1 << " ";
    for(int i=0;i<tree.size();i++) {
        int n = tree[i] - 1;
        int j = i+1;
        int children = 0;
        while(n > 0) {
            n -= tree[j];
            children++;
            j += tree[j];
        }
        cout << children << " ";
    }
    cout << endl;
}

void firstToSecond(vector<int> &tree) {
    cout << 2 << " ";
    for(int i=0;i<tree.size();i++) {
        int toRead = 1;
        int j=i;
        for(int count=0;count<toRead;count++) {
            toRead += tree[j];
            j++;
        }
        cout << toRead << " ";
    }
    cout << endl;
}

int main() {
    #ifdef EVAL
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif

    int type, N;
    vector<int> tree;

    cin >> type;
    if(type == 2) {
        cin >> N;
        tree = vector<int>(N);
        tree[0] = N;
        for(int i=1;i<N;i++) {
            int t;
            cin >> t;
            tree[i] = t;
        }
        secondToFirst(tree);
    } else {
        int toRead = 1;
        for(int i=0;i<toRead;i++) {
            int t;
            cin >> t;
            tree.push_back(t);
            toRead += t;
        }
        N = tree.size();
        firstToSecond(tree);
    }

    return 0;
}