#include<iostream>
#include<fstream>
#include<string>
#include<cstring>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

int N;
int supporto[100001];

int max(int i){
    int sum_max = 0;
    for(int j=i; j<N; j++){if(supporto[j]>sum_max){sum_max = supporto[j];}}
    return sum_max;
}

int main(){
    int gemme[100001];
    in >> N;
    int troll[100001];
    for (int i = 0; i < N; i++){in >> gemme[i];}
    for (int i = 0; i < N; i++){in >> troll[i];}
    for(int i = N - 1; i >= 0; i--){if(i == N-1) {supporto[i] = gemme[i];}else{if ((troll[i] + i + 1)<N){ supporto[i] = max(i + troll[i] + 1) + gemme[i];} else {supporto[i] = gemme[i];}}
    }
    out << max(0);
}
