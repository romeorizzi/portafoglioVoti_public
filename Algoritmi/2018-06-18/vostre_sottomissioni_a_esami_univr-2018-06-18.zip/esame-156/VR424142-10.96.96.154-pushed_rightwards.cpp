#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;

int N;

int ric(vector<int>& G, vector<int>& T, vector<int>& maxG, int i) {
    if(i >= N) {
        return 0;
    } else if(maxG[i] != -1) {
        return maxG[i];
    } else {
        int take = G[i] + ric(G,T,maxG,i+T[i]+1);
        int skip = ric(G,T,maxG,i+1);
        maxG[i] = max(take,skip);
        return maxG[i];
    }
}

int main() {
    #ifdef EVAL
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif

    cin >> N;
    vector<int> G(N), T(N), maxG(N);
    //int G[N], T[N], maxG[N];

    for(int i=0;i<N;i++) {
        maxG[i] = -1;
        cin >> G[i];
    }
    //maxG[N-1] = G[N-1];
    for(int i=0;i<N;i++) {
        cin >> T[i];
    }

    cout << ric(G,T,maxG,0) << endl;

    return 0;
}
