#include <cstdio>

int max_guadagno(int result[], int k, int N){
    int max=0;
    for(int i=k; i<=N; i++){
        if(result[i]>max)
            max = result[i];        
    }
    return max;
}
            
int main(){
    
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    
    int N;
    //leggo N
    scanf("%d", &N);

    int gemme[N+1];
    int troll[N+1];

    //leggo gemme
    for(int i=1; i<=N; i++)
        scanf("%d", &gemme[i]);
        
    //leggo troll
    for(int i=1; i<=N; i++)
        scanf("%d", &troll[i]);
    
    
    //vettore dei risultati massimi
    int result[N+1];
    
    //l'ultima cella ha valore delle gemme che contiene
    //result[N] = gemme[N];
    
    int gemme_future = 0;
    for(int i=N; i>=1; i--){
                
        gemme_future = max_guadagno(result, troll[i]+i+1, N);

        result[i] = gemme[i] + gemme_future;
    
    }
    

    printf("%d", result[1]);

    return 0;
}
