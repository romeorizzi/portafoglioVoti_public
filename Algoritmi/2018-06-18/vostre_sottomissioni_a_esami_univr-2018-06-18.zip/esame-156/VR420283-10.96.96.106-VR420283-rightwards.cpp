/**
 *  Soluzione farlocca di pushed_rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-18
 *
 */

#include <cassert>
#include <cstdio>
#include <algorithm>
using namespace std;

#define MAXN 1000000

int N;
int g[MAXN]; // g[i] = numero celle in cella i-esima.
int t[MAXN]; // t[i] = troll treathening in cella i-esima.
int max_sum_g[MAXN];


int risolvi(int inizio){
    if(inizio==N-1){
        return g[inizio];
    }
    if(inizio>N-1){
        return 0;
    }
    if(max_sum_g[inizio]!=0){ //già calcolato
        return max_sum_g[inizio];
    }else{  //da calcolare
        int ris1 = g[inizio] + risolvi(inizio + t[inizio]+1); //prendo la gemma
        int ris2 = risolvi(inizio+1); //non prendo la gemma
        max_sum_g[inizio] = max(ris1, ris2); //vale la pena prendere la gemma?
        return max_sum_g[inizio];
    }
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 0; i < N; i++){
       scanf("%d", &g[i]);
       max_sum_g[i]=0;
    }
    for(int i = 0; i < N; i++)
       scanf("%d", &t[i]);
    
    //printf("%d\n", 0); // giusto ad esempio quando non ci sono gemme
    
    printf("%d", risolvi(0));
    
    return 0;
}

