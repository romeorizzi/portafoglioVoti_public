#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>

using namespace std;


int main(){

    ifstream in("input.txt");
    ofstream out("output.txt");
    int N,M,A, B;
    int segnaposto, segnaposto1;
    vector<int> vecSoluzione;
    stack<int> pila;
    vector<list<int> > vecGrafo;
    vector<int> vecArchi;
    in >> N >> M >> A >> B;
    int c = A;
    vecGrafo.resize(N + 1);
    vecArchi.resize(M);

    for(int i = 0; i < M; i++){
        in >> segnaposto >> segnaposto1;
        vecArchi[i] = segnaposto + segnaposto1;
        vecGrafo[segnaposto].push_back(i);
        vecGrafo[segnaposto1].push_back(i);
    }

    while(vecSoluzione.size() < M){
        bool viciniCiSono = false;
        for(list<int>::iterator i = vecGrafo[c].begin(); i != vecGrafo[c].end(); i++)
            if(vecArchi[*i] > 0){
                pila.push(c);
                viciniCiSono = true;
                int next = vecArchi[*i] - c;
                vecArchi[*i] = -1;
                vecGrafo[c].remove(*i);
                c = next;
                vecGrafo[c].remove(*i);
                break;
            }
            if(!viciniCiSono){
                vecSoluzione.push_back(c);
                c = pila.top();
                pila.pop();
            }
    }//debug: ricordati di pushare
    vecSoluzione.push_back(A);
    for(int i = vecSoluzione.size() -1; i > 0; i--){
        out << vecSoluzione[i] << " " << vecSoluzione[i-1] << "\n";
    }
return 0;

}

