#include <iostream>
#include <fstream>
#include <vector>

#define MAXN 100000;
#define MAXM 1000000;

using namespace std;

unsigned int N, M, A, B, C;

struct edge{
  int el[2];
  bool seen;
  edge(int a,int b):seen(false){
    el[0]=a; el[1]=b;
  }
};

struct elink{
  int id;
  bool order;
  elink(int _id,bool ord){
    id=_id;
    order=ord;
  }
};

vector<edge> edges;
vector<vector<elink> > graph;
vector<int> result;

void depthFirst(int el);
void printResult();

int main() {

  ifstream in("input.txt");
  in >> N >> M >> A >> B;
  graph.reserve(N);
  A--; B--;
  int c, d;
  for(size_t i=0; i<M; i++) {
    in >> c >> d;
    c--; d--;
    graph[c].push_back( elink(edges.size(),1) );
    graph[d].push_back( elink(edges.size(),0) );
    edges.push_back( edge(c,d) );
  }
  in.close();
  depthFirst(B);
  printResult();
  return 0;
}

void depthFirst(int elk) {
  for(size_t j=0; j<graph[elk].size(); j++) {
     elink e=graph[elk][j];
     if(!edges[e.id].seen) {
        edges[e.id].seen=true;
        depthFirst(edges[e.id].el[e.order]);
     }
  }
  result.push_back(elk);
}

void printResult(){

  ofstream out("output.txt");
  for(size_t i=0; i<result.size()-1; i++)
    out << result[i]+1 << " " << result[i+1]+1 << endl;
  out.close();
}

