#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int M,N,L;
char mappa[1002][1002];

long calcola_percorsi(int riga, int col, int count) {

    if(mappa[riga][col] != '*') {
        return 0;
    }

    if(riga>M || col>N || count > L)
        return 0;

    if(riga==M && col==N)
        return 1;

    return calcola_percorsi(riga+1,col,count+1) + calcola_percorsi(riga,col+1,count+1) + calcola_percorsi(riga+1,col+1,count+1);
}

int main() {
    
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> M >> N >> L;
    
    /*for(int i=0; i<=M; i++) {
        mappa[i][0]='+';
    }

    for(int j=0; j<=N; j++) {
        mappa[0][j]='+';
    }*/

    for(int i=1; i<=M; i++){
        for(int j=1; j<=N; j++) {
            in >> mappa[i][j];   
        }
    }

    long percorsi = calcola_percorsi(1,1,0);

    out << percorsi%1000 << endl;

    return 0;
}
