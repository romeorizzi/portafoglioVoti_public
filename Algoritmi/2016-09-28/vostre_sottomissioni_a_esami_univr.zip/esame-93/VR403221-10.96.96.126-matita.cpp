#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>

#include <iostream>

using namespace std;

int main(){

    //stream di lettura input, output
    ifstream in ("input.txt");
    ofstream out("output.txt");

       //int x, y , z ,w;
        //int temp1;
        //int temp2;
    int N, V, A, B;
    vector<int> sol;
    stack<int> tempS;
    vector<list<int>> graph;
    vector<int> archi;
    
    in >> N >> V >> A >> B;
 

    graph.resize(N + 1);
    

    archi.resize(V);

    int temp1, temp2;

    for(int i = 0; i < V; i++){

    in >> temp1 >> temp2;

    //    graph[temp1].push_back(i);
   // graph[temp2].push_back(i);

    archi[i] = temp1 + temp2;

    graph[temp1].push_back(i);
    graph[temp2].push_back(i);

    }

    int c = A;

    while(sol.size() < V){

        bool hashNeighbour = false;
        //for(i = 0; i < V; i++){
        //}
        for(list<int>::iterator i = graph[c].begin(); i != graph[c].end(); i++)

            if(archi[*i] > 0){
                tempS.push(c);
                hashNeighbour = true;
                
                int next = archi[*i]-c;
                
                archi[*i] = -1;
                
                graph[c].remove(*i);
                c = next;
                graph[c].remove(*i);
                                
                break;
            }
            if(!hashNeighbour){
                
                sol.push_back(c);
                c = tempS.top();
                tempS.pop();
            }

    }//while

    sol.push_back(A);

    for(int i = sol.size() - 1; i > 0; i--)
        out << sol[i] << " " << sol[i - 1] << "\n";

    return 0; 
     
}//main

