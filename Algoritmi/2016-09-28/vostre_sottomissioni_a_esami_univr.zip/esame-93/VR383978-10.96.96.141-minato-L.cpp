#include <iostream>
#include <fstream>

using namespace std;
const int MAXM = 1000;
const int MAXN = 1000;

int M, N, L;
int long count;

char graph[MAXM][MAXN];

void makeamove(int positioni, int positionj, int path);

int main (){

    ifstream in("input.txt");
		ofstream out("output.txt");
    in>>M>>N>>L;
    for(int i=0;i<M;i++)
			for(int j=0;j<N;j++)
				in>>graph[i][j];     
		makeamove(0, 0, 0);
		out<<count % 1000 <<endl;
    return 0;
}

void makeamove(int i, int j, int path){

	if(path>L)return;
	
	if(i==(M-1) && j==(N-1))
	{
		count++;
		return;
	}
	
	int path_a = path;
	int path_b = path;
	int path_c = path;

	if(graph[i+1][j] == '*')
	{
		path_a++;
		makeamove(i+1, j, path_a);
	}
	if(graph[i][j+1] == '*')
	{
		path_b++;
		makeamove(i, j+1, path_b);
	}
	if(graph[i+1][j+1] == '*')
	{
		path_c++;
		makeamove(i+1, j+1, path_c);
	}
}

