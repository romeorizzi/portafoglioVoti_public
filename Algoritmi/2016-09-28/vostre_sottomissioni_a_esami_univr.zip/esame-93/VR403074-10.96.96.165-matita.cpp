#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct elink{
  int id_lato;
  int order;

  elink(int ed,int ord){
    id_lato=ed;
    order=ord;
  }

};

struct lato{
  int l[2];
  bool valido;

  lato(int a,int b){
    l[0]=a;
    l[1]=b;
    valido=true;
  }

};

vector<lato> lati;
vector<vector<elink> > graph;
vector<int> path;

int N, M, A, B;

void dfs(int l) {
  for(int i=0; i<graph[l].size(); i++) {

     elink e=graph[l][i];

     if(lati[e.id_lato].valido) {

        lati[e.id_lato].valido=false;

        dfs(lati[e.id_lato].l[e.order]);

     }

  }
  path.push_back(l);
}


int main() {

  freopen("input.txt","r", stdin);
  freopen("output.txt","w", stdout);


  cin >> N >> M >> A >> B;
  A--; B--;
  graph.reserve(N);
  int x, y;
  for(int i=0; i<M; i++) {
    cin >> x >> y;
    x--; y--;
    graph[x].push_back( elink(lati.size(),1) );
    graph[y].push_back( elink(lati.size(),0) );
    lati.push_back( lato(x,y) );
  }
  dfs(B);
  assert( M == path.size()-1 );
  for(int i=0; i<path.size()-1; i++)
    cout << path[i]+1 << " " << path[i+1]+1 << endl;
  return 0;
}

