#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100000;
const int MAXM = 1000000;

struct lato{
  int vertici[2];
  bool passo;
  lato(int a,int b){
    vertici[0]=a;
    vertici[1]=b;
    passo=true;
  }
};

struct passo_cammino{
  int vertice;
  int tempo;
  passo_cammino(int _vertice,int _tempo){
    vertice=_vertice;
    tempo=_tempo;
  }
};

vector<lato> lati;
vector<vector<passo_cammino> > passi_cammino;
vector<int> risultato;


int N, M, X, Y;

void dfs(int v_esplorato) {
  for(unsigned int i=0; i<passi_cammino[v_esplorato].size(); i++) {
     passo_cammino temp=passi_cammino[v_esplorato][i];
     if(lati[temp.vertice].passo) {
        lati[temp.vertice].passo=false;
        dfs(lati[temp.vertice].vertici[temp.tempo]);
     }
  }
  risultato.push_back(v_esplorato);
}


int main() {

        freopen("input.txt","r", stdin);
        freopen("output.txt","w", stdout);


  cin >> N >> M >> X >> Y;
  X--; Y--;
  passi_cammino.reserve(N);
  for(int i=0; i<M; i++) {
    int a, b;
    cin >> a >> b;
    a--; b--;
    passi_cammino[a].push_back( passo_cammino(lati.size(),1) );
    passi_cammino[b].push_back( passo_cammino(lati.size(),0) );
    lati.push_back( lato(a,b) );
  }
  dfs(Y);
  assert( (unsigned int)M == risultato.size()-1 );
  for(unsigned int i=0; i<risultato.size()-1; i++)
    cout << risultato[i]+1 << " " << risultato[i+1]+1 << endl;
  return 0;
}
