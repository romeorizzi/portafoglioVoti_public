#include <iostream>
#include <fstream>
#include <cassert>
#include <queue>

using namespace std;

char matrix[1000][1000];

int M;  //righe della matrice, massimo 1000
int N;  //colonne della matrice, massimo 1000
int L;  //massimo di mosse consentite per raggiungere l'obiettivo

int contatore = 0;  //Contatore dei passi
int percorsiOk = 0; //Contatore dei percorsi che vanno bene

int main(){

    ifstream inputfile;
    inputfile.open("input.txt");
    inputfile >> M >> N >> L;
    
    char carattere;

    for (int i=0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            inputfile >> carattere;
            matrix[i][j] = carattere;
        }
    }

    inputfile.close();
    
    // Coda per tenermi in memoria le posizioni
    queue<int> posRiga;
    queue<int> posColonna;
    // Inserisco la prima posizione
    posRiga.push(0);
    posColonna.push(0);

    while (posRiga.size() != 0){
                
        int dimensioneCoda = posRiga.size();

        for (int i = 0; i < dimensioneCoda; i++){
                
            int posRigaTemp = posRiga.front();
            int posColonnaTemp = posColonna.front();

            // Controllo che il contatore non abbia superato L
            if (contatore < L){

                // Verso il Basso
                if (matrix[posRigaTemp+1][posColonnaTemp] == '*' && (posRigaTemp+1 < M) && (posColonnaTemp < N)){
                    // Controllo se sono arrivato
                    if ((posRigaTemp+1 == M-1) && (posColonnaTemp == N-1)){
                        percorsiOk++;
                    }else{
                        posRiga.push(posRigaTemp+1);
                        posColonna.push(posColonnaTemp);
                    }
                }
                // Verso Destra
                if (matrix[posRigaTemp][posColonnaTemp+1] == '*' && (posRigaTemp < M) && (posColonnaTemp+1 < N)){
                    // Controllo se sono arrivato
                    if ((posRigaTemp == M-1) && (posColonnaTemp+1 == N-1)){
                        percorsiOk++;
                    }else{
                        posRiga.push(posRigaTemp);
                        posColonna.push(posColonnaTemp+1);
                    }
                }
                // In diagonale
                if (matrix[posRigaTemp+1][posColonnaTemp+1] == '*' && (posRigaTemp+1 < M) && (posColonnaTemp+1 < N)){
                    // Controllo se sono arrivato
                    if ((posRigaTemp+1 == M-1) && (posColonnaTemp+1 == N-1)){
                        percorsiOk++;
                    }else{
                        posRiga.push(posRigaTemp+1);
                        posColonna.push(posColonnaTemp+1);
                    }
                }

            }//EndIfContatore

            // Rimuovo la casella controllata
            posRiga.pop();
            posColonna.pop();

        }//EndFor

        // Aumento il contatore dei passi
        contatore++;

    }//EndWhile



    ofstream outputfile;
    outputfile.open("output.txt");
    
    percorsiOk = percorsiOk % 1000;
    outputfile << percorsiOk;

    outputfile.close();

    return 0;

}
