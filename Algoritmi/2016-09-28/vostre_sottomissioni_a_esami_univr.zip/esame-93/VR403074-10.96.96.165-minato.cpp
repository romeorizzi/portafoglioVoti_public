
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int M_MAX = 1000;
const int N_MAX = 1000; 

int M,N, L;
bool griglia[M_MAX][N_MAX];

struct nodo{
  int coord[2];


  nodo(int x,int y){
    coord[0]=x;
    coord[1]=y;

  }

};
// idea provo a fare una visita in ampiezza cercando tutte le possibili soluzioni 
// se arrivo ad una profondita maggiore di l oppure non posso piu proseguire la visita termino
int conta_sol(int l){
  
    int count = 0;
    int profondita = 0;
    bool visita = true;

        vector<nodo> vett;
        vett.push_back( nodo(0,0));
    while(visita){
 
        vector<nodo> new_vett;

         for(int i=0; i<vett.size(); i++){ 
                    nodo n = vett[i];
                    if(n.coord[0] == M-1 && n.coord[1] == N-1 && griglia[n.coord[0]][n.coord[1]]){ //ho trovato una posibile soluzione
                            count ++;
                    }else{
                       //aggiungo il nuovo livello di profondita scartando le caselle non agibili
                            if(n.coord[0]+1 < M && griglia[n.coord[0]+1][n.coord[1]])
                                new_vett.push_back( nodo(n.coord[0]+1,n.coord[1]));
                            if(n.coord[1]+1 < N && griglia[n.coord[0]][n.coord[1]+1])
                                new_vett.push_back( nodo(n.coord[0],n.coord[1]+1));
                            if(n.coord[0]+1 < M && n.coord[1]+1 < N  && griglia[n.coord[0]+1][n.coord[1]+1])
                                new_vett.push_back( nodo(n.coord[0]+1,n.coord[1]+1));
                    }
                 
         }
         vett = new_vett;

        if (profondita >= l  ||  vett.size() == 0 ) // o supero la profondita richiesta oppure non ho piu nodi da visitare
               visita = false;
        profondita ++;
    }

    return count;
};
int main() {

   freopen("input.txt","r", stdin);
  freopen("output.txt","w", stdout);
  cin >> M >> N >> L;
   for(int i =0 ; i < M;i++){
     for(int j =0 ; j < N;j++){
        char c;
            cin >> c;        
        if(c == '*'){
            griglia[i][j]= true;
            
        }else{
            griglia[i][j]= false;
             
        }
     }
    }

    if(griglia[M-1][N-1] && griglia[0][0]){
        cout << conta_sol(L)% 1000 << endl;
    }else{
         cout << 0 << endl;
    }
   

  return 0;
}

