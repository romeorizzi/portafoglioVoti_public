#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main(){
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    int N,M,A,B;
    //vettore che memorizza la soluzione (evitando le ridondanze)
    vector<int> soluzione;
    
    //vettore temporaneo (------toglilo se non lo usi)
    stack<int> solTemp;

    //salvo i nodi del grafo in un vettore di liste di vicinato
    vector< list<int> > grafo;
    
    //salvo tutti gli archi    
    vector<int> archi;
    
    //leggo tutti i valori
    in >> N >> M >> A >> B;

    //ora che conosco il numero |V| & |E| posso fissarli in modo permanente
    grafo.resize(N+1);
    archi.resize(M);

    int temp1,temp2;
    
    //popolo i vettori
    for(int i=0; i<M; i++){
        in >> temp1 >> temp2;
        archi[i] = temp1+temp2;
        grafo[temp1].push_back(i);
        grafo[temp2].push_back(i);
    }

    //scorro il grafo partendo da A
    //sotto uso i come iteratore sui vicini di ogni nodo
    int cursor = A;
    while(soluzione.size() < M){
        bool confina = false;
        for(list<int>::iterator i=grafo[cursor].begin(); i!=grafo[cursor].end(); i++)
            if(archi[*i]>0)
            {
                solTemp.push(cursor);
                confina = true;
                int next = archi[*i]-cursor;
                archi[*i] = -1;
                grafo[cursor].remove(*i);
                cursor = next;
                grafo[cursor].remove(*i);
                break;
            }
            if(!confina)
                {
                soluzione.push_back(cursor);
                cursor = solTemp.top();
                solTemp.pop();
                }
    }
    
    //alla fine chiudo il ciclo
    soluzione.push_back(A);

    for(int i = soluzione.size() -1; i>0; i--)
       out << soluzione[i] << " " << soluzione[i-1] << "\n";
    
    return 0;       
}

































