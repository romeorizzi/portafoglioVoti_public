#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main() {
    
    ifstream in("input.txt");
    ofstream out("output.txt");

    int N, V, VertexA, VertexB;
    vector<int> solution;
    stack<int> tempStack;
    vector<list<int>> graph;
    vector<int> edge;
    
    in >> N >> V >> VertexA >> VertexB;

    graph.resize(N+1);
    edge.resize(V);
    
    int temp1, temp2;

    for (int i = 0; i < V; i++) {
        in >> temp1 >> temp2;
        edge[i] = temp1 + temp2;
        graph[temp1].push_back(i);
        graph[temp2].push_back(i);
    }

    int c = VertexA;

    while (solution.size() < V) {
        bool hasNeighbour = false;
        
        for (list<int>::iterator i = graph[c].begin(); i != graph[c].end(); i++)
            if (edge[*i] > 0) {
                tempStack.push(c);
                hasNeighbour = true;
                int next = edge[*i] - c;
                edge[*i] = -1;
                graph[c].remove(*i);
                c = next;
                graph[c].remove(*i);
                break;
            }
        
        if (!hasNeighbour) {
            solution.push_back(c);
            c = tempStack.top();
            tempStack.pop();        
        }
    }

    solution.push_back(VertexA);
    for (int i = solution.size() - 1; i > 0; i--)
        out << solution[i] << " " << solution[i - 1] << "\n";
    
    return 0;
}
