#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main(void)
{
    ifstream in("input.txt");
    ofstream out("output.txt");

    long N, V, A, B;
    vector<long> sol;
    stack<long> tempS;
    vector<list<long>> grafo;
    vector<long> archi;

    in >> N >> V >> A >> B;

    grafo.resize(N+1);
    archi.resize(V);

    long temp1, temp2;

    for(long i=0; i<V; i++)
    {
        in >> temp1 >> temp2;
        archi[i]=temp1+temp2;
        grafo[temp1].push_back(i);
        grafo[temp2].push_back(i);
    }

    long c=A;

    while(sol.size()<V)
    {
        bool vicino=false;

        for(list<long>::iterator it=grafo[c].begin(); it!=grafo[c].end(); it++)
            if(archi[*it]>0)
            {
                tempS.push(c);
                vicino=true;
                long next=archi[*it]-c;
                archi[*it]=-1;
                grafo[c].remove(*it);
                c=next;
                grafo[c].remove(*it);
                break;
            }

        if(!vicino)
        {
            sol.push_back(c);
            c=tempS.top();
            tempS.pop();
        }
    }

    sol.push_back(A);

    for(long i=sol.size()-1; i>0; i--)
        out << sol[i] << " " << sol[i-1] << "\n";

    return 0;
}
