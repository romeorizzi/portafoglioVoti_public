//NOTE: Ho provato a mandarlo in esecuzione sul CMS più volte, 
// l'output di quasi tutti i tasks restituisce Execution timed out 
// probabilmente l'implementazione della visita in ampiezza richiede
// troppo tempo.

#include <fstream>
#include <vector>
#include <iostream>

using namespace std;

    short int N, M, L;
    char a;
    short int campo[100][100] = {};
    int result = 1;

// Ricerca in ampiezza
int bfs(short int x, short int y, short int z, short int steps){

    // Se la cella è un fantasmino, oppure ho superato il limite di passi, oppure sono uscito dal campo, allora ritorno nessun cammino
    if(campo[x][y] == -1 || steps > L || z > M || x > N || y > M)
        return 0;

    // Se sono arrivato alla posizione finale, incremento il numero di cammini possibili
    if(x == N && y == M){
        result++;
        return result;
    }

    // Cerco sulle righe
    for(short int i = x; i < N; i++)
       result = bfs(i+1, y, z, steps+1);           
        
    // Cerco sulle colonne
    for(short int j = y; j < M; j++)
       result = bfs(x, j+1, z, steps+1);            
        
    // Cerco in diagonale
    for(short int k = z; k < N; k++)
       result = bfs(x, y, k+1, steps+1);            
  
    return result;
}

int main(int argc, char* args[]){

    //stream di lettura input, output
    ifstream in ("input.txt");
    ofstream out("output.txt");



    in >> N >> M >> L;

    for(short int i = 0; i < N; i++)
        for(short int j = 0; j < M; j++)
        {
            in >> a;
            if(a == '+')
                campo[i][j]=-1;
            if(a == '*')
                campo[i][j]=0;
        }

    int solutions = bfs(0,0,0,0);

    solutions = solutions % 1000;

    out << solutions;

    return 0; 
     
}//main


