#define NDEBUG  
#include <cassert>
#ifdef NDEBUG
  #define EVAL
#endif
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100000;
const int MAXM = 100000; 

struct arco{
  int el[2];
  bool valid;
  arco(int a,int b){
    el[0]=a;
    el[1]=b;
    valid=true;
  }
};

struct elink{
  int arco_id;
  int order;
  elink(int ed,int ord){
    arco_id=ed;
    order=ord;
  }
};

vector<arco> arcos;
vector<vector<elink> > grafo;
vector<int> path;


int N, M, X, Y;

void dfs(int el) {
  for(unsigned int i=0; i<grafo[el].size(); i++) {
     elink e=grafo[el][i];
     if(arcos[e.arco_id].valid) {
        arcos[e.arco_id].valid=false;
        dfs(arcos[e.arco_id].el[e.order]);
     }
  }
  path.push_back(el);
}


int main() {
#ifdef EVAL
        freopen("input.txt","r", stdin);
        freopen("output.txt","w", stdout);
#endif

  cin >> N >> M >> X >> Y;
  X--; Y--;
  grafo.reserve(N);
  for(int i=0; i<M; i++) {
    int a, b;
    cin >> a >> b;
    a--; b--;
    grafo[a].push_back( elink(arcos.size(),1) );
    grafo[b].push_back( elink(arcos.size(),0) );
    arcos.push_back( arco(a,b) );
  }

  dfs(Y);

  assert( (unsigned int)M == path.size()-1 );

  for(unsigned int i=0; i<path.size()-1; i++)
    cout << path[i]+1 << " " << path[i+1]+1 << endl;
  return 0;
}

