#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int N, M, A, B;

// Creo due struct, una che identifica il tratto presente tra 2 nodi e l'altra che serve per identificare univocamente
// il collegamento tra due nodi
struct tratto{
  int listatratti[2];
  bool valido;

  tratto(int x,int y){
    listatratti[0] = x;
    listatratti[1] = y;
    valido=true;
  }

};

struct collegamento{
  int idtratto;
  int ordine;

  collegamento(int tid,int ord){
    idtratto = tid;
    ordine = ord;
  }
};

vector<tratto> tratti;
vector<vector<collegamento>> grafico;
vector<int> percorso;

// Usa l'algoritmo depth first search per calcolare il percorso
void cercaPercorso(int listatratti) {
  for(int i=0; i<grafico[listatratti].size(); i++) {

     collegamento coll = grafico[listatratti][i];

     if(tratti[coll.idtratto].valido) {
        tratti[coll.idtratto].valido=false;
        cercaPercorso(tratti[coll.idtratto].listatratti[coll.ordine]);
     }
  }
  percorso.push_back(listatratti);
}



int main (){
    
    // Apro l'input file e prendo i dati
    ifstream inputfile;
    inputfile.open("input.txt");

    inputfile >> N >> M >> A >> B;

    grafico.reserve(N);

    int x,y;
    for(int i=0; i<M; i++) {

        inputfile >> x >> y;

        grafico[x-1].push_back( collegamento(tratti.size(), 1) );
        grafico[y-1].push_back( collegamento(tratti.size(), 0) );
        tratti.push_back( tratto(x-1,y-1) );
    }

    inputfile.close();

    // Calcolo il percorso usando una depth first search
    cercaPercorso(B-1);

    // Apro l'output file
    ofstream outputfile;
    outputfile.open("output.txt");


    for(int i=0; i < percorso.size()-1; i++){
        outputfile << percorso[i]+1 << " " << percorso[i+1]+1 << endl;
    }

    outputfile.close();
    
    return 0;


}
