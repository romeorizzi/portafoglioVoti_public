#include <fstream>
#include <vector>

#define MAX_N 1001

using namespace std;

long dim_x, dim_y, maxxx;
int board[MAX_N][MAX_N];
long mem[MAX_N][MAX_N];

long calc(long x, long y, long moves)
{
    if(mem[x][y]!=-1)
        return mem[x][y];

    if(moves>maxxx || x>=dim_x-1 || y>=dim_y-1)
        return 0;       

    return mem[x][y]=calc(x+1, y, moves+1)+calc(x, y+1, moves+1)+calc(x+1, y+1, moves+1);
}

int main(void)
{
    char temp;

    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> dim_x >> dim_y >> maxxx;

    for(int i=0; i<dim_x; i++)
    {
        for(int j=0; j<dim_y; j++)
        {
            in >> temp;      
            mem[i][j]=-1;

            if(temp=='+')
            {
                board[i][j]=-1;
                mem[i][j]=0;
            }
        }
    }

    mem[dim_x-1][dim_y-1]=1;
    calc(0, 0, 0);

    out << mem[0][0];

    return 0;
}
