#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct arco{
    /*int from;
    int to;*/
    int arc[2];
    bool visitato;
    arco(int a,int b){
        arc[0]=a;
        arc[1]=b;
        visitato=true;
    }
};

struct direzione{
  int node;
  int verso;
  direzione(int a,int b){
    node=a;
    verso=b;
  }
};

int N, M, A, B;
vector<arco> archi;
vector<vector<direzione> > grafo;
vector<int> percorso;

void calcola_percorso(int n) {
  for(int i=0; i<grafo[n].size(); i++) {
     direzione dir=grafo[n][i];
     if(archi[dir.node].visitato) {
        archi[dir.node].visitato=false;
        /*if(dir.verso == 0)
            calcola_percorso(archi[dir.node].to);
        else
            calcola_percorso(archi[dir.node].from);*/
        calcola_percorso(archi[dir.node].arc[dir.verso]);
     }
  }
  percorso.push_back(n);
}

int main() {
    
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M >> A >> B;
    A--;
    B--;
    int from, to;
    grafo.reserve(N);
    for(int i=0; i<M; i++) {
        in >> from >> to;
        from--;
        to--;
        grafo[from].push_back( direzione(archi.size(),1) );
        grafo[to].push_back( direzione(archi.size(),0) );
        archi.push_back( arco(from,to) );
    }

    /*for(int i=0; i<archi.size(); i++){
        cout << archi[i].from << " " << archi[i].to << endl;
    }*/

    calcola_percorso(B);

    for(int i=0; i<percorso.size()-1; i++) {
        out << percorso[i]+1 << " " << percorso[i+1]+1 << endl;
    }

    return 0;
}
