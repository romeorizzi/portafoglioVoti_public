#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Node{
    public:
    int key = 0;
    vector<Node*> sons;
    Node(int n){key = n;};
};

void get_input(Node *node){
    int temp;
    for(int i = 0;i < node->key;i++){
        cin >> temp;
        Node *son = new Node(temp);
        node->sons.push_back(son);
        if(temp > 0){
            get_input(son);
        }
    }
}

void visit_node(Node *node){
    cout << node->key << " ";
    
    for(int i = (node->key - 1);i >=0;i--){
        visit_node((node->sons).at(i));
    
    }
}

int main(){
    int temp;
    cin >> temp;
    Node root(temp);    
    
    int max = root.key;
    
    get_input(&root);
    
    visit_node(&root);
    return 0;
}
