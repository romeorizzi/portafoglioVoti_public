#include <iostream>
#include <fstream>

using namespace std;

class Node{
    public:
    int key = 0;
    int last_son = 0;
    Node **sons;
    Node(int n){
    key = n;
    sons = new Node*[n];
    };
};

void get_input(Node *node){
    int temp;
    for(int i = 0;i < node->key;i++){
        cin >> temp;
        Node *son = new Node(temp);
        node->sons[node->last_son++] = son;
        if(temp > 0){
            get_input(son);
        }
    }
}

void visit_node(Node *node){
    cout << node->key << " ";
    
    for(int i = (node->key - 1);i >=0;i--){
        visit_node((node->sons)[i]);
    
    }
}

int main(){
    int temp;
    cin >> temp;
    Node root(temp);    
    
    int max = root.key;
    
    get_input(&root);
    
    //cout << "visiting root" << endl;
    visit_node(&root);
    //cout << endl;
    /*
    for(int i = 0;i < max;i++){
           input >> temp;
           if(temp > 0)
                max += temp;
    }
    */
    return 0;
}
