/* Esame Algoritmi

   Alessandra Fin   Vr379679

*/

#include <cassert> 
#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int main () {
    int n, m, s[200000], q1[200000], q2[200000], opt[200000];
    int sum=0;

    ifstream fin("input.txt"); assert( fin );
    fin >> n >> m;

    for(int i=1; i < (n+1); i++) 
        fin >> s[i];

    for(int i=0; i < m; i++) {
        fin >> q1[i];
        fin >> q2[i];
    }

    for(int j=0; j<m; j++) 
        for(int i=q1[j]; i <= q2[j]; i++)
            opt[i]++;

    sort(s+1, s+n+1);
    sort(opt+1, opt+n+1);

    for(int i=1; i<(n+1); i++)
        sum += opt[i]*s[i];

    ofstream fout("output.txt"); assert(fout);
    fout << sum << endl;
    fout.close();

    return 0;

}
