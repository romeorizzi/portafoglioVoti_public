#include <fstream>
#include <climits>

using namespace std;

ifstream input;
ofstream output;

const int MAX_N = 250;
const int MAX_M = 250;

int N;
int M;
int A;
int B;
int fette;

int torta[MAX_N][MAX_M];
int conteggio[MAX_N][MAX_M];

int conta_dim(int n, int m){
    
    for(int k = m; k<M; k++){
        int somma=0;
        for(int i=0; i<n+1; i++){
        if(k-m-1 >= 0)
            somma += (conteggio[i][k] - conteggio[i][k-m-1]);
        else
            somma += conteggio[i][k];
        }
        if(somma >= A && somma <= B)
           fette++;
    }
}

void conta_fette(){
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            conta_dim(i,j);
        }
    }
            
}


int main(){

    input.open("input.txt");
    input >> N >> M >> A >> B;
    output.open("output.txt", ofstream::trunc);
    fette = 0;
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            input >> torta[i][j]; 
            /*if(torta[i][j] >= A && torta[i][j] <= B)
                fette++;*/
            if(j>0)
                conteggio[i][j] = conteggio [i][j-1] + torta[i][j];
            else
                conteggio[i][j] = torta[i][j];
        }
    }
    conta_fette();
    output << fette;
    output.close();
        

}
