//#define NDEBUG
#include<cassert>
#include<fstream>
#include<vector>
//#ifndef NDEBUG
#include<iostream>
//#endif
#include <sstream>
const int MAX_DIM = 1000000;
using namespace std;


int albero[MAX_DIM];
int albero_specchio[MAX_DIM];
int dim_albero;
int pos_albero_specchio = 0;

/** Stampa l'array "a" fino a posizione length*/
void stampa_array(int* a, int length){

    //#ifndef NDEBUG
    for (int i = 0; i< length; i++){
        cout << a[i] << " ";
    }
    cout << endl;
    //#endif
    return;
}



int sottoalbero_specchio(int pos_radice){
    int dim = 0;

    // so che sicuramente ogni nodo ha almeno se' stesso
    dim++;

    // albero[pos_radice] e' il numero di figli di "pos_radice"
    // io calcolo la mia dimensione in base a:
    // la dimensione calcolata su di me e su una parte dei figli + la dimensione del i-esimo figlio che manca
    for(int i = 0; i < albero[pos_radice]; i++){
        dim = dim + sottoalbero_specchio(pos_radice + dim);
    }


    // sposto il figlio
    albero_specchio[pos_albero_specchio--] = albero[pos_radice];

    // ritorno quanto grande sono
    return dim;
}





int main() {
    ifstream fin;
    dim_albero = 0;

    fin.open("input.txt"); assert(fin);
    int tmp_nodo;

    // leggo l'albero
    /*while(true){
        fin>> tmp_nodo;
        if (fin.eof())
            break;
        albero[dim_albero++] = tmp_nodo;
    }
    */

    // Lettura da stdin
    string riga;
    stringstream streamRiga;
    getline(cin, riga);
    streamRiga << riga;

    while(streamRiga >> albero[dim_albero++]) ;
    dim_albero--;


    //sottoalbero_dim(0);


    // stampa
    //stampa_array(albero, dim_albero);

    pos_albero_specchio = dim_albero - 1;

    sottoalbero_specchio(0);

    // stampa
    stampa_array(albero_specchio, dim_albero);





    fin.close();

    //    fout.open("output.txt"); assert(fout);


    //    fout << endl;
    //    fout.close();

    return 0;
}
