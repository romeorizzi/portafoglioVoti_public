#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
int min(int i, int j){
    if (i < j)
        return i;
    return j;
}
/*
void merge2(int* A, int l, int r, int end, int* B, int* pos, int* aux){
    int s = l;
    for(int i = l; i < end; i++){
        if(A[l] < A[r] || r >= end){
            B[i] = A[l];
            aux[i] = pos[pos[l]];
            l++; 
        }else{
            B[i] = A[r];
            aux[i] = pos[pos[r]];
            r++;
        }
    }
    for( ; s < end; s++){
        A[s] = B[s];
        pos[s] = aux[s];
    }
    
}
void mergeBUs(int* A, int* B,int n, int* pos, int* aux){
    int w;
    for(w = 1; w <= n; w = 2*w){
        for(int i = 1; i < n - w+1; i += 2*w)
            merge2(A, i, min(i+w, n+1), min(i+2*w, n+1), B, pos, aux);
    }    
}*/
void merge1(int* A, int l, int r, int end, int* B){
    int s = l;
    for(int i = l; i < end; i++){
        if(A[l] < A[r] || r >= end){
            B[i] = A[l];
            l++; 
        }else{
            B[i] = A[r];
            r++;
        }
    }
    for( ; s < end; s++){
        A[s] = B[s];
    }
    
}
void mergeBU(int* A, int* B, int n){
    int w;
    for(w = 1; w <= n; w = 2*w){
        for(int i = 1; i < n - w+1; i += 2*w)
            merge1(A, i, min(i+w, n+1), min(i+2*w, n+1), B);
    }    
    
}


int main(){
    ifstream inf("input.txt");
    ofstream outf("output.txt");
    int n, q;
    int* input;
    int* qn;
    int* posq;
    int* B;
    int* aux;
    int* la; 
    int* ra;
    int i, j, l, r;
    inf >> n;
    inf >> q;
    input = new int[n+1];
    B = new int[n+1];
    qn = new int[n+1];
    la = new int[q];
    ra = new int[q];
    
    
  //  cout << "Hello"  << endl;
    for(i = 1; i <= n; i++){
        inf >> input[i];
        //posq[i] = i;
    } 
    for(i = 0; i < q; i++){
        inf >> l;
        inf >> r;
        la[i] = l;
        ra[i] = r;
        for(j = l; j <= r; j++){
            (qn[j])++;
        }
    }
  /*  for(i = 1; i < n+1; i++){
        cout << qn[i] << " ";
    }
    cout << endl;*/
    mergeBU(input, B, n);
  //  mergeBUs(qn, B, n, posq,aux);
   /* for(i = 1; i < n+1; i++){
        cout << input[i] << " ";
    }
    cout << endl;
    for(i = 1; i < n+1; i++){
        cout << qn[i] << " ";
    }
    cout << endl;*/
    int max = -1;
    int pos;
    int fin = n;
    int ini;
    int iniTemp;
    int fini;
    int len = -1;
    int lmax = -1;
    for(i = 1; i < n+1; i++){
        max = -1;
        for(j = 1; j < n+1; j++){
            if(qn[j] > max){
                pos = j;
                max = qn[j];
                 //cout << "max " << max << endl;            
                }
        }
        B[pos] = input[fin];
            fin--;
            qn[pos] = -1;
       /* iniTemp = -1;
        lmax = -1;
        if(max == -1)
            break;
       for(j = 0; j < n+1; j++){
            if(qn[j] == max && iniTemp == -1){
                len = 1;
                iniTemp = j;

            }else if(qn[j] == max && iniTemp > -1){
                len++;
                if(j == n && len >= lmax){
                lmax = len;
                ini = iniTemp;
                fini = j;
                iniTemp = -1;
                len = -1;
                }
            }else if((qn[j] != max || j == n) && iniTemp > -1){
                //cout << "max " << max << " len "  << len << endl;
                if(len >= lmax){
                lmax = len;
                ini = iniTemp;
                fini = j-1;
                iniTemp = -1;
                len = -1;
                }else{
                   iniTemp = -1;
                   fini = -1;
                    len = -1;
                }
            iniTemp = -1;
len = -1;
            }
  //          cout 
        }*/
     //   cout << "lmax " << lmax << " max " << max << endl;
       // cout << "ini " << ini << " fini " << fini << endl;
       
       /* for(j = ini; j <= fini; j++){
            B[j] = input[fin];
            fin--;
            qn[j] = -1;
        }*/
      /*  for(int t = 1; t < n+1; t++){
        outf << qn[t] << " ";
    }*/
         //cout << "Hello" << endl;
    }
    /*for(i = 1; i < n+1; i++){
        cout << B[i] << " ";
    }*/
    max = 0;
    int le;
    for(i = 0; i < q; i++){
       le = la[i];
        r = ra[i];
        for(j = le; j <= r; j++){
            max += B[j];
        }
        // trova intervallo più largo
    }
    
    outf << max << endl;
    //outf << f(inf) << endl;
    

}
