#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
string f(ifstream& inf){
    int n;
    inf >> n;
    string s = "";
    for(int i = 0; i < n; i++){
    s = f(inf) + s;
    }
    stringstream ss;
    ss << n << " " << s;
    return ss.str();
}
int main(){
    ifstream inf("input.txt");
    ofstream outf("output.txt");
    
    cout << f(inf) << endl;
    

}
