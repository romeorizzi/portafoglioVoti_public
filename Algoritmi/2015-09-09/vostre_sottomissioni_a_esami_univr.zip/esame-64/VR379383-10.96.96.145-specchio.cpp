//Federico Recchia vr379383

#include <stdlib.h>
#include <fstream>
#include <string>
#include <stdio.h>

using namespace std;
//int tree [] = {4, 2, 0, 3, 0, 0, 1,0,0,0,0};

int tree [1000000];
int contatoreGen = 0; 

string ric (int a){
    int contTMP = a;
    string strtmp = "";
    while (contTMP>0){
        contatoreGen ++;
        int num = tree[contatoreGen];
        if(num == 0){
            strtmp = "0 " + strtmp;
        }
        else{
            string st_in = ric(tree[contatoreGen]);
            strtmp = st_in + strtmp;
        }
        contTMP--;
    } 

    strtmp = to_string(a) + " " + strtmp;
    return strtmp;

}

int main(){

    FILE *f_in;
    FILE *f_out;

    f_in = fopen("input.txt","r");

    int i=0; int val;
    while(fscanf(f_in,"%d",&val)>0){
        tree[i++] = val;
    }
    fclose(f_in);

    string ris = ric(tree[0]);
    
    f_out = fopen("output.txt","w");
    fprintf(f_out,"%s",ris.c_str());
    fclose(f_out);

}


