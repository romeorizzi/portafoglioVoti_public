#include <cassert>
#include <algorithm>
#include <iostream>
#include <fstream>


using namespace std;

int main() 
{
    int summa = 0;
    int firstn, secondn, str[200000], temp1[200000], temp2[200000], vc[200000];
    
   
    ifstream fin("input.txt"); 
    assert(fin);
    fin >> firstn >> secondn;
    for (int i= 1; i < (firstn+1); i++)
        fin >> str[i];

    for (int i=0; i<secondn; i++)
    {
        fin >> temp1[i];
        fin >> temp2[i];
    }
    
    for (int j=0; j<secondn; j++)
        for (int i= temp1[j]; i<= temp2[j]; i++)
            vc[i]++;
    
    sort(str+1, str+firstn+1);
    sort(vc+1, vc+firstn+1);
    
    for(int i=1; i<(firstn+1); i++)
    {   
        summa += vc[i]*str[i];    
    }

    ofstream fout("output.txt"); 
    assert(fout);
    fout << summa << endl;
    fout.close();

    return 0;

}
