#include <fstream>
#include <climits>

using namespace std;

ifstream input;
ofstream output;

void merge(int *a, int l, int c, int r){
    int aux[r+1];
    int i,j;
    for(i=c+1; i>l; i--){
        aux[i-1]= a[i-1];
    }
    for(j = c; j < r; j++){
        aux[r+c-j]=a[j+1];
    }

    for(int k= l; k<=r; k++){
         if(aux[j] < aux[i]){
            a[k] = aux[j--];
        }else{
            a[k] = aux[i++];
        }
    } 
}

void mergesort(int *a, int l, int r){
    if(l < r){
        int c = (l + r)/2;
        mergesort(a, l, c);
        mergesort(a, c +1, r);
        merge(a, l, c, r);
    }
    return;
}

int main(){

    int N,Q;
    input.open("input.txt");
    input >> N >> Q;

    int array[N];
    int array2[N];
    int richieste[N];
    long long int prefix_sum[N+1];
    int l[Q];
    int r[Q];

    for(int i=0; i<N; i++){
        input >> array [i];
        array2[i] = -1;
        richieste[i] = 0;
    }

    for(int i = 0; i< Q; i++){
         input >> l[i] >> r[i];
         for(int j = l[i] -1; j<= r[i]-1; j++){
            richieste[j]++;
        }
    }
    
    input.close();
    mergesort(array, 0, N-1);

    int max = 0;
    int pos;

    for(int i = N-1; i>=0; i--){
     max = 0;
     for( int j = 0; j < N; j++){
        if(richieste[i] >= max && array2[j] == -1){
            max = richieste[j];
            pos = j;
         }
      }    
      array2[pos] = array [i];
    }

    for(int i = 0; i <= N; i++){
        if(i== 0){
            prefix_sum[0] = 0;
        }else{
            prefix_sum[i] = prefix_sum[i-1] + array2[i-1];
        }
    }

    long long int somma = 0;
    for(int i = 0; i< Q; i++){
        somma+=prefix_sum[r[i]] -prefix_sum[l[i]-1];
    }
    
    output.open("output.txt", ofstream::trunc);
    output << somma << endl;

    output.close();



}
