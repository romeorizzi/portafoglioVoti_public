#include <iostream>
#include <cassert>
#include <fstream>
#include <stdio.h>

#define MAX_N 1000000

using namespace std;

int N;
int albero[MAX_N]; //array dell'albero di input
int albero_specchiato[MAX_N]; //array dell'albero specchiato
int j; //posizione a cui sono arrivato nell'albero specchitato

//inverte l'albero facendo una post visita in base al numero di figli
int specchio(int r) {
    int figli = 1;
    for(int i = 0; i < albero[r]; i++) {
        figli += specchio(r + figli); //visita post fissa
    }
    albero_specchiato[j--] = albero[r];
    return figli;
}

int main()
{
    int tot_nodi = 1;
    //leggo l'input sommando il numero di figli per scoprire quanti nodi ci sono in tutto
    for(int i = 0; i < tot_nodi; i++) {
        cin >> albero[i];
        tot_nodi += albero[i];
    }

    //posizione da cui partire per compilare l'array dell'albero specchiato
    j = tot_nodi-1;

    //inverto l'albero
    specchio(0);

    //stampo l'output
    for(int i = 0; i < tot_nodi; i++) {
        cout << albero_specchiato[i] << " ";
    }
    cout << endl;

    return 0;
}

