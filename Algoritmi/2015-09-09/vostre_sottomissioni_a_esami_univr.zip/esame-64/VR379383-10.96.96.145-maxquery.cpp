//Federico Recchia vr379383

#include <stdlib.h>
#include <fstream>
#include <stdio.h>

using namespace std;

void riordinamento(int *array,int start, int end){
    
    int tmp, k, t;
    if(start < end){
        tmp = array[start];
        k = start+1;
        t = end +1;

        while(k<t){
            if(array[k] < tmp)
                k++;
            else{
                t--;
                int *n1 = &array[k];
                int *n2 = &array[t];
                int temp = *n1;
                *n1 = *n2;
                *n2 = temp;                                        
            }
        }
            k --;
            int *n1 = &array[start];
            int *n2 = &array[k];
            int temp = *n1;
            *n1 = *n2;
            *n2 = temp;  

            riordinamento(array,start,k);
            riordinamento(array,t,end);
    }
}

int main(){

    int array[200000];
    int qOcc[200000];

    int N,q,val;
    int min,max;

    FILE *f_in;
    FILE *f_out;

    f_in = fopen("input.txt","r");
    
    fscanf(f_in,"%d",&N);
    fscanf(f_in,"%d",&q);
    
    for(int i=0; i<N; i++){
        fscanf(f_in,"%d",&val);
        array[i] = val;
        qOcc [i] = 0;
    }


    for(int i=0; i<q; i++){
        fscanf(f_in,"%d %d",&min,&max);
        for(int j=min-1; j< max;j++)
            qOcc[j] ++;
    }
     fclose(f_in);

    //ordinamento occorrenze
    riordinamento(qOcc,0,N-1);
    riordinamento(array,0,N-1);
/*
    for(int k=0;k<N;k++)
        cout << qOcc[k] << " ";
    cout << endl;
    for(int k=0;k<N;k++)
        cout << array[k] << " ";
    cout << endl;
*/
    //Calcolo finale
    long long int ris =0 ;
    for(int i=0;i<N;i++)
        ris += qOcc[i]*array[i];

    f_out = fopen("output.txt","w");
    fprintf(f_out,"%lld",ris);
    fclose(f_out);

}
