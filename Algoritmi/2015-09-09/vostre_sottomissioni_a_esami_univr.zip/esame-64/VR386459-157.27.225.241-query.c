#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define INPUT "input.txt"
#define OUTPUT "output.txt"

#define N 1000000

int Array[N];

int Query[N];
//soa : Size of Array
int soa;
//soa : Size of Query
int soq;

void swap (int *a, int *b){
    int tmp=*a;
    *a=*b;
    *b=tmp;
}

void quick(int *array, int start, int end){

    int pivot,l,r;

    if (end>start){
        pivot=array[start];
        l=start+1; 
        r=end+1;
        while (l<r){
            if (array[l]<pivot){

                l++;
            }else{
                r--;
                swap(&array[l],&array[r]);
            }
        }
        l--;
        swap(&array[start],&array[l]);
        quick(array,start,l);
        quick(array,r,end);    
    }
}

void *readArray( FILE *in, int soa ) {
    int i;
	for ( i = 0; i < soa; ++i ) {
	   fscanf( in, "%d", &Array[i]);
       Query[i]=0;    
    }
}

void *readQuery( FILE *in, int soq ) {
    int i,j;
    int low,up;
	for ( i = 0; i < soq; ++i ) {
		fscanf( in, "%d %d", &low, &up );
        for (j = low-1; j < up; ++j ) ++Query[j];
    }
}

int main() {
    long int acc;
    
    //Read from INPUT
    //------------------------------------------------------------------
    FILE *in = fopen( INPUT, "r" );
   
    fscanf( in, "%d", &soa );
    fscanf( in, "%d", &soq );
    fclose( in );    
    //------------------------------------------------------------------
    quick(Array,0,soa-1);
    quick(Query,0,soa-1);    

    int flag=1;

    acc=0;
    int i;
    for ( i = soa-1; i >=0 && flag==1; --i ) {
    acc+=Query[i]*Array[i];
        	  if (Query[i]==0) flag=0;
    }

    //Write to OUTPUT
    FILE *out = fopen( OUTPUT, "w" );
    fprintf( out, "%ld", acc );
    fclose( out );
    return 0;
}

