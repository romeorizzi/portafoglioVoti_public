#include <stdio.h>
#define N 200001

void stampaArray();
void stampaNewArray();
void ordina();

FILE *fr, *fw;
long long int n, q, frequenza[N], num_freq = 0, cima, freq, oper1[N], oper2[N], somma = 0;
long long int array[N], new_array[N], s[N];

int main()
{
    long long int i, j, a, b;

    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
    fscanf(fr, "%lld %lld", &n, &q);
    for(i=1; i<=n; i++){
        fscanf(fr, "%lld", &array[i]);
        new_array[i] = -1;
    }
    ordina();
    for(i=1; i<=q; i++){
        fscanf(fr, "%lld %lld", &a, &b);
        oper1[i] = a;
        oper2[i] = b;
        if(a == 1 && b == n) continue;
        for(j=a; j<=b; j++){
            frequenza[j]++;
        }
        num_freq++;
    }
    cima = n;
    //stampaArray();
    for(freq=num_freq; freq>=0; freq--){
        for(i=1; i<=n; i++){
            if(frequenza[i]==freq) new_array[i] = array[cima--];
        }
    }
    //stampaNewArray();

    s[0] = 0;
    for(i=1; i<=n; i++){
        s[i] = s[i-1] + new_array[i];
    }

    for(i=1; i<=q; i++){
        somma += s[oper2[i]] - s[oper1[i]-1];
    }

    fprintf(fw, "%lld", somma);

    //printf("\n");
    fclose(fr);
    fclose(fw);
    return 0;
}

void ordina(){
    long long int i, j, tmp;

    for(i=n; i>=1; i--){
        for(j=1; j<i; j++){
            if(array[j] > array[j+1]){
                tmp = array[j+1];
                array[j+1] = array[j];
                array[j] = tmp;
            }
        }
    }
}

void stampaNewArray(){
    long long int i;

    for(i=1; i<=n; i++)
        fprintf(stdout, "%lld ", new_array[i]);
    printf("\n");
}

void stampaArray(){
    long long int i;

    for(i=1; i<=n; i++)
        fprintf(stdout, "%lld ", array[i]);
    printf("\n");
    for(i=1; i<=n; i++)
        fprintf(stdout, "%lld ", frequenza[i]);
    printf("\n");
}
