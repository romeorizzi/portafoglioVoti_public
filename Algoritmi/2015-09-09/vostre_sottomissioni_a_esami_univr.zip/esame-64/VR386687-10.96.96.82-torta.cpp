#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

int trovaBiscotti(int **torta, int N, int M, int A, int B){
    int F = 0;

    int sum_s = 0;
    int actual_s = 0;

    //trovo le sottoparti
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < M; j++)
        {
            sum_s = torta[i][j];
            if(sum_s >= A && sum_s <= B)
            {
                actual_s = sum_s;
                F++;
                //tutte le righe a partire da quella cella
                for(int k = 0; j+k < M; k++)
                {
                    sum_s = actual_s + torta[i][j+k];
                    if(sum_s >= A && sum_s <= B)
                    {
                        F++;
                        actual_s = sum_s;
                    }
                    else
                        break;
                }
                sum_s = torta[i][j];
                //tutte le colonne a partire da quella cella
                for(int k = 0; i+k < N; k++)
                {
                    sum_s = actual_s + torta[i+k][j];
                    if(sum_s >= A && sum_s <= B)
                    {
                        F++;
                        actual_s = sum_s;
                    }
                    else
                        break;
                }

                //tutti i quadrati formati



            }
        }
    }

    return F;
}


int main(void){

    ofstream output;
    ifstream input;

    int N = 2;
    int M = 4;

    int A = -3;
    int B = 3;

    input.open("input.txt");
    input>>N;
    input>>M;
    input>>A;
    input>>B;


    int** torta = new int*[N];
    for (int i = 0; i < N; i++)
        torta[i] = new int[M];

    for(int i = 0; i < N; i++)
        for(int j = 0; j < M; j++)
          input >> torta[i][j];

/*    torta[0][0] = 2;
    torta[0][1] = 0;
    torta[0][2] = -1;
    torta[0][3] = 3;
    torta[1][0] = -1;
    torta[1][1] = -2;
    torta[1][2] = 2;
    torta[1][3] = 1;
*/

    int result = trovaBiscotti(torta, N, M, A, B);

    output.open("output.txt");
    output<<result<<endl;

    return 0;
}
