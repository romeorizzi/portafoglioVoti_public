/**
g++ -o query query.cpp
*/

#include<iostream>
#include<fstream>
//#include<stdlib.h>
#include<assert.h>

using namespace std;

long long int n, i, j, q, l, r, indFreq, maxFreq, indVal, maxVal = 0;
long long int vector[200000];
long long int query[2][200000];
//long long int ripetute[200000];
long long int ordinato[200000];
long long int freq[200000];
long long int copy_freq[200000];

void ordina() {
	maxFreq = freq[0];
	indFreq = 0;
	/*
	for (i = 0; i < n; i ++)
		printf("freq[i]=%d ",freq[i]);
	printf("\n");
	*/
	for (i = 1; i < n; i ++) {	// trova la freq max
		if (freq[i] > maxFreq) {
			maxFreq = freq[i];
			indFreq = i;
		}
	}
	freq[indFreq] = 0;
}

/*
void scambia(int *a, int *b) {
	int c;
	c = *a;
	*a = *b;
	*a = c;
}

void pivot(int p, int r, int pivot) {
	int k, z;
	k = p;
	z = r;
	do {
		while (vector[z] >= pivot)
			z --;
		while (vector[k] >= pivot)
	} while();
}
*/

void ordina_arrray_iniziale() {
	int k;
	int z;
	int temp, pos_min;
	for (int k = 0; k < n-1; k ++) {
		pos_min = k;
		for (z = k+1; z < n; z ++) 
			if (vector[pos_min] > vector[z])
				pos_min = z;
			
		if (pos_min != k) {
			temp = vector[k];
			vector[k] = vector[pos_min];
			vector[pos_min] = temp;
		}
	}
	
	/*
	printf("vector\n");
	for (i = 0; i < n; i ++)
		printf("%lld ",vector[i]);
	printf("\n");
	*/
}


/*
return -1 se l'ordinamento e' finito
DELETE
*/
long long int valore_massimo_array() {
	maxVal = vector[0];
	indVal = 0;
	for (i = 1; i < n; i ++) {
		if (vector[i] > maxVal) {
			maxVal = vector[i];
			indVal = i;
		}
	}
	vector[indVal] = -1;

	return maxVal;
}


int main() {
	long long int sum = 0;
	ifstream infile("input.txt");
	ofstream outfile("output.txt");
	//FILE *F;
	//F = fopen("input.txt","r");
	//assert(2 == fscanf(F,"%lld %lld\n",&n, &q));
	infile >> n >> q;
	
	for (i = 0; i < n; i ++) {
		//assert(1 == fscanf(F,"%lld ", &vector[i]));
		infile >> vector[i];
		//if (vector[i] > maxVal)
		//	maxVal = vector[i];
		freq[i] = 1;
		copy_freq[i] = 0;
	}
	
	for (i = 0; i < q; i ++) {
		//assert(2 == fscanf(F,"%lld %lld\n",&l, &r));
		infile >> l >> r;
		query[0][i] = l-1;
		query[1][i] = r-1;
		
		//printf("l=%d r=%d\n",l,r);
		
		if (l != 1 || r != n) {
			for (j = l; j <= r; j ++)
				freq[j-1] ++;
		}
		for (j = l; j <= r; j ++)
			copy_freq[j-1] ++;
		/*for (j = 0; j < n; j ++)
			printf("freq[i]=%lld ",freq[j]);
		printf("\n");*/
	}
	infile.close();
	ordina_arrray_iniziale();
	indVal = n-1;
	
	// ORDINAMENTO
	while (indVal >= 0) {
		ordina();
		ordinato[indFreq] = vector[indVal];
		indVal --;
	}
	
	// SOMMA TOTALE
	for (i = 0; i < n; i ++)
		sum += copy_freq[i] * ordinato[i];
	
	/*for (i = 0; i < q; i ++) {
		for (j = query[0][i]; j <= query[1][i]; j ++) {
			sum += ordinato[j];
			//printf("ordinato[j-1]=%d ",ordinato[j-1]);
		}
	}*/
	//printf("\n");
	
	
	//F = fopen("output.txt","w");
	//for (i = 0; i < n; i ++)
	//	fprintf(F,"%d",ordinato[i]);
	//fprintf(F,"%lld",sum);
	outfile << sum;
	outfile.close();
	//fclose(F);
	
	return 0;
}
