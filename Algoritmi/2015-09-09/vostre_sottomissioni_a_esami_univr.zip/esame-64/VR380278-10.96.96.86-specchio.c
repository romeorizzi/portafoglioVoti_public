#include <stdlib.h>
#include <stdio.h>

typedef struct num {

    struct num **SP;
    short N;
} node;

void get(node *num);
void print(node *num);

int main(){
    node Tree;
    get(&Tree);
    print(&Tree);
    return 0;
}

void get(node *num) {
    short j;
    scanf(" %d", &num->N);
    num->SP = (node**) calloc (num->N, sizeof(node*));
    
    for (j=0; j < num->N; j++)
        get(num->SP[j] = (node*) malloc (sizeof(node)));
}

void print(node *num) {
    short i;
    printf(" %d", num->N);
    
    for(i = num->N - 1; i >= 0; i--)
        print( num->SP[i]);
}
