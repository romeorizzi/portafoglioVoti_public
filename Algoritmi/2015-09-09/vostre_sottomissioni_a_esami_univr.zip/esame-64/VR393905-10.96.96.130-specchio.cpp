#include <iostream>
#include <vector>

using namespace std;

vector<int>albero;

void visita() {

    //Lettura valore nodo corrente
    int numfigli;
    cin >> numfigli;
    //Se ha figli, prima di stampare analizzo ricorsivamente i figli
    for (int i = 0; i < numfigli; i++)
        visita();
    //La stampa avviene solo dopo aver analizzato eventuali figli
    albero.push_back(numfigli);

}

int main() {
    
    //Chiamata funzione ricorsiva
    visita();
    
    //Stampa in output l'input al rovescio
    for (int i = albero.size() - 1; i > 0; i--)
        cout << albero[i] << " ";

    cout << albero [0] << endl;

    return 0;

}
