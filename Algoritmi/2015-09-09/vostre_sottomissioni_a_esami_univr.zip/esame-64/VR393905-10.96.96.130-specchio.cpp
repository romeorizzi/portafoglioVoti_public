#include <fstream>
#include <vector>

using namespace std;

ifstream input("input.txt");
ofstream output("output.txt");
vector<int>albero;

void visita() {
    //Lettura valore nodo corrente
    int numfigli;
    input >> numfigli;
    //Se ha figli, prima di stampare analizzo ricorsivamente i figli
    for (int i = 0; i < numfigli; i++)
        visita();
    //La stampa avviene solo dopo aver analizzato eventuali figli
    albero.push_back(numfigli);
}

int main() {
    
    //Chiamata funzione ricorsiva
    visita();
    
    //Stampa in output l'input al rovescio
    for (int i = albero.size() - 1; i > 0; i--)
        output << albero[i] << " ";

    output << albero [0] << endl;
    return 0;

}
