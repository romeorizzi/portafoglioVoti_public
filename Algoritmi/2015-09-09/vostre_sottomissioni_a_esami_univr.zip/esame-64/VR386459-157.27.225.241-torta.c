#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define INPUT "input.txt"
#define OUTPUT "output.txt"

#define N 250
#define M 250

int Torta;
int P_sum_righe[N+1][M+1];
int P_sum_colonne[N+1][M+1];

unsigned int row;
unsigned int coloumn;

int main(int argc,char* argv[]){
	FILE *f_in;
	FILE *f_out;
	int flag,i,j,k,y,cont,tmp,cell,a,b;

	f_in=fopen(INPUT,"r+");
	f_out=fopen(OUTPUT,"w+");
	i=0;
	fscanf(f_in, "%d", &row );
	fscanf(f_in, "%d", &coloumn );
	fscanf(f_in, "%d", &a );
	fscanf(f_in, "%d", &b );

	for(i=0;i<row;++i){
		P_sum_righe[0][i]=0;
		P_sum_colonne[i][0]=0;
	}
	for(i=0;i<row;++i){
		for(j=0;j<coloumn;++j){
			fscanf(f_in,"%d",&Torta);
			P_sum_righe[i+1][j+1]=P_sum_righe[i+1][j]+Torta;
			P_sum_colonne[i+1][j+1]=P_sum_colonne[i][j+1]+P_sum_righe[i+1][j+1];
		}
	}

	/*for(i=0;i<row+1;++i){
		for(j=0;j<coloumn+1;++j)printf("%d ",P_sum_colonne[i][j] );
			printf("\n");
	}
	for(i=0;i<row+1;++i){
		for(j=0;j<coloumn+1;++j)printf("%d ",P_sum_righe[i][j] );
			printf("\n");
	}
	printf("a%d b%d\n",a,b );*/
	cont=0;
	for(i=0;i<row;++i){
		for(j=0;j<coloumn;++j){
			tmp=P_sum_colonne[i+1][j]+P_sum_colonne[i][j+1];
			for(k=i;k<row;++k){
				for(y=j;y<coloumn;++y){
					cell=P_sum_colonne[k+1][y+1]-tmp;
					//printf("cell[%d][%d][%d][%d]=%d\n",i,j,k+1,j+1,cell );
					if((cell>=a) && (cell<=b))cont++;
				}
			}
		}
	}
	//printf("cont %d\n",cont );
	fprintf(f_out, "%d ",cont );
	fclose(f_in);
	fclose(f_out);
	return 0;
}
