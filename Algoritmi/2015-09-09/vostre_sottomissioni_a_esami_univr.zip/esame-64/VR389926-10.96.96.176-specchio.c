/* MATTEO CALABRIA VR389926 
    specchio.c */

#include <stdio.h>
#include <stdlib.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"

#define MAX_N 1000000

// definiamo una struttura albero
typedef struct node {

    int num;
    struct node *last;
    struct node *prec;

} tree;

// prototipi di funzione
tree *create_tree(FILE *file);
void create_mirror(FILE *file, tree *t);

// MAIN
int main(){

    FILE *fp_in, *fp_out;
    tree *t;

    // apertura file
    fp_in = fopen(INPUT_FILE, "r");
    fp_out = fopen(OUTPUT_FILE, "w+");

    // lettura dati e creazione albero
    t = create_tree(fp_in);

    // creazione specchio
    create_mirror(fp_out, t);
    fprintf(fp_out, "\n");

    // chiusura file
    fclose(fp_in);
    fclose(fp_out);

    return 0;
}

tree *create_tree(FILE *file){

    tree *t, *prec, *son;
    int i;

    // allochiamo lo spazio necessario
    t = (tree *)malloc(sizeof(tree));

    fscanf(file, "%d", &(t->num) ); // leggiamo il valore dal file e inseriamo nell'albero
    prec = NULL;                    // prec inizia da NULL

    for(i=0; i<t->num; ++i){
        son = create_tree(file); // chiamata ricorsiva
        son->prec = prec;       // aggiorniamo son
        prec = son;             // aggiorniamo prec
    }

    // alla fine del ciclo aggiorniamo last e prec
    t->last = prec;
    t->prec = NULL;

    return t;
}

void create_mirror(FILE *file, tree *t){

    tree *son;

    fprintf(file, "%d ", t->num); // inseriamo già il valore nel file di output
    son = t->last;                  // son parte dall'ultimo

    while(son != NULL){         // continuamo fino a che son diventa NULL, cioè finchè ci sono figli
        create_mirror(file, son); // chiamata ricorsiva
        son = son->prec;          // aggiorniamo son
    }

}

