#include <stdlib.h>
#include <stdio.h>

typedef struct _grafo{
    int figli;
    struct _grafo** sottoalbero;
} Albero;


void ribalta(Albero* grafo){

        if(grafo==NULL){
            printf("%d ", 0);
        }
        else{
            printf("%d ", grafo->figli);
            int i;
            for(i=grafo->figli-1; i>=0; i--){
                ribalta(*(grafo->sottoalbero+i));
            }
        }
    }


Albero* genera(){

    int val;
    scanf("%d", &val);


    if(val==0){
        return NULL;
    }

    Albero* grafo=(Albero*)malloc(sizeof(Albero));
    grafo -> figli=val;
    grafo-> sottoalbero= (_grafo**)malloc(sizeof(Albero*)*val);
    int i;
    for(i=0; i<val; i++){
        *(grafo->sottoalbero+i)= genera();
    }
    return grafo;
    }



    int main(){
        Albero *grafo= genera();
        ribalta(grafo);
        return 0;
    }
