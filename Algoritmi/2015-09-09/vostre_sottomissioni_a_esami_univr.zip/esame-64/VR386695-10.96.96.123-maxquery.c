#include <stdio.h>

void ordina_array3(int *array, int dim);

int main(){

    int n,q;
    long long int max=0;
    int l,i,j,h,k;
    int a,b;

    FILE *fin = fopen ("input.txt", "r");

    fscanf(fin, "%d %d", &n, &q);
    
    int array[n];
    int sum[n];

    for(h=0; h<n; h++){
        sum[h]=0; 
    }
   
    for(l=0; l<n; l++){
       fscanf(fin,"%d ",&array[l]);
    }

    for(i=0; i<q; i++){
        fscanf(fin,"%d %d",&a, &b);
        for(h=a-1; h<=b-1; h++){
            sum[h]++; //quante volte bisogna sommare il numero in quella posizione
        }
       
    }

    ordina_array3(array,n);
    ordina_array3(sum,n);

    for(k=0; k<n; k++){
        max=max+array[k]*sum[k];
    }


    FILE *fout = fopen ("output.txt", "w");

    fprintf(fout, "%lld\n", max);

    fclose(fin);
    fclose(fout);


    return 0;
}


//Decrescente
void ordina_array3(int *array, int dim){

    if(dim>=2){    


        int i,j,k;
        int dl, dr;
        j=0;
        k=0;
        dl=dim/2;
        dr=dim-dl;
    
        int left[dl];
        int right[dr];

        for(i=0; i<dim; i++){
            if(i<dl) { left[i]=array[i]; }
            else { right[i-dl]=array[i]; }
        }

        ordina_array3(left,dl);
        ordina_array3(right,dr);

        while(!(j==dl && k==dr)){
    
            if(j==dl) {array[j+k]=right[k]; k++;}
            else { if(k==dr) {array[j+k]=left[j]; j++;}
                   else { if(left[j]>=right[k]) {array[j+k]=left[j]; j++;}
                          if(left[j]<right[k]) {array[j+k]=right[k]; k++;}
                    }
            }
        }

    }



}


