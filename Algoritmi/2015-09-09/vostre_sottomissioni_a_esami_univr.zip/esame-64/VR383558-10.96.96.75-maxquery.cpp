#include <iostream>
#include <fstream>
#include <cassert>
#include <algorithm>

using namespace std;

const int MAXN = 200000;



int main(){
    long n,q,tmp,sum; // righe e colonne
    ifstream in("input.txt"); assert(in);
    in >> n;
    in >> q;
    
    long orig [n];
    long count [n];
    //
    for(int i=0;i<n;i++){
    in >> tmp;
    orig[i]=tmp;
    count[i] =0;
    }
    sort(&orig[0],&orig[n]);
    long q1,q2;    
    for(long i=0;i<q;i++){
    in >> q1 >> q2;
        for(long j=q1-1;j<=q2-1;j++){
            ++count[j];        
        }
    }
    sort(&count[0],&count[n]);
    sum =0;    
    for(long i=n-1;i>=0;i--){    
        if(count[i]==0){
            break;
        }
        else{
        sum+=count[i]*orig[i];
        }
    }
    ofstream out ("output.txt");
    out << sum;
    return 0;
}
