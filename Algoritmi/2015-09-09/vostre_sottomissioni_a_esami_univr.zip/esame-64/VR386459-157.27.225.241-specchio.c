#include <stdio.h>

#include <stdlib.h>
#define INPUT "input.txt"
#define OUTPUT "output.txt"

typedef struct node {
	int N;
	struct node *lastside;
	struct node *nextside;
} tree;

tree *inTree( FILE *f ) {
	tree *myTree, *prev, *next;
	int i;

	myTree = (tree *) malloc( sizeof( tree ) );

	fscanf( f, "%d", &(myTree->N) );
	prev = NULL;
	for ( i = 0; i < myTree->N; i++ ) {
		next = inTree( f );
		next->nextside = prev;
		prev = next;
	}
	myTree->lastside = prev;
	myTree->nextside = NULL;
	return myTree;
}

void outTree( FILE *f, tree *myTree ) {
	tree *next;

	fprintf( f, "%d ", myTree->N );
	next = myTree->lastside;
	while ( next != NULL ) {
		outTree( f, next );
		next = next->nextside;
	}
}

int main() {
	
	tree *myTree;

    FILE *in;
	in = fopen( INPUT, "r" );
	myTree = inTree( in );
	fclose( in );
	
    FILE *out = fopen( OUTPUT, "w" );
	outTree( out, myTree );
	fprintf( out, "\n" );
	fclose( out );
	return 0;
}

