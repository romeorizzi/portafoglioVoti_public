/* MATTEO CALABRIA VR389926 
    maxquery.c */

#include <stdio.h>
#include <stdlib.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"

#define MAX_N 200000

// variabili globali
int array[MAX_N];
int query_used[MAX_N];
int num_elements;
int num_query;

void swap_numbers(int *num1, int *num2);
void anna_solve(int *array, int start, int end);

int main(){

    FILE *fp_in, *fp_out;
    int inf, sup , flag;
    int i, j;
    long long int result;

    // apertura file
    fp_in = fopen(INPUT_FILE, "r");
    fp_out= fopen(OUTPUT_FILE, "w+");

    // lettura numero elementi e query
    fscanf(fp_in, "%d", &num_elements);
    fscanf(fp_in, "%d", &num_query);

    // lettura elementi dell'array e init query_used
    for(i=0; i<num_elements; ++i){
        fscanf(fp_in, "%d", &array[i]);
        query_used[i] = 0;    
    }

    // lettura query
    for(i=0; i<num_query; ++i){
        fscanf(fp_in, "%d %d", &inf, &sup);
        for(j=inf-1; j<sup; ++j)
            ++query_used[j];
    }

    // procedura di risoluzione
    anna_solve(array, 0, num_elements-1);
    anna_solve(query_used, 0, num_elements-1);

    // init valori di flag e result
    flag = 1;
    result = 0;

    for(i=num_elements-1; i>=0 && flag==1; --i){
        result += query_used[i] * array[i];
        if(query_used[i]==0)
            flag = 0; 
    }

    // stampa risultato su file
    fprintf(fp_out, "%lld", result);

    // chiusura dei file
    fclose(fp_in);
    fclose(fp_out);

    return 0;
}

// procedura di swap tra due numeri
void swap_numbers(int *num1, int *num2){

    int tmp = *num1;
    *num1 = *num2;
    *num2 = tmp;

}

void anna_solve(int *array, int start, int end){

    int p, left, right;

    if(start < end){

        p = array[start];
        left = start + 1;
        right = end + 1;

        while(left < right){
            if(array[left] < p)
                left += 1;
            else{
                right -= 1;
                swap_numbers(&array[left], &array[right]);
            }   
        }

        left -= 1;
        swap_numbers(&array[start], &array[left]);
        anna_solve(array, start, left);
        anna_solve(array, right, end);

    }

}


