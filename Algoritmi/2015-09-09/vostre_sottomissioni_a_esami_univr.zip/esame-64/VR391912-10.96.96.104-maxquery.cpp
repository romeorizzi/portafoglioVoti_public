#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

int N, M;
int res[100000];
int sums[100000];
int queries[100000][2];
vector<int> v;
vector<int> intersect;
vector<int> intersect_to_order;

bool desc(int a, int b){
    return (a > b);
}

int main(){
    ifstream input("input.txt");
    input >> N >> M;
    v.reserve(N);
    intersect.resize(N);
    intersect_to_order.resize(N);
    int temp;
    for(int i = 0;i < N;i++){
        input >> temp;
        v.push_back(temp);
    }
    
    sort(v.begin(), v.end(), desc);
    long long int sum = 0;
    for(int i = 0;i < M;i++){
        input >> queries[i][0] >> queries[i][1];    
        //cout << "l = " << queries[i][0] << " r =  " << queries[i][1] << endl;
        
        for(int j = queries[i][0];j <= queries[i][1];j++){
            intersect.at(j - 1) += 1;
            intersect_to_order.at(j - 1) += 1;
            //cout << "upping intersect at " << j-1 << endl;    
        }
    }
    
   // for(int i = 0;i < N;i++)
        //cout << intersect.at(i) << " ";
        
    sort(intersect_to_order.begin(), intersect_to_order.end(), desc);
    
    //find max intersect
    int max = 0;
    int index = 0;
    for(int i = 0; i < N;i++){
        max = intersect_to_order.at(i);
        for(int j = 0;j < N;j++)
            if(intersect.at(j) == max){
                index = j;
                intersect.at(j) = 0;
                break;
            }
        
        res[index] = v.at(i);
    
    }
     //cout << endl;  
     sums[0] = 0;
     //vector sum
     for(int i = 1;i <= N;i++){
        sums[i] = sums[i-1] + res[i-1];
        //cout << sums[i] << " ";
        }
        //cout << endl;
     
     //cout <<"sol:\n";
    for(int i = 0;i < M;i++){
        sum += sums[queries[i][1]] - sums[queries[i][0] - 1];
//        //cout << sums[queries[i][1]] - sums[queries[i][0] - 1] << " ";
        
    }
    
    
        
    //cout << endl;
        
   
    
    ofstream output("output.txt");
    
    output << sum;
    /*
    for(vector<int>::iterator i;i != v.end();i++){
    
        //cout << v << " ";
    }
    */
        
    
    return 0;
}
