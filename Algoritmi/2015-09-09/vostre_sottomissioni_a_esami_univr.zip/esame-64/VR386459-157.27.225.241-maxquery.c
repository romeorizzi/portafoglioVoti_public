#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define INPUT "input.txt"
#define OUTPUT "output.txt"

#define N 1000000

int Array[N];
int Query[N];

//soa : Size of Array
int soa;
//soa : Size of Query
int soq;

void swapArray (int *x, int *y){
    int tmp=*x;
    *x=*y;
    *y=tmp;
}

void maxAQCounter(int *array, int start, int end){

    int pivot,left,right;

    if (end>start){
        pivot=array[start];
        left=start+1; 
        right=end+1;
        while (left<right){
            if (array[left]<pivot){
                left++;
            }else{
                right--;
                swapArray(&array[left],&array[right]);
            }
        }
        left--;
        swapArray(&array[start],&array[left]);
        maxAQCounter(array,start,left);
        maxAQCounter(array,right,end);    
    }
}

void *readArray( FILE *in, int soa ) {
    int i;
	for ( i = 0; i < soa; ++i ) {
	   fscanf( in, "%d", &Array[i]);
       Query[i]=0;    
    }
}

void *readQuery( FILE *in, int soq ) {
    int i,j;
    int low,up;
	for ( i = 0; i < soq; ++i ) {
		fscanf( in, "%d %d", &low, &up );
        for (j = low-1; j < up; ++j ) ++Query[j];
    }
}

int main(int argc,char* argv[]){
    
    
    //Read from INPUT
    //------------------------------------------------------------------
    FILE *in = fopen( INPUT, "r+" );
    fscanf( in, "%d", &soa );
    fscanf( in, "%d", &soq );
    readArray(in,soa);
    readQuery(in,soq);
    fclose(in);    
    //------------------------------------------------------------------
    maxAQCounter(Array,0,soa-1);
    maxAQCounter(Query,0,soq-1);    

    int flag=1;
    int acc=0;
    int i;
    for ( i = soa-1; i >=0 && flag==1; --i ) {
        acc+=Query[i]*Array[i];
        if (Query[i]==0) flag=0;
    }

    //Write to OUTPUT
    //------------------------------------------------------------------
    FILE *out = fopen( OUTPUT, "w+" );
    fprintf( out, "%d", acc );
    fclose( out );
    return 0;
}

