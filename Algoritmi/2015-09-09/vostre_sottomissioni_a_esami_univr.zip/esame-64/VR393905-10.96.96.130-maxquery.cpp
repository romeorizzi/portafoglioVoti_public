#include <stdio.h>
#include <stdlib.h>

using namespace std;

int* array;
int* tops;
int* pos;
int** queries;

void swap(int& a, int& b)
{
    int temp = a;
    a = b;
    b = temp;
}

int pivotP(int first, int last)
{
    int p = first;
    int pivotElement = tops[first];

    for(int i = first+1; i <= last; i++)
    {
        if(tops[i] > pivotElement)
        {
            p++;
            swap(tops[i], tops[p]);
            swap(pos[i], pos[p]);
        }
    }

    swap(tops[p], tops[first]);
    swap(pos[p], pos[first]);

    return p;
}

void quickSortP(int first, int last)
{
    int pivotElement;

    if(first < last)
    {
        pivotElement = pivotP(first, last);
        quickSortP(first, pivotElement-1);
        quickSortP(pivotElement+1, last);
    }
}

int compare(const void* a, const void* b)
{
    return(*(int*)b-*(int*)a);
}

int main(){

    int n, q;

    FILE *input = fopen("input.txt", "r");
    fscanf(input, "%d %d", &n, &q);

    array = new int[n];
    tops = new int[n]();
    pos = new int[n];
    queries = new int*[q];

    for (int i = 0; i<n; i++) {
        fscanf(input, "%d", &array[i]);
        pos[i] = i;
    }
    
    for (int i = 0; i<q; i++) {
        queries[i] = new int[2];
        fscanf(input, "%d %d", &queries[i][0], &queries[i][1]);
        queries[i][0]--;
        queries[i][1]--;
        for(int j = queries[i][0]; j <= queries[i][1]; j++)
            tops[j]++;
}

    quickSortP(0, n-1);

    qsort(array, n, sizeof(int), compare);

    for (int i = 0; i < n; i++)
        tops[pos[i]] = array[i];

    long long int somma = 0;

    for (int i = 0; i < q; i++) {
        for (int j = queries[i][0]; j <= queries[i][1]; j++)
            somma += tops[j];
    }

    FILE *output = fopen("output.txt", "w");

    fprintf(output, "%lld", somma);
    
}
