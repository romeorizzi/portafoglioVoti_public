#include <stdio.h>
#include <stdlib.h>



#define INPUT "input.txt"
#define OUTPUT "output.txt"

#define N 100000

int vect[N];
int query[N];
int n_elem;
int n_query;

void quick(int* vect,int start,int end);
void swap(int* a, int* b);

int main(){
    FILE* f_in;
    FILE* f_out;
    int inf,sup,j;
    long int acc;
    int flag,i;
    f_in = fopen(INPUT,"r");
    f_out = fopen(OUTPUT,"w");
    i = 0;
    fscanf(f_in,"%d",&n_elem);
    fscanf(f_in,"%d",&n_query);
    for(i = 0; i < n_elem; ++i){
        fscanf(f_in,"%d",&vect[i]);
        query[i] = 0;
    }
    for(i = 0; i < n_query; ++i){
         fscanf(f_in,"%d %d",&inf,&sup);
         for(j = inf - 1; j < sup; ++j)
            ++query[j];
    }
    
    quick(vect,0,n_elem-1);
    quick(query,0,n_elem-1);
    flag = 1;

    acc = 0;

    for(i = n_elem-1;i >= 0 && flag == 1; --i){
        acc+=query[i]*vect[i];
        if(query[i] == 0)
            flag = 0;
     }
    fprintf(f_out,"%ld",acc);
    fclose(f_in);
    fclose(f_out);
    return 0;
}

void swap(int* a,int* b){
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

void quick(int* vect,int start,int end){
    int pivot,l,r;
    if(end > start){
        pivot = vect[start];
        l = start + 1;
        r = end + 1;
        while(l < r)
            if(vect[l] < pivot)
                l++;
            else{
                r--;
                swap(&vect[l],&vect[r]);
            }
        l--;
        swap(&vect[start],&vect[l]);
        quick(vect,start,l);
        quick(vect,r,end);
    }
}
    








        





 
            
