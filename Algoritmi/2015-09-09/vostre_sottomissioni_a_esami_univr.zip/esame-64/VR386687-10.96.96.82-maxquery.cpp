#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

int fattoriale(int n){
    int f=1;
    for(int c = 1; c <= n; c++)
        f *= c;
    return f;
}

void swap(int *v, int i, int j){
    int aux;
    aux = v[i];
    v[i] = v[j];
    v[j] = aux;
}

int trovaSomma(int *a, int **q, int N, int Nq)
{
    int somma = 0;
    int old_somma = 0;
    int permutazioni = fattoriale(N);
    int index_x = 0;
    int index_y = 1;
    //for all permutation
    for(int k = 0; k < permutazioni; k++)
    {
        if( k > 0)
            swap(a, (index_x++)%N+1, (index_y++)%N+1);


        for(int i = 0; i < Nq; i++){
            //inizio
            int start = q[i][0];
            int end = q[i][1];
            int index = start;
            while(index <= end)
            {
                somma += a[index];
                index++;
            }
        }
        if(somma > old_somma)
            old_somma = somma;
        somma = 0;
    }

    return old_somma;
}

int main(void){

    ofstream output;
    ifstream input;

    int Nq = 2;
    int N = 2;

    input.open("input.txt");
    input>>N;
    input>>Nq;


    int** q = new int*[Nq];
    for (int i = 0; i < Nq; i++)
        q[i] = new int[2];

    int* a = new int[N];
    for (int i = 1; i < N+1; i++)
        input>>a[i];

    for (int i = 0; i < Nq; i++)
        for (int j = 0; j < 2; j++)
            input>>q[i][j];


    int result = trovaSomma(a, q, N, Nq);

    output.open("output.txt");
    output<<result<<endl;

    return 0;
}
