#include <stdio.h>
#include <stdlib.h>

typedef struct node{
    int N;
    struct node *last;
    struct node *prec;
}tree;

void print(tree *t);
tree *read(FILE *f);

int main(){
    FILE *input, *output;
    input = fopen("input.txt","r");
    tree *t;
    t = read(input);
    fclose(input);
    print(t);
    printf("\n");
    return 0;
}

tree *read(FILE *f){
    tree *t,*precedente,*s;
    t = (tree*)malloc (sizeof(tree));
    scanf("%d",&(t->N));
    fprintf(f,"%d",t->N);
    precedente = NULL;
    int k;
    for(k = 0; k < t->N; k++){
        s = read(f);
        s ->prec = precedente;
        precedente = s;
    }
    t->last = precedente;
    t->prec = NULL;
    return t;
}

void print(tree *t){
    tree *T;
    printf("%d ",t->N);
    T = t->last;
    while(T != NULL){
        print(T);
        T = T->prec;
    }
}
