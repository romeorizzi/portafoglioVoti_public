#include <iostream>
#include <string>
#include <sstream>

using namespace std;

const int N = 1000000;
int TREE[ N ];
int REFLEXED[ N ];

int POS;

int reflex(int r)
{
    int sons = 1;
    //cout << "TREE[r] " << TREE[r] << endl;

    for(int i=0; i < TREE[r]; i++)
    {
       // cout << "r+sons " << r + sons << endl;
        sons += reflex(r + sons);
    }
    //cout << "ass alla pos " << TREE[r] << POS << endl;

    REFLEXED[POS--] = TREE[r];
    return sons;

}

int main (){


    int i = 0;

    string tree;
    getline(cin,tree);
    stringstream ss;
    ss << tree;

    while(ss >> TREE[i])
         i++;

    i--;
    POS = i;
    reflex(0);

    for(int k = 0; k <= i; k++)
        cout << REFLEXED[k] << " ";




  return 0;

}
