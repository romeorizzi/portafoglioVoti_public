#include <stdio.h>
#include <stdlib.h>

//Struttura albero
typedef struct _grafo {
	int figli;
	struct _grafo** stratoInf;
} Albero;

//Prima chiamata ricorsiva presente nel main, con lettura dell'input
Albero* creazioneGrafo() {
	
    // lettura dell'input sul terminale
    int val;    	
    int b=scanf("%d", &val);
    if(b==0){    
    printf( "errore lettura\n" );
	}
    
    if(val == 0) {
		return NULL;
	}
	Albero* grafo = malloc(sizeof(Albero));
	grafo->figli = val;
	grafo->stratoInf = malloc(sizeof(Albero*)*val);
	int i;
	for(i=0;i<val; i++) {
		*(grafo->stratoInf+i) = creazioneGrafo();
	}
	return grafo;
}

// Funzione per la creazione dell'albero specchio (principale), con conseguente scrittura su stdout
void specchio(Albero* grafo) {
	if(grafo == NULL) {

		printf("%d ", 0);
	} else {

		printf("%d ", grafo->figli);
		
		int i;
		for(i=grafo->figli-1;i>=0; i--) {
			specchio(*(grafo->stratoInf+i));
		}
	}
}


/********************************************************MAIN***************************************************/
int main() {

	Albero* grafo = creazioneGrafo();
		
	specchio(grafo);


	return 0;
}

