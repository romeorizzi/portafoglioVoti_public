#include <iostream>
#include <list>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> input;
vector<int> temp;
int N;
int Q;
int a,b;

int main(){

    ifstream fin("input.txt"); 
    //assert( fin );
	fin >> N;
    fin >> Q;
    input.resize(N);
    temp.resize(N);
    for(int i=0;i<N;i++){
        fin >> input[i];
    }
    for(int i=0;i<Q;i++){
        fin >> a;
        fin >> b;
        for(int j=a ; j<= b ; j++){
            temp[j-1]++;
        }
    }
    int somma = 0;
    sort(input.begin(),input.end());
    sort(temp.begin(),temp.end());
    for(int i=0;i<N;i++){
            somma += input[i] * temp[i];
        
    }
    fin.close();
    ofstream fout("output.txt");
    fout << somma;
    fout.close();
}

