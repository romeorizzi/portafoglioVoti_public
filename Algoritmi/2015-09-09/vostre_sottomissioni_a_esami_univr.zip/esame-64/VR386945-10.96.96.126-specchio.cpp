#include <iostream>  

using namespace std;
int reverse_child(int r);

const int N_MAX = 1000000;
int n,p;
int tree[N_MAX];
int sol[N_MAX];

int main() {

  n = 0;                                // contatore dei nodi
  int myTree = 1;                       // considero già la radice 

  for(int i = 0; i < myTree ; i++)
  {
     cin >> tree[n];
     myTree += tree[n];  // sommo alla radice i num di figli dell'albero
    // cout << " myTree -- " << myTree << endl;
     n++;
  }
   
 //cout << " n total -- " << n << endl;  

  p = n-1; // considero N-1 nodi, la radice non cambia posizione!

  reverse_child(0);

  for(int i = 0; i < n; i++)  
  {
    cout << sol[i] << " ";
  }
  cout << endl;

  return 0;
}



int reverse_child(int r) {
  int childs = 1; 
  for(int i = 1; i <= tree[r]; i++) 
    {
        childs += reverse_child(r + childs);
    }
  sol[p--] = tree[r];
  return childs;
}


