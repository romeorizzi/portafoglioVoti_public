#include <iostream>
#include <fstream>

using namespace std;

const int MAX_N=1000000;
int n,d,pos;
int a[MAX_N],s[MAX_N];

int specchio(int rad) {
      int desc=1;
      for(int i=1;i<=a[rad];i++)
         desc+=specchio(rad+desc);
      s[pos--]=a[rad];
      return desc;
    }


    int main() {

      ifstream in("input.txt");
      n=0;
      d=1;
      while(n<d)
         { in>>a[n];
           d+=a[n];
           n++;
          }
      pos=n-1;
      specchio(0);
      ofstream out("output.txt");
       for(int i=0; i<n;i++)
          out<<s[i]<<" ";
      return 0;
    }



