#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

class Node{
public:
    int value;
    Node *last;
    Node *pre;

};

ofstream output;
ifstream input;


Node *readTreeFromFile() {
    Node *a, *prev, *subtree;
    int i;

    a = new Node();

    input >> a->value;
    prev = NULL;

    for(int i = 0; i < a->value; i++){
        subtree = readTreeFromFile();
        subtree->pre = prev;
        prev = subtree;
    }
    a->last = prev;
    a->pre = NULL;
    return a;
}


void writeTreeInFile(Node *a){
    Node *subtree;
    output << " " << a->value;
    subtree = a->last;

    while(subtree != NULL){
        writeTreeInFile(subtree);
        subtree = subtree->pre;
    }
}



int main(void){
    input.open("input.txt");
    output.open("output.txt");
    Node *A;
    A = readTreeFromFile();
    writeTreeInFile(A);
    output << endl;
    input.close();
    output.close();
}
