#include <iostream>
#include <cassert>
#include <fstream>
#include <stdio.h>

#define MAX_N 200000
#define MAX_Q 200000

using namespace std;

//mergesort
void merge(int *a, int left, int center, int right) {
    int aux[right+1];
    int i, j;
    for(i = center+1; i > left; i--) {
        aux[i-1] = a[i-1];
    }
    for(j = center; j < right; j++) {
        aux[right+center-j] = a[j+1];
    }
    for(int k = left; k <= right; k++) {
        if(aux[j] < aux[i]) {
            a[k] = aux[j--];
        } else {
            a[k] = aux[i++];
        }
    }
}

void mergesort(int *a, int left, int right) {
    if(left < right) {
        int center = (left+right)/2;
        mergesort(a, left, center);
        mergesort(a, center+1, right);
        merge(a, left, center, right);
    }
    return;
}

int main()
{
    int N, Q;

    ifstream input("input.txt");
    input >> N >> Q;

    int array[N]; //array del'input
    int nuovo_array[N]; //array che soddisfa la somma massima
    int richieste[N]; //array che contiene per ogni posizione quante volte viene richiesta dalle query
    long long int prefix_sum[N+1]; //array delle somme prefisse
    int l[Q]; //array delle query (left bound)
    int r[Q]; //array delle query (right bound)

    //leggo l'array
    for(int i = 0; i < N; i++) {
        input >> array[i];
        nuovo_array[i] = -1;
        richieste[i] = 0;
    }

    //compilo l'array delle richieste
    for(int i = 0; i < Q; i++) {

        input >> l[i] >> r[i];
        for(int j = l[i]-1; j <= r[i]-1; j++) {
            richieste[j]++;
        }

    }
    input.close();
    //ordino in ordine crescente l'input
    mergesort(array, 0, N-1);

    int max = 0;
    int pos;
    //compilo l'array che soddista le somme massime
    for(int i = N-1; i >= 0; i--) {
        max = 0;
        for(int j = 0; j < N; j++) {
            //posizione in cui va messo il prossimo numero più grande in base a quanto viene richiesto
            if(richieste[j] >= max && nuovo_array[j] == -1) {
                max = richieste[j];
                pos = j;
            }
        }
        nuovo_array[pos] = array[i];

    }

    //creo l'array delle somme prefisse
    for(int i = 0; i <= N; i++) {
        if(i == 0) {
            prefix_sum[0] = 0;
        } else {
            prefix_sum[i] = prefix_sum[i-1] + nuovo_array[i-1];
        }
    }

    long long int somma = 0;
    //eseguo le query
    for(int i = 0; i < Q; i++) {
        somma += prefix_sum[r[i]] - prefix_sum[l[i]-1];
    }

    ofstream output("output.txt");


    output << somma << endl;

    output.close();


    return 0;
}

