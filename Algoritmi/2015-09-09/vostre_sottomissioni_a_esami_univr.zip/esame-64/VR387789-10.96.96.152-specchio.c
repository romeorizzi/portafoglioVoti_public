#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

int specchiaAlbero(int pos);

int alberoSpecchiato[1000000]; // (da switchare)
int alberoSpecchiato2[1000000]; // (switchato)
int albero[1000000]; // input
int size = 0; // decrementata durante il calcolo
int size2; // copia della size originale

int main()
{
    FILE *F;
    int i;

    F = fopen("input.txt","r");
    while(!feof(F))
    {
       (fscanf(F, "%d", &albero[size++]));
    }
    size--; // ora so quanto è lungo il vettore dell'albero fornito
    size2=size;
    fclose(F);

    // la soluzione equivale ad una lettura da destra dell'albero fornito (prendo sempre il figlio a dx al posto di quello a sx)
    // una dfs con scelta di prevalenza a destra praticamente.

    specchiaAlbero(0);

    for(i=0; i < size2-1; i++) // eseguo lo switch
        alberoSpecchiato2[i] = alberoSpecchiato[i+1];

    alberoSpecchiato2[size2-1]=0; // inserisco il valore relativo l'ultimo figlio (0 in quanto è ultimo e non ha altri figli)

    F = fopen("output.txt", "w");
    for(i=0; i<size2; i++)
        fprintf(F, "%d ",  alberoSpecchiato2[i]);
    fclose(F);

    return 0;
}

specchiaAlbero(int pos) // fornisco la radice ogni volta
{
    int i;
    int numFigli = 1; // parto da 1 considerando che come figlio c'è almeno il nodo stesso

    // il primo nodo sarà ovviamente uguale a quello fornito in input

    for(i=1; i <= albero[pos]; i++) // scorro tutti i nodi
        numFigli += specchiaAlbero(pos + numFigli); // e aggiorno il valore dei figli

    alberoSpecchiato[size--] = albero[pos]; // diminuisco la size dell'albero e trovo il rispettivo valore dell'albero specchiato

    return numFigli; // ogni volta ritorno il numero di figli a partire dal sottoalbero che parte da pos (indicante la radice)
}
