#include <stdio.h>
#define N 1000000

void stampaNodi();
void stampaOffset();
int calcolaOffset(int id);
void chiamaRicorsiva(int id);
void push(int id);
int pop();

FILE *fr, *fw;
int albero[N], n = 0, offset[N], stack[N], cima = -1;

int main()
{
    int i = 0;
    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");

    while(fscanf(fr, "%d", &albero[i]) != -1){
        i++;
        n++;
    }

    //stampaNodi();
    calcolaOffset(0);
    //stampaOffset();

    fprintf(fw, "%d ", albero[0]);
    chiamaRicorsiva(0);

    while(cima != -1)
        fprintf(fw, "%d ", albero[pop()]);

    //printf("\n");
    return 0;
}

void chiamaRicorsiva(int id){
    int figlio, id_figlio;

    if(albero[id] == 0){
        push(id);
        return;
    }

    id_figlio = id+1;
    for(figlio=1; figlio<=albero[id]; figlio++){
        if(albero[id_figlio] > 0) chiamaRicorsiva(id_figlio);
        push(id_figlio);
        id_figlio = id_figlio + offset[id_figlio];
    }
}

int calcolaOffset(int id){
    int figlio, id_figlio, off=0;

    if(albero[id] == 0) return 1;

    id_figlio = id +1;
    for(figlio=1; figlio<=albero[id]; figlio++){
        offset[id_figlio] = calcolaOffset(id_figlio);
        off = off + offset[id_figlio];
        id_figlio = id_figlio + offset[id_figlio];
    }
    off++;
    return off;
}

void push(int id){
    stack[++cima] = id;
}

int pop(){
    return stack[cima--];
}


void stampaOffset(){
    int i;
    printf("\n");
    for(i=0; i<n; i++){
        fprintf(stdout, "%d ", offset[i]);
        if(i == 10){
            printf("\n");
            printf("\n");
            printf("\n");
        }
    }
}

void stampaNodi(){
    int i;

    for(i=0; i<n; i++){
        fprintf(stdout, "%d ", albero[i]);
        if(i == 10) printf("\n");
    }

}
