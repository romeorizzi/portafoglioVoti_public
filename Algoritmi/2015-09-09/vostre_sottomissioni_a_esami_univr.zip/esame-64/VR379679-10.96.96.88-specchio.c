/* Esame Algoritmi

   Alessandra Fin   Vr379679

*/

#include <stdio.h>
#include <stdlib.h>

typedef struct n {
    struct n **S;
    short N;
} nodo;

void get(nodo *n) {
    short i;
    scanf(" %d", &n->N);
    n->S = (nodo**) calloc (n->N, sizeof(nodo*));

    for(i=0; i < n->N; i++)
        get(n->S[i] = (nodo*)malloc(sizeof(nodo)));
}

void print(nodo *n) {
    short i;
    printf(" %d", n->N);
    for(i=n->N-1; i>=0; i--)
        print(n->S[i]);
}

int main() {
    nodo albero;
    get(&albero);
    print(&albero);

    return 0;
}
