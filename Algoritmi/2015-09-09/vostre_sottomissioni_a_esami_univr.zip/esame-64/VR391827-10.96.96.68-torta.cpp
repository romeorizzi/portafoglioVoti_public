#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
int main(){
    ifstream inf("input.txt");
    ofstream outf("output.txt");
    int n;
    int m;
    int a, b;
    int i, j, k, l;
    int** arr;
    inf >> n;
    inf >> m;
    inf >> a;
    inf >> b;
   // cout << n << " " << m << " " << a << " " << b << endl;
    arr = new int*[n+1];
    for(i = 0; i < n+1; i++){
        arr[i] = new int[m+1];
    }
   // cout << "HEllo" << endl;
    int aux;
    int value = 0;
 for(i = 1; i < n+1; i++){
        for(j = 1; j < m+1; j++){
            inf >> arr[i][j];
}}
    for(i = 1; i < n+1; i++){
        for(j = 1; j < m+1; j++){
 //           inf >> aux;
            //cout << " h " << aux << endl;
            arr[i][j] = arr[i][j] + arr[i-1][j] + arr[i][j-1] - arr[i-1][j-1];
           // cout << arr[i][j] << " ";
            for(k = 1; k <= i; k++){
                for(l = 1; l <= j; l++){
                    aux = arr[i][j] - arr[k-1][j] - arr[i][l-1] + arr[k-1][l-1];
                  //  cout << aux << " ";
                    if(aux <= b && aux >= a){
                        value++;
                    }
                }
            }
        }
        //cout << endl;
    }
    outf << value << endl;
    

}
