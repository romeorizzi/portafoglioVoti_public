#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<int> input;
vector<int> ris;
int temp;
int N;




int main(){

    ifstream fin("input.txt"); 
    //assert( fin );
	fin >> N;
    input.resize(N);
    ris.resize(N);
    
    int a=0;
    int b=0;

    for(int i = 0; i < N; ++i){
		fin >> input[i];
	}
    fin.close();
    int s=0;
    int d=0;
    int x=0;

    ris[0]=input[0];
    for(int i = 1; i < N; ++i){
        x=N-i-input[i];
		ris[x] = input[i];
        for(int j = 0; j < input[i]; ++j){
            if(i+1 < N){
		        ris[++x]=input[i+1];                
            }
	    }
        i += input[i];
	}
   
    ofstream fout("output.txt");
    for(int i=0;i<N;i++)
        fout << ris[i] << " ";
    fout.close();
}
