//#define NDEBUG  
#include <cassert>
#ifndef NDEBUG
#endif
#include <fstream>

using namespace std;

const int MAX_N = 1000000;
int n;
ifstream input;
ofstream output;

int tree[MAX_N]; 
int specchio[MAX_N]; 

int posizione;
int specchio_fun(int radice) {
  int d = 1;
  for(int i = 1; i <= tree[radice]; i++){
    d += specchio_fun(radice + d);
    }
  specchio[posizione--] = tree[radice];
  return d;
}


int main() {
  input.open("input.txt"); 
  assert( input );
  n = 0; 
  while( input >> tree[n] ) {
     n++;
  }
  input.close();

  posizione = n-1; 
  specchio_fun(0);
  output.open("output.txt");

  for(int i = 0; i < n; i++){ 
    output << specchio[i] << " ";
  }
  output << endl;
  output.close();

  return 0;
}
