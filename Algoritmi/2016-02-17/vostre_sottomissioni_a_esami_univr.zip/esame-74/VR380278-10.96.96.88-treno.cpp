#include <iostream>
#include <fstream>
using namespace std;

int K,N;
ifstream in("input.txt");
ofstream out("output.txt");

void calcola(int j) {
    if (j==10){
        out << (j-2)/2 << " " << j-1 << endl;
        return;
    }
    out << (j-2)/2 << " " << j-1 << endl;
    out << j-3 << " " << (j-2)/2 << endl;
    calcola(j-2);
}

int main()
{
    in >> N;
    K = 2*N-3;
    out << K << " " << N << endl;
    calcola(2*N+2);
    out << 6 << " " << 4 << endl;
    out << 2 << " " << 6 << endl;
    out << 5 << " " << 2 << endl;
    out << 2*N+1 << " " << 5 << endl;
    return 0;
}
