#include <cassert>
#include <fstream>

using namespace std;

int n, m;
int maxSottoseq, result;
int temp;


int main() {
    ifstream fin("input.txt"); assert( fin );
    fin >> n >> m;

    char a[n+1];
    char b[m+1];
    int matrix[n+1][m+1];

    for(int i = 0; i < n; i++)
        fin >> a[i];
    for(int i = 0; i < m; i++)
        fin >> b[i];
    fin.close();

/*
    cout << n << " " << m << "\n";
    for(int i = 0; i < n; i++)
        cout << a[i];
    cout << "\n";
    for(int i = 0; i < m; i++)
        cout << b[i];
*/
    for(int i = n; i >= 0; i--) {
        for(int j = m; j >= 0; j--) {
            if((i == n) || (j == m))
                matrix[i][j] = 0;
            else if(a[i] != b[j]) {
                temp = max(matrix[i+1][j], matrix[i][j+1]);
                matrix[i][j] = max(temp, matrix[i+1][j+1]);
                }
            else
                matrix[i][j] = matrix[i+1][j+1] + 1;
        }
    }

    maxSottoseq = matrix[0][0];
    result = m + n - (maxSottoseq * 2);

    ofstream fout("output.txt");
    fout << result << endl;
    fout.close();
    return 0;
}

