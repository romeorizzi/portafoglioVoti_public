#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <malloc.h>
#include <assert.h>
#include <string.h>

#define MAX_DIM_ARRAY 100000

using namespace std;

string V,W;

int minnum(int a, int b, int c){
    int minimo=a;
    if (b<minimo) minimo = b;
    if (c<minimo) minimo = c;
    return minimo;
}

int minima_distanza(char *x, char *y, int m, int n){
    register int i,j;
    int distance=0;

    int *pre=(int *)malloc((n+1)*sizeof(int));
    int *cur=(int *)malloc((n+1)*sizeof(int));
    int *temp;

    memset((void*) pre,1,sizeof(int)*(n-1));

    for (int i=1; i<=m; i++){
        cur[0]=1;
        for(j=1;j<=n;j++)
            if (x[i-1] != y[j-1])
                cur[j]=minnum(cur[j-1],pre[j-1], pre[j])+1;
            else
                cur[j] = pre[j-1];

        temp = pre; pre=cur; cur=temp;
        memset((void*) cur,0,sizeof(int)*(n-1));
    }

    distance=pre[n];
    free(cur);
    free(pre);

    return distance-1;
}

int main()
{
    FILE *file_inp, *file_out;
    int N, M;
    char *p, *q, buffer[200];

    file_inp = fopen("input.txt","r");
    file_out = fopen("output.txt","w");

    fscanf(file_inp, "%d %d", &N, &M);

    assert(N<MAX_DIM_ARRAY || M<MAX_DIM_ARRAY || N>0 || M>0);

    p = (char *) malloc(sizeof(char)*N);
    q = (char *) malloc(sizeof(char)*M);

    fscanf(file_inp, "%s\n", &buffer);

    for ( int i = 0; i < N; i++){
        p[i] = (char) buffer[i];
    }

    fscanf(file_inp, "%s\n", &buffer);

    for ( int i = 0; i < M; i++){
        q[i] = (char) buffer[i];
    }

    //cout << p << "#" << q << "#" << endl;

    int val_minimo = minima_distanza(p,q, N, M);
    int x=M-(N - val_minimo)+val_minimo;

    //printf("%d", (abs(x
    fprintf(file_out, "%d", (abs(x)));

    free(p);
    free(q);

    return 0;
}
