#include <iostream>
#include <vector>
#include <fstream>
 
using namespace std;
ifstream fin("input.txt");
ofstream fout("output.txt");

int main(){
    int numero_container = 0;
    fin >> numero_container;
    
    fout << 2 * numero_container - 3 << " " << numero_container << endl;
  
    int posti =  2 * numero_container + 2;
   
    while(posti != 10){
         fout << (posti-2)/2 << " " << posti-1 << endl;
         fout << posti-3 << " " << (posti-2)/2 << endl;
         posti-=2;
    }
    fout << (posti-2)/2 << " " << posti-1 << endl;

    fout << 6 << " " << 4 << endl;
    fout << 2 << " " << 6 << endl;
    fout << 5 << " " << 2 << endl;
    fout << 2*numero_container+1 << " " << 5 << endl;

    fout.close();
    fin.close();
}

