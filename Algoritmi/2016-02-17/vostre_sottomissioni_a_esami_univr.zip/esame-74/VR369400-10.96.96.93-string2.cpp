#include <iostream>
#include <vector>
#include <fstream>
#include <string>
 
using namespace std;
ifstream fin("input.txt");
ofstream fout("output.txt");

#define MIN3(a,b,c) ((a) < (b) ? ((a) < (c) ? (a) : (c)) : ((b) < (c) ? (b) : (c)))
#define MIN2(a,b,c) ((a) < (b) ? (a) : (b))
int distanza(string s1, string s2 ,int len_s1, int len_s2){
      
    int dp[len_s1+1][len_s2+1];

    for(int i=0; i <= len_s1;i++){
        for(int j=0; j <= len_s2; j++){
            if(i==0)
                dp[i][j] = j;   
            else if(j==0)
                dp[i][j]=i;
            else if(s1.at(i-1) == s2.at(j-1))
                dp[i][j] = dp[i-1][j-1];
            else
                dp[i][j] = 1 + MIN3(dp[i][j-1], dp[i-1][j], dp[i-1][j-1]);
        }
    }
    return dp[len_s1][len_s2];
}

int main(){
    int len_s1, len_s2;
    //char* s1, s2;
       string s1, s2;
    fin >> len_s1 >> len_s2;

   
   // s1= (char*) calloc(len_s2, sizeof(char));
    getline(fin,s1); // evita stringa vuota
    getline(fin,s1);
    getline(fin,s2);

    //cout << "len_s1: " << len_s1 << " len_s2: " << len_s2 << endl; 
    //cout << "s1: "<< s1 << endl;
    //cout << "s2: "<< s2 << endl;

    fout << distanza(s1,s2,len_s1,len_s2) << endl;

}
