#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
#include <utility>

using namespace std;

int num_coin;
int k;

ifstream in("input.txt");
ofstream out("output.txt");

void spost(int j)
{
    if(j == 10) {
        out << (j-2)/2 << " " << j-1 << endl;
        return;
    }
    out << (j-2)/2 << " " << j-1 << endl;
    out << j-3 << " " << (j-2)/2 << endl;
    spost(j-2);
}

int main() 
{
    in >> num_coin;
    k = 2*num_coin-3;
    out << k << " " << num_coin << endl;
    spost(2*num_coin+2); 
    out << 6 << " " << 4 << endl;
    out << 2 << " " << 6 << endl;
    out << 5 << " " << 2 << endl;
    out << 2*num_coin+1 << " " << 5 << endl;

    return 0;
    
}
