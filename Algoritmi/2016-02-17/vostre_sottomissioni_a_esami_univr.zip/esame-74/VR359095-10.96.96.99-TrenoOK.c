#include <stdio.h>
#include <stdlib.h>

const int MAXN = 1000;

int N;

FILE *in,*out;

void dispari(int N, int inizio, int ultimi)
{

    fprintf(out,"%d %d\n",2+inizio,ultimi);
    fprintf(out,"%d %d\n",ultimi-1,2+inizio);
    fprintf(out,"%d %d\n",2*N-2+inizio,ultimi-1);
    fprintf(out,"%d %d\n",ultimi,2*N-2+inizio);

    if(N > 3)
        dispari(N-2,inizio+2, ultimi);
}

void pari(int N, int inizio, int ultimi)
{
    fprintf(out,"%d %d\n",N+inizio,ultimi);
    fprintf(out,"%d %d\n",2*N-2+inizio,N+inizio);
    fprintf(out,"%d %d\n",2+inizio,2*N-2+inizio);
    fprintf(out,"%d %d\n",2*N-3+inizio,2+inizio);

    if (N > 4)
        dispari(N-3,inizio+2, ultimi-4);
        fprintf(out,"%d %d\n",2*N+1+2*inizio,2*N-3+inizio);
}

int main()
{
    in=fopen("input.txt","r");
    out=fopen("output.txt","w");
    fscanf(in,"%d",&N);

    if(N % 2 == 0)
    {
        fprintf(out,"%d %d\n",(2*N-3),N);
        pari(N,0,2*N+1);
    }
        else
            {
                fprintf(out,"%d %d\n",(2*N-2),N);
                dispari(N,0,2*N+1);
            }

    fclose(in);
    fclose(out);

    return 0;

}
