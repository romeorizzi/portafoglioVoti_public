#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

#define MONETE 100000

int monete[MONETE];

std::ifstream in;
std::ofstream out;

void gira_monete(int a, int b)
{
    for(int i=a; i<=b; i++)
        monete[i] = -monete[i];
}

int conta_monete(int a, int b)
{
    int count = 0;
    for(int i=a; i<=b; i++)
        if(monete[i] == -1)
            count++;
            
    return count;
}

int main()
{
    in.open("input.txt");
    int n, q;
    in >> n;
    in >> q;

    for(int i=0; i<n; i++)
        monete[i] = 1;

    out.open("output.txt");
    
    for(int i=0; i<q; i++)
    {
        int op, a, b, count;
        in >> op;
        in >> a;
        in >> b;
        
        switch(op)
        {
        case 0:
            gira_monete(a,b);
            break;
        case 1:
            count = conta_monete(a, b);
            out << count << std::endl;
            break;
        }
    }
    
    in.close();
    out.close();
    
    
    std::cout << n << " " << q << std::endl;
    return 0;
}
