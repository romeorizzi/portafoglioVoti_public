// Esame di Algoritmi 17/02/2016
// Mancini Francesco Maria
// Treno

#include<cstdlib>
#include<fstream>
#include<iostream>

using namespace std;

int d = 10;

// Apertura file input
FILE* f = fopen("input.txt","rb");

//File output
ofstream out("output.txt");
char spazio[] = " ";

// Funzione ricorsiva principale
void treno(int j){
        
    int a = (j-2)/2;
    int b = j-1;
        
    if ( j == d){
        out << a << spazio << b << endl;
        return;    
        }
    else{
        out << a << spazio << b << endl;
        out << b-2 << spazio << a << endl;
        treno (b-1);
        }
}


// Inizio Main
int main( int argc, char** argv){

        int K_spostamenti;
        int N_container;

        fscanf(f, "%d", &N_container);
        K_spostamenti = 2*N_container-3;
        out << K_spostamenti << " " << N_container << endl;
        treno(2*N_container+2);
        out << d-4 << spazio << d-6 << endl;
        out << d-8 << spazio << d-4 << endl;
        out << d-5 << spazio << d-8 << endl;
        out << 2*N_container+1 << " " << d-5 << endl;
        return 0;

}
