#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
int count_testa(int da, int a, vector<int> monete);

int main(){
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    int numero=0, righe=0, op=0, da=0, a=0;
    fin >> numero >> righe;
    vector<int> monete(numero, 0);

    for(int i=0; i < righe ; i++){
           fin >> op >> da >> a;
            if(op == 0){
                for(int i=da; i<=a; i++){
                    if(monete.at(i) == 0)
                        monete[i]= 1;
                    else
                        monete[i]= 0;
                }
            }
            if(op == 1)
                 fout << count_testa(da, a, monete) << endl;
    } 
    fin.close();
    fout.close();
}

int count_testa(int da, int a, vector<int> monete){
        int testa=0;
        for(int i = da; i<=a; i++){
            if(monete.at(i) == 1)
                testa++;
        }
    return testa;
}



