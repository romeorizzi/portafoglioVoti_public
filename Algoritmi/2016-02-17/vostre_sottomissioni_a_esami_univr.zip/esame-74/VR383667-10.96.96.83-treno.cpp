#include <iostream>
#include <fstream>

using namespace std;

int K;
int N;


ifstream in("input.txt");
ofstream out("output.txt");

void esegui(int t)

{
    if (t == 10) 
    {
        out << (t-2)/2 << " " << t-1 << endl; 
        return;
    
    }
    
    out << (t-2)/2 << " " << t-1 << endl; 
    out << t-3 << " " << (t-2)/2 << endl;
    esegui(t-2);

}

int main()

{
    in >> N;
    K = 2*N-3;
    out << K << " " << N << endl;
    esegui(2*N+2);
    out << 6 << " " << 4 << endl;
    out << 2 << " " << 6 << endl;
    out << 5 << " " << 2 << endl;
    out << 2*N+1 << " " << 5 << endl;
    return 0;

}
