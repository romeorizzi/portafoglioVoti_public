// Esame di Algoritmi 17/02/2016
// Mancini Francesco Maria
// Flipping Coins

#include<iostream>
#include<fstream>
#include<vector>
#include<deque>
#include<utility>

using namespace std;

int N;
int Q;

// Inizializzazione nodo
struct pos
{
bool b;
int inizio;
int fine;
int val;

};

// Costruzione albero
void grafo(int inizio, int fine, int i, pos g[])
{
g[i].inizio = inizio;
g[i].fine = fine;
g[i].b = false;
g[i].val = 0;

if(inizio == fine)
{ 
    return;
    }

grafo(inizio, inizio+(fine-inizio)/2, 2*i, g);
grafo(inizio + (fine-inizio)/2+1, fine, 2*i+1, g);

}

// Funzione principale
void range_tree(int inizio, int fine, int i, pos g[])
{
    if(g[i].b)
    {
        g[i].val = (g[i].fine - g[i].inizio+1) - g[i].val;
        
        if(g[i].inizio != g[i].fine)
        {
            g[i*2].b = !g[i*2].b;
            g[i*2+1].b = ! g[i*2+1].b;
        }
        
        g[i].b= false;
    
    }

    if(g[i].inizio > fine || g[i].fine < inizio) 
    {
        return;
    }

    if(g[i].inizio >= inizio && g[i].fine<= fine)
    {
        g[i].val = (g[i].fine - g[i].inizio +1) - g[i].val;
        
        if(g[i].fine != g[i].inizio)
        {
            g[i*2].b = ! g[i*2].b;
            g[i*2+1].b = !g[i*2+1].b;        
            
        }
        return;

    }        
        range_tree(inizio,fine,i*2, g);
        range_tree(inizio,fine,i*2+1,g);

        g[i].val = g[i*2].val + g[i*2+1].val;
}

// Inizio nuova funzione
int coin(int inizio, int fine, int i, pos g[])
{
    if(g[i].inizio >fine || g[i].fine<inizio) 
    {
    return 0;
    }
    if(g[i].b)
    {
        g[i].val = (g[i].fine - g[i].inizio +1) - g[i].val;
        
        if(g[i].inizio != g[i].fine)
        {
            g[i*2].b = !g[i*2].b;
            g[i*2+1].b = !g[i*2+1].b;
        }         
        g[i].b = false;
    }

    if (g[i].inizio >=inizio && g[i].fine <= fine)
    {
    return g[i].val;    
    }

return coin (inizio,fine,i*2,g) + coin(inizio,fine,i*2+1,g);

}

// Inizio main
int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> Q;

   int d = 2;

        while(d<2*N)
        d *=2;

    pos p[d];

    grafo(0, N-1, 1, p);

    int b, inizio, fine;
    for (int idx = 0; idx<Q; idx++)

    {
        in >> b >> inizio >> fine;
        if(b == 0){
            range_tree(inizio,fine,1,p);
            }

        else
            {
            out << coin(inizio,fine,1,p) << endl;

            }
           
    }

    return 0;

}
