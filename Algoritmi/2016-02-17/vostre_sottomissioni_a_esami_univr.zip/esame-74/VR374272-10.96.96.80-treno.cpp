#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

#define MAXN 1000;

std::ifstream in;
std::ofstream out;

void dispari(int n, int inizio, int ultimi);
void pari(int n, int inizio, int ultimi);


void dispari(int n, int inizio, int ultimi)
{
    out << 2+inizio << " " << ultimi << std::endl;
    out << ultimi-1 << " " << 2+inizio << std::endl;
    out << 2*n-2+inizio << " " << ultimi-1 << std::endl;
    out << ultimi << " " << 2*n-2+inizio << std::endl;
    
    if(n > 3)
        dispari(n-2, inizio+2, ultimi);
}

void pari(int n, int inizio, int ultimi)
{
    out << n+inizio << " " << ultimi << std::endl;
    out << 2*n-2+inizio << " " << n+inizio << std::endl;
    out << 2+inizio << " " << 2*n-2+inizio << std::endl;
    out << 2*n-3+inizio << " " << 2+inizio << std::endl;
    
    if(n > 4)
        dispari(n-3, inizio+2, ultimi-4);
        
    out << 2*n+1+2*inizio << " " << 2*n-3+inizio << std::endl;
}

int main()
{
    in.open("input.txt");
    int n;
    in >> n;

    out.open("output.txt");
    
    if(n%2 == 0)
    {
        out << 2*n-3 << " " << n << std::endl;
        pari(n, 0, 2*n+1);
    }
    else
    {
        out << 2*n-2 << " " << n << std::endl;
        dispari(n, 0, 2*n+1);
    }
        
    in.close();
    out.close();
    
    return 0;      
}
