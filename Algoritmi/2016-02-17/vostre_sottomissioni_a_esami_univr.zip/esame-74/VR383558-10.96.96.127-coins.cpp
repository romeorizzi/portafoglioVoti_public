#include <iostream>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <fstream>

//CROCE = FALSE TESTA = TRUE
using namespace std;

int main() {
  ifstream fin("input.txt"); assert( fin );
  ofstream out("output.txt");
  int n,q,op,s,e; //#monete,#query,tipo query, inizio,fine 
  fin >> n >> q;
  bool fl[n]; //tengo traccia del verso della moneta
  for(int j=0;j<n;++j){//situaz iniziale
    fl[j] = 0;
  }      
  for(int i=0;i<q;i++){
    fin >> op >> s >> e;
    if(op==0){ //caso flipping
      for (int j=s;j<=e;j++){
        fl[j] = !fl[j];      
      }
    }
    else{//caso lettura
      int sum = 0;
      for (int j=s;j<=e;j++){
        if (fl[j]){
          ++sum;
        }     
      }
      out << sum << "\n";
    }
  }
}
