#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <fstream>
#include <cmath>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
   const int max_leng = 1<<20;

    int head[max_leng<<1];
    int t[max_leng<<1];
    
void add(int inf, int sup, int p, int k, int v) {
    if(k < inf || p > sup)
        return;
    else if(inf <= p && sup >= k) 
        t[v]^=1;
    else {
        int tot = 0;
        add(inf,sup,p,(p+k)/2,v*2);
        add(inf,sup,(p+k)/2+1,k,v*2+1);
        if(t[v*2] == 0)
            tot += head[v*2];
        else
            tot += (k-p+1)/2 - head[v*2];
        if(t[v*2+1] == 0)
            tot += head[v*2+1];
        else
            tot += (k-p+1)/2-head[v*2+1];
        head[v] = tot;
    }
}

int query(int inf, int sup, int p, int k, int v, int xt) {
    if(k < inf || p > sup)
        return 0;
    else if(inf <= p && sup >= k) {
        if((xt^t[v]) == 0)
            return head[v];
        else
            return (k-p+1)-head[v];
    }
    else {
        int sum = 0;
        sum +=query(inf,sup,p,(p+k)/2,v*2,xt^t[v]);
        sum += query(inf,sup,(p+k)/2+1,k,v*2+1,xt^t[v]);
        return sum;
    }
}

int main() {
int n_coin,q,t,inf,sup;
in >> n_coin >> q;
    while(q--) {
        in >> t >> inf >> sup;
        if(t == 0)
            add(inf,sup,0,max_leng-1,1);
        else
            out << query(inf,sup,0,max_leng-1,1,0) << endl;
    }
}
