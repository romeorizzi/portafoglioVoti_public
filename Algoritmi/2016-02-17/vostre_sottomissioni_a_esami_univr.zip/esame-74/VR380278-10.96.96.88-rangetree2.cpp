#include <cstdio>
#include <algorithm>
#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

const int M=1<<18;

int heads_up[M<<1];
int times[M<<1];

void add(int a, int b, int p, int k, int v) {
    if (k<a or p>b)
        return;
    else if(a<=p && b>=k)
        times[v]^=1;
    else{
        int sum = 0;
        add(a,b,p,(p+k)/2,v*2);
        add(a,b,(p+k)/2+1,k,v*2+1);
        if(times[v*2]==0)
            sum+= heads_up[v*2];
        if(times[v*2+1]==0)
            sum+= heads_up[v*2+1];
        else
            sum += (k-p+1)/2-heads_up[v*2+1];
    heads_up[v] = sum;
    }
}

int query(int a, int b, int p, int k, int v, int xsum)
{
        if (k <a or p>b)
            return 0;
        else if(a<=p && b>=k){
            if ((xsum^times[v]) ==0)
                return heads_up[v];
            else
                return (k-p+1)-heads_up[v];

}
else {
    int sum=0;
    sum += query(a,b,p,(p+k)/2,v*2,xsum^times[v]);
    sum += query(a,b,(p+k)/2+1,k,v*2+1,xsum^times[v]);
    return sum;
    }
}


int main() {
    int n,q,t,a,b;
    cin >> n >> q;
    while(q--){
    cin >> t >> a >> b;
    if(t==0)
        add(a,b,0,M-1,1);
    else
        cout << query(a,b,0,M-1,1,0) << endl;
    }
}
