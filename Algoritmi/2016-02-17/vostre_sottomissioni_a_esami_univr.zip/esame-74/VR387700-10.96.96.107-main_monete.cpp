#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <malloc.h>
#include <assert.h>
#include <string.h>

using namespace std;

struct val_moneta{
    bool invertita;
    bool valore;
    val_moneta():invertita(false), valore(false){}
};

val_moneta *monete;

int main()
{
    ifstream inp("input.txt");
    ofstream fout("output.txt");

    int N, Q;
    inp >> N >> Q;

    monete = (val_moneta*) malloc(sizeof(val_moneta)*N);

    for (int i = 0; i < Q;i++){
        int m,r,s;
        inp >> m >> r >> s;

        if (m == 0) // capovolgere
            for (int j = r; j<=s; j++ ){
                monete[j].invertita = true;
                monete[j].valore = !monete[j].valore;
        }

        if (m == 1){
            int val=0;

            for (int j = r; j<=s; j++ )
                val+= (int) monete[j].valore;

            fout << val << endl;
        }

    }

    return 0;
}
