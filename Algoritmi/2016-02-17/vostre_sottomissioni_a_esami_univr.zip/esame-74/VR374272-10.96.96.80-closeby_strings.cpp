#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

#define N 100000
#define M 100000
#define D 100

std::ifstream in;
std::ofstream out;

int max;
char str1[N];
char str2[M];
int nothing[N];

void naviga(int n, int m, int count)
{
std::cout << n << " " << m << std::endl;
    if(n > 0 && m > 0)
    {
        if(str1[n-1] == str2[m-1])
        {
            count++;
            naviga(n-1, m-1, count);
        }
        else
        {
            naviga(n, m-1, count);
            naviga(n-1, m, count);
        }
    }
    else
        if(count >= max)
            max = count;
}

int main()
{
    in.open("input.txt");
    out.open("output.txt");

    int n,m;
    in >> n;
    in >> m;

    for(int i=0; i<n; i++){
        nothing[i] = 0;
        in >> str1[i]; 
    }
    for(int i=0; i<m; i++)
        in >> str2[i];

    max = 0;   

    std::cout << "inizio" << std::endl;

    naviga(n,m,0);
    
    int result = (n-max) + (m-max);
    
    std::cout << n << " " << m << " " << max << " " << result << std::endl;
    out << result << std::endl;
    
    in.close();
    out.close();
    
    return 0;
}
