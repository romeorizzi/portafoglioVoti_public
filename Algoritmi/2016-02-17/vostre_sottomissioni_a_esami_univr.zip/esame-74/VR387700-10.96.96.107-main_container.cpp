nta#include <iostream>
#include <fstream>

using namespace std;

int K,N;
ofstream F_out("output.txt");

void spostamento_vagone(int j){
    if (j==10){
        F_out << (j-2)/2 << " " << j-1 << endl;
        F_out << 6 << " " << 4 << endl;
        F_out << 2 << " " << 6 << endl;
        F_out << 5 << " " << 2 << endl;
        F_out << 2*N+1 << " " << 5 << endl;
        return;
    }

    if (j==8){
        F_out << ((j-2)/2)-1 << " " << j-1 << endl;
        F_out << j-2 << " " << ((j-2)/2)-1 << endl;
        F_out << j-4 << " " << j-2 << endl;
        F_out << j-1 << " " << j-4 << endl;
        return;
    }

    F_out << (j-2)/2 << " " << j-1 << endl;
    F_out << j-3 << " " << (j-2)/2 << endl;
    spostamento_vagone(j-2);
}

int main()
{
    ifstream F_inp("input.txt");
    F_inp >> N;

    K = (N > 3) ? 2*N-3 : 4;

    F_out << K << " " << N << endl;
    spostamento_vagone(2*N+2);

    return 0;
}
