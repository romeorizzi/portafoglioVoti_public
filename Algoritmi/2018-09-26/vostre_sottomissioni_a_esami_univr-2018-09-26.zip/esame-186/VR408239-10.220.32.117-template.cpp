/* template per attract, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-18
*/

#include <iostream>
#include <cassert>
#include <vector>
#include <stdio.h>

using namespace std;

const unsigned MAXN = 1000000;
int N, M;
int x[MAXN];
bool visti[MAXN];
vector<int> exits[MAXN], enters[MAXN];
vector<int> enters2[MAXN];
bool modifica;

int d[MAXN];

int massimo(int a, int b){
    if(a < b){
        return b;
    }
    return a;
}
/*
int percorso(int nodoPartenza, int nodoArrivo, int count){
    if(nodoPartenza == 0){
        return count;
    }else if(nodoPartenza == -1 || count > N*2){
        return -1;
    }
    else{
        return 0;        
    }
}
*/
void percorso2(int nodoPartenza,int* d){
    int nodoArrivo; 
    for(int i = 0; i < enters2[nodoPartenza].size(); i++){
        nodoArrivo = enters2[nodoPartenza].at(i);
        if(nodoArrivo != -1){
        cout <<"vicino " <<nodoArrivo << "\n";
        //if(visti[nodoArrivo] == false){
        //        visti[nodoArrivo] = true;
                enters2[nodoPartenza].at(i) = -1;
                d[nodoArrivo] = d[nodoPartenza]+1; 
                cout <<"d partenza " <<d[nodoPartenza];
                cout <<";   d arrivo " <<d[nodoArrivo] << "\n";
                if(x[nodoArrivo] == 1)
                percorso2(nodoArrivo,d);
        //}
        }
    }
}

int sistemo(int nodoDaSistemare){
    int maxx = d[nodoDaSistemare];
    cout << maxx << "\n";
    modifica = false;
    for(int i = 0; i < exits[nodoDaSistemare].size(); i++){
        //cout <<"vicino " <<exits[nodoDaSistemare].at(i) << "\n";
        if(maxx < (d[nodoDaSistemare]+d[exits[nodoDaSistemare].at(i)])){
            modifica = true;
            maxx = d[nodoDaSistemare]+d[exits[nodoDaSistemare].at(i)];
        }
    }
    return maxx;
}


int main() {

    FILE * fineIn = fopen ("input.txt","r");
    FILE * fineOut = fopen ("output.txt","w");
   // assert( freopen("input.txt", "r", stdin) );
 //   assert( freopen("output.txt", "w", stdout) );


    fscanf(fineIn,"%d %d",&N, &M);

    for (int i=0; i<N; i++) {
        fscanf(fineIn,"%d ",&x[i]);
    }

    
    for (int i=0; i<M; i++) {
        int a, b;
        fscanf(fineIn,"%d %d",&a, &b);
        exits[a].push_back( b );
        enters[b].push_back( a );
        enters2[b].push_back( a );
    }

 //   cout << enters[0].at(0);
    
    // ToDO: risolvere il problema!
    d[0] = 0;
    for (int i=1; i<N; i++){
        d[i] = -1;
        visti[i] = false;
    }
    percorso2(0,d);

    d[0] = 0;
    /*
    for (int i=0; i<N; i++){
        if(d[i] != -1)
            d[i]++;
    }*/

    modifica = true;
    do{
        for(int i = 1; i < N; i++){
            if(x[i] == 1 && d[i] != -1) {
                d[i] = sistemo(i); 
            }else{
                modifica = false;
            }
        }
    }while(modifica);
    

    d[0] = 0;
    for (int i=0; i<N; i++){
        cout << d[i] << " ";
        fprintf(fineOut,"%d ",d[i]);
    }
    fprintf(fineOut,"\n");
    cout << endl;

    return 0;
}
