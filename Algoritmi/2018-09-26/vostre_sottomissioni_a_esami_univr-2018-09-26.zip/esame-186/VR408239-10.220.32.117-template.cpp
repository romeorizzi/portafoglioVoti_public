/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>

#include <iostream>
#include <vector>
#include <stdio.h>
using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];

int M, N;
int risp;

int valoreHulk(int i, int j,int hulk){
    if(mappa[i][j] > '0' && mappa[i][j] < '6'){
        if(hulk < (mappa[i][j]-'0'))
            hulk = mappa[i][j]-'0';
        return hulk;
    }
    else{
        if(hulk != 0)
            return hulk = hulk-1;
    }
}

bool posso(int i, int j, int hulk){
    cout<<mappa[i][j];
    if(mappa[i][j]== '#'){
        //cout<<"NO"<<"\n";
        return false;
    }else if(mappa[i][j]== '+') {
        //cout<<"SI"<<hulk<<"\n";
        return true;
    }
    else if(mappa[i][j] > '0' && mappa[i][j] < '6'){
        //cout<<"SI"<<hulk<<"\n";
        return true;
    }
    else{
        if(hulk != 0){
            //cout<<"SI"<<hulk<<"\n";
            return true;
        }else{
            //cout<<"NO"<<"\n";
            return false;
        }

    }
}

void spostamento(int i, int j,int hulk){
    cout << "i,j "<<i<<";"<<j<<"\n";
    if(i == (M-1) && j == (N-1)){
            //cout << "----------------ciao\n";
        risp = (risp+1) % BASE;
    }
    else{
        if((i+1) == M){//non posso più andare in basso
            j++;
            if(posso(i,j,hulk)){
                hulk = valoreHulk(i,j,hulk);
                spostamento(i,j,hulk);
            }
        }
        else if((j+1) == N){//non posso più andare a dx
            i++;
            if(posso(i,j,hulk)){
                hulk = valoreHulk(i,j,hulk);
                spostamento(i,j,hulk);
            }
        }
        else{//non sono ai confini
            i++;
            //cout << "vado in "<<i<<";"<<j<<" ";
            if(posso(i,j,hulk)){
                hulk = valoreHulk(i,j,hulk);
                spostamento(i,j,hulk);
            }
            i--;
            j++;
            //cout << "vado in "<<i<<";"<<j<<" ";
            if(posso(i,j,hulk)){
                hulk = valoreHulk(i,j,hulk);
                spostamento(i,j,hulk);
            }

        }
        
    }

}


int main() {

    FILE * fineIn = fopen ("input.txt","r");
    FILE * fineOut = fopen ("output.txt","w");

    fscanf(fineIn,"%d %d", &M, &N);
 char c;
    for (int i = 0; i < M; i++) {
      for (int j = 0; j < N; j++) {
         
	do { 
        fscanf(fineIn,"%c", &mappa[i][j]);
       
        } while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );  
        //cout<<mappa[i][j]<<"\n";
      }
    }
    int hulk = 0;
    spostamento(0,0, hulk);

    //int risp = 0;
    //risp = 3;
    fprintf(fineOut,"%d\n",risp);
    return 0;
}
