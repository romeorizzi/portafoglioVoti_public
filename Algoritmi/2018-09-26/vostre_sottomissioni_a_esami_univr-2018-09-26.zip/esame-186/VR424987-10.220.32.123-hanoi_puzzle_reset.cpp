/**
 *  Un template per la soluzione di hanoi_tower_reset
 *
 *  Author: Romeo Rizzi, 2018-09-21
 *
 */

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXN = 30;

int N;
char pole[MAXN +1];
int numMoves = 0;
int counter = 0;

// USE THE FOLLOWING FUNCTION WHEN YOU ARE REQUIRED TO ACTUALLY SPECIFY EACH MOVE (n<=10)
void spostaDisco(int n, char from, char to) {
    if(N <= 10){
        assert(pole[n]==from);
        printf("Muovi il disco %d dal piolo %c al piolo %c\n", n, from, to);
        pole[n] = to;
    }else{
        counter = (counter+1)%BASE;
    }
  
}

void print_moves(int n, char start, char end, char sup){
    if(n == 0){
        return;
    }
    print_moves(n-1, start, sup, end);
    spostaDisco(n, start, end);
    print_moves(n-1, sup, end, start);

}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       do{
          scanf("%c", &pole[i]);
        }
       while( pole[i] < 'A' || pole[i] > 'C');
    }


    print_moves(N, 'C', 'A', 'B');
    if( N>10 )
        printf("%i", counter);
        
    return 0;
}

