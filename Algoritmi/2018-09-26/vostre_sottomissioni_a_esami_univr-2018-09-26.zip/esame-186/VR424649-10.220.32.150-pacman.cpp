/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];

int M, N;

int percorsi(int i, int j, int blu){
    //printf("%d %d %d\n", i, j, blu);

    if(mappa[i][j] == '#'){ 

        return 0;
    }
    int new_blu = mappa[i][j] - '0';
    if(new_blu > 0 and new_blu < 6){
        blu += new_blu;
    }
    if(i == M and j == N)
        return 1;
    int n = 0;
    if( i <=M and j<=N){
        int new_jblu = mappa[i][j+1] - '0';
        //printf("%c\n", mappa[i][j]);
        if(mappa[i][j+1] == '+'){
             if(blu ==0)  
                n += percorsi(i, j+1, blu);
             if(blu > 0)
                n += percorsi(i, j+1, blu - 1);
        }else if( new_jblu<6 and new_jblu>0){
             if(blu ==0)  
                n += percorsi(i, j+1, blu);
             if(blu > 0)
                n += percorsi(i, j+1, blu - 1);
        }else if(mappa[i][j+1] == '*'){
            //printf("%d, %d, %d\n", i, j+1 , blu);
            if(blu> 0){
                  n += percorsi(i, j+1, blu - 1);
            }
        }
        int new_iblu = mappa[i+1][j] - '0';
        if(mappa[i+1][j] == '+'){
             if(blu ==0)   
                n += percorsi(i+1, j, blu);
             if(blu > 0)
                n += percorsi(i+1, j, blu -1);
        }else if( new_iblu<6 and new_iblu>0){
             if(blu ==0)   
                n += percorsi(i+1, j, blu);
             if(blu > 0)
                n += percorsi(i+1, j, blu -1);
        }else if(mappa[i+1][j] == '*'){
            //printf("%d, %d, %d\n", i+1, j , blu);
            if(blu> 0){
                  n += percorsi(i+1, j, blu - 1);
            }
        }
    }
    return n;
}


int main() {
#ifdef EVAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    scanf("%d%d", &M, &N);
	
    for (int i = 1; i <= M; i++) {
        for (int j = 1; j <= N; j++) {
            do { 
                scanf("%c", &mappa[i][j]);
            } while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
        }
    }
    int risp = 0;
    //printf("M:%d N:%d\n", M, N);
    risp = percorsi(1, 1, 0);
    printf("%d\n",risp);
    return 0;
}
