#include <cassert>
#include <cstdio>

int N;
char pole[31];
int ct =0;

void spostaDisco(int n, char from, char to) {
    if(N <= 10){
        assert(pole[n]==from);
        printf("Muovi il disco %d dal piolo %c al piolo %c\n", n, from, to);
        pole[n] = to;
    }
    else
        ct = (ct+1)%1000000;
}


void stampa(int n, char i, char f, char s){
    if(n== 0)
        return;
    stampa(n-1, i,s,f);
    spostaDisco(n,i,f);
    stampa(n-1,s,f,i);
}



int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       do
          scanf("%c", &pole[i]);
       while( pole[i] < 'A' || pole[i] > 'C');
    }

    stampa(N,'C','A','B');
    if(N > 10)
        printf("%d\n", ct);
        
}


