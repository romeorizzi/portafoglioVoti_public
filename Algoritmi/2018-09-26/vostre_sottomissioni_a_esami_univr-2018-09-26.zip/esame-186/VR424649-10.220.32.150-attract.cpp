/* template per attract, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-18
*/

#include <iostream>
#include <cassert>
#include <vector>
#include <cstdio>

using namespace std;

const unsigned MAXN = 1000000;
int N, M;
int x[MAXN];
vector<int> exits[MAXN], enters[MAXN];

int d[MAXN];

bool is_enters(int enter, int exit){
    if(x[exit] == 1){
        for(int i=0; i<enters[enter].size(); i++){
            if(enters[enter][i] == exit) return true;
        }
    }
    return false;
} 

int Ovile(int nodo, int path){
    if(path >= N) return -1;
    int max = -1;
    int temp = 0;
    if(nodo == 0)
        return path;
    if(x[nodo] == 0){
        for(int i=0; i<exits[nodo].size(); i++){
               //printf( "exit:%d enter:%d\n", nodo, exits[nodo][i]);
               if(!is_enters(nodo, exits[nodo][i])){
                    temp = Ovile(exits[nodo][i], path + 1);
                    //printf( "exit:%d enter:%d tempo:%d\n", nodo, i, temp);
                    if(max == -1)
                        max = temp;
                    if(temp == -1) continue;
                    if(temp < max)
                        max = temp;
                }
        }
    } 
    if(x[nodo] == 1){
        bool non_arrivo = true;
        for(int i=0; i<exits[nodo].size(); i++){
            //printf( "exit:%d enter:%d\n", nodo, exits[nodo][i]);
            if(!is_enters(nodo, exits[nodo][i])){
                temp = Ovile(exits[nodo][i] , path + 1);
                if(non_arrivo and temp > max)
                    max = temp;
                if(temp == -1){
                    non_arrivo = false;
                    max = -1;
                    break;
                }
            }
            else return -1;
        }
    }
    return max;

}

int main() {
#ifdef EVAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    scanf("%d %d", &N, &M);

    for (int i=0; i<N; i++) {
      scanf("%d", &x[i]);
    }

    for (int i=0; i<M; i++) {
        int a, b;
        scanf("%d %d", &a, &b);
        exits[a].push_back( b );
        enters[b].push_back( a );
        //printf("%d %d\n", a, b);
    }


    for(int i=0; i<N; i++)
        d[i] = Ovile(i, 0);
    
    for (int i=0; i<N; i++)
      printf("%d ", d[i]);
    printf("\n");

    return 0;
}
