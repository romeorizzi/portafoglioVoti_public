/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;
const int CELLCHAR = 7;

// E se salvassi lo stato delle pillole in un intero aggiunto alla matrice?
// Qua sotto lo stato originale della matrice.
//char mappa[MAXM][MAXN];
// Qua sotto la mia aggiunta.
// Salvo anche i sei interi dei sei percorsi.
// E la faccio d'interi perché m'importa una sega.
int mappa[MAXM][MAXN][8];

int M, N;

int main() {
//#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    //assert( freopen("esempio1.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
//#endif
    scanf("%d%d", &M, &N);
	
    
    for (int i = 0; i < M; i++) {
      for (int j = 0; j < N; j++) {
	//do { 
	  scanf(" %c", &mappa[i][j][CELLCHAR]);
      mappa[i][j][0] = 0;
      mappa[i][j][1] = 0;
      mappa[i][j][2] = 0;
      mappa[i][j][3] = 0;
      mappa[i][j][4] = 0;
      mappa[i][j][5] = 0;
      mappa[i][j][6] = 0;
	//} while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
    }
    }

    int risp = 0;

    // Variabile che conta il numero di passi salvi grazie a un pillolozzo.
    // Ad ogni passo la decremento.
    // La recupero solo se la matrice sopra mi esplode.
    //int safetime = 0;

    // Problema: nel caso potessi arrivare da sopra e sotto in una casella, quale configurazione scelgo di mantenere?
    // Salvo le configurazione in uno stack per ogni iterazione, nel numero [1] salvo solo il numero di secondi che sono ancora impasticcato.

    // Funzione di stampa temporanea per vedere il check di lettura
    /*
     for (int i = 0; i < M; i++) {
      for (int j = 0; j < N; j++) {
        printf("%c\t",mappa[i][j][CELLCHAR]);
        }
        printf("\n");
    }
    */

    // Faccio la prima casella, no muri e no fantasmi.
    int carattere = mappa[0][0][CELLCHAR];
    // Se pillola salvo 1 nel corrispondente +1.
    if (carattere - '0' > 0 && carattere - '0' < 6)
        mappa[0][0][carattere - '0' + 1] = 1;
    // Altrimenti è vuota.
    else
        mappa[0][0][0] = 1;

    for (int row = 0; row < M; row++){
        //printf("Inizio l'analisi della riga %d.\n",row);
        for (int col = 0; col < N; col++){
            //printf("Inizio l'analisi della colonna %d.\n",col);
            //printf("(%d,%d)\n",row,col);
            int carattere = mappa[row][col][CELLCHAR];
            //printf("Carattere: %c, salvato come intero %d.\n",carattere,carattere);
            if (row == 0 & col == 0)
                continue;
            // Se trovo un muro mi fermo.
            if (carattere == '#'){
                //printf("Continue per muro\n");
                continue;
            }
            // Creo un miniarray, merge dei superiori.
            int local[7];
            //printf("Creazione dell'array merge in corso.\n");
            // Se esiste la cella a sinistra o sopra me le copio qua.
            for (int q = 0; q <= 6; q++){
                local[q] = 0;
                //printf("Fin qui tutto bene, row vale %d\n",row);
                if (row != 0){
                    //printf("mappa[%d][%d][%d] vale %d\n",row-1,col,q,mappa[row-1][col][q]);
                    //printf("mappa[row-1][col][q] : %d\n",mappa[row-1][col][q]);
                    local[q] += mappa[row-1][col][q];
                }
                if (col != 0){
                    //printf("mappa[%d][%d][%d] vale %d\n",row,col-1,q,mappa[row][col-1][q]);
                    local[q] += mappa[row][col-1][q];
                }
                // Stampa mia.
                //printf("local[%d] = %d - ",q,local[q]);
            }
            //printf("\n");
            

            // Se trovo un fantasma copio tutti scalando di 1, tranne gli zero.
            if (carattere == '*') {
                //printf("Sono entrato in un fantasma\n");
                for (int a = 1; a <= 6; a++){
                    mappa[row][col][a-1] = local[a];
                }
                // No zeri perché sul fantasma perdono.
            }
            else if (carattere - '0' > 0 && carattere - '0' < 6){
                //printf("Sono entrato in una pillola\n");
                // Creo il valore vero, che è + 1.
                int value = carattere - '0' + 1;
                //printf("value: %d\n",value);
                // Ricopio i valori maggiori di value+1 qua verbatim.
                for (int a = 6; a > value+1; a--)
                    mappa[row][col][a-1] += local[a];
                for (int a = value + 1; a >= 0; a--){
                    mappa[row][col][value] += local[a];
                }
            }
            else if (carattere == '+'){
                //printf("Sono entrato in una cella vuota.\n");
                // Salvo tutti quelli a sinistra.
                // Poi potro unirlo a quello sopra verosimilmente.
                for (int a = 1; a <= 6; a++)
                    mappa[row][col][a-1] += local[a];
                //Salvo gli zeri che non vengono decrementati.
                mappa[row][col][0] += local[0];
            }
        }
        /*
        printf("-----------------------------------\n");
        printf("Fine analisi della riga %d.\n",row);
        printf("-----------------------------------\n");
        */
        
    }

    for (int a = 0; a < 7; a++){
        risp += mappa[M-1][N-1][a];
    }

    // Funzione di stampa temporanea per vedere il check di lettura
    /*
     for (int i = 0; i < M; i++) {
      for (int j = 0; j < N; j++) {
        printf("%d\t",mappa[i][j][0]);
        }
        printf("\n");
    }*/





    printf("%d\n",risp);
    return 0;
}
