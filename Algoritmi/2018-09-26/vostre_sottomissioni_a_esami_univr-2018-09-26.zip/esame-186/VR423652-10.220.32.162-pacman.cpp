#include <iostream>
#include <fstream>
using namespace std;


const int MAXM = 1000;
const int MAXN = 1000;
    
char matrice[MAXM+1][MAXN+1];

int move_down( int save, int i, int j, int righe){
    if(matrice[i+1][j]!='#' and i+1<righe){
        if((save>0 and matrice[i+1][j]=='*') or matrice[i+1][j]!='*'){
        save--;
        return 0;}
        else return 1;
    }
    return 1;
}

int move_left( int save, int i, int j, int col){
     if(matrice[i][j+1]!='#' and j+1<col){
        if((save>0 and matrice[i][j+1]=='*') or matrice[i][j+1]!='*') {
        save--;
        return 0;}
        else return 1;
    }
    return 1;
}
int save=0;
int n_percorsi=0;
void numero_percorsi(int i, int j, int righe, int collone){
if(i==righe-1 and j==collone-1) return;

if(move_down(save, i, j, righe)==1 and move_left(save, i, j, collone)==1) return;

if(matrice[i][j]=='1' or matrice[i][j]=='2' or matrice[i][j]=='3' or matrice[i][j]=='4' or matrice[i][j]=='5'){
   save=max(matrice[i][j]-'0', save);}

if(move_down(save, i, j, righe)==0 and move_left(save, i, j, collone)==0){
    if(i+1==righe-1 and j==collone-1) n_percorsi++;
    else{numero_percorsi(i++,j, righe, collone);
    numero_percorsi(i,j++, righe, collone); }
}

if(move_down(save, i, j, righe)==0 and move_left(save, i, j, collone)==1){
     if(i+1==righe-1 and j==collone-1) n_percorsi++;
     else numero_percorsi(i++,j, righe, collone);
    }

    if(move_left(save, i, j, collone)==0 and move_down(save, i, j, righe)==1){
       if(i==righe-1 and j+1==collone-1) n_percorsi++;
       else numero_percorsi(i,j++, righe, collone); 

}
return;
}
 


int main(){
int m, n;
std::ifstream input("esempio5.txt");
    input>>m;
    input>>n;

    for(int i=0; i<m; i++){
        for(int j=0;j<n; j++){
            input>>matrice[i][j];
        }
    }





std::ofstream output("output.txt");
numero_percorsi(0, 0, m, n);
output<<n_percorsi;




   return 0;
}
