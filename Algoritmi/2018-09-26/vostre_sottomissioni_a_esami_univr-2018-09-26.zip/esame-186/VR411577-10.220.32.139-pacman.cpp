/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>
#include <map>

using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];
map<pair<pair<int, int>, int>, int> *mem;

int M, N;

int partenza(int i, int j, int residuo_blu){
    
    if(mappa[i][j] == '#')
        return 0;
    if(i == M && j == N)
        return 1;
    //printf("sono in %d %d con %d\n",i,j,residuo_blu);
    int somma = 0;
    int nuovo_residuo=residuo_blu;
    switch(mappa[i][j]){
                case '1': if(nuovo_residuo < 1)  nuovo_residuo = 1; break;
                case '2': if(nuovo_residuo < 2)  nuovo_residuo = 2; break;
                case '3': if(nuovo_residuo < 3)  nuovo_residuo = 3; break;
                case '4': if(nuovo_residuo < 4)  nuovo_residuo = 4; break;
                case '5': if(nuovo_residuo < 5)  nuovo_residuo = 5; break;
            }
    if(i < M){
            if(nuovo_residuo > 0){
                if(mem->find({{i+1, j}, nuovo_residuo-1}) == mem->end())
                    somma = (somma + partenza(i+1, j, nuovo_residuo-1)) % 1000000;
                else{
                    //printf("cache\n");
                    somma = (somma + mem->at({{i+1, j}, nuovo_residuo-1})) % 1000000;
                }
            }
            else{
                if(mappa[i+1][j] != '*'){
                    if(mem->find({{i+1, j}, 0}) == mem->end())
                        somma = (somma + partenza(i+1, j, 0)) % 1000000;
                    else{
                        //printf("cache\n");
                        somma = (somma + mem->at({{i+1, j}, 0})) % 1000000;
                    }
                }
            } 
    }
    if(j < N){
            
            if(nuovo_residuo > 0){
                if(mem->find({{i, j+1}, nuovo_residuo-1}) == mem->end())
                    somma = (somma + partenza(i, j+1, nuovo_residuo-1)) % 1000000;
                else{
                    //printf("cache\n");
                    somma = (somma + mem->at({{i, j+1}, nuovo_residuo-1})) % 1000000;
                }
            }
            else{
                if(mappa[i][j+1] != '*')
                    if(mem->find({{i, j+1}, 0}) == mem->end())
                        somma = (somma + partenza(i, j+1, 0)) % 1000000;
                    else{
                        //printf("cache\n");
                        somma = (somma + mem->at({{i, j+1}, 0})) % 1000000;
                    }
            } 
    }
    //(&mem)[{i,j}] = somma;
    mem->insert({{{i, j}, residuo_blu}, somma});
    return somma;
}

int main() {
    //printf("inizio");
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    //printf("devo leggere M e N\n");
    scanf("%d", &M);
    scanf("%d", &N);
    //printf("M = %d N = %d\n", M, N);
	
    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) {
	  scanf(" %c", &mappa[i][j]);
        //printf("%c", mappa[i][j]);
        }
    }
    mem = new map<pair<pair<int,int>, int>, int>();
    //printf("lettura finita\n");
    int risp = partenza(1,1,0);
    printf("%d\n",risp);
    return 0;
}
