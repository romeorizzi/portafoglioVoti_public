/* template per attract, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-18
*/

#include <cstdio>
#include <iostream>
#include <cassert>
#include <vector>

using namespace std;

const unsigned MAXN = 1000000;
int N, M;
int x[MAXN];
vector<int> exits[MAXN], enters[MAXN], visited[MAXN];
int max_so_far;
int d[MAXN];

int recursive(int node, int passi, int caller_node) {    
    if (node == 0) return passi;
    else {
        for (int i=0; i<visited[caller_node].size(); i++) {
            if (node == visited[caller_node][i]) return -1;
        }

        visited[caller_node].push_back(node);

        if (x[node] == 0) {
            for (int i=0; i<exits[node].size(); i++) {
                int passi_new = passi+1;
                int temp = recursive(exits[node][i], passi_new, caller_node);

                if (passi_new == temp) return temp;
                else if (temp > max_so_far) max_so_far = temp;
            }

            return max_so_far;
        } else {
            for (int i=0; i<exits[node].size(); i++) {
                int passi_new = passi+1;
                int temp = recursive(exits[node][i], passi_new, caller_node);

                if (temp == -1) return temp;
                else if (temp > max_so_far) max_so_far = temp;
            }

            return max_so_far;
        }
    }
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    cin >> N >> M;

    for (int i=0; i<N; i++) {
        cin >> x[i];
    }

    for (int i=0; i<M; i++) {
        int a, b;
        cin >> a >> b;
        exits[a].push_back( b );
        enters[b].push_back( a );
    }

    for (int i=0; i<N; i++) {
        max_so_far = -10;
        d[i] = recursive(i, 0, i);
    }

    for (int i=0; i<N; i++)
        cout << d[i] << " ";
    cout << endl;

    return 0;
}
