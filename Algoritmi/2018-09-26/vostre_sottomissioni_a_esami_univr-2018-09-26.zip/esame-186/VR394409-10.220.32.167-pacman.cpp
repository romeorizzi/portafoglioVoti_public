/*
 * FILE: PACMAN
 */

#include <fstream>
#include <cstdio>
#include <string>
#include <assert.h>

using namespace std;

const int BASE= 100000; 
const int MAXBLUE=5;
const int MAXM=1000;
const int MAXN=1000;

char campo[MAXM+1][MAXN+1];
int num_path=0;

int M, N;

ifstream in("input.txt");
ofstream out("output.txt");

/*
* prva a camminare nel campo di gioo i j coordinate pill il numero di pillole
*/
void cammina(int i, int j, int pill)
{
    // casi base
    if(i==N || j==M)
        return;

    if(campo[i][j]=='*' && pill==0)
        return;
    
    if(i==N-1 && j==M-1){
        num_path+=1;
        return;
    }
    if(campo[i][j]=='#')
        return;
    
    // passo induttivo
    if(campo[i][j]='+'){
        if(pill==0){
            cammina(i+1,j, pill);
            cammina(i,j+1, pill);
        }
        else
        {
            pill=-1;
            cammina(i+1,j, pill);
            cammina(i,j+1, pill);
        }
    }
    if(campo[i][j]=='*' && pill!=0){
        pill=-1;
        cammina(i+1,j, pill);
        cammina(i,j+1, pill);
    }
    if(campo[i][j]!='+' && campo[i][j]!='*' && campo[i][j]!='#'){
        int num;
        num = campo[i][j]-'0';

        if( num>pill || num ==pill){
            cammina(i+1,j, pill);
            cammina(i,j+1, pill);
        }
        else{
            pill-=1;
            cammina(i+1,j, pill);
            cammina(i,j+1, pill);
        }
    }
}

/*
* MAIN
*/
int main()
{
   /************** acquisizione dei dati ***********/
    in >> M >> N;
 
    string linea;

    for (int i=0; i<M; i++)
    {
        in >> linea;
        for (int j=0; j<N; j++)
            campo[i][j]= linea[j];
    }


    /****************** processo e risultato ****************/
    cammina(0,0,0);
    out << num_path % BASE;

    return 0;
 }