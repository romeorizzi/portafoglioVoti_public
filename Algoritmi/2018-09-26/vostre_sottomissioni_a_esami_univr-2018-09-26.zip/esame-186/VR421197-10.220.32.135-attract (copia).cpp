/* template per attract, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-18
*/

#include <iostream>
#include <stdio.h>
#include <cassert>
#include <vector>

using namespace std;

const unsigned MAXN = 1000000;
int N, M;
int x[MAXN];
vector<int> exits[MAXN], enters[MAXN];

int d[MAXN];

int evaluate(int i){
    for(int element:exits[i]){
        if(element==0 && x[i] ==0)
            return 1;
        if(d[element]==1)
            return 2;
        else continue;

    }
    return -1;


}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    cin >> N >> M;

    for (int i=0; i<N; i++) {
        cin >> x[i];
    }

    for (int i=0; i<M; i++) {
        int a, b;
        cin >> a >> b;
        exits[a].push_back( b );
        enters[b].push_back( a );
    }

    for (int i=1; i<N; i++) {
         d[i] = evaluate(i);
    }


    // ToDO: risolvere il problema!


    for (int i=0; i<N; i++)
        cout << d[i] << " ";
    cout << endl;

    return 0;
}
