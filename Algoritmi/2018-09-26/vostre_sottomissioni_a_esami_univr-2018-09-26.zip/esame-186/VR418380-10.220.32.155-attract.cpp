/* template per attract, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-18
*/

#include <iostream>
#include <cassert>
#include <vector>
#include <cstdio>

using namespace std;

const unsigned MAXN = 1000000;
int N, M;
int x[MAXN];
vector<int> exits[MAXN], enters[MAXN];

int d[MAXN];
int mosse = 1; 
int conta(int nodo)
{
    //printf("sono in conta");
    printf("%d\n", mosse);
    if(nodo == 0)
    {
        return 1;
    }
    else{
        for(int i = 0; i< exits[nodo].size(); i++)
            mosse += conta(exits[nodo][i]);
    }
    mosse = 0;
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    cin >> N >> M;

    for (int i=0; i<N; i++) {
        cin >> x[i];
    }

    for (int i=0; i<M; i++) {
        int a, b;
        cin >> a >> b;
        exits[a].push_back( b );
        enters[b].push_back( a );
    }

    //printf("%d", exits[1][1]);
    bool test;

    for (int i = 1; i < N; i++){
        test = false;
        for (int j = 0; j<exits[i].size(); j++){
            if (exits[i][j] == 0){
                test = true;
            }

            if(enters[i][j] == 0){
                test = true;
            }
        }
        if(!test && x[i] == 1){
            d[i] = -1;
        }
    }

    for(int i = 1; i < N; i++)
    {
        if(d[i] != -1)
        {
            for (int j = 0; j<exits[i].size(); j++){
                if (exits[i][j] == 0 && x[i] == 0){
                    d[i] = 1;
                }
                else
                {
                    d[i] = conta(exits[i][j]);
                }

            }
        }
    }



    
    for (int i=0; i<N; i++)
        cout << d[i] << " ";
    cout << endl;

    return 0;
}
