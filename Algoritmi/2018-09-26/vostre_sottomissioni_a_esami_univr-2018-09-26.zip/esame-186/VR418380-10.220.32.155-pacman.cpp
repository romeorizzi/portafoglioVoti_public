/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 10;
const int MAXN = 10;

char mappa[MAXM+1][MAXN+1];
int percorsi;

int M, N;
bool blue;
char n_blue;


int muovi(int new_i, int new_j)
{
  int mosse;
  int n_blue_new;
  int num;
  
  if(mappa[new_i][new_j]=='+')
    {
      mosse = 1;
    }
  if(mappa[new_i][new_j]=='*' && n_blue>0)
    {
      mosse = 1;
    }
  if(mappa[new_i][new_j]=='*' && n_blue <= 0)
    {
      mosse = -2;
    }
  if(mappa[new_i][new_j]=='#')
    {
      mosse = -1;
    }
  else{
    num = mappa[new_i][new_j] - '0';
 
    if(num > 1 && num < 5)
    {
      n_blue_new = mappa[new_i][new_j];
      if(n_blue <= n_blue_new){
	  n_blue = n_blue_new;
       }
    }
  }
  if(n_blue > 0){
    n_blue--;
  }
  //printf("%d\n",mosse);
  return mosse;
}

void esplora(int i, int j)
{
  int dx = 0;
  int dw = 0;
  int new_i = i;
  int new_j= j;

  
  //printf("sono in esplora");
  if(i <= M && j<= N )
  {
    dx = muovi(i+1,j);
    dw = muovi(i, j+1);
  }
    printf("dx: %d", dx);
printf("dy: %d", dw);
  if(i > M)
  {
    dx = -1;
  }
  if(j > N)
  {
    dw = -1;
  }
  if(dx == -1)
  {
    new_j = j+1;
  }
  if(dw == -1)
  {
    new_i = i+1;
  }

  if(dx == -2 || dw == -2)
  {
    return;
  }
  if(i==M && j==N)
  {
    percorsi += 1%1000000;
    return;
  }

  esplora(new_i,new_j);
  esplora(new_i,new_j);
}



int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d%d", &M, &N);
	
    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) {
	do { 
	  scanf("%c", &mappa[i][j]);
	} while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
      }
    }
    if(mappa[1][1]-'0'>0)
      {
	n_blue = mappa[1][1]-'0';
      }
    esplora(1,1);
    printf("%d\n",percorsi);
}
