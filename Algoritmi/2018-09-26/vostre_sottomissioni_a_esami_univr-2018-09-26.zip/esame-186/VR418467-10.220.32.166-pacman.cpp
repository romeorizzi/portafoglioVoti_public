#include <cassert>
#include <cstdio>
#include <iostream>
#include <fstream>


using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];
int risposte[MAXM+1][MAXN+1];
int numSentieri = 0;
int M, N;
ifstream in("esempio1.txt");
ofstream out("output.txt");

void stampaMappa(){
    for (int i = 0; i < N; i++) {
      for (int j = 0; j < M; j++) {
          cout << mappa[i][j] << "\t";
      }
      cout << "\n";
    }
}


bool conquista(int i, int j, int blue){
    bool value;

    if (i == N || j == M)
        return false;

    if (mappa[i][j] == '*' && blue == 0)
        return false;

    if (mappa[i][j] == '#')
        return false;


    if (i == N-1 && j == M-1){
        numSentieri += 1;
        risposte[N-1][M-1] = blue;
        return true;
    }

    if (risposte[i+1][j] != blue){
        numSentieri += 1;
        return true;
    }

    if (risposte[i][j+1] != blue){
        numSentieri += 1;
        return true;
    }



    if (mappa[i][j] == '+'){
        if (blue == 0){
            value = conquista(i+1, j, blue);
            if (value == true){
                risposte[i+1][j] = blue;
            }else
                risposte[i+1][j] = -1;

            value = conquista(i, j+1, blue);
            if (value == true){
                risposte[i][j+1] = blue;
            }else
                risposte[i][j+1] = -1;
        }else{
            blue -= 1;
            value = conquista(i+1, j, blue);
            if (value == true){
                risposte[i+1][j] = blue;
            }else
                risposte[i+1][j] = -1;
            value = conquista(i, j+1, blue);
            
            if (value == true){
                risposte[i][j+1] = blue;
            }else
                risposte[i][j+1] = -1;
        }
        
    }

    if (mappa[i][j] == '*' && blue != 0){
            blue -= 1;
            value = conquista(i+1, j, blue);
            if (value == true){
                risposte[i+1][j] = blue;
            }else
                risposte[i+1][j] = -1;

            value = conquista(i, j+1, blue);
            if (value == true){
                risposte[i][j+1] = blue;
            }else
                risposte[i][j+1] = -1;
        
    }

    if (mappa[i][j] != '+' && mappa[i][j] != '*' && mappa[i][j] != '#'){
        int num;
        num = mappa[i][j]-'0';
        if (num > blue || num == blue){
            value = conquista(i+1, j, num);
            if (value == true){
                risposte[i+1][j] = num;
            }else
                risposte[i+1][j] = -1;
            value = conquista(i, j+1, num);
            if (value == true){
                risposte[i][j+1] = num;
            }else
                risposte[i][j+1] = -1; 
        }else{
            blue -= 1;
            value = conquista(i+1, j, blue);
            if (value == true){
                risposte[i+1][j] = blue;
            }else
                risposte[i+1][j] = -1;
            value = conquista(i, j+1, blue);
            if (value == true){
                risposte[i][j+1] = blue;
            }else
                risposte[i][j+1] = -1;            
        } 
        
    }
}



int main() {
    char a;
    in >> N;
    in >> M;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
	        in >> mappa[i][j];
            risposte[i][j] = -1;
        }
    }

    stampaMappa();
    conquista(0,0,0);
    out << numSentieri % BASE;


}