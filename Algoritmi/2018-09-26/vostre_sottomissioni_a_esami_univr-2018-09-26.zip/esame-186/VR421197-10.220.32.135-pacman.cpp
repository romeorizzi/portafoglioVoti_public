/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>
#include <algorithm>

using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1001;
const int MAXN = 1001;

char mappa[MAXM+1][MAXN+1];
long int memo[MAXM+1][MAXM+1];

int M, N;

int evaluate(int i, int j, int count){

    if(i > M || j > N){
        // out of map
        return 0;
    }else if (i == M && j == N){
        return 1;
    }else{
        if(memo[i][j] > 0){
            return memo[i][j];
        }


        if(mappa[i][j] == '#'){
            //muro
            return 0;
        }else if (mappa[i][j] >= '1' && mappa[i][j] <= '5'){
            memo[i][j] = evaluate(i+1, j, max(count, mappa[i][j]-'0')-1) + evaluate(i, j+1, max(count, mappa[i][j]-'0')-1);

        }else if(mappa[i][j] == '*'){
            if(count >= 0){
                memo[i][j] = evaluate(i+1, j, count-1) + evaluate(i, j+1, count-1);
            }else{
                return 0;
            }

        }else{
            memo[i][j] = evaluate(i+1, j, count-1) + evaluate(i, j+1, count-1);

        }


        return memo[i][j];

    }


}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d%d", &M, &N);

    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) {
            do {
              scanf(" %c", &mappa[i][j]);
            } while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
        }
    }
/*
    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) {
            printf("%c ", mappa[i][j]);
        }
        printf("\n");
    }
*/


    long int risp = evaluate(1,1,-1);
    printf("%d\n",risp % BASE);
    return 0;
}
