/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>
#include <algorithm>

using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];
long int arr[MAXM+1][MAXN+1];

int M, N;


int calc(int i, int j, int ct){

    if(i > M || j > N){
        return 0;
    } else if(i == M && j == N){
        return 1;
    } else{
        /*if(arr[i][j] > 0){
            return arr[i][j];
        }*/

        if(mappa[i][j] == '#'){
            return 0;
        } else if(mappa[i][j] >= '1' && mappa[i][j] <= '5'){
            arr[i][j] = calc(i+1, j, max(ct, mappa[i][j] - '0')-1) + calc(i, j+1, max(ct, mappa[i][j] - '0')-1);
        } else if(mappa[i][j] == '*'){
            if(ct >= 0){
                arr[i][j] = calc(i+1, j, ct-1) + calc(i, j+1, ct -1);
            } else{
                return 0;
            }
        }else{
            arr[i][j] = calc(i+1, j, ct-1) + calc(i, j+1, ct - 1);
        }

        return arr[i][j];

    }

}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    scanf("%d%d", &M, &N);
	
    for (int i = 1; i <= M; i++) {
        for (int j = 1; j <= N; j++) {
	        do { 
	            scanf(" %c", &mappa[i][j]);
	        } while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
        }
    }

    long int percorsi = calc(1, 1, -1);

    percorsi = percorsi % BASE;
    printf("%d\n",percorsi);
    return 0;
}
