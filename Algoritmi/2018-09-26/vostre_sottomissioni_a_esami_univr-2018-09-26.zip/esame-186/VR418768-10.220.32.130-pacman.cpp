#include <stdio.h>
#include <vector>

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];

FILE* fi;
FILE* fo; //file di input e output
int i,j,M,N,fine;
char a;


int ricorsione(int x,int y,int blue){
    int res=0;
    int k;

    if(x==M-1 && y==N-1){

        return 1;
    }
    if(mappa[x][y]!='#'){
        k=mappa[x][y]-'0';

        if(mappa[x][y]=='+' || (mappa[x][y]=='*' && blue>0) || k<= 5 && k>0 ){
            if( k<= 5 && k>0 && k>=blue){
                blue=k+1;
            }
            if(blue>0){
                blue=blue-1;
            }
            if(x<M-1){
                res+=ricorsione(x+1,y,blue);
            }
            if(y<N-1){
                res+=ricorsione(x,y+1,blue);
            }
        }
    }
    return res;
}

int main() {
 
    fi=fopen("input.txt","r");
    fscanf(fi,"%d %d", &M, &N);
    for(i=0; i<M; i++){
        for(j=0; j<N; j++){
            fscanf(fi,"%c", &a);
            if(a!='\n'){
                mappa[i][j]=a;
            }else{
                j--;
            }
        }
    }
    fclose(fi);  

    fine=ricorsione(0,0,0);
  
    fo=fopen("output.txt","w");
    fprintf(fo,"%d",fine);
    fclose(fo);
    

    return 0;

}