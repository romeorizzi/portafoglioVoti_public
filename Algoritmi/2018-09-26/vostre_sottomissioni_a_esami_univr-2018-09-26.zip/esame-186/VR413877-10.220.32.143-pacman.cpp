/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>
#include <map>

using namespace std;

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;

char mappa[MAXM+1][MAXN+1];
int memo[MAXM+1][MAXN+1];

int M, N;

int calcola(int r,int c,bool invincibile,int rimasti){
 
   //printf("R: %d\n" ,r);
   //  printf("C: %d\n" ,c);
   //   printf("mappa: %c\n" ,mappa[r][c]);
 // printf("invincibile %d rimasti %d\n",invincibile,rimasti);
  int res;

  if(r==M+1 || c==N+1) return 0;
  /*if(!invincibile){
    if(memo[r][c]!=-1) {
       printf("memo %d\n",memo[r][c]);
       return memo[r][c];
    }
  }
  else if(invincibile){
    if(memo_inv[r][c]!=-1) {
       printf("memo inv %d\n",memo_inv[r][c]);
       return memo_inv[r][c];
    }
  }*/

  if(r==M && c==N){
    // printf("BASEEE_____\n");
     return 1;
  }
  if(mappa[r][c]=='#') {
   // printf("muro\n");
    return 0;
  }
  
  //trovo la pillola
  if( mappa[r][c] == '1' ||  mappa[r][c] == '2' ||  mappa[r][c] == '3' ||  mappa[r][c] == '4' || mappa[r][c] == '5') {
     //printf("trovo pillola \n");
     if(!invincibile) {
       res= ( calcola(r+1,c,true, mappa[r][c]-'0'-1) + calcola( r,c+1,true, mappa[r][c]-'0'-1 ) ) % BASE ;
   
      }
     if(invincibile && mappa[r][c]-'0'>rimasti) {
      // printf("rimasti %d\n",rimasti-1);
      // printf("mappa %d\n",mappa[r][c]-'0'-1);
       res= (calcola(r+1,c,true, mappa[r][c]-'0'-1) +  calcola( r,c+1,true, mappa[r][c]-'0'-1 ) ) % BASE;
  
      }
     if(invincibile && mappa[r][c]-'0'<=rimasti) {
      // printf("rimasti %d\n",rimasti-1);
       res=( calcola(r+1,c,true, rimasti-1) + calcola( r,c+1,true, rimasti-1 ) ) % BASE; 
     }

     // if(!invincibile) memo[r][c]=res;
     // else memo_inv[r][c]=res;
     
     return res;
  }

  //sono invincibile ed è ultima
  if(invincibile && rimasti==0){
   // printf("invinc ultima\n");
    if(mappa[r][c]=='+' || mappa[r][c]=='*'){
      res= ( calcola(r+1,c,false,  0) + calcola(r,c+1,false,0) ) % BASE;
    ///  printf("ok");
    }
    // memo_inv[r][c]=res;
     return res;
  }
  //sono invincibile e non è ultima
   if(invincibile && rimasti!=0){
   // printf("invinc no ultima\n");
    if(mappa[r][c]=='+' || mappa[r][c]=='*'){
    // printf("ok");
      res= ( calcola(r+1,c,true, rimasti-1) + calcola(r,c+1,true,rimasti-1) ) % BASE;
    }
     //memo_inv[r][c]=res;
     return res;
  }

  //non sono invincibile
   if(!invincibile){
    //printf("no inv\n");
    if(mappa[r][c]=='+'){
   //   printf("ok");
      res= ( calcola(r+1,c,false, 0) + calcola(r,c+1,false,0) )% BASE;
    }
    if(mappa[r][c]=='*'){
    //  printf("morto\n");
      res=0; //morto
    }
    //memo[r][c]=res;
    return res;
  }

}

int calcola_no_fantasmi(int r,int c,bool invincibile,int rimasti){

  int res;
  //printf("R: %d " ,r);
  //printf("C: %d\n" ,c);
 

  if(memo[r][c]!=0) {
    //printf("memo\n");
     return memo[r][c]; 
  }
 
  if(r==M+1 || c==N+1) return 0;  
  if(r==M && c==N){
     //printf("base\n"); 
     return 1;
  }
  if(mappa[r][c]=='#') {
    //printf("muro\n"); 
    return 0;
  }

    res= ( calcola_no_fantasmi(r+1,c,false, 0) + calcola_no_fantasmi(r,c+1,false,0) )% BASE;
    memo[r][c]=res;
    return res;

}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d%d", &M, &N);

    bool fantasmi=false;
	
    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) { 
	do { 
	  scanf("%c", &mappa[i][j]);
      if(mappa[i][j]=='*') fantasmi=true;
	} while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
    } }

    int risp=0;
 
    if(!fantasmi) risp=calcola_no_fantasmi(1,1,false,0); 
    else risp = calcola(1,1,false,0);
    
    printf("%d\n",risp);
    return 0;
}
