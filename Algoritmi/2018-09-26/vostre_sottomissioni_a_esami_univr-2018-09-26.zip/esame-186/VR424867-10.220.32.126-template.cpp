/**
 *  Un template per la soluzione di hanoi_tower_reset
 *
 *  Author: Romeo Rizzi, 2018-09-21
 *
 */

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXN = 31;

int N;
char pole[MAXN +1];
int numMoves = 0;
int contatore=0;



// USE THE FOLLOWING FUNCTION WHEN YOU ARE REQUIRED TO ACTUALLY SPECIFY EACH MOVE (n<=10)
void spostaDisco(int n, char from, char to) {
  if(N<=10){
    assert(pole[n]==from);
    printf("Muovi il disco %d dal piolo %c al piolo %c\n", n, from, to);
    pole[n] = to;
  }else{
      contatore=(contatore+1)%1000000;
  }
}


void stampa_mosse(int n,char inizio,char fine,char supporto ){

    if(n==0)
        return;
    stampa_mosse(n-1,inizio,supporto,fine);
    spostaDisco(n,inizio,fine);
    stampa_mosse(n-1,supporto,fine,inizio);

}


int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       do
          scanf("%c", &pole[i]);
       while( pole[i] < 'A' || pole[i] > 'C');
    }
    int i=0;
    while(pole[N-i]=='A'){
        i++;
    }
    stampa_mosse(N-i,'C','A','B');
    if(N>10)
        printf("%i",contatore%1000000);
    return 0;
}

