/* template per pacman, problema per esame Algorimi 2018-09-26
   Romeo 2018-09-25
*/

#include <cassert>
#include <cstdio>

const int BASE = 1000000;
const int MAXBLUE = 5;
const int MAXM = 1000;
const int MAXN = 1000;
int indici[100000][2];
int pos;

char mappa[MAXM+1][MAXN+1];

int M, N;

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    scanf("%d%d", &M, &N);
	
    for (int i = 1; i <= M; i++) {
      for (int j = 1; j <= N; j++) {
	do { 
	  scanf("%c", &mappa[i][j]);
	} while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );
    }
    }

	int cammini[M+1][N+1];
	int blu[M+1][N+1];
	

    cammini[1][1]=1;
    for (int i = 1; i <= M; i++) {
      for (int j=1; j<=N;j++){

        if(i==1 && j==1)
            cammini[1][1]=1;
        
        else if(mappa[i][j]=='+'){
                if(i==1)
                    cammini[i][j]=(cammini[i][j-1])%1000000;
                else if(j==1)
                    cammini[i][j]=(cammini[i-1][j])%1000000;
                else
                    cammini[i][j]=(cammini[i-1][j]+cammini[i][j-1])%1000000;
        }
        else if(mappa[i][j]=='#'){
                cammini[i][j]=0;
        }

        else if(mappa[i][j]=='*'){
                cammini[i][j]=0;
        }

        else if(mappa[i][j]>='1' || mappa[i][j]<='5'){
                indici[pos++][1]=i;
                indici[pos++][2]=j;
                
                if(i==1){
                    cammini[i][j]=(cammini[i][j-1])%1000000;
                }
                else if(j==1){
                    cammini[i][j]=(cammini[i-1][j])%1000000;
                }else{
                    cammini[i][j]=(cammini[i-1][j]+cammini[i][j-1])%1000000;
                }
        }

        
      }
    }

    

	
       
    int risp = 0;
    risp=cammini[M][N];
    printf("%d\n",risp);
    return 0;
}
