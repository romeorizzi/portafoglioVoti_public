#include <cstdio>
#include <algorithm>
using namespace std;

const int BASE = 1000000, MAXBLUE = 5, MAX = 1001;

char mappa[MAX+1][MAX+1];
long int memo[MAX+1][MAX+1];


int M, N;


int evaluate (int i, int j, int ct){
    if ( i>M || j> N)
        return 0;
    else if( j == N && i==M)
        return 1;
    else{
        if (mappa[i][j] == '#')
            return 0;
        else if(mappa[i][j] >= '1' && mappa[i][j] <='5')
            memo[i][j] = evaluate(i+1,j,max(ct,mappa[i][j]-'0')-1) + evaluate(i,j+1,max(ct,mappa[i][j]-'0')-1);
        else if(mappa[i][j]=='*'){
            if(ct>=0)
                memo[i][j] = evaluate(i+1,j,ct-1)+ evaluate(i,j+1, ct-1);
            else
                return 0;
        }
        else
            memo[i][j] = evaluate(i+1,j,ct-1)+ evaluate(i,j+1,ct-1);
    }
    
    
    return memo[i][j];

}




int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d%d", &M, &N);
	
    for (int i = 1; i <= M; i++) 
      for (int j = 1; j <= N; j++) 
	    do { 
	        scanf("%c", &mappa[i][j]);
	    } while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '5')  );

    long int risp = evaluate(1,1,-1);
    printf("%d\n", risp%BASE);
}























