#include <cassert>
#include <cstdio>
#include <iostream>
#include <fstream>

const int BASE = 1000000;
const int MAXN = 30;

int N;
char pole[MAXN + 1];
int numMoves = 0;
int ct = 0;

void spostaDisco(int n, char from, char to){
    if (N <= 10){
        assert(pole[n] == from);
        printf("Muovi il disco %d dal piolo %c al piolo %c\n", n, from, to);
        pole[n] = to;
    }else{
        ct = (ct+1)%BASE;
    }
}

void stampaMosse(int n, char inizio, char fine, char supporto){
    if (n == 0)
        return;
    stampaMosse(n-1, inizio, supporto, fine);
    spostaDisco(n, inizio, fine);
    stampaMosse(n-1, supporto, fine, inizio);
}


int main(){
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin));
    assert( freopen("output.txt", "w", stdout));
#endif

    scanf("%d", &N);
    for(int i=1; i <= N; i++ ){
        do
            scanf("%c", &pole[i]);
        while( pole[i] < 'A' || pole[i] > 'C');
    }

    stampaMosse(N, 'C', 'A', 'B');
    if(N>10)
        printf("%d", ct);

    return 0;






}
