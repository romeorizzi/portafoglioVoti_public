#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int maxN = 2000000; int N;

static int altezza[maxN];
int left[maxN];
int right[maxN];
int memo[maxN];
int first[maxN];
bool direzione[maxN];
int NCand,i,j, test;
int candidati[maxN];
int candMin[maxN];

void Abbatti(int , int );

void Pianifica(int N, int altezza[]) {
    left[0] = 0;
    for (i = 1; i < N; i++) {
        j = i-1;
        while (j >= 0 && i - j < altezza[i])
            j = left[j] - 1;
        left[i] = j + 1;
    }

    right[N-1] = N-1;
    for (i = N-2; i >= 0; i--) {
        j = i + 1;
        while (j < N && j - i < altezza[i])
            j = right[j] + 1;
        right[i] = j - 1;
    }


    for (i = 0; i < N; i++) {

        j = left[i] - 1;

        test = 1;
        if (j >= 0)
            test += memo[j];

        memo[i] = test;
        first[i] = i;
        direzione[i] = false;


        while (NCand && right[*(candidati + NCand - 1)] < i)
            --NCand;

        if (NCand) {
            j = candMin[NCand - 1] - 1;

            test = 1;
            if (j >= 0)
                test += memo[j];

            if (test < memo[i]) {
                memo[i] = test;
                first[i] = j + 1;
                direzione[i] = true;
            }
        }

        j = i;
        if (NCand) {
            if (
                candMin[NCand - 1] == 0 ||
                memo[candMin[NCand - 1] - 1] < memo[i - 1]
            ) {
                j = candMin[NCand - 1];
            }
        }

        ++NCand;
        candidati[NCand - 1] = i;
        candMin[NCand - 1] = j;
    }


    int k = N - 1;
    while (k >= 0) {
        Abbatti(first[k], direzione[k]);

        if (direzione[k] == false)
            k = left[k] - 1;
        else
            k = first[k] - 1;
    }
}


