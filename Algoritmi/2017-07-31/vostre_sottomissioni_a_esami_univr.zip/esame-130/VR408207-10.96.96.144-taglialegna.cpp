#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAXN = 2000000; int N;

int lep[MAXN];
int rep[MAXN];
int arr[MAXN];
int first_tree[MAXN];
bool dir[MAXN];
int n_cand;
int cand[MAXN];
int min_cand[MAXN];

void Abbatti(int indice, int dir);

void Pianifica(int N, int H[]) {
	lep[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = lep[j] - 1;
		lep[i] = j + 1;
	}

	rep[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = rep[j] + 1;
		rep[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		j = lep[i] - 1;

		test = 1;
		if (j >= 0)
			test += arr[j];
		
		arr[i] = test;
		first_tree[i] = i;
		dir[i] = false;

		while (n_cand && rep[*(cand + n_cand - 1)] < i)
			--n_cand;

		if (n_cand) {
			j = min_cand[n_cand - 1] - 1;

			test = 1;
			if (j >= 0)
				test += arr[j];

			if (test < arr[i]) {
				arr[i] = test;
				first_tree[i] = j + 1;
				dir[i] = true;
			}
		}

		j = i;
		if (n_cand)
			if (min_cand[n_cand - 1] == 0 || arr[min_cand[n_cand - 1] - 1] < arr[i - 1])
				j = min_cand[n_cand - 1];

		++n_cand;
		cand[n_cand - 1] = i;
		min_cand[n_cand - 1] = j;
	}

	int i = N - 1;
	while (i >= 0) {
		Abbatti(first_tree[i], dir[i]);
		
		if (dir[i] == false)
			i = lep[i] - 1;
		else
			i = first_tree[i] - 1;
	}
}

