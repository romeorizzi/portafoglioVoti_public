#include <iostream>
#include <algorithm>
#include <limits>
#include <stack>

using namespace std;

void Abbatti(int, int);

const int MAXN = 2000000;
int n_alberi;
int alberi[MAXN];
int min_alberi[MAXN];
int lep[MAXN];
int rep[MAXN];
int memo[MAXN];
int albero[MAXN];
bool direzione[MAXN];

void Pianifica(int N, int altezza[]) {
	lep[0]=0;
	for (int i=1; i<N; i++) {
		int j=i-1;
		while (j>=0 && i-j < altezza[i])
			j=lep[j]-1;
		lep[i]=j+1;
	}

	rep[N-1]=N-1;
	for (int i=N-2; i>=0; i--) {
		int j=i+1;
		while (j<N && j-i < altezza[i])
			j=rep[j]+1;
		rep[i]=j-1;
	}

	int j, test;
	for (int i=0; i<N; i++) {
		j=lep[i]-1;

		test=1;
		if (j>=0)
			test += memo[j];
		
		memo[i]=test;
		albero[i]=i;
		direzione[i]=false;

		while (n_alberi && rep[*(alberi + n_alberi-1)] < i)
			--n_alberi;

		if (n_alberi) {
			j=min_alberi[n_alberi-1]-1;

			test=1;
			if (j >= 0)
				test+=memo[j];

			if (test<memo[i]) {
				memo[i]=test;
				albero[i]=j+1;
				direzione[i]=true;
			}
		}

		j = i;
		if (n_alberi) {
			if (min_alberi[n_alberi-1] == 0 || memo[min_alberi[n_alberi-1]-1] < memo[i-1])
				j=min_alberi[n_alberi-1];
		}

		++n_alberi;
		alberi[n_alberi-1]=i;
		min_alberi[n_alberi-1]=j;
	}

	int i=N-1;
	while (i>=0) {
		Abbatti(albero[i], direzione[i]);
		
		if (direzione[i] == false)
			i=lep[i]-1;
		else
			i=albero[i]-1;
	}
}

