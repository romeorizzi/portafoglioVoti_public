#include <bits/stdc++.h>
using namespace std;

#define MAXN 100000
#define MAXM 100000

struct arco{
  int el[2];
  bool valid;
  arco(int a,int b){
    el[0]=a;
    el[1]=b;
    valid=true;
  }
};

struct elink{
  int arco_id;
  int ordine;
  elink(int ed,int ord){
    arco_id=ed;
    ordine=ord;
  }
};

vector<arco> archi;
vector<vector<elink> > graph;
vector<int> cammino;


int N, M, X, Y;

void dfs(int el) {
  for(unsigned int i=0; i<graph[el].size(); i++) {
     elink e=graph[el][i];
     if(archi[e.arco_id].valid) {
        archi[e.arco_id].valid=false;
        dfs(archi[e.arco_id].el[e.ordine]);
     }
  }
  cammino.push_back(el);
}


int main() {

    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);


    cin >> N;
    cin >> M;
    cin >> X;
    cin >> Y;
    X--; Y--;
    graph.reserve(N);
    for(int i=0; i<M; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        graph[a].push_back( elink(archi.size(),1) );
        graph[b].push_back( elink(archi.size(),0) );
        archi.push_back( arco(a,b) );
    }
    dfs(Y);
    assert( (unsigned int)M == cammino.size()-1 );
    for(unsigned int i=0; i<cammino.size()-1; i++)
        cout << cammino[i]+1 << " " << cammino[i+1]+1 << "\n";
    return 0;
}

