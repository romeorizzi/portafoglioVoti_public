#include <iostream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>
using namespace std;

void Abbatti(int, int);

int num_candid;
const int MAXN = 2000000;
int memor[MAXN];
int first_tree[MAXN];
int arrR[MAXN];
int arrL[MAXN];
bool direz[MAXN];
int candidati[MAXN];
int min_candid[MAXN];

void Pianifica(int N, int H[]) {
	arrL[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i]) {j = arrL[j] - 1; }
		arrL[i] = j + 1;
	}

	arrR[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i]) {j = arrR[j] + 1; }
		arrR[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		//vado a sx
		j = arrL[i] - 1;

		test = 1;
		if (j >= 0)
			test += memor[j];
		
		memor[i] = test;
		first_tree[i] = i;
		direz[i] = false;

		//vado a dx
		while (num_candid && arrR[*(candidati + num_candid - 1)] < i)
			--num_candid;

		if (num_candid) {
			j = min_candid[num_candid - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memor[j];

			if (test < memor[i]) {
				memor[i] = test;
				first_tree[i] = j + 1;
				direz[i] = true;
			}
		}

		j = i;
		if (num_candid) {
			if (min_candid[num_candid - 1] == 0 ||
				memor[min_candid[num_candid - 1] - 1] < memor[i - 1]){
				j = min_candid[num_candid - 1];
			}
		}

		++num_candid;
		candidati[num_candid - 1] = i;
		min_candid[num_candid - 1] = j;
	}



	int p = N - 1;

	while (p >= 0) {
		Abbatti(first_tree[p], direz[p]);

		if (direz[p] == false){ p = arrL[p] - 1; }
		else { p = first_tree[p] - 1; }
	}


}


