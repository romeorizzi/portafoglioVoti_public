#define NDEBUG   
#include <cassert>
#ifdef NDEBUG
  #define EVAL
#endif
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

const int MAXN = 1000000;
const int MAXM = 1000000;  

struct arco{
  int elemento[2];
  bool valido;
  arco(int a,int b){
    elemento[0]=a;
    elemento[1]=b;
    valido=true;
  }
};

struct collegamento{
  int arco_id;
  int order;
  collegamento(int ed,int ord){
    arco_id=ed;
    order=ord;
  }
};

//inizializzo tutte le variabili necessari
vector<vector<collegamento> > graph;
vector<arco> archi;

vector<int> path;


int A, B, J, val;

void dfs(int elemento);


int main() {

        freopen("input.txt","r", stdin);
        freopen("output.txt","w", stdout);


  cin >> A >> B >> J >> val;
  J--; val--;
  graph.reserve(A);


//ciclo for per creare il grafo che deve poi essere visitato con la dfs
      for(int i=0; i<B; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        graph[a].push_back( collegamento(archi.size(),1) );
        graph[b].push_back( collegamento(archi.size(),0) );
        archi.push_back( arco(a,b) );
      }
  
    dfs(val);




      for(int i=0; i<path.size()-1; i++)
        cout << path[i]+1 << " " << path[i+1]+1 << endl;
      return 0;
}

void dfs(int elemento) {
  for(int i=0; i<graph[elemento].size(); i++) {
     collegamento e=graph[elemento][i];
     if(archi[e.arco_id].valido) {
        archi[e.arco_id].valido=false;
        dfs(archi[e.arco_id].elemento[e.order]);
     }
  }


     path.push_back(elemento);
}
