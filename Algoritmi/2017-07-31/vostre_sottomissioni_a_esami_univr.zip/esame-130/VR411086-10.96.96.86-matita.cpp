#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main(){
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    int N, V, A, B;
    vector<int> risultato;
    stack<int> tmpStack;
    
    vector<list<int>> grafo;
    vector<int> archi;
    
    in >> N >> V >> A >> B;
    grafo.resize(N + 1);
    archi.resize(V);

    int temp1, temp2;

    for(int i = 0 ; i < V ; i++){
        in >> temp1 >> temp2;
        archi[i] = temp1 + temp2;
        grafo[temp1].push_back(i);
        grafo[temp2].push_back(i);
    }

    int c = A;

    while(risultato.size() < V){
        bool haVicini = false;

        for(list<int>::iterator i = grafo[c].begin(); i != grafo[c].end(); i++)
            if(archi[*i] > 0){
                tmpStack.push(c);  
                haVicini = true;
                int next = archi[*i] - c;
                archi[*i] = -1;
                grafo[c].remove(*i);
                c = next;
                grafo[c].remove(*i);
                break;
            }
        
        if(!haVicini){
            risultato.push_back(c);
            c = tmpStack.top();
            tmpStack.pop();
        }
    }
    
    risultato.push_back(A);

    for(int i = risultato.size() - 1; i > 0; i--){
        out << risultato[i] << " " << risultato[i - 1] << "\n";
    }

    return 0;
}
