
#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>

using namespace std;

struct edge{
    int vertex[2];
    bool used;
    edge(int a,int b){
        vertex[0]=a;
        vertex[1]=b;
        used=false;
    }
};

struct edge_track{
    int edge_id;
    int order;
    edge_track(int id_default, int ord_default){
        edge_id = id_default;
        order = ord_default;
    }
};

//GLOBAL VAR
vector<vector<edge_track> > graph;
vector<edge> edge_list;
vector<int> solution;

//FUNCTION
void depth_first(int);

int main() {
    std::ifstream input_file("input.txt");
    std::ofstream output_file("output.txt");
    int N_VERT, N_EDGES, SOURCE, DEST;

    input_file >> N_VERT >> N_EDGES >> SOURCE >> DEST;
    SOURCE -= 1; 
    DEST -= 1;
    graph.reserve(N_VERT);
    for(int i=0; i<N_EDGES; i++) {
        int from, to;
        input_file >> from >> to;
        from -= 1; 
        to -= 1;
        graph[from].push_back(edge_track(edge_list.size(),1));
        graph[to].push_back(edge_track(edge_list.size(),0));
        edge_list.push_back(edge(from,to));
    }

    depth_first(DEST);
  
    for(int i=0; i<solution.size()-1; i++)
        output_file << solution[i]+1 << " " << solution[i+1]+1 << endl;

    return 0;
}

void depth_first(int start) {
  for(int i=0; i<graph[start].size(); i++) {
     edge_track etr = graph[start][i];
     if(!edge_list[etr.edge_id].used) {
        edge_list[etr.edge_id].used = true;
        depth_first(edge_list[etr.edge_id].vertex[etr.order]);
     }
  }

  solution.push_back(start);
}
