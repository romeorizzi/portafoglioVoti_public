#include <bits/stdc++.h>
using namespace std;
const int DISPONIBILE = -1;
const int NO = -1;

set<int> available;
vector<int> posti;
vector<int> where;
int N;
int Q;
int answer;
int i;
int reservation;
int offender;

int aux(int person){
    offender= posti[person];
    posti[person]= where[person]=person;
    if(posti[offender]==DISPONIBILE){
        posti[offender] = where[offender] = offender;
        auto posto_temp = available.find(offender);
        assert(posto_temp!= available.end());
        available.erase(posto_temp);
        return 1;
    }else{
        return 1+aux(offender);
    }
}

int main(){
    cin >> N >> Q;
    answer=0;
    posti.resize(N, DISPONIBILE);
    where.resize(N, NO);

    for(i=0; i<Q; i++){
        string event;
        cin >> event >> reservation;
        if(event[0]=='b'){
            auto leftmost = available.begin();
            assert (leftmost!= available.end());
            if(*leftmost <= reservation){
                posti[*leftmost]= reservation;
                where[reservation] = *leftmost;
                available.erase(leftmost);
            }else{
                answer+=aux(reservation);
            }
        }else{
            assert(where[reservation]!= NO);
            available.insert(where[reservation]);
            posti[where[reservation]]= DISPONIBILE;
            where[reservation] = NO;
        }
    }
    cout << answer << endl;
}
