#include <bits/stdc++.h>

using namespace std;

const int SEAT_AVAILABLE = -1;
const int NON_EXISTENT = -1;
set<int> available;
vector<int> seat;
vector<int> where;
int N, Q, answer, i, reservation, offender;

int fix_people(int person){
    offender = seat[person];
    seat[person]= where[person]=person;

    if(seat[offender] == SEAT_AVAILABLE){
        seat[offender] = where[offender]= offender;
        auto my_seat = available.find(offender);
        assert(my_seat!=available.end());
        available.erase(my_seat);
        return 1;
    }
    else{
        return 1+fix_people(offender);
    }
}

int main()
{

    cin >> N >> Q;
    seat.resize(N, SEAT_AVAILABLE);
    where.resize(N, NON_EXISTENT);


    for(i=0; i<N; i++){
        available.insert(i);
    }

    answer=0;
    for(i=0; i<Q; i++){

        string event;

        std::cin >> event >> reservation;

        if(event[0] == 'b'){
            auto leftmost = available.begin();



            if(*leftmost <= reservation){
                seat[*leftmost]= reservation;
                where[reservation] = *leftmost;
                available.erase(leftmost);
            }
            else{
                answer+=fix_people(reservation);
            }
        }else{
             assert(where[reservation]!= NON_EXISTENT);

             available.insert(where[reservation]);
             seat[where[reservation]]== SEAT_AVAILABLE;
             where[reservation]= NON_EXISTENT;
         }



    }

    cout << answer << std::endl;

}

