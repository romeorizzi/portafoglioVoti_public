#include<bits/stdc++.h>

using namespace std;

const int LIBERO=-1;
const int NON_PRESENTE=-1;
int N,Q,risposta,i,reservation,offender;
set<int> available;
vector<int> posto;
vector<int> posizione;


int aux(int person){
    offender=posto[person];
    posto[person]=posizione[person]=person;

    if(posto[offender]==LIBERO){
        posto[offender]=posizione[offender]=offender;
        auto posto_temp= available.find(offender);
        assert(posto_temp!=available.end());
        available.erase(posto_temp);
        return 1;
    }else{
        return 1+aux(offender);
    }
}

int main(){

    cin >> N >> Q;
    risposta=0;
    posto.resize(N,LIBERO);
    posizione.resize(N,NON_PRESENTE);

    for(i=0; i<N;i++){
        available.insert(i);
    }

    for(i=0;i<Q;i++){
        string event;
        std:cin >> event >> reservation;
        if(event[0]=='b'){
            auto leftmost=available.begin();
            assert(leftmost!=available.end());
            if(*leftmost<=reservation){
                posto[*leftmost]=reservation;
                posizione[reservation]=*leftmost;
                available.erase(leftmost);
            }else{
                risposta+=aux(reservation);
            }
        }else{
            assert(posizione[reservation]!=NON_PRESENTE);

            available.insert(posizione[reservation]);
            posto[posizione[reservation]]=LIBERO;
            posizione[reservation]=NON_PRESENTE;
        }

    }
    cout<<risposta<<endl;
}



