#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
#include <list>
#include <vector>

using namespace std;

int main()
{
ifstream in("input.txt");
ofstream out("output.txt");

int M,W,A,B;
vector<int> sol;
stack<int> tempS;
vector<list<int> >grafo;
vector<int> archi;

in >> M >> W >> A >> B;

grafo.resize(M+1);
archi.resize(W);

int temp1, temp2;

for(int i=0; i<W; i++)
{
 in>>temp1>>temp2;
 archi[i]=temp1 + temp2;
 grafo[temp1].push_back(i);
 grafo[temp2].push_back(i);
 }

 int d=A;

 while(sol.size() < W)
 {
 bool hasNeighbour = false; 

 for(list<int>::iterator i = grafo[d].begin(); i !=grafo[d].end(); i++)
 
 if (archi[*i]>0)
 {
 tempS.push(d);
 hasNeighbour = true;
 int next = archi[*i]-d;
 archi[*i]=-1;
 grafo[d].remove(*i);
 d=next;
 grafo[d].remove(*i); 
break;
 }

if(!hasNeighbour)
{

 sol.push_back(d);
 d= tempS.top();
 tempS.pop();
 }
}
 sol.push_back(A);

 for(int i= sol.size() -1; i>0; i--)
 out<<sol[i]<< " " <<sol[i-1] << "\n";
 
 return 0;
}






 

