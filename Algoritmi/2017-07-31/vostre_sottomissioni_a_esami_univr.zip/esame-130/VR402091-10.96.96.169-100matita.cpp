#include <iostream>
#include <stdlib.h>
#include <cassert>
#include <vector>
#include <stack>
#include <list>
#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

int main()
{
ifstream in("input.txt");
ofstream out("output.txt");
int D,U,C,E;
vector <int> sol;
stack <int> tempS;
vector <list<int>> graph;
vector <int> edge;

in >> D >> U >> C >> E;

graph.resize(D+1);
edge.resize(U);

int temp1,temp2;
int i;
        
for(i=0;i<U;i++){
in >> temp1 >> temp2;
edge[i]= temp1+temp2;
graph[temp1].push_back(i);
graph[temp2].push_back(i);
}

int a= C;
while(sol.size() < U )
{
bool haVicini = false ;
for(list<int>::iterator i=graph[a].begin();i!=graph[a].end();i++)       
if(edge[*i]> 0){
tempS.push(a);
haVicini = true;
int next=edge[*i]-a;
edge[*i]= -1;
graph[a].remove(*i);
a=next;
graph[a].remove(*i);
break;
}
if(!haVicini)
{
sol.push_back(a);
a=tempS.top();
tempS.pop();
}
}
sol.push_back(C);

for(int i=sol.size()-1;i>0;i--)
out << sol[i]<< " " << sol[i-1] << "\n";
return 0;
}

        

    
