#include <cassert>
#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100000;
const int MAXM = 100000; 

struct arco{
  int elemento[2];
  bool ok;
  arco(int a,int b){
    elemento[0]=a;
    elemento[1]=b;
    ok=true;
  }
};

struct alink{
  int arco_id;
  int ord;
  alink(int ad,int ord_){
    arco_id=ad;
    ord=ord_;
  }
};
 
vector<arco> edges;
vector<vector<alink> > graph;
vector<int> path;
ifstream fin;
ofstream fout;


int N, M, X, Y;

void dfs(int current) {
  for(int i=0; i<graph[current].size(); i++) {
     alink a=graph[current][i];
     if(edges[a.arco_id].ok) {
        edges[a.arco_id].ok=false;
        dfs(edges[a.arco_id].elemento[a.ord]);
     }
  }
  path.push_back(current);
}


int main() {

  fin.open("input.txt");
  fout.open("output.txt");
  assert(fin);assert(fout);
  


  fin >> N >> M >> X >> Y;
  X--; Y--;
  graph.resize(N);
  for(int i=0; i<M; i++) {
    int a, b;
    fin >> a >> b;
    a--; b--;
    graph[a].push_back( alink(edges.size(),1) );
    graph[b].push_back( alink(edges.size(),0) );
    edges.push_back( arco(a,b) );
  }
  dfs(Y);
  assert(M == path.size()-1 );
  for(int i=0; i<path.size()-1; i++)
    fout << path[i]+1 << " " << path[i+1]+1 << endl;
  fin.close();
  fout.close();
  return 0;
}

