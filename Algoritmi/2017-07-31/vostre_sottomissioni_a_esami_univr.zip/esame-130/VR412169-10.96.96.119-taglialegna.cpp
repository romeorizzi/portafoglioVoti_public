#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAXN = 2000000; int N;

ifstream fr;
ofstream fw;

//static int Abbatti[MAXN];
int leftEp[MAXN];  // fissato i, leftEp[i] contiene l'indice dell'albero più a sinistra
			    // distrutto dall'abbattimento di i
int rightEp[MAXN];  // fissato i, rightEp[i] contiene l'indice dell'albero più a destra
			    // distrutto dall'abbattimento di i
int memoria[MAXN];
int primo_albero[MAXN];
bool direzione[MAXN];
int n_candidati;
int candidati[MAXN];
int minimo_candidati[MAXN];
static char intbuf[32];

void Abbatti(int indice, int direzione);


void Pianifica(int N, int H[]) {
	leftEp[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = leftEp[j] - 1;
		leftEp[i] = j + 1;
	}

	rightEp[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = rightEp[j] + 1;
		rightEp[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		// Primo caso: butto i a sinistra
		j = leftEp[i] - 1;

		test = 1;
		if (j >= 0)
			test += memoria[j];
		
		memoria[i] = test;
		primo_albero[i] = i;
		direzione[i] = false;

		// Secondo caso: abbatto a destra un albero che abbatte i nella caduta
		while (n_candidati && rightEp[*(candidati + n_candidati - 1)] < i)
			--n_candidati;

		if (n_candidati) {
			j = minimo_candidati[n_candidati - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memoria[j];

			if (test < memoria[i]) {
				memoria[i] = test;
				primo_albero[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (n_candidati) {
			if (
				minimo_candidati[n_candidati - 1] == 0 ||
				memoria[minimo_candidati[n_candidati - 1] - 1] < memoria[i - 1]
			) {
				j = minimo_candidati[n_candidati - 1];
			}
		}

		++n_candidati;
		candidati[n_candidati - 1] = i;
		minimo_candidati[n_candidati - 1] = j;
	}

	// Ricostruisci la soluzione
	int i = N - 1;
	while (i >= 0) {
		Abbatti(primo_albero[i], direzione[i]);
		
		if (direzione[i] == false) // A sinistra
			i = leftEp[i] - 1;
		else
			i = primo_albero[i] - 1;
	}
}

