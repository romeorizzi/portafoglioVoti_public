#include <bits/stdc++.h>
#define N_MAX 100000
using namespace std;

bool occupato[N_MAX];
long long int posto[N_MAX];
long long int spostamenti;
long long int N;
long long int primo_libero;

void aggiornaPL(){
    for(long long int i = 0; i<N; i++)
        if(!occupato[i]){
            primo_libero = i;
            return;            
        }
    return;
}

void aggiorna(long long int pos){
    if(primo_libero<pos){
        occupato[primo_libero] = true;
        posto[primo_libero] = pos;
        aggiornaPL();
        return;    
    }
    if(occupato[pos]){
        long long int mandato_via = posto[pos];
        spostamenti++;
        posto[pos] = pos;
        return aggiorna(mandato_via); 
    }
    else{//se pos è libero
        occupato[pos] = true;
        posto[pos] = pos;
        aggiornaPL();
        return;
    }
    return;
}

int main(void){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    long long int Q;
    cin>>N;
    cin>>Q;
    char comando;
    long long int posizione; 
    for(long long int i = 0; i<Q; i++){
        cin>>comando;
        cin>>posizione;
        if(comando == 'b')
            aggiorna(posizione);
        if(comando == 'l'){
            primo_libero = min(primo_libero, posizione);
            occupato[posizione] = false;
        }
    } 
    cout<<spostamenti<<"\n";   
    return 0;
}





