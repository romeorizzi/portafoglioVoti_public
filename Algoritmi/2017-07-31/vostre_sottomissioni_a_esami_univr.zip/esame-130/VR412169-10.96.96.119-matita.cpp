#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>

#include <iostream>

using namespace std;

int main() 
{
    ifstream in("input.txt");
    ofstream out("output.txt");

    //N numero vertici
    //V numero lati che li collegano
    //START vertiche di partenza
    //END vertice di arrivo
    int N, V, START, END;
    vector<int> soluzioni;
    stack<int> tempS;
    vector<list<int> > grafo;
    vector<int> archi;

    //inizializzazione dei valori da input
    in >> N >> V >> START >> END;
    
    //definiamo la grandezza degli array del grafo e quella degli archi
    grafo.resize(N+1);
    archi.resize(V);
    
    int vertice1, vertice2;

    //per ogni vertice presente nel nostro file di input
    //tolgo dal nostro array dei grafu vertici collegati da un lato 
    for (int i = 0; i < V; i++) {
        in >> vertice1 >> vertice2;
        archi[i] = vertice1 + vertice2;
        grafo[vertice1].push_back(i);
        grafo[vertice2].push_back(i);
    }
    
    int c = START;

    //se la dimensione del vettore delle soluzione è minore del numero dei lati che collegano i vertici
    while (soluzioni.size() < V) {
        bool hasN = false;
        
        //iteriamo sul grafo
        for (list<int>::iterator i = grafo[c].begin(); i != grafo[c].end(); i++)
            if (archi[*i] > 0) {
                tempS.push(c);
                hasN = true;
                int next = archi[*i]-c;
                archi[*i] = -1;
                grafo[c].remove(*i);
                c = next;
                grafo[c].remove(*i);
                break;            
            }

        //se non ho vicini
        if (!hasN) {
            //tolgo dalle soluzioni c.
            soluzioni.push_back(c);
            
            //predo la testa dello stack
            c = tempS.top();
            //faccio la pop
            tempS.pop();
        }
    }

    //tolgo dalle soluzioni il vertice di partenza
    soluzioni.push_back(START);

    //per ogni soluzione partendo dalla coda stampo le coppie dei nodi che si possono raggiungere
    for(int i = soluzioni.size() -1; i > 0; i--)
        out << soluzioni[i] << " " << soluzioni[i-1] << "\n";

    return 0;
}
