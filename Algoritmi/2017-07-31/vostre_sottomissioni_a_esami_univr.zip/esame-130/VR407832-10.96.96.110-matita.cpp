#include<vector>
#include<queue>
#include<fstream>
#include<stack>
#include<list>
#include<iostream>

using namespace std;

int main()
{
    
    ifstream in("input.txt");
	ofstream out("output.txt");

	int N, V, A, B;

	vector<int> soluzione;
	vector<list<int>> grafo;
	vector<int> archi;

	stack<int> stack;

	in >> N >> V >> A >> B;

	grafo.resize(N+1);
	archi.resize(V);

	int t1, t2;

	for(int i = 0; i < V; i++)
	{
		in >> t1 >> t2;
		archi[i] = t1 + t2;
		grafo[t1].push_back(i);
		grafo[t2].push_back(i);
	}

	int c = A;

	while(soluzione.size() < V)
	{

		bool neigh = false;

		for(list<int>::iterator i = grafo[c].begin(); i != grafo[c].end(); i++)
		{
			stack.push(c);
            neigh = true;
            int next = archi[*i] - c;
            grafo[c].remove(*i);
            c = next;
            grafo[c].remove(*i);
            break;
		}

        if(!neigh)
		{
            soluzione.push_back(c);
            c = stack.top();
            stack.pop();
        }
	}

    soluzione.push_back(A);

    for(int i = soluzione.size() - 1; i > 0; i--)
        out << soluzione[i] << " " << soluzione[i-1] << "\n";

    return 0; 
}
