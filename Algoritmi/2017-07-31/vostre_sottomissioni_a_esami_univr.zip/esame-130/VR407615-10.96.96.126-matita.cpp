#define NDEBUG  
#include <cassert>
#ifdef NDEBUG
#define EVAL
#endif
#include <iostream>
#include <fstream>
#include <vector>
#define MAXN  100000;
#define MAXM  100000;
using namespace std;


struct arco{
    int vertici[2];
    bool valido;
    arco(int a,int b){
        vertici[0]=a;
        vertici[1]=b;
        valido=true;
    }
};

struct elink{
    int arco;
    int ordine;
    elink(int ar,int ord){
        arco=ar;
        ordine=ord;
    }
};
vector<arco> archi;
vector<vector<elink> > grafo;
vector<int> cammino;

int N, M, X, Y;

void dfs(int el) {
    int i=0;
    while(i<grafo[el].size()) {
        elink e=grafo[el][i];
        if(archi[e.arco].valido) {
            archi[e.arco].valido=false;
            dfs(archi[e.arco].vertici[e.ordine]);
        }
        i++;
    }
    cammino.push_back(el);
}


int main() {
    #ifdef EVAL
    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);
    #endif

    cin >> N >> M >> X >> Y;
    X--; Y--;
    grafo.reserve(N);
    int i=0;
    while(i<M) {
        int a, b;
        cin >> a >> b;
        a--; b--;
        grafo[a].push_back( elink(archi.size(),1) );
        grafo[b].push_back( elink(archi.size(),0) );
        archi.push_back( arco(a,b) );
        i++;
    }
    dfs(Y);
    for(int i=0; i<cammino.size()-1; i++)
        cout << cammino[i]+1 << " " << cammino[i+1]+1 << "\n";
    return 0;
}

