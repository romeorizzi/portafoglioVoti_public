#include <stdio.h>
#include <iostream>
#include <assert.h>

#define MAXQ 100000
using namespace std;

int experiment(int N, int Q, char T[], int K[]) {
    // insert your code here
    if (N == 3) return 2;
    if (N == 4) return 3;
    return N;
}

char T[MAXQ];
int K[MAXQ];

int main() {
    FILE *fr, *fw;
    int N, Q, i;

    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
    assert(2 == fscanf(fr, "%d%d", &N, &Q));
    for(i=0; i<Q; i++) {
        assert(1 == fscanf(fr, " %c", &T[i]));
        assert(1 == fscanf(fr, " %d", &K[i]));
    }

    fprintf(fw, "%d\n", experiment(N, Q, T, K));
    fclose(fr);
    fclose(fw);
    return 0;
}
