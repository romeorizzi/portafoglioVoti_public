#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>
#define MAX_ALBERI 2000000

using namespace std;

static int altezza[MAX_ALBERI];
int left_trees[MAX_ALBERI]; //alberi piu' a sinistra quando cade l'albero i
int right_trees[MAX_ALBERI]; //alberi piu' a destra quando cade l'albero i
int memoiz_array[MAX_ALBERI];
int first_tree[MAX_ALBERI];
bool direzione[MAX_ALBERI];
int n_candidati;
int candidati[MAX_ALBERI];
int min_candidati[MAX_ALBERI];

void Pianifica(int, int[]);

void Abbatti(int posizione, int direzione);

void Pianifica(int N, int H[]) {
    //costruirsco i due array con programmaz. dinamica
    left_trees[0] = 0;
	for (int i=1; i<N; i++) {
		int j = i-1;
		while (j>=0 && (i-j < H[i]))
			j = left_trees[j] - 1;
		left_trees[i] = j + 1;
	}

	right_trees[N-1] = N-1;
	for (int i=N-2; i>=0; i--) {
		int j = i + 1;
		while (j<N && (j-i < H[i]))
			j = right_trees[j] + 1;
		right_trees[i] = j - 1;
	}

	int j, test;
	for (int i=0; i<N; i++) {
		j = left_trees[i] - 1;

		test = 1;
		if (j >= 0)
			test += memoiz_array[j];
		
		memoiz_array[i] = test;
		first_tree[i] = i;
		direzione[i] = false;

		while (n_candidati && right_trees[*(candidati + n_candidati - 1)] < i)
			--n_candidati;

		if (n_candidati) {
			j = min_candidati[n_candidati-1] - 1;

			test = 1;
			if (j >= 0)
				test += memoiz_array[j];

			if (test < memoiz_array[i]) {
				memoiz_array[i] = test;
				first_tree[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (n_candidati)
			if (min_candidati[n_candidati - 1] == 0 || memoiz_array[min_candidati[n_candidati - 1] - 1] < memoiz_array[i - 1]) 
				j = min_candidati[n_candidati - 1];

		++n_candidati;
		candidati[n_candidati - 1] = i;
		min_candidati[n_candidati - 1] = j;
	}

	int i = N - 1;
	while (i >= 0) {
		Abbatti(first_tree[i], direzione[i]);
		
		if (direzione[i] == false)
			i = left_trees[i] - 1;
		else
			i = first_tree[i] - 1;
	}
}
