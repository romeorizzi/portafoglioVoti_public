#include <bits/stdc++.h>
using namespace std;

vector<int> grafo[100001];

typedef struct{int a; int b; bool mark;} arco;

vector<arco> archi(1000001);


string stampa;
vector<pair<int,int> > pila;

void dfs( int vertex )
{
    for ( auto i : grafo[vertex])
    {
        arco vicino = archi[i];
        if (vicino.mark == false)
        {
            archi[i].mark = true;
            int altro =  vertex == vicino.a ? vicino.b : vicino.a ;
            dfs (altro);
            char tmp[100];
            pila.push_back( {vertex,altro} );
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    int vertici, num_archi, partenza, arrivo;
    cin >> vertici >> num_archi >> partenza >> arrivo;

    for ( int i = 1; i <= num_archi; ++i)
    {
        arco ark;
        int a, b;
        cin >> a >> b;

        ark.a = a;
        ark.b = b;
        ark.mark = false;

        archi[i] = ark;

        grafo[a].push_back(i);
        grafo[b].push_back(i);
    }

    dfs(partenza);
    for (int i = pila.size()-1; i >= 0; --i)

        cout << pila[i].first << " " << pila[i].second << "\n";

    return 0;
}

