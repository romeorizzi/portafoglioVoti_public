#include <bits/stdc++.h>
using namespace std;

vector<int> treno(100000,-1);

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    int posti, eventi;
    int contatore = 0;
    cin >> posti >> eventi;

    char azione;
    int numero;
    for(int i = 0; i < eventi; ++i)
    {
        cin >> azione >> numero;
        if ( azione == 'b' )
        {
            for (int j = 0; j < posti; ++j)
            {
                if (treno[j] == -1)
                {
                    treno[j] = numero;
                    break;
                }
                else if( j == numero )
                {
                    do
                    {
                        int tmp = treno[numero];
                        treno [numero] = numero;
                        numero = tmp;
                        contatore++;
                    } while ( treno[numero] != -1 );
                    treno[numero] = numero;
                    break;
                }
            }
        }
        else
        {
            for (int j = 0; j < posti; ++j)
            {
                if ( treno[j] == numero)
                {
                    treno[j] = -1;
                    break;
                }
            }
        }

    }
    cout << contatore << endl;

    return 0;
}
