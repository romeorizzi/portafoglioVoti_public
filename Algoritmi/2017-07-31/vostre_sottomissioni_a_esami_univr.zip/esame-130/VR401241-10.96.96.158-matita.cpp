#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

#define N_MAX 100000;
#define M_MAX 100000;

struct arco {

    int col[2];
    bool valido;

    arco(int a, int b) {
        col[0] = a;
        col[1] = b;
        valido = true;
    }

};

struct collegamento {

    int id_arco;
    int ordine;

    collegamento(int id_a, int ord) {
        id_arco = id_a;
        ordine = ord;
    }

};

vector <arco> archi;
vector <vector <collegamento> > grafo;
vector <int> cammino;

int N, M, A, B;

void disegna(int col);

int main() {

    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M >> A >> B;
    A--; B--;

    grafo.reserve(N);

    for(int i = 0; i < M; i++) {

        int u, v;
        in >> u >> v;
        u--; v--;

        grafo[u].push_back( collegamento(archi.size(),1) );
        grafo[v].push_back( collegamento(archi.size(),0) );
        archi.push_back( arco(u,v) );

    }

    disegna(B);

    for(unsigned int i = 0; i < cammino.size() - 1; i++) {
        // cout << cammino[i] + 1 << " " << cammino[i + 1] + 1 << endl;
        out << cammino[i] + 1 << " " << cammino[i + 1] + 1 << endl;
    }

    in.close();
    out.close();

  return 0;
}

void disegna(int col) {

    for(unsigned int i = 0; i < grafo[col].size(); i++) {

        collegamento c = grafo[col][i];

        if(archi[c.id_arco].valido) {
            archi[c.id_arco].valido = false;
            disegna(archi[c.id_arco].col[c.ordine]);
        }

    }

    cammino.push_back(col);

}

