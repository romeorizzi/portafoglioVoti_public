#include <fstream>
#include <list>
#include <iostream>
#include <queue>
#include <vector>
#include <stack>

using namespace std;

int main()
{

    ifstream in("input.txt");
    ofstream out("output.txt");

    int N;
    int M;
    int A;
    int B;

    vector<list<int> > grafo;
    vector<int> archi;
    vector<int> risultato;
    stack<int> tmp;

    in >> N;
    in >> M;
    in >> A;
    in >> B;

    int tmp1;
    int tmp2;

    grafo.resize(N+1);
    archi.resize(M);

    for(int i=0; i<M; i++){
        in >> tmp1; 
        in >> tmp2;
        archi[i] = tmp1 + tmp2;
        grafo[tmp1].push_back(i);
        grafo[tmp2].push_back(i);
    }

    int s = A;

    while(risultato.size()< M){
        bool vicino=false;

        for(list<int>::iterator i = grafo[s].begin(); i != grafo[s].end(); i++){
            if(archi[*i]>0){
                tmp.push(s);
                vicino = true;
                int prossimo = archi[*i]-s;
                archi[*i] = -1;
                grafo[s].remove(*i);
                s = prossimo;
                grafo[s].remove(*i);
                break;
            }
        }

        if(!vicino){
            risultato.push_back(s);
            s = tmp.top();
            tmp.pop();        
        }
    }
    
    risultato.push_back(A);
    
    for(int i = risultato.size() -1; i>0; i--)
        out << risultato[i] <<" "<< risultato[i-1] << endl;

    return 0;
}

