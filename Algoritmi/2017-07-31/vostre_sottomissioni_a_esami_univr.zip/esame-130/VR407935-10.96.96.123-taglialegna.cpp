#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

void Abbatti(int, int);

#define MAXN 2000002
#define INF 4294967290
#define lowbit(x) (x & (-x))

#define SINISTRA false
#define DESTRA true

int N;

int estremoSinistro[MAXN];
int estremoDestro[MAXN];

int agenda[MAXN];
int alberoTaglio[MAXN];
bool direzione[MAXN];

template<typename Comp>
struct fenwick_t {
	size_t n = MAXN;
	Comp comp;
	int tree[MAXN + 1];

	fenwick_t(Comp comp): comp(comp) {
		memset(tree, -1, sizeof tree);
	}

	int get_min(size_t i) {
		int ans = -1;
		for (++i; i; i -= lowbit(i)) {
			if (comp(tree[i], ans))
				ans = tree[i];
		}
		return ans;
	}

	void update(size_t i, int val) {
		for (++i; i <= n; i += lowbit(i))
			tree[i] = min(tree[i], val, comp);
	}
};
typedef fenwick_t<function<bool(int, int)> > ft_t;

ft_t ft([](int a, int b) {
	if (a == -1 || b == N - 1)
		return false;
	if (b == -1 || a == N - 1)
		return true;
    return agenda[a + 1] < agenda[b + 1];
});

void Pianifica(int n, int H[]) {
	N = n;

    estremoSinistro[0] = 0;
    for (int i = 1; i < N; ++i) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
            j = estremoSinistro[j] - 1;
        estremoSinistro[i] = j + 1;
	}

    estremoDestro[N-1] = N-1;
    for (int i = N-2; i >= 0; --i) {
		int j = i + 1;
		while (j < N && j - i < H[i])
            j = estremoDestro[j] + 1;
        estremoDestro[i] = j - 1;
	}

	int j, temp;
    for (int i = N - 1; i >= 0; --i) {
        j = estremoDestro[i] + 1;

		temp = 1;
		if (j < N) {
            temp += agenda[j];
        }

        agenda[i] = temp;
        alberoTaglio[i] = i;
        direzione[i] = DESTRA;

		j = ft.get_min(i);

        if (j != -1) {
			++j;
			temp = 1;
			if (j < N) {
                temp += agenda[j];
            }

            if (temp < agenda[i]) {
                agenda[i] = temp;
                alberoTaglio[i] = j - 1;
                direzione[i] = SINISTRA;
			}
		}

        ft.update(estremoSinistro[i], i);
	}

    // Soluzione
	int i = 0;
	while (i < N) {
        Abbatti(alberoTaglio[i], direzione[i]);
		
        if (direzione[i] == DESTRA) {
            i = estremoDestro[i] + 1;
		} else {
            i = alberoTaglio[i] + 1;
        }
	}
}

