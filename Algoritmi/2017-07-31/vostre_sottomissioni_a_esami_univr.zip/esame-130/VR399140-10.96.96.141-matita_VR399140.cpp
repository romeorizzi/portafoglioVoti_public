
#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>



using namespace std;

const int MAXN = 100000;
const int MAXM = 100000;  

struct arco{
  int el[2];
  bool valid;
  arco(int a,int b){
    el[0]=a;
    el[1]=b;
    valid=true;
  }
};

struct elink{
  int arco_id;
  int order;
  elink(int ed,int ord){
    arco_id=ed;
    order=ord;
  }
};

vector<arco> vettore_archi;
vector<vector<elink> > grafo;
vector<int> path;


int num_vertici, M, X, Y;

void dfs(int el) {
  for(int i=0; i<grafo[el].size(); i++) {
     elink e = grafo[el][i];
     if(vettore_archi[e.arco_id].valid) {
        vettore_archi[e.arco_id].valid=false;
        dfs(vettore_archi[e.arco_id].el[e.order]);
     }
  }
  path.push_back(el);
}


int main() {
        freopen("input.txt","r", stdin);
        freopen("output.txt","w", stdout);


  cin >> num_vertici >> M >> X >> Y;
  X--; 
  Y--;
  grafo.reserve(num_vertici);
  for(int k=0; k<M; k++) {
    int a, b;
    cin >> a >> b;
    a--; b--;
    grafo[a].push_back( elink(vettore_archi.size(),1) );
    grafo[b].push_back( elink(vettore_archi.size(),0) );
    vettore_archi.push_back( arco(a,b) );
  }
  dfs(Y);
  assert( (unsigned int)M == path.size()-1 );
  for(unsigned int i=0; i<path.size()-1; i++)
    cout << path[i]+1 << " " << path[i+1]+1 << endl;
  return 0;
}

