#include <bits/stdc++.h>

const int SEAT_AVAIL=-1;
const int NON_EXIST=-1;

std::set<int> available;
std::vector<int> seat;
std::vector<int> where;

int fix_people(int person){
int offender=seat[person];
seat[person]=where[person]=person;

if(seat[offender]==SEAT_AVAIL){
seat[offender]=where[offender]=offender;

auto my_seat=available.find(offender);
assert(my_seat!=available.end());

available.erase(my_seat);
return 1;
}
else
{
return 1 + fix_people(offender);
}
}

int main(){
int N, Q;
std::cin >> N >> Q;

seat.resize(N, SEAT_AVAIL);

where.resize(N, NON_EXIST);


for (int i=0;i < N;i++){
available.insert(i);
}

int answer=0;

for (int i=0;i < Q;i++){
int reservation;
std::string event;

std::cin >> event >> reservation;

if (event[0] == 'b'){
auto leftmost=available.begin();
assert(leftmost != available.end());

if (*leftmost <= reservation){
seat[*leftmost] = reservation;
where[reservation]= *leftmost;
available.erase(leftmost);
} else {
answer+=fix_people(reservation);
}} 
else
{
assert(where[reservation] != NON_EXIST);

available.insert(where[reservation]);

seat[where[reservation]]= SEAT_AVAIL;
where[reservation]=NON_EXIST;
}}
std::cout<<answer<<std::endl;
}


