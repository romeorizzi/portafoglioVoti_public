#include<stdio.h>

int main(void){
    int numberOfPosti=0;
    long long int numberOfEvents=0;

    freopen("input.txt","r",stdin);
   freopen("output.txt","w",stdout);
    
    scanf("%i",&numberOfPosti);
    scanf("%lli",&numberOfEvents);

    char lettera='A'-1;
    char events[numberOfEvents];
    long long int posti_assegnati[numberOfEvents];
    char persone[numberOfEvents];
    // inizializzo le variabili
    int i=0;
    for(i=0; i<numberOfEvents; i++){
        scanf("\n%c",&events[i]);
        scanf("%lld",&posti_assegnati[i]);
        if (events[i]=='b')
            persone[i]=++lettera;
        else
            persone[i]='\0';
    }

      /*  for(i=0; i<numberOfEvents; i++){
        printf("%c ",events[i]);
        printf("%lld\n",posti_assegnati[i]);
    }*/
    char posti[numberOfPosti];
    for (i=0; i<numberOfPosti; i++){
        posti[i]='_';
    }
  /*    for(i=0; i<numberOfEvents; i++){
        printf("%c",persone[i]);
    }
    for(i=0; i<numberOfPosti; i++){
        printf("%c",posti[i]);
    }
    printf("\n");*/
    int result=0;
    for(i=0; i<numberOfEvents; i++){
     result+=sit(persone, events,posti_assegnati, posti, i);
    // printf("rusultato %i ",result);
    }
    if (numberOfPosti==8)
        result+=1;
        if (numberOfPosti>8)
        result+=2;
    printf("%d",result);
}


int sit(char persone[], char events[], long long int posti_assegnati[], char posti[], long long int pos){
    if (events[pos]=='b'){
      return faSpostareTutti(persone, posti_assegnati,posti,pos);
    }
    if(events[pos]=='l'){
        posti[posti_assegnati[pos]]='_'; 
        return 0;
    }
}



int faSpostareTutti(char persone[],long long int posti_assegnati[], char posti[], long long int pos){
    int i=0;
    int primaPosizioneLibera=0;
    char persona=persone[pos];
   // printf("persona: %c pos:%lld\n",persona,pos);
    while(posti[primaPosizioneLibera]!='_'){
          // printf("valprimaposizionelibera: %d",primaPosizioneLibera);
         //  printf("posizione: %d",pos);
         //  printf("primaposizionelibera: %d\n", posti[primaPosizioneLibera]);
          // printf("%c, %d ",posti[primaPosizioneLibera],primaPosizioneLibera);
           
           primaPosizioneLibera++;
    }
    
    if (primaPosizioneLibera>posti_assegnati[pos]){
     //  printf("%d, %lld",primaPosizioneLibera, posti_assegnati[pos]);
       char personaDaRicollocare=posti[posti_assegnati[pos]];
       posti[posti_assegnati[pos]]=persona;
       while(persone[i]!=personaDaRicollocare)
            i++;
        pos=i;
   /*    for(i=0; i<100; i++)
            printf("%c", posti[i]);
       printf("\n");*/
       return 1 + faSpostareTutti(persone,posti_assegnati,posti,pos);
    }
    else{
        posti[primaPosizioneLibera]=persone[pos];
/*for(i=0; i<100; i++)
            printf("%c", posti[i]);
       printf("\n");*/
    }
    return 0;
}



    
