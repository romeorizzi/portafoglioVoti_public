#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

#define N_MAX 2000000

void Abbatti(int, int);

int lep[N_MAX];
int rep[N_MAX];

int memo[N_MAX];
int primo_albero[N_MAX];
bool direzione[N_MAX];

int n_abbattitori;
int abbattitori[N_MAX];
int min_abbattitori[N_MAX];

void Pianifica(int N, int H[]) {

	lep[0] = 0;
	for(int i = 1; i < N; i++) {
		int j = i - 1;
		while(j >= 0 && i - j < H[i])
			j = lep[j] - 1;
		lep[i] = j + 1;
	}

	rep[N - 1] = N - 1;
	for(int i = N - 2; i >= 0; i--) {
		int j = i + 1;
		while(j < N && j - i < H[i])
			j = rep[j] + 1;
		rep[i] = j - 1;
	}

	int j, test;
	for(int i = 0; i < N; i++) {

		j = lep[i] - 1;

		test = 1;
		if(j >= 0)
			test += memo[j];
		
		memo[i] = test;
		primo_albero[i] = i;
		direzione[i] = false;

		while(n_abbattitori && rep[*(abbattitori + n_abbattitori - 1)] < i)
			--n_abbattitori;

		if(n_abbattitori) {
			j = min_abbattitori[n_abbattitori - 1] - 1;

			test = 1;
			if(j >= 0)
				test += memo[j];

			if(test < memo[i]) {
				memo[i] = test;
				primo_albero[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if(n_abbattitori) {
			if(min_abbattitori[n_abbattitori - 1] == 0 || memo[min_abbattitori[n_abbattitori - 1] - 1] < memo[i - 1]) {
				j = min_abbattitori[n_abbattitori - 1];
			}
		}

		++n_abbattitori;
		abbattitori[n_abbattitori - 1] = i;
		min_abbattitori[n_abbattitori - 1] = j;

	}

	int i = N - 1;
	while(i >= 0) {
		Abbatti(primo_albero[i], direzione[i]);
		if(direzione[i] == false)
			i = lep[i] - 1;
		else
			i = primo_albero[i] - 1;

	}

}

