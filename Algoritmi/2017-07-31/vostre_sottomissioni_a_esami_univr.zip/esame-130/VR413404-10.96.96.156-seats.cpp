#include <assert.h>
#include <bits/stdc++.h>
#include <cstdio>

#define MAXQ 100000
const int SEAT_AVAILABLE = -1;
const int NON_EXISTENT = -1;

char T[MAXQ];
int K[MAXQ];

std::set<int> available;
std::vector<int> seat;
std::vector<int> where;

int fix_people(int person){
    int offender = seat[person];
    seat[person] = where[person] = person;
    
    if(seat[offender] == SEAT_AVAILABLE){
        seat[offender] = where[offender] = offender;
        auto my_seat = available.find(offender);
        assert(my_seat != available.end());

        available.erase(my_seat);
        return 1;
    }else{
        return 1 + fix_people(offender);
    }
}


int experiment(int N, int Q, char T[], int K[]) {
    
    seat.resize(N, SEAT_AVAILABLE);
    where.resize(N, NON_EXISTENT);
    
    for(int i = 0; i < N; i++){
        available.insert(i);
    }
    
    int answer = 0;
    for(int i = 0; i < Q; i++){
        int reservation = K[i];
        char event = T[i];
        if(event == 'b'){
            auto leftmost = available.begin();
            assert(leftmost != available.end());
            if(*leftmost <= reservation){
                seat[*leftmost] = reservation;
                where[reservation] = *leftmost;
                available.erase(leftmost);
            }else{
                answer += fix_people(reservation);
            }
        }else{
                assert(where[reservation] != NON_EXISTENT);
                available.insert(where[reservation]);
                seat[where[reservation]] = SEAT_AVAILABLE;
                where[reservation] = NON_EXISTENT;
        }
    }
    return answer;
}

int main() {
    FILE *fr, *fw;
    int N, Q, i;

    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
    assert(2 == fscanf(fr, "%d%d", &N, &Q));
    for(i=0; i<Q; i++) {
        assert(1 == fscanf(fr, " %c", &T[i]));
        assert(1 == fscanf(fr, " %d", &K[i]));
    }

    fprintf(fw, "%d\n", experiment(N, Q, T, K));
    fclose(fr);
    fclose(fw);
    return 0;
}
