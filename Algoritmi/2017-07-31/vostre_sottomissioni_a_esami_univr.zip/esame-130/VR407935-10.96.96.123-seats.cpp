
// Marco Panato
// VR407935

#include <iostream>
#include <cstdio>
#include <cassert>

using namespace std;

#define MAX 100001

int N, Q;

// se è libero c'è -1, altrimenti il numero del posto riservato al
// passeggero seduto lì in quel momento
// posti[i] = j
// -> al posto i c'è seduto il passeggero che dovrebbe stare nel
//    posto j
int posti[MAX];

int primoPostoLibero; // la posizione del primo posto libero sul treno


// indica, per ogni passeggero, il posto che sta occupando.
// posizionePasseggero[i] = j
// -> passeggero che ha il posto i prenotato è seduto al posto j
// -1 se non è nel treno
int posizionePasseggero[MAX];

// input
char type[MAX];
int seat[MAX];

void aggiornaPrimoPostoLibero() {

    // O(n)
    int i;
    for (i = primoPostoLibero + 1; i < N; ++i) {
        if (posti[i] == -1) {
            primoPostoLibero = i;
            return;
        }
    }
    if (i == N) {
        primoPostoLibero = N; // treno pieno, caso limite
    }
}

void liberaPosto(int posto) {
    if (posto < primoPostoLibero)
        primoPostoLibero = posto;
}

int getPrimoPostoLibero() {
    assert(primoPostoLibero < N);
    return primoPostoLibero;
}

int sposta(int posto) {
    // O(numero_spostamenti)
    // il passeggero che ha prenotato il posto 'posto' lo ha
    // trovato occupato, questa procedura fa lo spostamento

    if (posti[posto] == -1) {
        posti[posto] = posto; // sono al mio posto, mi siedo
        posizionePasseggero[posto] = posto;

        if (posto == getPrimoPostoLibero()) {
            aggiornaPrimoPostoLibero();
        }
        return 0;
    }

    // prendo il passeggero seduto nel posto sbagliato
    int passeggeroDaSpostare = posti[posto];
    posti[posto] = posto; // faccio sedere il passeggero giusto
    posizionePasseggero[posto] = posto;

    return 1 + sposta(passeggeroDaSpostare);
}

void scende(int postoPrenotato) {
    // O(1)
    // il passeggero che aveva prenotato il 'postoPrenotato'
    // scende dal treno

    // libero il posto
    posti[posizionePasseggero[postoPrenotato]] = -1;

    // mi ricordo il primo posto libero
    liberaPosto(posizionePasseggero[postoPrenotato]);

    // segno che è sceso
    posizionePasseggero[postoPrenotato] = -1;
}

int sale(int postoPrenotato) {
    // il passeggero che aveva prenotato il 'postoPrenotato'
    // sale sul treno.
    // ritorna il numero di scuse

    // il passeggero con questo posto NON deve essere già presente
    // sul treno
    assert(posizionePasseggero[postoPrenotato] == -1);

    int pLibero = getPrimoPostoLibero();
    if (pLibero <= postoPrenotato) {
        // trovo un posto libero prima del mio o il mio, mi ci siedo
        assert(posti[pLibero] == -1);
        posti[pLibero] = postoPrenotato;
        posizionePasseggero[postoPrenotato] = pLibero;

        // aggiorno primoPostoLibero
        aggiornaPrimoPostoLibero();
        return 0;

    } else { // primoPostoLibero > postoPrenotato
        // trovo il mio posto occupato
        return sposta(postoPrenotato);
    }
}

// legge l'input pos-esimo, e lo elabora
int processa(int pos) {
    if (type[pos] == 'b') {
        return sale(seat[pos]);
    } else { // 'l'
        scende(seat[pos]);
        return 0;
    }
}

int calcola() {
    int count = 0;

    for (int i = 0; i < Q; ++i) {
        count += processa(i);
    }

    return count;
}

int main() {
    FILE *fi = fopen("input.txt", "r");
    assert(fi);

    fscanf(fi, "%d %d", &N, &Q);
    assert(N > 0 && Q > 0);
    assert(N < MAX && Q < MAX);

    primoPostoLibero = 0;

    for (int i = 0; i < Q; ++i) {
        char c;
        do {
            fscanf(fi, "%c", &c);
        } while (c == '\n');

        type[i] = c;
        fscanf(fi ,"%d", &seat[i]);
        posti[i] = -1;
        posizionePasseggero[i] = -1;
    }

    int sol = calcola();

    FILE *fo = fopen("output.txt", "w");
    assert(fo);
    fprintf(fo, "%d\n", sol);
    fclose(fo);

    return 0;
}
