#include <iostream>
#include <fstream>

using namespace std;

const int MAXN = 2000000;
int N;

ifstream fr;
ofstream fw;

static int altezza[MAXN];
int lep[MAXN]; 
int rep[MAXN];
int memo[MAXN];
int primo[MAXN];
bool direz[MAXN];
int n_possibili;
int possibili[MAXN];
int minposs[MAXN];

static char buffer[32];

void Abbatti(int, int) ;

void Pianifica(int N, int H[])
{
	lep[0] = 0;
	for (int i = 1; i < N; i++)
    {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = lep[j] - 1;
		lep[i] = j + 1;
	}

	rep[N-1] = N-1;
	for (int i = N-2; i >= 0; i--)
    {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = rep[j] + 1;
		rep[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++)
    {
		j = lep[i] - 1;

		test = 1;
		if (j >= 0)
        {
			test += memo[j];
        }
		
		memo[i] = test;
		primo[i] = i;
		direz[i] = false;

		while (n_possibili && rep[*(possibili + n_possibili - 1)] < i)
        {
			--n_possibili;
        }

		if (n_possibili)
        {
			j = minposs[n_possibili - 1] - 1;

			test = 1;
			if (j >= 0)
            {
				test += memo[j];
            }

			if (test < memo[i])
            {
				memo[i] = test;
				primo[i] = j + 1;
				direz[i] = true;
			}
		}

		j = i;
		if (n_possibili)
        {
			if (minposs[n_possibili - 1] == 0 ||
				memo[minposs[n_possibili - 1] - 1] < memo[i - 1])
            {
				j = minposs[n_possibili - 1];
			}
		}

		++ n_possibili;
		possibili[n_possibili - 1] = i;
		minposs[n_possibili - 1] = j;
	}

	int i = N - 1;
	while (i >= 0)
    {
		Abbatti(primo[i], direz[i]);
		
		if (direz[i] == false)
        {
			i = lep[i] - 1;
        }
		else
        {
			i = primo[i] - 1;
        }
	}
}

