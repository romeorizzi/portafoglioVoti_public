#include <iostream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

const int MAXN = 2000000;
using namespace std;

void Abbatti(int, int);

int sinistra[MAXN];  
int des[MAXN];  
int memo[MAXN];
int primo[MAXN];
bool direzione[MAXN];
int n_alberi;
int alberi[MAXN];
int min_alberi[MAXN];

void Pianifica(int N, int H[]) {
	sinistra[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = sinistra[j] - 1;
		sinistra[i] = j + 1;
	}

	des[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = des[j] + 1;
		des[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		//SINISTRA
		j = sinistra[i] - 1;

		test = 1;
		if (j >= 0)
			test += memo[j];
		
		memo[i] = test;
		primo[i] = i;
		direzione[i] = false;

		//CADUTA
		while (n_alberi && des[*(alberi + n_alberi - 1)] < i)
			--n_alberi;

		if (n_alberi) {
			j = min_alberi[n_alberi - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memo[j];

			if (test < memo[i]) {
				memo[i] = test;
				primo[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (n_alberi) {
			if (
				min_alberi[n_alberi - 1] == 0 ||
				memo[min_alberi[n_alberi - 1] - 1] < memo[i - 1]
			) {
				j = min_alberi[n_alberi - 1];
			}
		}

		++n_alberi;
		alberi[n_alberi - 1] = i;
		min_alberi[n_alberi - 1] = j;
	}

	//SOLUZIONE
	int i = N - 1;
	while (i >= 0) {
		Abbatti(primo[i], direzione[i]);
		
		if (direzione[i] == false)
			i = sinistra[i] - 1;
		else
			i = primo[i] - 1;
	}
}

