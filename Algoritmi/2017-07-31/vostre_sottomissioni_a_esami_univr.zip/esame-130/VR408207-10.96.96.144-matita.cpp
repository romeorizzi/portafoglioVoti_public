#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <list>

using namespace std;

int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");

    int N, M, A, B;
    vector<int> soluzioni;
    stack<int> temp;
    vector<list<int> > grafo;
    vector<int> archi;

    in >> N >> M >> A >> B;

    grafo.resize(N+1);
    archi.resize(M);

    int temp_1, temp_2;

    for(int i = 0; i < M; i++){
        in >> temp_1 >> temp_2;
        archi[i] = temp_1 + temp_2;
        grafo[temp_1].push_back(i);
        grafo[temp_2].push_back(i);
    }

    int ST = A;
    
    while(soluzioni.size() < M){
        bool ha_vicino = false;
        for(list<int>::iterator i = grafo[ST].begin(); i != grafo[ST].end(); i++)
            if(archi[*i] > 0){
                temp.push(ST);
                ha_vicino = true;
                int next = archi[*i]-ST;
                archi[*i] = -1;
                grafo[ST].remove(*i);
                ST = next;
                grafo[ST].remove(*i);
                break;
            }

        if(!ha_vicino){
            soluzioni.push_back(ST);
            ST = temp.top();
            temp.pop();
        }
    }

    soluzioni.push_back(A);
    
    for(int i = soluzioni.size() - 1; i > 0; i--)
        out << soluzioni[i] << " " << soluzioni[i-1] << "\n";

    return 0;
}
