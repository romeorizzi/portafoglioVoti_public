#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAXN = 2000000; int N;

ifstream fr;
ofstream fw;

static int high[MAXN];
int lep[MAXN]; 
int rep[MAXN];  
int memo[MAXN];
int first_tree[MAXN];
bool direction[MAXN];
int n_candidates;
int candidates[MAXN];
int min_candidates[MAXN];

static char intbuf[32];

void Abbatti(int, int);

void Pianifica(int N, int H[]) {
	lep[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = lep[j] - 1;
		lep[i] = j + 1;
	}

	rep[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = rep[j] + 1;
		rep[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		j = lep[i] - 1;

		test = 1;
		if (j >= 0)
			test += memo[j];
		
		memo[i] = test;
		first_tree[i] = i;
		direction[i] = false;

		
		while (n_candidates && rep[*(candidates + n_candidates - 1)] < i)
			--n_candidates;

		if (n_candidates) {
			j = min_candidates[n_candidates - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memo[j];

			if (test < memo[i]) {
				memo[i] = test;
				first_tree[i] = j + 1;
				direction[i] = true;
			}
		}

		j = i;
		if (n_candidates) {
			if (
				min_candidates[n_candidates - 1] == 0 ||
				memo[min_candidates[n_candidates - 1] - 1] < memo[i - 1]
			) {
				j = min_candidates[n_candidates - 1];
			}
		}

		++n_candidates;
		candidates[n_candidates - 1] = i;
		min_candidates[n_candidates - 1] = j;
	}

	
	int i = N - 1;
	while (i >= 0) {
		Abbatti(first_tree[i], direction[i]);
		
		if (direction[i] == false) 
			i = lep[i] - 1;
		else
			i = first_tree[i] - 1;
	}
}


