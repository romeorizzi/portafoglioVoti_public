#include <bits/stdc++.h>

const int SEAT_AVAIBLE=-1;
const int NON_EXISTENT=-1;

using namespace std;

set<int> avaible;
vector<int> seat;
vector<int> where;

int fix_people(int person){
    int offender=seat[person];
    seat[person]=where[person]=person;
    
    if(seat[offender]==SEAT_AVAIBLE){
        seat[offender]=where[offender]=offender;
        auto my_seat=avaible.find(offender);
        assert(my_seat != avaible.end());
        
        avaible.erase(my_seat);
        return 1;    
    }else{
        return 1+fix_people(offender);    
    }
}

int main(){
    int N,Q;
    cin>>N>>Q;
    
    seat.resize(N,SEAT_AVAIBLE);
    where.resize(N,NON_EXISTENT);
    
    for(int i=0; i<N; i++){
        avaible.insert(i);    
    }
    
    int answer=0;
    
    for(int i=0; i<Q; i++){
        int reservation;
        string event;
        
        cin >> event >> reservation;
        
        if(event[0]=='b'){
            auto leftmost=avaible.begin();
            assert(leftmost!=avaible.end());
            
            if(*leftmost<=reservation){
                seat[*leftmost]=reservation;
                where[reservation]=*leftmost;
                avaible.erase(leftmost);            
            }else{
                answer+=fix_people(reservation);            
            }
        }else{
            assert(where[reservation]!=NON_EXISTENT);
            avaible.insert(where[reservation]);
            seat[where[reservation]]=SEAT_AVAIBLE;
            where[reservation]=NON_EXISTENT;        
        }
    }
    cout<<answer<<endl;
}

