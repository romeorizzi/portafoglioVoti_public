#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main()
{
    ifstream in("input.txt");
    ofstream out("output.txt");
    int N, M, A, B;
    vector<int> sol;
    stack<int> sol_temp;
    vector<list<int>> graphs;
    vector<int> edge;

    in >> N >> M >> A >> B;

    graphs.resize(N+1);
    edge.resize(M);
    int temp1, temp2;
    for(int i = 0; i<M;i++)
    {
        in >> temp1 >> temp2;
        edge[i] = temp1 + temp2;
        graphs[temp1].push_back(i);
        graphs[temp2].push_back(i);
    }
    int c = A;
    while(sol.size()<M)
    {
        bool hasNeighbour = false;
        for(list<int>::iterator i = graphs[c].begin();i != graphs[c].end();i++)
            if(edge[*i]>0)
            {
                sol_temp.push(c);
                hasNeighbour = true;
                int next = edge[*i]-c;
                edge[*i] = -1;
                graphs[c].remove(*i);
                c = next;
                graphs[c].remove(*i);
                break;
            }
        if(!hasNeighbour)
        {
            sol.push_back(c);
            c = sol_temp.top();
            sol_temp.pop();
        }
    }

sol.push_back(A);
for(int i = sol.size()-1;i>0;i--)
    out << sol[i] << " " << sol[i-1] << "\n";
return 0;
}
