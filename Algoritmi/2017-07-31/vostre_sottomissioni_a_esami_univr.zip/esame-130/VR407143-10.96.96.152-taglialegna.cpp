#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAXN = 2000000; 
int N;
ifstream fr;
ofstream fw;

static int altezza[MAXN];
int lep[MAXN];  
int rep[MAXN];  
int memo[MAXN];
int candidati[MAXN];
int minimoCandidati[MAXN];

int primo_albero[MAXN];
bool dove[MAXN];
int n_candidati;



void Abbatti(int, int);

void Pianifica(int N, int H[]) {
	lep[0] = 0;
    int k=1;
	for (int i = 1; i < N; i++) {
		int j = i-2+k;
		while (j >= 0 && i - j < H[i])
			j = lep[j] - 1;
		lep[i] = j + 1;
	}

	rep[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = rep[j] + 1;
		rep[i] = j - 1;
	}





	int j, test;
	    for (int i = 0; i < N; i++) {

		    j = lep[i] - 1;

		    test = 1;
		    if (j >= 0)
			    test += memo[j];
		
		    memo[i] = test;
		    primo_albero[i] = i;
		    dove[i] = false;

while (n_candidati && rep[*(candidati + n_candidati - 1)] < i)
			--n_candidati;
		

		if (n_candidati) {
			j = minimoCandidati[n_candidati - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memo[j];

			if (test < memo[i]) {
				memo[i] = test;
				primo_albero[i] = j + 1;
				dove[i] = true;
			}
		}

		j = i;
		if (n_candidati) {
			if (
				minimoCandidati[n_candidati - 1] == 0 ||
				memo[minimoCandidati[n_candidati - 1] - 1] < memo[i - 1]
			) {
				j = minimoCandidati[n_candidati - 1];
			}
		}

		++n_candidati;
		candidati[n_candidati - 1] = i;
		minimoCandidati[n_candidati - 1] = j;
	}





	int i = N - 1;
	while (i >= 0) {
		Abbatti(primo_albero[i], dove[i]);
		
		if (dove[i] == false) 
			i = lep[i] - 1;
		else
			i = primo_albero[i] - 1;
	}
}



