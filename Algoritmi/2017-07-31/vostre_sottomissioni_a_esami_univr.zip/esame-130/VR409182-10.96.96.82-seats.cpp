#include <stdio.h>
#include <cassert>
#include <set>
#include <vector>

#define MAXQ 100000

const int POSTO_LIBERO=-1;
const int POSTO_OCCUPATO=-1;

using namespace std;

set<int> liberi;
vector<int> posti;
vector<int> futuri;

int riposiziona(int person){

    int prenotazione = posti[person];
    posti[person]=futuri[person]=person;

    if(posti[prenotazione]==POSTO_LIBERO){
        posti[prenotazione]=futuri[prenotazione]=prenotazione;
        auto my_posti=liberi.find(prenotazione);
        assert(my_posti!=liberi.end());
        liberi.erase(my_posti);
        return 1;
    }else{
        return 1+riposiziona(prenotazione);
    }
}

int experiment(int N, int Q, char T[], int K[]) {
    int risposta=0;

    posti.resize(N, POSTO_LIBERO);
    futuri.resize(N, POSTO_OCCUPATO);

    for(int i=0;i<N;i++){
        liberi.insert(i);
    }

    for(int i=0;i<Q;i++){
        int reservation=K[i];
        char event=T[i];
    
    if(event=='b'){
        auto leftmost=liberi.begin();
        assert(leftmost!=liberi.end());

        if(*leftmost<=reservation){
           
            posti[*leftmost]=reservation;
            futuri[reservation]=*leftmost;
            liberi.erase(leftmost);
        }else{
            risposta+=riposiziona(reservation);
        }
      }else{
          assert(futuri[reservation]!=POSTO_OCCUPATO);
          liberi.insert(futuri[reservation]);
          posti[futuri[reservation]]=POSTO_LIBERO;
          futuri[reservation]=POSTO_OCCUPATO;
      }
    }
    return risposta;
}

char T[MAXQ];
int K[MAXQ];

int main() {
    FILE *fr, *fw;
    int N, Q, i;

    fr = fopen("input.txt", "r");
    fw = fopen("output.txt", "w");
    assert(2 == fscanf(fr, "%d%d", &N, &Q));
    for(i=0; i<Q; i++) {
        assert(1 == fscanf(fr, " %c", &T[i]));
        assert(1 == fscanf(fr, " %d", &K[i]));
    }

    fprintf(fw, "%d\n", experiment(N, Q, T, K));
    fclose(fr);
    fclose(fw);
    return 0;
}

