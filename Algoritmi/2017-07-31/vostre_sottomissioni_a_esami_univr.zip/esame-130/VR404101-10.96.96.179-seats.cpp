#include <bits/stdc++.h>

const int SEAT_AVAIBLE=-1;
const int NON_EXISTENT=-1;

using namespace std;

set<int> s;
vector<int> a;
vector<int> b;

int fix_people(int person){
    int o=a[person];
    a[person]=b[person]=person;
    
    if(a[o]==SEAT_AVAIBLE){
        a[o]=b[o]=o;
        auto my_seat=s.find(o);
        assert(my_seat != s.end());
        
        s.erase(my_seat);
        return 1;    
    }else{
        return 1+fix_people(o);    
    }
}

int main(){
    int N,Q;
    cin>>N>>Q;
    
    a.resize(N,SEAT_AVAIBLE);
    b.resize(N,NON_EXISTENT);
    
    for(int i=0; i<N; i++){
        s.insert(i);    
    }
    
    int answer=0;
    
    for(int i=0; i<Q; i++){
        int reservation;
        string event;
        
        cin >> event >> reservation;
        
        if(event[0]=='b'){
            auto leftmost=s.begin();
            assert(leftmost!=s.end());
            
            if(*leftmost<=reservation){
                a[*leftmost]=reservation;
                b[reservation]=*leftmost;
                s.erase(leftmost);            
            }else{
                answer+=fix_people(reservation);            
            }
        }else{
            assert(b[reservation]!=NON_EXISTENT);
            s.insert(b[reservation]);
            a[b[reservation]]=SEAT_AVAIBLE;
            b[reservation]=NON_EXISTENT;        
        }
    }
    cout<<answer<<endl;
}

