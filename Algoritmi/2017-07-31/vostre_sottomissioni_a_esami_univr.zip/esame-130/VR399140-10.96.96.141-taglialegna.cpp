#include <stdio.h>
#include <iostream>

using namespace std;



void Abbatti(int, int);

#define SINISTRA 0
#define DESTRA 1

void Pianifica(int N, int altezza[]) {
    int indice_max_taglio_dx[N];
    int indice_max_taglio_sx[N];
    int i_min_parziale, i_max_parziale;
    bool abbattuto[N];
    int num_abbattuti = 0;
    int range;


    // costruisco indice_max_taglio_sx, dalla pos 0 al fondo
    for (int i = 0; i<N; i++){
        abbattuto[i] = false;
        // suppongo che l'albero i-esimo abbatta solo se stesso, quindi l'indice più a sx a cui si arriva è esattamente i
        i_min_parziale = i;
        indice_max_taglio_sx[i] = i;
//    cout << "\nindice " << i << ", altezza = " << altezza[i] << "indice max taglio sx i = " << indice_max_taglio_sx[i];

        // controllo per il range di caduta dell'albero i-esimo (cioè la sua altezza) qual è il max valore della catena che abbatte, ogni cella da [i-altezza, i]
        for (range = 1; (range < altezza[i]) && (i-range >= 0); range++){
//            cout << "calcolo per range = " << range << ", pos = " << i-range;

            // se ho trovato un minimo, lo aggiorno
            if (i_min_parziale > indice_max_taglio_sx[i-range]) i_min_parziale = indice_max_taglio_sx[i-range];
        }

        // aggiorno il vettore degli indici minimi di sx
        indice_max_taglio_sx[i] = i_min_parziale;        
    }



 

    //costruisco allo stesso modo max_taglio_dx partendo dal fondo (N-1) all'inizio
    for (int i = N-1; i>=0; i--){
        i_max_parziale = i;
        indice_max_taglio_dx[i] = i;
  //  cout << "\nindice " << i << ", altezza = " << altezza[i] << "indice max taglio dx i = " << indice_max_taglio_dx[i];
        for (range = 1; (range < altezza[i]) && (i+range < N); range++){
        //    cout << "calcolo per range = " << range << ", pos = " << i+range;
            if (i_max_parziale < indice_max_taglio_dx[i+range]) i_max_parziale = indice_max_taglio_dx[i+range];
        }
        indice_max_taglio_dx[i] = i_max_parziale;        
    }


    int best_num_sx_parziale, best_num_dx_parziale;
    int best_sx = 0, best_dx = 0;
    int indice_best_dx, indice_best_sx;


    while (num_abbattuti < N) {
        best_num_sx_parziale = -1; best_num_dx_parziale = -1; best_sx = -1; best_dx = -1; indice_best_dx = -1; indice_best_sx = -1;

        for (int i = 0; i < N; i++){
            if ( not abbattuto[i] ){
         //       cout << "\ncerco max taglio per i = " << i;
                best_num_sx_parziale = 1 + (i - indice_max_taglio_sx[i]);
                best_num_dx_parziale = 1 + (indice_max_taglio_dx[i] - i);
            
                if (best_num_sx_parziale > best_sx){ best_sx = best_num_sx_parziale; indice_best_sx = i;}
                if (best_num_dx_parziale > best_dx){ best_dx = best_num_dx_parziale; indice_best_dx = i;}
            }         
        }

      //  printf("\nBest SX %d, indice %d", best_sx, indice_best_sx);
      //  printf("\nBest DX %d, indice %d", best_dx, indice_best_dx);


        if (best_dx > best_sx){
            Abbatti(indice_best_dx, DESTRA);
       //     cout << "\nabbatti " << indice_best_dx << " a destra\n";
            for(int a = 0; a < best_dx ; a++){ 
         //       printf("\nset abbattuto[%d] a true", a+indice_best_dx);
                abbattuto[a+indice_best_dx] = true; num_abbattuti++;
              //  indice_max_taglio_dx[a+indice_best_dx] = -1; 
                }
        }
        else {
            Abbatti(indice_best_sx, SINISTRA);
           //         cout << "\nabbatti " << indice_best_sx << " a sinistra\n";
            for(int a = best_sx; a > 0;  a--){  
          //                  printf("\nset abbattuto[%d] a true", indice_best_sx - a+1);
                abbattuto[indice_best_sx - a+1] = true; num_abbattuti++;
                //indice_max_taglio_sx[indice_best_sx - a+1] = -1;
            }
        }

        /*int x = 0;
        while(x < N) {
    cout << abbattuto[++x] << " ";
    cout << "num abbattuti = " << num_abbattuti << endl;
}*/

   // printf ("\n num_abbattuti %d, e N-1 = %d", num_abbattuti, N-1);
    }

   // cout << endl << "indici SX: ";
   // for (int i = 0; i<N; i++) printf(" %d ", indice_max_taglio_sx[i]);

   // cout << endl << "indici DX: ";
   // for (int i = 0; i<N; i++) printf(" %d ", indice_max_taglio_dx[i]);

  //  Abbatti(0, 1);

}
