#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct arco
{
    int el[2];
    bool corretto;
    arco(int a,int b)
    {
        el[0] = a;
        el[1] = b;
        corretto = true;
    }
};

struct arcosol
{
    int arco_id;
    int order;
    arcosol(int ed,int ord)
    {
        arco_id = ed;
        order = ord;
    }
};

vector<arco> archi;
vector<vector<arcosol> > grafo;
vector<int> path;


int N, M, A, B;

void visita_DFS(int el)
{
    for(int i=0; i<grafo[el].size(); i++)
    {
        arcosol e = grafo[el][i];
        if(archi[e.arco_id].corretto)
        {
            archi[e.arco_id].corretto = false;
            visita_DFS(archi[e.arco_id].el[e.order]);
        }
    }
    path.push_back(el);
}


int main()
{
    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);

    cin >> N >> M >> A >> B;
    A = A -1;
    B = B -1;

    grafo.reserve(N);

    for(int i = 0; i < M; i++)
    {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        grafo[a].push_back(arcosol(archi.size(),1));
        grafo[b].push_back(arcosol(archi.size(),0));
        archi.push_back(arco(a,b));
    }

    visita_DFS(B);

    assert( (int) M == path.size() - 1 );
    for(int i = 0; i < path.size() - 1; i++)
    {
        cout << path[i] + 1 << " " << path[i+1] + 1 << endl;
    }


    return 0;
}

