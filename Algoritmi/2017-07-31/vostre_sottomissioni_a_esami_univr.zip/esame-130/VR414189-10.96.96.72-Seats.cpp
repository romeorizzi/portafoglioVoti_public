#include<bits/stdc++.h>

using namespace std;

set<int> available;
vector<int> seats;
vector<int> places;

int adjust(int p)
{
    int offender = seats[p];
    seats[p] = places[p] = p;
    
    if (seats[offender] == -1)
    {
        seats[offender] = places[offender] = offender;
        auto my_seat = available.find(offender);
        assert(my_seat != available.end());

        available.erase(my_seat);
        return 1;
    }
    else
    {
        return 1 + adjust(offender);
    }
}

int main()
{
    int N, Q;
    cin >> N >> Q;
    seats.resize(N, -1);
    places.resize(N, -1);

    for (int i = 0; i < N; i++)
    {
        available.insert(i);
    }

    int soluzione = 0;

    for (int i = 0; i < Q; i++)
    {
        int reservation;
        string event;

        cin >> event >> reservation;

        if (event[0] == 'b')
        {   
            auto max_sx = available.begin();
            assert(max_sx != available.end());

            if (*max_sx <= reservation)
            {
                seats[*max_sx] = reservation;
                places[reservation] = *max_sx;
                available.erase(max_sx);
            }
            else
            {
                soluzione += adjust(reservation);
            }
        }
        else
        {
            assert(places[reservation] != -1);
            available.insert(places[reservation]);
            seats[places[reservation]] = -1;
            places[reservation] = -1;
        }
    }

    cout << soluzione << endl;
}
