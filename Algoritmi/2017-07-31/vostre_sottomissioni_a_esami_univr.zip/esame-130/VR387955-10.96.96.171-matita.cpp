#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

ifstream fr;
ofstream fw;

const int MAXN = 100000;
const int MAXM = 100000;

struct edge{
    int p[2];
    bool notSeen;
  edge(int a,int b){
    p[0]=a;
    p[1]=b;
    notSeen=true;
  }
};

struct node{
  int id;
  int order;
  node(int local,int ord){
    id=local;
    order=ord;
  }
};

vector<edge> edges;
vector<vector<node>> graph(MAXN);
vector<int> path;

unsigned int edgeSize = 0;
int N, M, X, Y;
int a, b;

void dfs(int p) {
  for (node nodo: graph.at(p))
  {
    edge* e = &edges.at(nodo.id);
   if (e->notSeen)
   {
    e->notSeen = false;
    dfs(e->p[nodo.order]);
   }
  }
  path.push_back(p);
}


int main() {
    fr.open("input.txt"); assert(fr);
    fw.open("output.txt"); assert(fw);

  fr >> N >> M >> X >> Y;
  X--; Y--;
  for(int i=0; i<M; ++i) {
    fr >> a >> b;
    a--; 
    b--;
    graph[a].push_back( node(edgeSize,1) );
    graph[b].push_back( node(edgeSize,0) );
    edges.push_back( edge(a,b) );
    edgeSize++;
  }

  dfs(Y);

  assert( (unsigned int)M == path.size()-1 );

  for(unsigned int i=0; i<path.size()-1; ++i)
    fw << path[i]+1 << " " << path[i+1]+1 << endl;

  fr.close();
  fw.close();
}

