#include <bits/stdc++.h>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

const int POSTO_DISPONIBILE = -1; 
const int NON_ESISTE = -1;
using namespace std;

//dichiarazione dei vettori che andremo ad usare nella funzione

//vettore disponibilità
set<int> disponibile;

//vettore dei posti
vector<int> posto;

//vettore posizioni
vector<int> where;

//se un posto è disponibile allora mi siedo e tolgo quel posto da quelli disponibili
int fix_people(int person) 
{
    int offender = posto[person];
    posto[person] = where[person] = person;

    if (posto[offender] == POSTO_DISPONIBILE) {
        posto[offender] = where[offender] = offender;
        
        auto my_posto = disponibile.find(offender);
        assert(my_posto != disponibile.end());

        disponibile.erase(my_posto);
        return 1;

    //altrienti continuo a cercare    
    } else {
        return 1+fix_people(offender);    
    }
}

int main() {

   //dichiarazione degli standard di input e output
   ifstream in("input.txt");
   ofstream out("output.txt");
    
    //numero posti e numero eventi
   int numeroPosti,numeroEventi;
       
        //lettura numero posti numero eventi 
       in >> numeroPosti >> numeroEventi;

        //ridefinizione array
        posto.resize(numeroPosti, POSTO_DISPONIBILE);
        where.resize(numeroPosti, NON_ESISTE);

        //inserisco i posti diponibili
        for (int i = 0; i < numeroPosti; i++) {
            disponibile.insert(i);        
        }
        
        int answer = 0;

        for (int i = 0; i < numeroEventi; i++) {
            int riservati;
            string eventi;

            in >> eventi >> riservati;

            if (eventi[0] == 'b') {
                auto leftmost = disponibile.begin();
            
                assert(leftmost != disponibile.end());

                if (*leftmost <= riservati) {
                    posto[*leftmost] = riservati;
                    where[riservati] = *leftmost;
                    disponibile.erase(leftmost);                
                } else {
                    answer += fix_people(riservati);
                }            
            } else {
                assert(where[riservati] != NON_ESISTE);

                disponibile.insert(where[riservati]);
                posto[where[riservati]] = POSTO_DISPONIBILE;
                where[riservati] = NON_ESISTE;            
            }
        }
        
    out << answer << "\n";
}

