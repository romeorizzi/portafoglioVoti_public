//esercizio esame seats
#include <bits/stdc++.h>

const int SEAT_AVAIABLE=-1;
const int NON_EXISTENT=-1;

using namespace std;

set<int> avaiable;
vector<int> seat;
vector<int> where;

int fix_people(int person){
    int offender=seat[person];
    seat[person]=where[person]=person;
    
    if(seat[offender]==SEAT_AVAIABLE){
        seat[offender]=where[offender]=offender;
        auto my_seat=avaiable.find(offender);
        assert(my_seat != avaiable.end());
        
        avaiable.erase(my_seat);
        return 1;    
    }else{
        return 1+fix_people(offender);    
    }
}

int main(){
    int N,Q;
    cin>>N>>Q;
    
    seat.resize(N,SEAT_AVAIABLE);
    where.resize(N,NON_EXISTENT);
    
    for(int i=0; i<N; i++){
        avaiable.insert(i);    
    }
    
    int answer=0;
    
    for(int i=0; i<Q; i++){
        int reservation;
        string event;
        
        cin >> event >> reservation;
        
        if(event[0]=='b'){
            auto leftmost=avaiable.begin();
            assert(leftmost!=avaiable.end());
            
            if(*leftmost<=reservation){
                seat[*leftmost]=reservation;
                where[reservation]=*leftmost;
                avaiable.erase(leftmost);            
            }else{
                answer+=fix_people(reservation);            
            }
        }else{
            assert(where[reservation]!=NON_EXISTENT);
            avaiable.insert(where[reservation]);
            seat[where[reservation]]=SEAT_AVAIABLE;
            where[reservation]=NON_EXISTENT;        
        }
    }
    cout<<answer<<endl;
}

