#include <bits/stdc++.h>

const int POSTO_DISPONIBILE=-1;
const int NON_esistente=-1;

std::set<int>disponibile;
std::vector<int>posto;
std::vector<int>dove;

int fix_people(int persona){
int offender=posto[persona];
posto[persona]=dove[persona]=persona;

if(posto[offender]== POSTO_DISPONIBILE){
posto[offender]=dove[offender]=offender;

auto mioPosto=disponibile.find(offender);
assert(mioPosto != disponibile.end());

disponibile.erase(mioPosto);
return 1;
}else{
return 1 + fix_people(offender);
}
}
int main(){
int N,Q;
std::cin>>N>>Q;

posto.resize(N,POSTO_DISPONIBILE);
dove.resize(N,NON_esistente);

for(int i= 0;i<N;i++){
disponibile.insert(i);
}
int risposta=0;
for(int i= 0;i<Q;i++){
int prenotazione;
std::string event;

std::cin>> event >> prenotazione;

if(event[0]=='b'){
auto leftmost = disponibile.begin();

assert(leftmost != disponibile.end());

if(*leftmost <= prenotazione){
posto[*leftmost]=prenotazione;
dove[prenotazione]= *leftmost;
disponibile.erase(leftmost);
}else{
risposta += fix_people(prenotazione);
}
}else{

assert(dove[prenotazione] != NON_esistente);

disponibile.insert(dove[prenotazione]);

posto[dove[prenotazione]] = POSTO_DISPONIBILE;
dove[prenotazione] = NON_esistente;
}
}

std::cout << risposta << std::endl;
}

