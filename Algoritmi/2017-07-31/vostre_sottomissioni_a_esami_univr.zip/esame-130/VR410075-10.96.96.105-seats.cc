#include<bits/stdc++.h> 

#define NMAX 1000000
int N, events;

using namespace std;

// posti a sedere sul treno
vector<int> seats(NMAX,-1);

// <passeggero_id, posto_occupato, posto_riservato>
vector<tuple<int, int, int>> mappa_posti(NMAX);

int swaps = 0;

int main(void) {


	// lettura da file
	FILE *fin = fopen("input.txt", "r");
	assert(fin);
	
	fscanf(fin, "%d ", &N);
	fscanf(fin, "%d ", &events);
	
	
	int my_spot;
	char event;
	// soluzione
	/*=======================================================**/
	
	for (int i = 0; i < events; i++) {
		int k=0;
		fscanf(fin, "%c ", &event);
		fscanf(fin, "%d\n", &my_spot);
	
		if (event == 'b') { // se qualcuno sale sul treno cerca il primo posto libero e ci si mette
			
			for (int current_seat : seats) {
				if ( seat == -1) {
					seats[k++] = 1;
					mappa_posti.push_back({i, current_seat, my_spot});
				}
				else if ( seat == 1 && current_seat == my_spot ) { // se è il mio posto, ma è occupato
					// chi ci sta? scorro l'array dei posti occupati e lo scopro: sarà colui che sta nel current seat (secondo campo della tupla)
					int abusivo=-1;
					for (tuple<int, int, int> t : mappa_posti) 
						if (get<2>(t) == current_seat) {
							abusivo = t(1); 
							swaps++;
							
							// sposto l'abusivo nel suo posto
							for(int other_seat : seats) {
								if (other_seat == -1 && other_seat == get<2>(t)) // il posto riservato dell'abusivo: non può prendere il primo libero, ma il suo (terzo elemento della tupla)
									mappa_posti.push_back({i, other_seat, get<2>(t)});
							} 
						}
						
						
	
				}
		
			}
			
		}
		else if (event == 'l') { // se scendo dal treno libero il posto senza scatenare ulteriori scambi
			seats[my_spot] = -1;
	
		}

	}
	
	/*=======================================================**/
	fclose(fin);
	// scrittura su file
	FILE *fout = fopen("output.txt", "w");
	assert(fout);
	
	fprintf(fout, "%d ", swaps);

	
	fclose(fout);
	
	
	return 0;
	
	
}
