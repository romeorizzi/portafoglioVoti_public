#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100000;
const int MAXM = 1000000;

struct bordo{
  int el[2];
  bool valid;
  bordo(int a,int b){
    *(el+0)=a;
    *(el+1)=b;
    valid=true;
  }
};

struct collegamento{
  int idBordo;
  int order;
  collegamento(int ed,int ord){
    idBordo=ed;
    order=ord;
  }
};

vector<bordo> bordi;
vector<vector<collegamento> > grafo;
vector<int> percorso;

int N,M,X,Y;

void ricerco(int el) {
    for(int i=0; i<grafo[el].size(); i++) {
        collegamento e=grafo[el][i];
        if(bordi[e.idBordo].valid) {
            bordi[e.idBordo].valid=false;
            ricerco(bordi[e.idBordo].el[e.order]);
        }
    }
    percorso.push_back(el);
}


int main() {

    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);

    cin >> N >> M >> X >> Y;
    grafo.reserve(N);
    X--;
    Y--;

    for(int i=0; i<M; i++) {
        int a,b;
        cin >> a >> b;
        a--;
        b--;
        grafo[a].push_back( collegamento(bordi.size(),1) );
        grafo[b].push_back( collegamento(bordi.size(),0) );
        bordi.push_back( bordo(a,b) );
    }
    ricerco(Y);
    assert( (int)M == percorso.size()-1 );
    for(int i=0; i<percorso.size()-1; i++)
        cout << percorso[i]+1 << " " << percorso[i+1]+1 << endl;
    return 0;
}
