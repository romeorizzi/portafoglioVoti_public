//VR413467 - seats.cpp

#include <bits/stdc++.h>

const int POSTO_DISP = -1;
const int NON_EXIST = -1;

std::vector<int> posto;
std::set<int> disponibile;
std::vector<int> dove;



int fix_people(int person){
    int offender = posto[person];
    posto[person] = dove[person] = person;

    if(posto[offender] == POSTO_DISP){
        posto[offender] = dove[offender] = offender;

        auto my_seat = disponibile.find(offender);
        assert(my_seat != disponibile.end());
        disponibile.erase(my_seat);
        return 1;
    } else { return 1 + fix_people(offender); }
}




int main(){

    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);


    int Q, N;
    std::cin >> N >> Q;

    posto.resize(N, POSTO_DISP);
    dove.resize(N, NON_EXIST);
    
    for(int i = 0; i < N; i++){ disponibile.insert(i); }
    int answer = 0;
    
    for(int i = 0; i < Q; i++){
        int reservation;
        std::string event;
        
        std::cin >> event >> reservation;
        
        if(event[0] == 'b'){
            auto leftmost = disponibile.begin();
            assert(leftmost != disponibile.end());
            
            if(*leftmost <= reservation){
                posto[*leftmost] = reservation;
                dove[reservation] = *leftmost;
                disponibile.erase(leftmost);
            } else { answer += fix_people(reservation); }
        } else {
            assert(dove[reservation] != NON_EXIST);
            disponibile.insert(dove[reservation]);
            posto[dove[reservation]] = POSTO_DISP;
            dove[reservation] = NON_EXIST;
        }
    }
    std::cout << answer << std::endl;

}





