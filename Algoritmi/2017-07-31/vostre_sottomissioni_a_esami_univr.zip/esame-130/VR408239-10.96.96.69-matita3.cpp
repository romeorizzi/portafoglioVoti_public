#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAX_N = 100000;

struct edge{
  int e[2];
  bool valido;
  edge(int a,int b){
    e[0]=a;
    e[1]=b;
    valido=true;
  }
};

struct elink{
  int id_edge;
  int order;
  elink(int ed,int ord){
    id_edge=ed;
    order=ord;
  }
};

vector<edge> edges;
vector<vector<elink> > grafo;
vector<int> percorso;


int N, M, X, Y;

void dfs(int el) {
  for(unsigned int i=0; i<grafo[el].size(); i++) {
     elink link=grafo[el][i];
     if(edges[link.id_edge].valido) {
        edges[link.id_edge].valido=false;
        dfs(edges[link.id_edge].e[link.order]);
     }
  }
  percorso.push_back(el);
}


int main() {
  ifstream in("input.txt");
  ofstream out("output.txt");

  in >> N >> M >> X >> Y;
  X--; Y--;
  grafo.reserve(N);
  for(int i=0; i<M; i++) {
    int a, b;
    in >> a >> b;
    a--; b--;
    grafo[a].push_back( elink(edges.size(),1) );
    grafo[b].push_back( elink(edges.size(),0) );
    edges.push_back( edge(a,b) );
  }
  dfs(Y);
  for(unsigned int i=0; i<percorso.size()-1; i++)
    out << percorso[i]+1 << " " << percorso[i+1]+1 << endl;
  return 0;
}
