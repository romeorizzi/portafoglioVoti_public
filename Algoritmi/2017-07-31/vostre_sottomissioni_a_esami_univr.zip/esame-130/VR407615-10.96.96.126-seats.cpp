#include <bits/stdc++.h>

const int LIBERO = -1;
const int NON_ESISTE = -1;

std::set<int> liberi;
std::vector<int> posto;
std::vector<int> dove;

int seats_rec(int persona) {
    int occupante = posto[persona]; // chi è seduto al mio posto
    posto[persona] = dove[persona] = persona; //mi siedo io

    if (posto[occupante] == LIBERO) { //l'occupante può sedersi senza far alzare altri
        posto[occupante] = dove[occupante] = occupante;

		auto mio_posto = liberi.find(occupante);
		assert(mio_posto != liberi.end());

		liberi.erase(mio_posto); // quello dell'occupante non è più libero
        return 1;
    } else {
        return 1 + seats_rec(occupante); //devo far alzare altre persone
    }
}

int main() {
    int N, Q;
    std::cin >> N >> Q;

    posto.resize(N, LIBERO);
    dove.resize(N, NON_ESISTE);

    for (int i = 0; i < N; i++) {
        liberi.insert(i);
    }

    int res = 0; // la soluzione, quante persone faccio alzare

    for (int i = 0; i < Q; i++) {
        int mio;
        std::string evento;

        std::cin >> evento >> mio;

        if (evento[0] == 'b') { //entro in treno
            auto sx = liberi.begin();
            assert(sx != liberi.end());

            if (*sx <= mio) {
                //mi siedo al primo libero che trovo
                posto[*sx] = mio;
                dove[mio] = *sx;
                liberi.erase(sx); //adesso il mio posto è occupato
            } else {
                // il mio posto è già accupato
                res += seats_rec(mio);
            }
            
        } else {
            // esco dal treno
            assert(dove[mio] != NON_ESISTE);

            liberi.insert(dove[mio]); //libero il mio posto

            posto[dove[mio]] = LIBERO;
            dove[mio] = NON_ESISTE;
        }
    }

    std::cout << res << std::endl;
}
