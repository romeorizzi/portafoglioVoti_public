#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>
#include <vector>
#include <set>

using namespace std;

const int SEAT_AVAILABLE = -1;
const int NON_EXISTENT = -1;
int N, Q;
int res = 0;

set<int> avail;
vector<int> seat;
vector<int> where;
ifstream fr;
ofstream fw;

int fix_people(int traveler) {
  auto pers_posto_sbagliato = seat[traveler];
  seat[traveler] = where[traveler] = traveler;
  if (seat[pers_posto_sbagliato] == SEAT_AVAILABLE)
  { 
    seat[pers_posto_sbagliato] = where[pers_posto_sbagliato] = pers_posto_sbagliato;
    auto posto = avail.find(pers_posto_sbagliato);
    assert(posto != avail.end());
    avail.erase(posto);
    return 1;
  }
  else
  {
    return 1 + fix_people(pers_posto_sbagliato);
  }
}

int main()
{
    fr.open("input.txt"); assert(fr);
    fw.open("output.txt"); assert(fw);
    fr >> N >> Q;
    seat.resize(N, SEAT_AVAILABLE);
    where.resize(N, NON_EXISTENT);

    for(int i = 0; i < N; ++i)
    {
        avail.insert(i);
    }

    for(int i = 0; i < Q; ++i)
    {
        int prenot;
        char event;

        fr >> event >> prenot;
        if (event == 'b')
        {
            auto leftmost = avail.begin();
            assert(leftmost != avail.end());
        
            if (*leftmost <= prenot)
            {
                seat[*leftmost] = prenot;
                where[prenot] = *leftmost;
                avail.erase(leftmost);
            }
            else
            {
                res += fix_people(prenot);
            }
        }
        else
        {
            assert(where[prenot] != NON_EXISTENT);
            avail.insert(where[prenot]);
            seat[where[prenot]] = SEAT_AVAILABLE;
            where[prenot] = NON_EXISTENT;
        }
    }
    fw << res << endl;

    fr.close();
    fw.close();
}
