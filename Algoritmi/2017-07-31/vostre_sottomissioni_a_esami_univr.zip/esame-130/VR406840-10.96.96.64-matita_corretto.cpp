#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main(){
    ifstream in ("input.txt");
    ofstream out("output.txt");

    int N, V, A, B;
    vector<int> sol;
    stack<int> tempS;
    vector<list<int> > graph;
    vector<int> edges;

    in >> N >> V >> A >> B;

    graph.resize(N + 1);
    edges.resize(V);

    int temp1, temp2;

    for(int i = 0; i < V; i++){
        in >> temp1 >> temp2;
        edges[i] = temp1 + temp2;
        graph[temp1].push_back(i);
        graph[temp2].push_back(i);    
    }

    int c = A;
    
    while (sol.size() < V){
        bool hasNeighbour = false;
        for(list<int>::iterator i = graph[c].begin(); i != graph[c].end(); i++)
            if(edges[*i] > 0){
                tempS.push(c);
                hasNeighbour = true;
                int next = edges[*i] - c;
                edges[*i] = -1;
                graph[c].remove(*i);
                c = next;
                graph[c].remove(*i);
                break;
            }
        if(!hasNeighbour){
            sol.push_back(c);
            c = tempS.top();
            tempS.pop();        
        }
    }

    sol.push_back(A);

    for(int i = sol.size() - 1; i > 0; i--)
        out << sol[i] << " " << sol[i-1] << "\n";

    return 0;
    
}
