//VR413467 - matita.cpp

#include <fstream>
#include <iostream>
#include <cassert>
#include <vector>
//#include <bits/stdc++.h>
using namespace std;

struct linkt{
    int edge_id;
    int ords;
    linkt(int ed,int ord){
        edge_id=ed;
        ords=ord;
    }
};

struct edge{
    int val[2];
    bool valido;
    edge(int a,int b){
        val[0]=a;
        val[1]=b;
        valido=true;
    }
};

vector<edge> veced;
vector<int> percorso;
vector<vector<linkt> > grafo;

void dfsfun(int el){
    for(unsigned int i=0; i<grafo[el].size(); i++){
        linkt e = grafo[el][i];
        if(veced[e.edge_id].valido){
            veced[e.edge_id].valido = false;
            dfsfun(veced[e.edge_id].val[e.ords]);
        }
    }
    percorso.push_back(el);
}

int n, m, c, d;
int main(){
    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);

    cin >> n >> m >> c >> d;
    c--; d--;

    grafo.reserve(n);
    for(int s = 0; s < m; s++){
        int a, b;
        cin >> a >> b;

        a--;
        b--;

        grafo[a].push_back(linkt(veced.size(),1));
        grafo[b].push_back(linkt(veced.size(),0));
        veced.push_back(edge(a,b));
    }
    dfsfun(d);
    assert((unsigned int)m == percorso.size()-1);

    for(int s = 0; s < percorso.size()-1; s++){
        cout << percorso[s]+1 << " " << percorso[s+1]+1 << endl;
    }


    return 0;

}
