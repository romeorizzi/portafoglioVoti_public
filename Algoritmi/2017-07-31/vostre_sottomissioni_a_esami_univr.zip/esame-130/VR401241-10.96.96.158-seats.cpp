#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>

using namespace std;

#define N_MAX 100000
#define Q_MAX 100000

int N;
int Q;
int posti[N_MAX + 1] = {-1};
int riservati[N_MAX + 1] = {-1};

int eventi = 0;
int num_pass = 0;

void boards(int j, int ris);
void leaves(int ris);

int main() {

    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> Q;

    for(int i = 0; i < Q; i++) {
        char t;
        int k;
        in >> t >> k;

        if(t == 'b')
            boards(0, k);
        else
            leaves(k);
    }

    out << eventi << endl;

    in.close();
    out.close();

  return 0;
}

void boards(int j, int ris) {
    if(ris == j)
        return;
    for(int i = j; i <= N; i ++) {
        if(posti[i] == -1)
            posti[i] = ris;
        else {
            if(i == ris) {
                int occ = posti[i];
                boards(i, occ);
                eventi++;
            }
        }
    }
}

void leaves(int ris) {
    for(int i = 0; i < N; i++)
        if(posti[i] == ris)
            posti[i] = -1;
}
