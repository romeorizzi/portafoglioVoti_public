
// Marco Panato VR407935

#include <cstdio>
#include <cassert>
#include <vector>

using namespace std;

#define MAX_N 100000
#define MAX_M 1000000

int N, M, A, B;

vector<vector<int>> graph;

FILE* fo;

int cerca(vector<int> listaAdiacenza, int nodo) {
    for (int i = 0; i < listaAdiacenza.size(); ++i) {
        if (listaAdiacenza[i] == nodo) {
            return i;
        }
    }
    return -1;
}

void dfs(int nodo, int da) {
    int next;
    int tmp;
    for (int i = 0; i < graph[nodo].size(); ++i) {
        if (graph[nodo][i] != -1) {
            next = graph[nodo][i];
            graph[nodo][i] = -1;

            // evito i cicli
            tmp = cerca(graph[next], nodo);
            graph[next][tmp] = -1;

            dfs(next, nodo);
        }
    }

    if(da != -1) {
        fprintf(fo, "%d %d\n", nodo, da);
    }
}

int main() {
    FILE *fi = fopen("input.txt", "r");
    assert(fi);

    fscanf(fi, "%d %d %d %d", &N, &M, &A, &B);
    assert(N > 0 && M > 0 && A > 0 && B > 0);
    assert(N <= MAX_N && M <= MAX_M);
    assert(A != B);
    assert(A <= N && B <= N);

    graph.resize(N + 1);

    int t1, t2;
    for (int i = 0; i < M; ++i) {
        fscanf(fi, "%d %d", &t1, &t2);

        graph[t1].push_back(t2);
        graph[t2].push_back(t1);
    }

    fo = fopen("output.txt", "w");
    assert(fo);

    dfs(B, -1);

    fclose(fo);
    return 0;
}
