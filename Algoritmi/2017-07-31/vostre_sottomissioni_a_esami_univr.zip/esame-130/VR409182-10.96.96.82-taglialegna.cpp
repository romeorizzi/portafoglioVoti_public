#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAXN = 2000000;

int alberi_sx[MAXN]; 

int alberi_dx[MAXN];  

int memoization[MAXN];
int primo[MAXN];
bool direzione[MAXN];
int num_c;
int candidati[MAXN];
int min_c[MAXN];

void Abbatti(int, int);


void Pianifica(int N, int H[]) {
	alberi_sx[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = alberi_sx[j] - 1;
		alberi_sx[i] = j + 1;
	}

	alberi_dx[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = alberi_dx[j] + 1;
		alberi_dx[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		j = alberi_sx[i] - 1;

		test = 1;
		if (j >= 0)
			test += memoization[j];
		
		memoization[i] = test;
		primo[i] = i;
		direzione[i] = false;


		while (num_c && alberi_dx[*(candidati + num_c - 1)] < i)
			--num_c;

		if (num_c) {
			j = min_c[num_c - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memoization[j];

			if (test < memoization[i]) {
				memoization[i] = test;
				primo[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (num_c) {
			if (
				min_c[num_c - 1] == 0 ||
				memoization[min_c[num_c - 1] - 1] < memoization[i - 1]
			) {
				j = min_c[num_c - 1];
			}
		}

		++num_c;
		candidati[num_c - 1] = i;
		min_c[num_c - 1] = j;
	}

	int i = N - 1;
	while (i >= 0) {
		Abbatti(primo[i], direzione[i]);
		
		if (direzione[i] == false) 
			i = alberi_sx[i] - 1;
		else
			i = primo[i] - 1;
	}
}
