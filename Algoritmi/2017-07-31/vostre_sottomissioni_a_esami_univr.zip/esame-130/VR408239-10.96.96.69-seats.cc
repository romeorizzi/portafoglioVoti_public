#include <stdio.h>
#include <vector>
#include <assert.h>
#include <set>
#include <bits/stdc++.h>

using namespace std;

set<int> disp;
vector<int> seat;
vector<int> dove;

const int SEAT_DISPONIBILI = -1;
const int NON_ESISTENTE = -1;

int fix_people(int persona){
    int offender = seat[persona];
    seat[persona] = dove[persona] = persona;

    if(seat[offender] == SEAT_DISPONIBILI){
        seat[offender] = dove[offender] = offender;

        auto my_seat = disp.find(offender);

        disp.erase(my_seat);
        return 1;
    }else{
        return 1+ fix_people(offender);
    }    
}

int main(){
    int N,Q;
    cin >> N >> Q;

    seat.resize(N, SEAT_DISPONIBILI);
    dove.resize(N, NON_ESISTENTE);

    for(int i = 0; i < N; i++)
        disp.insert(i);

    int answer = 0;
    for(int i = 0; i <Q; i++){
        int riservare;
        string evento;
        cin >> evento >> riservare;

        if(evento[0] == 'b'){
            auto leftmost = disp.begin();

            if(*leftmost <= riservare){
                seat[*leftmost] = riservare;
                dove[riservare] = *leftmost;
                disp.erase(leftmost);
            }else{
                answer += fix_people(riservare);
                             
            }
        }else{
            disp.insert(dove[riservare]);
            seat[dove[riservare]] = SEAT_DISPONIBILI;
            dove[riservare] = NON_ESISTENTE;


        }
    }
    cout << answer << endl;


    return 0;
}
