#include <bits/stdc++.h>
#include <cassert>

const int POSTO_DISPONIBILE= -1;
const int NON_ESISTE = -1;

using namespace std;

vector<int> posto;
vector<int> dove;
set<int> disponibile;

int fissa_persone(int persona){
    int off=posto[persona];
    posto[persona]=dove[persona] = persona;
    
    if(posto[off]==POSTO_DISPONIBILE){
        posto[off]=dove[off]=off;
        
        auto m_posto = disponibile.find(off);
        assert(m_posto != disponibile.end());
        
        disponibile.erase(m_posto);
            return 1;
    }
    else{
        return 1 + fissa_persone(off);
    }
}

int main()
{
    int N;
    int Q;
    cin >> N >> Q;
    
    posto.resize(N, POSTO_DISPONIBILE);
    dove.resize(N, NON_ESISTE);
    
    for(int i=0; i<N; i++){
        disponibile.insert(i);
    }
    
    int risposta = 0;
    
    for(int i=0; i<Q; i++){
        int riservato;
        string evento;
        cin >> evento >> riservato;
        
        if(evento[0]== 'b'){
            auto sinistra= disponibile.begin();
            
        assert(sinistra!=disponibile.end());
        
        if(*sinistra <=riservato){
            posto[*sinistra] = riservato;
            dove[riservato] = *sinistra;
            disponibile.erase(sinistra);
        }
        else{
            risposta+=fissa_persone(riservato);  
        }
        }
        else{
            assert(dove[riservato]!= NON_ESISTE);
            disponibile.insert(dove[riservato]);
            posto[dove[riservato]] = POSTO_DISPONIBILE;
            
            dove[riservato] = NON_ESISTE;
        }       
    }
    cout << risposta << endl;
}
    
