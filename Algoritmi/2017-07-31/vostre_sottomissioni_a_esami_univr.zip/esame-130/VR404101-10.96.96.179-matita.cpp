#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <iostream>

using namespace std;

int main(){

    ifstream in("input.txt");
    ofstream out("output.txt");

    int N, V, A, B;

    vector<int> sol;
    stack<int> temp;
    vector<list<int> > g;
    vector<int> a;

    in >> N >> V >> A >> B;

    g.resize(N+1);
    a.resize(V);

    int t1, t2;

    for(int i = 0; i < V; i++){
        
        in >> t1 >> t2;
        a[i] = t1 + t2;
        g[t1].push_back(i);
        g[t2].push_back(i);         
        
    }

    int c = A;

    while(sol.size() < V){
    
        bool hasNeighbour = false;

        for(list<int>::iterator i = g[c].begin(); i != g[c].end(); i++)
            if(a[*i] > 0){

            temp.push(c);
            hasNeighbour = true;
            int next = a[*i]-c;
            a[*i] = -1;
            g[c].remove(*i);
            c = next;
            g[c].remove(*i);
            break;            

            }
        
    if(!hasNeighbour){
    
        sol.push_back(c);
        c = temp.top();
        temp.pop();            

        }        

    }    

sol.push_back(A);

    for(int i = sol.size() - 1; i > 0; i--)
        out << sol[i] << " " << sol[i-1] << "\n";

return 0;

}
