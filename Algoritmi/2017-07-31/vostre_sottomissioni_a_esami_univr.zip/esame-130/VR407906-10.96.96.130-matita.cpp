#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
#include <vector>
#include <list>

using namespace std;

int N,V,A,B;
vector<list<int> > graph;
vector<int> edge;

int main()
{
    ifstream inp("input.txt");
    ofstream out("output.txt");

    vector<int> sol;
    stack<int> tmpS;

    inp >> N >> V >> A >> B;

    edge.resize(V);
    graph.resize(N+1);
    
    int tmp1,tmp2;

    for(int i=0;i<V;i++){
        inp >> tmp1 >> tmp2;
        edge[i] = tmp1+tmp2;
        graph[tmp1].push_back(i);
        graph[tmp2].push_back(i);
    }

    
    int ind=A;

    while(sol.size()<V){
        bool vicini = false;
        
        for(list<int>::iterator i= graph[ind].begin();i!=graph[ind].end();i++){
            if(edge[*i] > 0)
            {
                tmpS.push(ind);
                vicini = true;
                int next = edge[*i]-ind;
                edge[*i] = -1;
                graph[ind].remove(*i);
                ind = next;
                graph[ind].remove(*i);
                break;
            }        
        }
        if(!vicini)
        {
            sol.push_back(ind);
            ind = tmpS.top();
            tmpS.pop();
        }  
    }
    sol.push_back(A);
    
    for(int i=sol.size()-1;i>0;i--){
        out << sol[i] << " " << sol[i-1] << "\n";    
    }

    return 0;
    
}



