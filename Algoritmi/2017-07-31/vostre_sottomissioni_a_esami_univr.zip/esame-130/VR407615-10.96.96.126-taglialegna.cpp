#include <bits/stdc++.h>
#include <iostream>
#include <algorithm>
#include <limits>
#include <cassert>
#define MAXN 2000002
using namespace std;

const int infinito = numeric_limits<int>::max();
int *a;
int N;

struct tree {
	int alberi, primo_albero;
	bool direzione; //f sx t dx

	tree(): alberi(infinito) {}
	tree(int alberi, int primo_albero, bool direzione): alberi(alberi), primo_albero(primo_albero), direzione(direzione) {}

	bool operator< (const tree& other) const {
		return alberi < other.alberi;
	}
};

tree memo[MAXN];
int l[MAXN];
int r[MAXN]; 

void Abbatti(int, int);

tree risolvi(int c) { 

	if (memo[c].alberi != infinito)
		return memo[c];

	tree ans;

	int j = r[c] + 1;

	int test = 1;
	if (j < N)
		test += risolvi(j).alberi;

	ans.alberi = test;
	ans.primo_albero = c;
	ans.direzione = true;

	j = -1;
    int i=c+1;
	while(i < N) {
		if (l[i] <= c) {

			if (i < N - 1) {
				tree x = risolvi(i + 1);

				if (x.alberi + 1 < ans.alberi) {
					ans.alberi = x.alberi + 1;
					ans.direzione = false;
					ans.primo_albero = i;
				}
			} else {
				ans.alberi = 1;
				ans.direzione = false;
				ans.primo_albero = N - 1;
			}
		}
        i++;
	}

	return memo[c] = ans;
}

void ricostruisci(int c) { 

	int i = memo[c].primo_albero;
	bool dir = memo[c].direzione;

	Abbatti(i, dir);

	if (dir == false) { 
		if (i < N - 1)
			ricostruisci(i + 1);
	} else { 
		if (r[i] < N - 1)
			ricostruisci(r[i] + 1);
	}
}

void Pianifica(int n, int H[]) {
	a = H;
	N = n;
    int i=0;
	while (i < N) {
		int cont = a[i] - 1;
		for (l[i] = i - 1; l[i] >= 0 && cont; l[i]--)
			cont = max(cont - 1, a[l[i]] - 1);
		++l[i];

		cont = a[i] - 1;
		for (r[i] = i + 1; r[i] < N && cont; r[i]++)
			cont = max(cont - 1, a[r[i]] - 1);
		--r[i];
        i++;
	}

	risolvi(0);

	ricostruisci(0);
}

