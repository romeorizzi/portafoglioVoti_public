#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

const int MAX_LIMIT = 2000000; 

static char int_buffer[32];
static FILE *fr, *fw;

bool direzione[MAX_LIMIT];

int N;
int n_cdt;
int cdt[MAX_LIMIT];
int min_cdt[MAX_LIMIT];
int left_ep[MAX_LIMIT];  
int right_ep[MAX_LIMIT];  
int memoria[MAX_LIMIT];
int f_tree[MAX_LIMIT];
void Abbatti(int, int);


void Pianifica(int N, int altezza[]) {
	left_ep[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < altezza[i])
			j = left_ep[j] - 1;
		left_ep[i] = j + 1;
	}

	right_ep[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < altezza[i])
			j = right_ep[j] + 1;
		right_ep[i] = j - 1;
	}

	int j, test;
	for (int i = 0; i < N; i++) {
		j = left_ep[i] - 1;

		test = 1;
		if (j >= 0)
			test += memoria[j];
		
		memoria[i] = test;
		f_tree[i] = i;
		direzione[i] = false;

		while (n_cdt && right_ep[*(cdt + n_cdt - 1)] < i)
			--n_cdt;

		if (n_cdt) {
			j = min_cdt[n_cdt - 1] - 1;

			test = 1;
			if (j >= 0)
				test += memoria[j];

			if (test < memoria[i]) {
				memoria[i] = test;
				f_tree[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (n_cdt) {
			if (
				min_cdt[n_cdt- 1] == 0 ||
				memoria[min_cdt[n_cdt - 1] - 1] < memoria[i - 1]
			) {
				j = min_cdt[n_cdt - 1];
			}
		}

		++n_cdt;
		cdt[n_cdt - 1] = i;
		min_cdt[n_cdt - 1] = j;
	}

	int i = N - 1;
	while (i >= 0) {
		Abbatti(f_tree[i], direzione[i]);
		
		if (direzione[i] == false)
			i = left_ep[i] - 1;
		else
			i = f_tree[i] - 1;
	}
}


