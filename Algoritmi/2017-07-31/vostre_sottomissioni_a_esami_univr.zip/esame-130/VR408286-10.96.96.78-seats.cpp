#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <vector>
#include <bits/stdc++.h>

using namespace std;

//GLOBAL VAR
set<int> disponibili;
vector<int> sedili;
vector<int> loc;
const int DISPONIBILE = -1;
const int INUTILIZZABILE = -1;

//FUNCTIONS
int fix_people(int);

int main(void){
    std::ifstream input_file("input.txt");
    std::ofstream output_file("output.txt");
    int N,Q;
    
    input_file >> N >> Q;

    sedili.resize(N, DISPONIBILE);
    loc.resize(N, INUTILIZZABILE);

    //inizialmente tutti disponibili
    for(int i=0; i<N; i++)
        disponibili.insert(i);

    int answer = 0;
    for(int i=0; i<Q; i++){
        int reservation;
        string event;

        input_file >> event >> reservation;

        if(event[0] == 'b'){
            auto set_start = disponibili.begin();
            if(*set_start <= reservation){
                sedili[*set_start] = reservation;
                loc[reservation] = *set_start;
                disponibili.erase(set_start);
            }
            else{
                answer += fix_people(reservation);
            }
        }
        else{
            disponibili.insert(loc[reservation]);
            sedili[loc[reservation]] = DISPONIBILE;
            loc[reservation] = INUTILIZZABILE;
        }
    }

    output_file << answer << endl;
    return 0;
}

int fix_people(int position){
    int wrong_location = sedili[position];
    sedili[position] = loc[position] = position;

    //sposto la persona che era in posizione sbagliata
    if(sedili[wrong_location] == DISPONIBILE){
        sedili[wrong_location] = wrong_location;
        loc[wrong_location] = wrong_location;

        auto found_seat = disponibili.find(wrong_location);
        disponibili.erase(found_seat);
        return 1;
    }
    else{
        //sistema le altre persone ricorsivamente
        return 1 + fix_people(wrong_location);  
    }
}

