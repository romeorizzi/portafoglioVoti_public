#include <iostream>
#include <algorithm>
#include <limits>
#include <stack>
#include <cassert>

using namespace std;

void Abbatti(int, int);

const int MAXN = 2000000;
int indice_sx[MAXN];  
int indice_dx[MAXN];  
int mem[MAXN];
int albero[MAXN];
bool direzione[MAXN];
int numero_candidati;
int candidati[MAXN];
int candidati_minimi[MAXN];

void Pianifica(int N, int H[]) {
	indice_sx[0] = 0;
	for (int i = 1; i < N; i++) {
		int j = i-1;
		while (j >= 0 && i - j < H[i])
			j = indice_sx[j] - 1;
		indice_sx[i] = j + 1;
	}

	indice_dx[N-1] = N-1;
	for (int i = N-2; i >= 0; i--) {
		int j = i + 1;
		while (j < N && j - i < H[i])
			j = indice_dx[j] + 1;
		indice_dx[i] = j - 1;
	}

	int j, prova;
	for (int i = 0; i < N; i++) {
		// Primo caso: butto i a sinistra
		j = indice_sx[i] - 1;

		prova = 1;
		if (j >= 0)
			prova += mem[j];
		
		mem[i] = prova;
		albero[i] = i;
		direzione[i] = false;

		// Secondo caso: abbatto a destra un albero che abbatte i nella caduta
		while (numero_candidati && indice_dx[*(candidati + numero_candidati - 1)] < i)
			--numero_candidati;

		if (numero_candidati) {
			j = candidati_minimi[numero_candidati - 1] - 1;

			prova = 1;
			if (j >= 0)
				prova += mem[j];

			if (prova < mem[i]) {
				mem[i] = prova;
				albero[i] = j + 1;
				direzione[i] = true;
			}
		}

		j = i;
		if (numero_candidati) {
			if (
				candidati_minimi[numero_candidati - 1] == 0 ||
				mem[candidati_minimi[numero_candidati - 1] - 1] < mem[i - 1]
			) {
				j = candidati_minimi[numero_candidati - 1];
			}
		}

		++numero_candidati;
		candidati[numero_candidati - 1] = i;
		candidati_minimi[numero_candidati - 1] = j;
	}

	// Ricostruisci la soluzione
	int i = N - 1;
	while (i >= 0) {
		Abbatti(albero[i], direzione[i]);
		
		if (direzione[i] == false) // A sinistra
			i = indice_sx[i] - 1;
		else
			i = albero[i] - 1;
	}
}
