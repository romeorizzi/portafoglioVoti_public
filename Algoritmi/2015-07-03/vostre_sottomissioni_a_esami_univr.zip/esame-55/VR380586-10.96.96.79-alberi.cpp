#include<cstdio>
#include <vector>
#include <iostream>

using namespace std;


void visita(int N, int *PRE, int *POST, int *SIMM ){

    struct elemento{
        elemento(){
            visitato=false;
            posizione=0;
            nome=0;
        }
        int nome;
        int posizione;
        bool visitato;    
    };
    
    vector<elemento> nodi;

    nodi.assign(N+2,elemento());

    int pos=0;
    int count=N; 

    //scorro tutti gli elementi
    for(int i=0;i<N;i++){
        if(count!=0){
            for(int j=0;j<N;j++){
                if(POST[i]==PRE[j]) 
                {   
                    if(nodi[PRE[j]].visitato==false){ //non ancora visitato          
                        SIMM[pos++]=PRE[j];
                        nodi[PRE[j]].posizione=pos;
                        nodi[PRE[j]].visitato=true;                        
                        count--;
                    }

                   if(nodi[PRE[j-1]].visitato==false){
                        SIMM[pos++]=PRE[j-1];
                        nodi[PRE[j-1]].posizione=pos;
                        nodi[PRE[j-1]].visitato=true;
                        count--;
                    }
                }
            }
        }
        else break;
    }
}

