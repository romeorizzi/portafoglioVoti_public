#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <iterator>
#include <cassert>
#include <cstdlib>
#include <cstdio>
#include <math.h>

using namespace std;

int V;
vector<int>a;
vector<int>b;

int sign(int a){
    if(a < 0)return -1;
    else if(a == 0) return 0;
    else if(a > 0) return 1;
}

int main() {

    fstream in,out; 
	in.open("input.txt",ios::in); 
	out.open("output.txt",ios::out); 
	in >> V;
    a.resize(V);
    b.resize(V);

	for(int i = 0; i < V; i++)
		in >> a.at(i);

	for(int i = 0; i < V; i++)
		in >> b.at(i);

    in.close();

    int n = 0;
    
    for(int i = 0; i < V-1; ++i){
        for(int j = i; j < V; ++j){
            if(sign(a.at(i) < a.at(j)) * sign(b.at(i) > b.at(j)))
                n++;
            if(sign(a.at(i) > a.at(j)) * sign(b.at(i) < b.at(j)))
                n++;
        }
    }

    out << n;


return 0;
}
    
     
