#include <stdio.h>
#include <assert.h>

int main(){
    int n, i, j;
    
    // acquisisco n
    scanf("%d", &n);
    
    // controllo
    assert(n>0);
    assert(n<=1000000);
    
    // creo l'array pi
    int pi[n];
    
    //riempio pi
    for(i=0; i<n; i++){
        scanf("%d", &pi[i]);
    }
    
    // creo l'array sigma
    int sigma[n];
    
    // riempio sigma
    for(i=0; i<n; i++){
        scanf("%d", &sigma[i]);
    }

    // applico la formula kendall
    int kDist = 0;
    for(i=0; i<n; i++){
        for(j=i+1; j<n; j++){
            if( ((pi[i]<pi[j]) && (sigma[i]>sigma[j])) || ((pi[i]>pi[j]) && (sigma[i]<sigma[j])) ){
                kDist = kDist+1;
            }
        }
    }
    
    // restituisco il risultato
    printf("%d", kDist);

    return 0;
}
