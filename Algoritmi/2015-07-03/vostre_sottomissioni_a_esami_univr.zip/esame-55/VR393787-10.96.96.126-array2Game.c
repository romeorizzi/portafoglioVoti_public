#include<stdio.h>
#include<stdlib.h>

#define MAX_N 3000
#define MAX_M 3000

char turning_table[MAX_M][MAX_N];

int m,n,i_start,j_start;

void turning(int tmp,int i,int j);

int main(){
    
    int i,j;
    int tmp;
    scanf("%d %d %d %d",&m,&n,&i_start,&j_start);
    //brutale
    for(i=0; i<i_start;++i){
        for(j=0; j<n;++j){
            scanf("%d",&tmp);
            // calcolate turning
            if(j<j_start)turning(tmp,i,j);
        }
    }
    if(turning_table[i_start-1][j_start-1]==0)printf("LOST\n");
    else printf("WINNING STARTING POSITION\n");
    
    return 0;
}

void turning(int tmp,int i,int j){
   int flag=0;
    int k;
   for(k=1;k<=tmp && flag==0;++k){
        if((i-k)>=0 && turning_table[i-k][j]==0)flag=1;//righe
        if((j-k)>=0 && turning_table[i][j-k]==0)flag=1;//colonne
    }
    turning_table[i][j]=flag;
}
