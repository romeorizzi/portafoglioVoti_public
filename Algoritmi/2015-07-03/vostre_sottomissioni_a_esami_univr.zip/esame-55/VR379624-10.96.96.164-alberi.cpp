
/**
 * @brief visita da implementare
 * @param N numero nodi dell'albero
 * @param PRE array con visita in preordine
 * @param POST array con visita in postordine
 * @param SIMM array da riempire con visita simmetrica
 */

bool confronta_pos(int N, int a, int b, int *POST){
    int pos1=0, pos2=0;
    for(int i = 0; i < N; i++){
        if(POST[i]=a)
            pos1=i;
        if(POST[i]=b)
            pos2=i;
    }
    if(pos1 < pos2)
        return true;
    return false;
}

/**
 * guardo il primo numero di PRE, è radice
 * scorro PRE:
 * se il numero i viene prima di uno di quelli visitati, allora ne è figlio
 *
 **/
void visita(int N, int *PRE, int *POST, int *SIMM ){

    int root = PRE[0];

    int visitati[N];
    visitati[0]=root;
    int corrente=-1;

    SIMM[0]=POST[0];
    int k = 1;
    for(int i = 1; i < N; i++){
        corrente=PRE[i];
        for(int j=N; j>=0; j--){
            if(confronta_pos(N, corrente, visitati[j], POST)){
                SIMM[k]=corrente;
                k++;
                SIMM[k]=visitati[j];
                k++;
                visitati[j-1]=corrente;
                break;
            }
        }

    }
}
