#include <stdlib.h>
#include <stdio.h>

int idx = 0;

void build_tree(int val, int *found, int *pre, int *post, int* prepos, int *postpos, int n, int *simm){

    int i;

    if(prepos[val] +1 >= n || postpos[val]-1 < 0){ //foglia
        simm[idx++] = val;
        return;
    }
    
    int candidateleft = pre[prepos[val]+1];

    if(found[candidateleft]){   //foglia
        simm[idx++] = val;
        return;
    }
    int candidateright = post[postpos[val]-1];

    if(found[candidateright]){ //foglia
        simm[idx++] = val;
        return;
    }

    found[candidateleft] = 1;
    found[candidateright] = 1;


    //stampo in visita simmetrica
    build_tree(candidateleft, found, pre, post, prepos, postpos, n, simm);
    simm[idx++] = val;
    build_tree(candidateright, found, pre, post, prepos, postpos, n, simm);
    

}


void visita(int N, int *PRE, int *POST, int *SIMM){

    int i;

    int *PREPOS = (int *) malloc((N+1)*sizeof(int));
    int *POSTPOS = (int *) malloc((N+1)*sizeof(int));
    
    for(i=0; i<N; i++){
        PREPOS[PRE[i]] = i;
        POSTPOS[POST[i]] = i;
    } 


    int found[N];
    int root = PRE[0];

    for(i=0; i<N+1; i++)
        found[i] = 0;

    found[root] = 1;

    build_tree(root, found, PRE, POST, PREPOS, POSTPOS, N, SIMM);

}
