#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
struct cols{
    vector <int> matrixCol;
};
vector <cols> matrixRaw;

//if player==1 -> player 1, else player 2
void array2Game(int i, int j, int player){
bool go=true;
    if(player==1){    
        //prima cella
        if(i==1 && j==1)
            printf("\"LOST\"\n");
        //prima riga e spostamenti > 
        else if(i==1 && matrixRaw[0].matrixCol[j-1]>=j-1)
            printf("\"WINNING STARTING POSITION\"\n");
        //prima riga e spostamenti=1
        else if(i==1 && matrixRaw[0].matrixCol[j-1]==1)
            array2Game(i, j-1, -1);
        //prima colonna e spostamenti >
        else if(j==1 && matrixRaw[i-1].matrixCol[0]>=i-1)
            printf("\"WINNING STARTING POSITION\"\n");
        //prima colonna e spostamenti=1
        else if(j==1 && matrixRaw[i-1].matrixCol[0]==1)
            array2Game(i-1, j, -1);
        else{
            for(int k=matrixRaw[i-1].matrixCol[j-1]; k>0; k--){
                 if (go = true && i-k>0 && matrixRaw[i-1-k].matrixCol[j-1] < i-1-k){
                    array2Game(i-k, j, -1);
                    go = false;
                    }
                 else if(go = true && j-k>0 && matrixRaw[i-1].matrixCol[j-1-k] < j-1-k){
                    array2Game(i, j-k, -1);
                    go = false;
                    }
            }
            if(go == true)//do priorità all'altezza
                 array2Game(i-matrixRaw[i-1].matrixCol[j-1], j, -1);
        }


    }
    else{
        if(i==1 && j==1)
            printf("\"WINNING STARTING POSITION\"\n");
        else if(i==1 && matrixRaw[0].matrixCol[j-1]>=j-1)
            printf("\"LOST\"\n");
        else if(i==1 && matrixRaw[0].matrixCol[j-1]==1)
            array2Game(i, j-1, 1);
        else if(j==1 && matrixRaw[i-1].matrixCol[0]>=i-1)
            printf("\"LOST\"\n");
        else if(j==1 && matrixRaw[i-1].matrixCol[0]==1)
            array2Game(i-1, j, 1);
        else{
            for(int k=matrixRaw[i-1].matrixCol[j-1]; k>0; k--){
                 if (go = true && i-k>0 && matrixRaw[i-1-k].matrixCol[j-1] < i-1-k){
                    array2Game(i-k, j, 1);
                    go = false;
                    }
                 else if(go = true && j-k>0 && matrixRaw[i-1].matrixCol[j-1-k] < j-1-k){
                    array2Game(i, j-k, 1);
                    go = false;
                    }
            }
            if(go == true)
                 array2Game(i-matrixRaw[i-1].matrixCol[j-1], j, 1);
        }
    }
}

int main(int argc, char *argv[]) {
    
    int n=0, m=0, i=0, j=0;
    int val=0;

    int input = scanf("%d %d %d %d", &m, &n, &i, &j);

    matrixRaw.assign(m,cols());

	for (int i = 0; i < m; i++) {
        for(int j = 0; j < n; j++){
	        input = scanf("%d", &val);
            matrixRaw[i].matrixCol.push_back(val);
        }
    }
    
    array2Game(i,j,1);

	return 0;
}

