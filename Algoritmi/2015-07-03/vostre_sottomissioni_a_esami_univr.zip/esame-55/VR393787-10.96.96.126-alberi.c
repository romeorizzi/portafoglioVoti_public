void visita(int N, int *PRE, int *POST, int *SIMM ){
    // caso base N=1
    if(N==1){
        *SIMM=*PRE;
        return;    
    }
	int i ;
    // selezione sottoalberi
    int target=*PRE;
    int sx_head=*(++PRE);
    int dx_head=POST[N-1];
    int sx_depth=0;
    int dx_depth=0;
    
	for( i = 1 ; i < N && dx_depth==0 && sx_depth==0; ++i ){
        if(PRE[i]==dx_head){
           sx_depth=i;
            dx_depth=N-1-i;             
        }
        if(POST[N-i-2]==sx_head){
           dx_depth=i;
            sx_depth=N-1-i;        
        }        
    }
    SIMM[sx_depth]=target;
    //visita sottoalbero sx
    visita(sx_depth,PRE,POST,SIMM);
    //visita sottoalbero dx
    visita(dx_depth,&(PRE[sx_depth]),&(POST[sx_depth]),&(SIMM[sx_depth+1]));

}


