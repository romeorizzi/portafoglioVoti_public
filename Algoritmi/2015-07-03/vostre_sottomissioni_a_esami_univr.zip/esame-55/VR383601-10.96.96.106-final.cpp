#include <cassert>
#include <iostream>

using namespace std;

//fin >> B[i][j]; {  } hhhhhhhhhhhhhhhhhhhhhhhhh
int main() {
   int n = 0; //dimensione permutazioni
   cin >> n; assert(n>0);
   
   int a[n];
   int b[n];
   //inizializzo a
   int aa = 0;
   for(int i=0; i<n; i++){  
    cin >> a[i];
    if( !(a[i] >  a[i-1] ||  a[i] >  a[i-1]))
        aa=1; 
   }
   /*
   for(int i=0; i<n; i++){  
    cout << a[i] << ' ';
   }
   */
   
   //inizializzo b
   int  bb = 0;
    for(int i=0; i<n; i++){  
    cin >> b[i];
    if( !(b[i] >  b[i-1] ||  b[i] >  b[i-1]))
        bb=1;
   }
  
   int kendal = 0;
  if(bb==1 || aa==1) { 
   for(int i=0; i<n-1; i++){  
            for(int j=i+1; j<=n-1; j++){  
              
                if(( (a[i]<a[j]) )){
                    if(b[i]>b[j]) {   
                    kendal++;  
                    continue;  }
                    }
                    
                   else if ( (a[i]>a[j])){ 
                     if(b[i]<b[j]) {   
                      kendal++;  
                    continue;  
                    }
                    
                    }
            }
     }
     }
     else { 
     for(int i=0; i<n-1; i++)  
            for(int j=i+1; j<=n-1; j++)
              kendal++;
              
              }
     
     cout << kendal;
    
   return 0;
}

