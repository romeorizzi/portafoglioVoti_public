#include<cstdio>
#include <vector>
#include <iostream>

using namespace std;

void controlla();
vector <int> pi;
vector <int> sigma;
int num_elementi;


int main(){

    //acquisizione input    
    cin >> num_elementi;
    for(int i=0;i<num_elementi;i++){
        int temp;
        cin >> temp;
        pi.push_back(temp);       
    }
    for(int i=0;i<num_elementi;i++){
        int temp;
        cin >> temp;
        sigma.push_back(temp);       
    }


    
    controlla();
    return 0;  
}


void controlla(){
    int i=0,j=0;
    int risultato=0;
    for(int i=0;i<num_elementi;i++){
        for(j=i+1;j<num_elementi;j++){
            if(pi[i]<pi[j] && sigma[i]>sigma[j])
                risultato++;
            else if(pi[i]>pi[j] && sigma[i]<sigma[j])
                    risultato++;
        }
    }

    cout<<risultato;

}
