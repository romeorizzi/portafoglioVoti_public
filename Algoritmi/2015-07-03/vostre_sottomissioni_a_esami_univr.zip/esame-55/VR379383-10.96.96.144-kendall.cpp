#include <stdio.h>
//#include <iostream> 
//  using namespace std;
int main(){


    int n=0;

    int sum=0;

    fscanf(stdin,"%d ",&n);

    int a1[n];
    int a2[n];

    for(int i=0;i<n;i++)
        fscanf(stdin,"%d",&a1[i]);

    for(int i=0;i<n;i++)
        fscanf(stdin,"%d",&a2[i]);

    int k1=0;   
    int k2=n-1;
    bool guardia=true;

//CASO OTTIMO E PESSIMO
/*****************************/
int i=0;
while(guardia==true && i<n){
    if(a1[i]!=a2[i])
        guardia=false;

    i++;
}
if(guardia==true){
    sum=0;
    fprintf(stdout,"%d",sum);
    return 0;
}
/*****************************/

guardia=true;

 while(guardia==true && (k1<=k2)){
        if(a1[k1]==a2[k2])
            guardia=true;
        else
            guardia=false;

        ++k1;
        --k2;
       
    }

    if(guardia==true){
        sum=(n*(n-1))/2;
         fprintf(stdout,"%d",sum);
        return 0;
    }


/*****************************/
//ALTRI CASI
    for(int i=0;i<n-1;i++){
        for(int j=i;j<n;j++){
            if((a1[i]<a1[j]) && (a2[i]>a2[j]))
                sum++;
            if((a1[i]>a1[j]) && (a2[i]<a2[j]))
                sum++;
            }
        }
    fprintf(stdout,"%d",sum);
    return 0;
}
