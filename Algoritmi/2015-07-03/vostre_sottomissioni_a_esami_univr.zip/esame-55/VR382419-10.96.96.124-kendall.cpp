#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;

const int MAX_N=1000000;
long int n;
int K;
int pi[MAX_N],ro[MAX_N];

int main()
{
    scanf("%ld",&n);
    for(int i=0;i<n;i++) scanf("%d",&pi[i]);
    for(int i=0;i<n;i++) scanf("%d",&ro[i]);
    /*ifstream in("input.txt");
    in>>n;
    for(int i=0;i<n;i++)
        in>>pi[i];
    for(int i=0;i<n;i++)
        in>>ro[i];*/

    /*std::cout<<"il numero è"<<n<<endl;
    for(int i=0;i<n;i++) cout<<pi[i]<<" ";
    cout<<endl;
    for(int i=0;i<n;i++) cout<<ro[i]<<" ";
    cout<<endl;*/
      K=0;
    for(int i=0;i<n;i++)
     { for(int j=n-1;j>i;j--)
       if(((pi[i]<pi[j])&&(ro[i]>ro[j]))||((pi[i]>pi[j])&&(ro[i]<ro[j])))
         { K++;
          }
     }
    if(K<(n*(n-1)/2)) printf("%d",K);


    return 0;
}
