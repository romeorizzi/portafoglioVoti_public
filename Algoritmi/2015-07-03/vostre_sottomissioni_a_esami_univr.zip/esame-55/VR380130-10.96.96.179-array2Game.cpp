#include <iostream>

using namespace std;

#define MAXN 1002

static int m,n,i,j;
static int scacchiera [MAXN][MAXN] ;
static  int vincitore = 2;


void verifica_strade(int i, int j, int player){

    if((i+j) == 2){ //cioè sono arrivato alla prima cella dove nn mi posso muoverre più
        //cout << "zero"<< endl;
        if(player == 2)
            vincitore = 1;
        return;
       }
    else{

        int max_spostamento_up = min(scacchiera[i][j],(i - 1));
       // cout << "max up "<< max_spostamento_up << endl;

        int max_spostamento_left = min(scacchiera[i][j],(j - 1));
        //cout <<"max left "<< max_spostamento_left << endl;

        player =  (player == 2 ? 1 :2);
        //cout << "player" << player << endl;

        //muovo verso alto il primo giocatore
        if (max_spostamento_up != 0){
          //  cout<< "scelto su"<<endl;
            verifica_strade(i - max_spostamento_up, j,player);

        }
        if (max_spostamento_left != 0){
            //cout<< "scelto sx"<<endl;
            verifica_strade(i,j - max_spostamento_left, player);
        }
    }
 }



int main(){
    //cout << "inserisci N: ";
    cin >> m >> n >> i >> j;
    //cout << "inserisci prima riga di " << N <<" elementi: ";
    for(int r=1; r<=m; r++)
        for(int c=1; c<=n; c++)
            cin >> scacchiera[r][c];


     verifica_strade(i,j,1);
     if(vincitore == 2)
         cout << "LOST" << endl;
     else
         cout << "WINNING STARTING POSITION" << endl;





  return 0;
}

