#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;
const int MAX_N=3000;
const int MAX_M=50;
int m,n,posi,posj,statoin;
int scac[MAX_M][MAX_N],pedina[MAX_M][MAX_N];
char res[]="WINNING STARTING POSITION";
char res1[]="LOST";

int max(int a,int b)
{
    if(a>b) return a;
    else return b;
}

/*void mossaoriz(int pi,int pj,int s)
{int temp;
  temp=max(1,j-scac[pi][pj]);
  (temp<J)
    for(int i=1;i<=m;i++)
      for(int j=1;j<=n;j++)
          pedina[pi][pj]=0;
          pedina[pi][temp]=1;
}*/
/*void mossavert(int pi,int pj,int s)
{int temp;
  temp=max(1,j-scac[pi][pj]);
  (temp<J)
    for(int i=1;i<=m;i++)
      for(int j=1;j<=n;j++)
          pedina[pi][pj]=0;
          pedina[temp][pj]=1;
}*/
int main()
{
    scanf("%d",&m);
    scanf("%d",&n); assert(n<=MAX_N);
    scanf("%d",&posi);
    scanf("%d",&posj);
    for(int i=1;i<=m;i++)
      for(int j=1;j<=n;j++)
       scanf("%d",&scac[i][j]);

 /*  ifstream in("input.txt");
   in>>m>>n>>posi>>posj;
   //cout<<m<<n<<posi<<posj<<endl;
    for(int i=1;i<=m;i++)
       for(int j=1;j<=n;j++)
       in>>scac[i][j];*/

  /*for(int i=1;i<=m;i++)
       for(int j=1;j<=n;j++)
     cout<<scac[i][j];
   cout<<endl;*/

    statoin=scac[posi][posj];
   //cout<<stato;

   for(int i=1;i<=m;i++)
      for(int j=1;j<=n;j++)
         pedina[posi][posj]=1;

   //prima mossa...

  // mossaorizz(posi,posj,scac[posi][posj])

   /*for(int i=1;i<=m;i++)
     for(int j=1;j<=n;j++)
      cout<<pedina[i][j];*/




   if((posi==1)&&(posj==1))  printf("%s\n",res1);
     else  printf("%s\n",res);

    return 0;
}

