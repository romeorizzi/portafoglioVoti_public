#include <stdio.h>
#include <stdlib.h>

void check(int x, int y, int limit, int **result){

    int i;

    //check for vertical
    for(i=1; i<=limit; i++){
        if(result[x-i][y] == -1)
            break;

        if(result[x-i][y] == 0){            //se trovo una mossa che porta l'avversario in posizione perdente ho vinto
            result[x][y] = 1;
            return;    
        }
    }

    //check for horizontal
    for(i=1; i<=limit; i++){
        if(result[x][y-i] == -1)
            break;

        if(result[x][y-i] == 0){
            result[x][y] = 1;
            return;    
        }
    }

    result[x][y] = 0;                       //se tutte le mosse portano l'avversario in una posizione vincente ho perso

}

int main(void){

    int x, y, n, m, i, j;

    scanf("%d %d %d %d\n", &n, &m, &x, &y);

    n++; //aggiusto per essere comodo con gli indici
    m++;

    int **scacchiera = (int **)malloc(n*sizeof(int *));
    int **result = (int **)malloc(n*sizeof(int *));

    for(i=0; i<n; i++){
        scacchiera[i] = (int *)malloc(m*sizeof(int));
        result[i] = (int *)malloc(m*sizeof(int));

    }
        

    for(i=1; i<n; i++)
        for(j=1; j<m; j++)
            scanf("%d", &scacchiera[i][j]);

   

    for(i=0; i<n; i++){             //già che ho un padding, lo rendo riconoscibile per usarlo come sentinella dell'imminente uscita dal bordo
        scacchiera[i][0] = -1;
        result[i][0] = -1;
    }

    for(i=0; i<m; i++){
        scacchiera[0][i] = -1;
        result[0][i] = -1;
    }

    result[1][1] = 0;               //La cella d'angolo è sempre perdente

    if(x == 1 && y ==1){
        printf("LOST\n");
        return;
    }
    int maxdim = (n>m)? n : m;

    for(i=2; i<maxdim; i++){    //i rappresenta la "distanza" dalla cella 1,1, calcolo i risultati a macchia d'olio dall'angolo per calcolare solo i risulati necessari 
                                //per avvicinarmi all'obiettivo

        for(j=1; j<i; j++){
            
            if(i>=m || j >= n)
                break;

            check(j,i, scacchiera[j][i], result);
            if(x == j && y == i){                                                           //fermo il calcolo dei risultati appena arrivo alla cella desiderata
                printf("%s", (result[x][y])? "WINNING STARTING POSITION\n" : "LOST\n");
                return;
            }

        }

        for(j=1; j<i; j++){

            if(i>=n || j >= m)
                break;

            check(i,j, scacchiera[i][j], result);
            if(x == i && y == j){                                                           //fermo il calcolo dei risultati appena arrivo alla cella desiderata
                printf("%s", (result[x][y])? "WINNING STARTING POSITION\n" : "LOST\n");
                return;
            }

        }

        if(i <=m-1 && i<= n-1){

        check(i,i, scacchiera[i][i], result);
        if(x == i && y == j){                                                               //fermo il calcolo dei risultati appena arrivo alla cella desiderata
                printf("%s", (result[x][y])? "WINNING STARTING POSITION\n" : "LOST\n");
                return;
            }
        }

    }


}
