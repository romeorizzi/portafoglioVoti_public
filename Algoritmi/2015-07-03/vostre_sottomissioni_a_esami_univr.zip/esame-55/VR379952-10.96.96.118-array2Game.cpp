#include <iostream>

using namespace std;






//int main()
//{

//    int righe,colonne,rigaIniziale,colonnaIniziale,i,j,z,valoreLetto,tmp=0,k=0;
//    int indiceVincentePiuVicinoColonna,indiceVincentePiuVicinoRiga;

//    cin >> righe;
//    cin >> colonne;
//    cin >> rigaIniziale;
//    cin >> colonnaIniziale;



//    int matrice[rigaIniziale][colonnaIniziale];
//    matrice[0][0]=-1;

//    indiceVincentePiuVicinoRiga=1;

//    colonnaIniziale--;
//    rigaIniziale--;


//    i=0;
//    cin >> valoreLetto;
//    for(j=1;j<colonnaIniziale;j++){
//        cin >> valoreLetto;
//        // controllo se sulla stessa riga riesco a raggiungere una casella P

//        if(valoreLetto>=indiceVincentePiuVicinoRiga){
//            matrice[i][j]=1;
//            indiceVincentePiuVicinoRiga++;
//        }else{
//            matrice[i][j]=-1;
//            indiceVincentePiuVicinoRiga=1;
//        }

//    }

//    for(k=0;k<colonne-colonnaIniziale+1;k++) cin >> valoreLetto;



//    int confronto=0;
//    int indiceConteggioColonne=0;
//    int indiceConteggioRighe=0;

//    for(i=1;i<rigaIniziale;i++){
//        for(j=0;j<colonnaIniziale;j++){


//            indiceConteggioColonne=0;
//            indiceConteggioRighe=0;

//            cin >> valoreLetto;

//            if(valoreLetto<=i)
//                indiceConteggioColonne=valoreLetto;
//            else
//                indiceConteggioColonne=i;

//            if(valoreLetto<=j)
//                indiceConteggioRighe=valoreLetto;
//            else
//                indiceConteggioRighe=j;

//            tmp=0;

//            for(z=1;z<indiceConteggioColonne+1;z++) {
//                tmp+=matrice[i-z][j];
//            }


//            if(tmp<indiceConteggioColonne) {
//                matrice[i][j]=1;
//            }else {
//                matrice[i][j]=-1;
//            }

//            if(j==0) continue;

//            tmp=0;

//            for(z=1;z<indiceConteggioRighe+1;z++) {
//                tmp+=matrice[i][j-z];
//            }

//            if(tmp<indiceConteggioRighe) {
//                matrice[i][j]=1;
//            }

//        }
//        for(k=0;k<colonne-colonnaIniziale+1;k++) cin >> valoreLetto;

//    }

//    for(k=0;k<colonne*(righe-rigaIniziale);k++) cin >> valoreLetto;



//    if(matrice[rigaIniziale][colonnaIniziale]==1)
//        cout << "WINNING STARTING POSITION" << endl;
//    else
//        cout << "LOST" << endl;

//    return 0;
//}


























int main()
{

    int righe,colonne,rigaIniziale,colonnaIniziale,i,j,z,valoreLetto,tmp=0;
    int indiceVincentePiuVicinoColonna,indiceVincentePiuVicinoRiga;

    cin >> righe;
    cin >> colonne;
    cin >> rigaIniziale;
    cin >> colonnaIniziale;

    int matrice[righe][colonne];
    matrice[0][0]=-1;

    indiceVincentePiuVicinoRiga=1;

    colonnaIniziale--;
    rigaIniziale--;


    i=0;
    cin >> valoreLetto;
    for(j=1;j<colonne;j++){
        cin >> valoreLetto;
        // controllo se sulla stessa riga riesco a raggiungere una casella P

        if(valoreLetto>=indiceVincentePiuVicinoRiga){
            matrice[i][j]=1;
            indiceVincentePiuVicinoRiga++;
        }else{
            matrice[i][j]=-1;
            indiceVincentePiuVicinoRiga=1;
        }

    }


    int confronto=0;
    int indiceConteggioColonne=0;
    int indiceConteggioRighe=0;

    for(i=1;i<righe;i++){
        for(j=0;j<colonne;j++){


            indiceConteggioColonne=0;
            indiceConteggioRighe=0;

            cin >> valoreLetto;

            if(valoreLetto<=i)
                indiceConteggioColonne=valoreLetto;
            else
                indiceConteggioColonne=i;

            if(valoreLetto<=j)
                indiceConteggioRighe=valoreLetto;
            else
                indiceConteggioRighe=j;

            tmp=0;

            for(z=1;z<indiceConteggioColonne+1;z++) {
                tmp+=matrice[i-z][j];
            }


            if(tmp<indiceConteggioColonne) {
                matrice[i][j]=1;
            }else {
                matrice[i][j]=-1;
            }

            if(j==0) continue;

            tmp=0;

            for(z=1;z<indiceConteggioRighe+1;z++) {
                tmp+=matrice[i][j-z];
            }

            if(tmp<indiceConteggioRighe) {
                matrice[i][j]=1;
            }

        }
    }



    if(matrice[rigaIniziale][colonnaIniziale]==1)
        cout << "WINNING STARTING POSITION" << endl;
    else
        cout << "LOST" << endl;

    return 0;
}







//    for(i=0;i<righe;i++){
//        cout << endl;
//        for(j=0;j<colonne;j++){
//           cout <<  matrice[i][j] << " | ";
//        }

//    }
//cout << endl;
