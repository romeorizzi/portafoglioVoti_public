#include<stdio.h>
#include<stdlib.h>
#include<assert.h>

#define MAXN 1000000

int n, kend=0;
int pi[MAXN], si[MAXN];

void kendall()
{
    int i,j;
    assert(fscanf(stdin,"%d",&n));
    for(i=0;i<n;i++)
    {
        assert(fscanf(stdin,"%d",&pi[i]));
    }
    for(j=0;j<n;j++)
    {
        assert(fscanf(stdin,"%d",&si[j]));
        if(j>0)
        {
            for(i=j-1;i>=0;i--)
            {
                if((pi[i]<pi[j] && si[i]>si[j]) || (pi[i]>pi[j] && si[i]<si[j])) kend++;
            }
        }
    }
}

int main()
{
    kendall();
    fprintf(stdout,"%d",kend);
    return 0;
}
