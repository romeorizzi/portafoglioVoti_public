#include <stdio.h>

int main(void){

    int n, j, i;
    int count = 0;

    scanf("%d\n", &n);
    
    int pi[n];
    int sigma[n];

    for(i=0; i<n; i++)
        scanf("%d", &pi[i]);

    for(i=0; i<n; i++)
        scanf("%d", &sigma[i]);
    

    //soluzione nel caso in cui sigma è l'identità    
    for(i=0; i<n; i++)
       
        for(j=1; j <= i; j++)

            if(pi[i-j] > pi[i])
                count++;


    
    printf("%d\n", count);


return 0;

}
