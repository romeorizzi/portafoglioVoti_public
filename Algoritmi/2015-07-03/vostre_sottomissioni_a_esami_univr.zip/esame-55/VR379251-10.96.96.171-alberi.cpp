void visita(int N, int *PRE, int *POST, int *SIMM )
{
    //dichiarazione variabili
    int i=0,sx_le=0,dx_le=0;;
    int sx_k,dx_k,mem;
   
    //controllo il caso base cioe lunghezza del albero uguale a uno
    //quindi ho solo il nodo radice e di conseguenza il la visita simettica corrisponde alle altre due visite
    if(N==1){ *SIMM=*PRE; return ;}
    //primo elemento della post visita corriaponde al primo della simmettrica    
    mem=*(PRE);    
    //il figlio sinistro del nodo radice del albero corrisponde al secondo nodo della previsita
    sx_k=*(++PRE);
    //il figlio desto del nodo radice del albero corrisponde al penultimo elemento della postvisita
    dx_k=POST[N-1];
    //ciclo for che mi aiuto a calcolare le dimensioni dei sottoalberi sinistro e destro che passero in input alla chiamata ricorsiva 
    for(i=0;i<N;++i)
    {
       if(POST[N-i-2]==sx_k) { dx_le=i; sx_le=N-i-1; }  
       if(PRE[i]==dx_k) { sx_le=i; dx_le=N-i-1;}
        
    }
    //salvo ad ogni ricorsione il promo elemento della previsita al interno della visita simettrica 
    SIMM[sx_le]=mem;
    //chiamata ricorsiva sul sottoalbero sinistro
    visita(sx_le,PRE,POST,SIMM);
    //chiamata ricorsiva sul sottoalbero destro 
    visita(dx_le,&(PRE[sx_le]),&(POST[sx_le]),&(SIMM[sx_le+1]));
}
