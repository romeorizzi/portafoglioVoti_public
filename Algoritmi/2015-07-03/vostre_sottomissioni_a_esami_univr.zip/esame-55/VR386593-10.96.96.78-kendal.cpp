#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#define PRINT 1

int main(int argc, char* argv[]){

    
    int n;
    int* one;
    int* two;
    
    scanf("%d",&n);
    
    one = new int[n];
    two = new int[n];
    
    for(int i = 0; i < n; i++){
        scanf("%d",&one[i]);
    }
    for(int i = 0; i < n; i++){
        scanf("%d",&two[i]);
    }
    
    int count = 0;
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            if( ((one[i] < one[j]) && (two[i] > two[j])) || ((one[i] > one[j]) && (two[i] < two[j])) ){
                count++;
            }
        }
    }

    printf("%d",count);

    return 0;
}
