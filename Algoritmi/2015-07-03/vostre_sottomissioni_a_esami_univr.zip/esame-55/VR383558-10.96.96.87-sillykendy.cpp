
#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

long n,tmp;
long SIG[1000000], PIE[1000000];
int K;
int main() {
  cin >> n;
  K=0;
  for(int i=0;i<n;i++){
    cin >> tmp;
    SIG[i] = tmp;
  }
  for(int j=0;j<n;j++){
    cin >> tmp;
    PIE[j] = tmp;
  }
  for(int i=n-1;i>=0;i--){
    for(int j=0;j<i;j++){
      if((SIG[i] < SIG[j] && PIE[i] > PIE[j] ) || ( SIG[i] > SIG[j] && PIE[i] < PIE[j] )){
       ++K;
      }
    }
  }
  cout << K << "\n";
  return 0;
}
