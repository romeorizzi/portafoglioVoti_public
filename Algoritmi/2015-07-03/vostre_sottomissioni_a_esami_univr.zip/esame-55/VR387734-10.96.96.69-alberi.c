void visita(int N, int *PRE, int *POST, int *SIMM )
{
    // indice della prima posizione da riempire
    int indexSimm = 0;
    // array delle marcature (i nodi partono da 1)
    int marcato[N+1];

    // imposto le marcature di tutti i nodi a 0
    int i;
	for(i=0; i<=N; ++i){
        marcato[i] = 0;
    }
    
    // riempio l'array SIMM cercando uno alla volta i nodi di
    // POST in PRE, una volta trovato inserisco tale nodo in SIMM
    // se non e' marcato, e lo stesso per il nodo che occupa la
    // posizione precedente nell'array PRE
    int j;
    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            if(POST[i] == PRE[j]){
                if(marcato[ PRE[j] ] == 0){
                    SIMM[indexSimm] = PRE[j];
                    marcato[ PRE[j] ] = 1;
                    indexSimm = indexSimm+1;
                }
                
                if(marcato[ PRE[j-1] ] == 0){
                    SIMM[indexSimm] = PRE[j-1];
                    marcato[ PRE[j-1] ] = 1;
                    indexSimm = indexSimm+1;
                }
                
                break;
            }
        }
    }
}
