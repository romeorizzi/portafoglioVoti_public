int shift = 1;
int loshift = 0;
int index = 0;

void visitaSimm(int *PRE, int *POST, int *SIMM, int daPost, int aPost) {
    int demarcaz = shift;
    shift++;
    int n = PRE[demarcaz];
    int pos = posizioneInPostvisitaDi(POST, n);
    
    if(pos == loshift) {
        SIMM[index++] = POST[pos];
        loshift++;
        return;
    }
    
    visitaSimm(PRE, POST, SIMM, daPost, pos - 1);
    SIMM[index++] = POST[pos];
    visitaSimm(PRE, POST, SIMM, pos + 1, aPost);
}

int posizioneInPrevisitaDi(int *PRE, int nodo) {
    int i=0;
    while(PRE[i] != nodo)
        i++;
    return i;
}

int posizioneInPostvisitaDi(int *POST, int nodo) {
    int i =0;
    while(POST[i] != nodo)
        i++;
    return i;
}

void visita(int N, int *PRE, int *POST, int *SIMM )
{
   
    visitaSimm(PRE, POST, SIMM, 0, N-1);

/*
    int i ;
	for( i = 0 ; i < N ; i++ ) SIMM[i] = i ;*/
}
