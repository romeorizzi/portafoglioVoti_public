#include <stdio.h>
#include <stdlib.h>

using namespace std;

int main(int argc, char** argv)
{
	int m, n, s_i, s_j;
    int i,j,z;
    
    FILE* f= fopen("input.txt", "r");
    fscanf(f,"%d %d %d %d\n", &m, &n, &s_i, &s_j);
    
    bool victory[m][n];
    
    for(i=0; i<m; i++)
    {
    	for(j=0; j<n; j++)
    	{
   			short win = false;
   			int limit;
   			fscanf(f,"%d", &limit);
   			if(i>0)
   			{
   				int moves = 0;
   				for(z=i-1; z>=0; z--)
   				{
   					if(!victory[z][j])
   					{
   						win = true;
   						break;
   					}
   					if(++moves == limit)
   						break;
   				}
   			}
   			if(!win && j>0)
   			{
   				int moves = 0;
   				for(z=j-1; z>=0; z--)
   				{
   					if(!victory[i][z])
   					{
   						win = true;
   						break;
   					}
   					if(++moves == limit)
   						break;
   				}
   			}
   			victory[i][j] = (win) ? true : false;
       	}
    }
    
    fclose(f);
    f = fopen("output.txt", "w");
    fprintf(f, "%s\n", (victory[s_i-1][s_j-1]) ? "WINNING STARTING POSITION" : "LOST");
    return 0;
}
