#include<cstdio>
#include <vector>
#include <iostream>

using namespace std;

int posizione_x, posizione_y;
int num_righe,num_colonne;

vector <vector <int>> matrice;
vector <vector <string>> matrice_vittorie;

void popola();
string calcola(int i,int j);

int main(){

    //acquisizione input    
    cin >> num_righe;
    cin >> num_colonne;
    cin >> posizione_x;
    cin >> posizione_y;
    for(int i=0;i<num_righe;i++){
        vector<int> riga;       
        for(int j=0;j<num_colonne;j++){
            int temp;
            cin >> temp;
            riga.push_back(temp);
        }
        matrice.push_back(riga);       
   }

    
    
    popola();
    
    if(matrice_vittorie[posizione_x-1][posizione_y-1]=="P")
        cout<<"LOST";
    else    
        cout<<"WINNING STARTING POSITION";
    return 0;  
}

void popola(){
    
    for(int i=0;i<posizione_x;i++){ //vado solo in su
        
        vector <string> riga;
        for(int j=0;j<posizione_y;j++){ //vodo solo a sx
                   
           if(j==0 && i==0){
                riga.push_back("P");
                matrice_vittorie.push_back(riga);

            }
            else if(j==1 && i==0){
                riga.push_back("V");
                matrice_vittorie[i].push_back("V");

            }
            else{
                    
                    matrice_vittorie.push_back(riga);
                    string temp=calcola(i,j);
                    riga.push_back(temp);
                    matrice_vittorie[i].push_back(temp);
                }
        }
    }
}

string calcola(int i, int j){
    int valore=matrice[i][j];
    int pos_x=i;
    int pos_j=j;
    bool notFine=true;
    while(notFine){
        pos_x--;
        pos_j--;
        if(pos_x>=0){
            if(matrice_vittorie[pos_x][j]=="P")
                return "V";
        }
        if(pos_j>=0){
            if(matrice_vittorie[i][pos_j]=="P")
                return "V";
        }
        valore--;
        if(valore==0)
            notFine=false;
    }
    return "P";
}











