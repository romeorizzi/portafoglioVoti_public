#include <stdio.h>

int main(){

    int kendall=0;
    
    int N;
    int i, j;

    scanf("%d", &N);

    int pi[N];
    int sigma[N];

    for(i=0; i<N; i++){
        scanf("%d", &pi[i]);
    }

    for(j=0; j<N; j++){
        scanf("%d", &sigma[j]);
    }



    for(i=0; i<N; i++){
        for(j=i+1; j<N; j++){

            if((pi[i]<pi[j] && sigma[i]>sigma[j]) || (pi[i]>pi[j] && sigma[i]<sigma[j]))
                kendall++;
        }
    }


    printf("%d\n", kendall);

    return 0;
}
