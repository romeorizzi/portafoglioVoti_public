
void visita(int N, int *PRE, int *POST, int *SIMM ){


    int result[N];
    int p1[N];
    int p2[N];

    for(int i=0;i<N;i++){
        result[i]=0;
        p1[i]=PRE[i];        
        p2[i]=POST[i];
    }


int k=0;
int tmp=0;
int i=0;
int pos=-1;
    while(i<N){
        pos=-1;
        if(p2[i]!=0){
            result[k]=p2[i];
            k=k+1;
            for(int j=0;j<N;j++){
                
                if(p1[j]==p2[i]){
                    result[k]=tmp;
                    pos=k;                    
                    k=k+1;
                    p1[j]=0;
                    break;
                }
                
                if(p1[j]!=0){
                    tmp=p1[j];
                }
            }
            

            for(int a=0;a<N;a++)
                if(p1[a]==result[pos])
                    p1[a]=0;
            for(int a=0;a<N;a++)
                if(p2[a]==result[pos])
                    p2[a]=0;
            p2[i]=0;
        }
        
        i++;
    }

    for(int i=0;i<N;i++)
        SIMM[i]=result[i];

}
