#include <stdio.h>

int main(){
    
    int N,M; //dimensioni array
    int a,b; // posizione iniziale
    int i, j, h;

    int win=0;

    scanf("%d %d %d %d", &N, &M, &a, &b);

    int s[M][N]; //a b
    int w[M][N]; //a b

    for(i=0; i<M; i++){ //a
        for(j=0; j<N; j++){ //b
            scanf("%d", &s[i][j]);
            w[i][j]=0;

            //if(i==0 && j==0) break;
            if(i==0 && j!=0){ // posso andare solo in orizzontale
                int m;
                //j<s[i][j]? m=j : m=s[i][j];
                if(j<s[i][j]) m=j;
                else m=s[i][j];

                for(h=1; h<=m; h++){
                    if(w[i][j-h]==0) {w[i][j]=1; break;} 
                }
            }
            if(i!=0 && j==0){ // posso andare solo in verticale
                int m;
                //i<s[i][j]? m=i : m=s[i][j];
                if(i<s[i][j]) m=i;
                else m=s[i][j];

                for(h=1; h<=m; h++){
                    if(w[i-h][j]==0) {w[i][j]=1; break;} 
                }
            }

            if(i!=0 && j!=0){ // posso andare in orizz e in vert
                int mi,mj;
                //i<s[i][j]? mi=i : mi=s[i][j];
                //j<s[i][j]? mj=j : mj=s[i][j];
                if(j<s[i][j]) mj=j;
                else mj=s[i][j];

                if(i<s[i][j]) mi=i;
                else mi=s[i][j];

                for(h=1; h<=mi; h++){
                    if(w[i-h][j]==0) {w[i][j]=1; break;}
                }

                for(h=1; h<=mj; h++){
                    if(w[i][j-h]==0) {w[i][j]=1; break;} 
                }
            }





        }
    }


    w[a-1][b-1]==0? printf("LOST\n") : printf("WINNING STARTING POSITION\n");

    return 0;
}
