#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;
int N;
int M;
int startX;
int startY;

int main(){
    ifstream input("input.txt");
    input >> M >> N >> startX >> startY;
    int board[M][N];
    bool winner[M][N];
    winner[0][0] = false;
    //if i can reach this, it's a position of victory for me
    //to win you just need to reach one lost position (from p2's perspective?)
    //to lose you have to reach 2 win positions
    
    for(int i = 0;i < M;i++)
        for(int j = 0;j< N;j++)
            winner[i][j] = false;
            
    for(int i = 0;i < M;i++)
        for(int j = 0;j< N;j++)
            cout << winner[i][j];
    
    for(int i = 0;i < M;i++){
        for(int j = 0;j< N;j++){
            input >> board[i][j];
            if(i != 0){//vertical? control
                if(i-board[i][j] >= 0){
                    cout << "i = " << i << " j = " << j << " winner[i-board[i][j]] = " << winner[i-board[i][j]] << " i-board[i][j]  = " << (i-board[i][j]) << endl;
                    winner[i][j] |= !winner[i-board[i][j]];
                    cout << "then winner["<<i<<"]["<<j<<"] = " << winner[i][j] << endl;
                }
                else{
                    winner[i][j] |= !winner[0][j];
                }
            }
            if(j != 0){//lateral? control
            cout << "j = " << j << " board["<<i<<"]["<<j<<"] = "<<board[i][j] <<endl;
                if(j - board[i][j] >= 0){
                    cout << "winner["<<i<<"]["<<(j- board[i][j])<<"] = " << winner[i][j - board[i][j]] << endl;
                    winner[i][j] |= !winner[i][j - board[i][j]];      
                }
                else{
                    cout << "j = " << j << " i = " << i << endl;
                    winner[i][j] |= !winner[i][0];                
                }
            }
        }    
    }
    
    for(int i = 0;i < M;i++){
        for(int j = 0;j< N;j++)
            cout << winner[i][j] << " ";
        cout << endl;
    }
    
    
    ofstream output("output.txt");
    output << ((winner[startX-1][startY-1])?"WINNING STARTING POSITION":"LOST");
    return 0;
}
