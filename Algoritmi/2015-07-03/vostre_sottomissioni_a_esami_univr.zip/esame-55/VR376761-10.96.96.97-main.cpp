#include <iostream>
#include <vector>

int N;

using namespace std;

#define lsb(x) (x & (-x))

struct ft_t
{
    int N;
    vector<int> conteggio;

    ft_t(int n): N(n), conteggio(n+1){ }

    int sum(int k) const {
        int ans = 0;
        for(++k; k!=0; k-=lsb(k))
            ans += conteggio[k];
        return ans;

    }

    int sum(int a, int b) const{
        return sum(b) - sum(a - 1);
    }

    int quanti_maggiori(int k){
        return sum(k,N);
    }

    void update(int k, int delta){
        for(++k; k<=N; k+=lsb(k))
            conteggio[k] += delta ;
    }

    void aggiungi_inversioni(int k){
        update(k, 1);
    }

};

int main()
{
    cin>>N;
    int pi[N];
    int sigma[N];
    int distanza = 0;
    /*int distanza1 = 0;
    int distanza2 = N;
    ft_t pi_ft(N);
    ft_t sigma_ft(N);*/
    for(int i=0; i<N; i++)
    {
        cin >> pi[i];
        /*distanza1 += pi_ft.quanti_maggiori(pi[i]);
        pi_ft.aggiungi_inversioni(pi[i]);*/
    }

    for(int i=0; i<N; i++)
    {
        cin >> sigma[i];

        /*distanza2 -= sigma_ft.quanti_maggiori(sigma[i]);
        sigma_ft.aggiungi_inversioni(sigma[i]);*/

    }

   for(int i=0; i<N-1; i++)
       for(int j=i+1; j<N; j++)
        {
            if((pi[i]<pi[j] && sigma[i]>sigma[j]) || (pi[i]>pi[j] && sigma[i]<sigma[j]))
                distanza++;
         }





    cout << distanza << endl;

    return 0;
}

