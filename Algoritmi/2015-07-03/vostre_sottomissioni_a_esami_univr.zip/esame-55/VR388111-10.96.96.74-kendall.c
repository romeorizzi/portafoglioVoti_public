#include <stdio.h>
#include <stdlib.h>

int main()
{
    int N, i, j;
    
    FILE* f= fopen("input.txt", "r");
    fscanf(f,"%d\n", &N);
    
    //Se N == 0, ritorno 0
    
    int p[N];
    int s[N];

    for(i=0; i<N; i++)
    {
       	fscanf(f,"%d", &p[i]);
    }
    
    for(i=0; i<N; i++)
    {
       	fscanf(f,"%d", &s[i]);
    }
    
    fclose(f);
    
    int kendall = 0;
    
    for(i=0; i<N-1; i++)
    {
    	for(j=i+1; j<N; j++)
    	{
    		if((p[i] < p[j] && s[i] > s[j]) || (p[i] > p[j] && s[i] < s[j]))
    			++kendall;
    	}
    }
    
    f = fopen("output.txt", "w");
    fprintf(f, "%d\n", kendall);
    
    return 0;
}
