#include <stdio.h>
#include <assert.h>

//int marcatura[3000][3000];
//int mosse[3000][3000];

int main(){
    int m, n, posInizI, posInizJ;
    scanf("%d %d %d %d", &m, &n, &posInizI, &posInizJ);
    // assert
    
    
    int marcatura[m][n];
    int mosse[m][n];
    
    int i, j;
    for(i=0; i<m; i++){
        for(j=0; j<n; j++){
            scanf("%d", &mosse[i][j]);
        }
    }
    
    for(i=0; i<m; i++){
        for(j=0; j<n; j++){
            marcatura[i][j] = 0;
        }
    }
    
    // codifico la posizione iniziale allora come arrivo per le mie marcature
    int arrivoM = posInizI-1;
    int arrivoN = posInizJ-1;
    
    // marco come perdente la posizione finale, quindi a ritroso 
    // chi riesce a raggiungere tale posizione si trova in una
    // posizione vincente
    
    // se riesco a raggiungere almeno una marcatura perdente, sono in una posizione vincente
    
    // se posso raggiungere solo posizioni marcate come vincenti, mi trovo in una posizione perdente
    
    // marco come perdente la posizione finale
    marcatura[0][0] = -1;
    
    for(i=0; i<m; i++){
        for(j=0; j<n; j++){
            if(i==0 && j==0){
                continue;
            }
            
            int k;
            for(k=1; k<=mosse[i][j]; k++){
                if(i-k>0 && marcatura[i-k][j] == -1)
                    marcatura[i][j] = 1;
                    
                if(j-k>0 && marcatura[i][j-k] == -1)
                    marcatura[i][j] = 1;
            }
            
            if(marcatura[i][j] == 0){
                marcatura[i][j] = -1;
            }
        }
    }
    
    if(marcatura[arrivoM][arrivoN] == 1)
        printf("WINNING STARTING POSITION\n");
    else if (marcatura[arrivoM][arrivoN] == -1)
        printf("LOST\n");
    else printf("errore! arrivo=(%d, %d), marcatura=%d\n", arrivoM, arrivoN, marcatura[arrivoM][arrivoN]);

    return 0;
}
