#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

int N;
int result = 0;

int main(){
    ifstream input("input.txt");
    input >> N;
    int first[N];
    int second[N];
    bool check = false;
    
    for(int i = 0;i < N;i++)
        input >> first[i];
        
    for(int i = 0;i < N;i++){
        input >> second[i];
        if(!check && second[i] != first[i])
            check = true;
    }
    
    if(!check){
        ofstream output("output.txt");
        output << 0;
        return 0;    
    }
    
    for(int i = 0;i < N;i++){
        for(int j = i + 1;j < N;j++){
            if(((first[i] < first[j]) && (second[i] > second[j])) || (( first[i] > first[j]) && (second[i] < second[j])))
                result++;        
        }
    }    
    
    ofstream output("output.txt");
    output << result;
    
    return 0;
}
