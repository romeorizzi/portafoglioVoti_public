#include <iostream>  // uso di cin e cout non consentito in versione finale

using namespace std;


class scacchiera{
public:
    int mosse;
    scacchiera *sottoalbero_sx;
    scacchiera *sottoalbero_dx;

    //visita sinistra
    scacchiera *mossa_up(){
        return sottoalbero_sx;
    }

    //visita destra
    scacchiera *mossa_sx(){
        return sottoalbero_dx;
    }
};


void crea_nuova_scacchiera(scacchiera *sc, int **mosse, int sx, int dx)
{
    sc->mosse = mosse[sx][dx];

    if(sx == 0 && dx == 0)
        return;

    if(sx == 0)
    {
        sc->sottoalbero_dx = new scacchiera;
        return crea_nuova_scacchiera(sc, mosse, 0, dx-1);
    }
    else if(dx == 0)
    {
        sc->sottoalbero_sx = new scacchiera;
        return crea_nuova_scacchiera(sc, mosse, sx-1, 0);
    }
    else
    {
        sc->sottoalbero_dx = new scacchiera;
        sc->sottoalbero_sx = new scacchiera;
        return crea_nuova_scacchiera(sc, mosse, sx-1, dx-1);
    }
}

bool vedi_se_vinci(scacchiera *sc, bool sto_muovendo_io)
{

    if(sc->sottoalbero_dx == nullptr && sc->sottoalbero_sx == nullptr)
        return !sto_muovendo_io;

    else
    {
        //posso muovere solo su
        if(sc->sottoalbero_dx == nullptr)
        {
            bool res = false;
            while(sc->mosse-- > 1)
            {
                res |= vedi_se_vinci(sc->mossa_up(), !sto_muovendo_io);
                sc = sc->mossa_up();
            }
            return res || vedi_se_vinci(sc->mossa_up(), !sto_muovendo_io);
        }
        //posso muovere solo a sinistra
        else if(sc->sottoalbero_sx == nullptr)
        {
            bool res = false;
            while(sc->mosse-- > 1)
            {
                res |= vedi_se_vinci(sc->mossa_sx(), !sto_muovendo_io);
                sc = sc->mossa_sx();
            }
            return res || vedi_se_vinci(sc->mossa_sx(), !sto_muovendo_io);
        }

        else
        {
            bool res = false;
            while(sc->mosse-- > 1)
            {
                res |= vedi_se_vinci(sc->mossa_up(), !sto_muovendo_io);
                sc = sc->mossa_up();
                res |= vedi_se_vinci(sc->mossa_sx(), !sto_muovendo_io);
                sc = sc->mossa_sx();
            }
            return res || vedi_se_vinci(sc->mossa_sx(), !sto_muovendo_io) && vedi_se_vinci(sc->mossa_up(), !sto_muovendo_io);
        }
    }


}

int main(void)
{
    //    1 7 1 2

    int num_sottoalberi_sx;
    int num_sottoalberi_dx;

    cin >> num_sottoalberi_sx;
    cin >> num_sottoalberi_dx;

    int pos_sx;
    int pos_dx;

    cin >> pos_sx;
    cin >> pos_dx;

    --pos_sx;
    --pos_dx;

    // 2 2 2 2 2 2 2
    int **mosse = new int*[num_sottoalberi_dx + 2];
    for(int i = 0; i < num_sottoalberi_dx + 2; i++)
        *mosse = new int[num_sottoalberi_sx + 2];


    for(int i = 0; i < num_sottoalberi_dx; i++)
        for(int j = 0; j < num_sottoalberi_sx; j++ )
        {
            cout << i << " " << j << endl;
            cin >> mosse[num_sottoalberi_dx - 1 - i][ num_sottoalberi_sx - 1 - j];
            cout << i << " " << j << endl;
        }

    scacchiera *game;
    game = new scacchiera;

    crea_nuova_scacchiera(game, mosse, pos_sx, pos_dx);

    bool win = vedi_se_vinci(game, true);

    //posiziono la pedina

    if(win)
        cout << "WINNING STARTING POSITION" << endl;
    else
        cout << "LOST" << endl;

    return 0;
}
