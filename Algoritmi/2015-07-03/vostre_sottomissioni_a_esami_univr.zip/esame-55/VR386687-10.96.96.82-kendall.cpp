#include <iostream>  // uso di cin e cout non consentito in versione finale

using namespace std;

int main(void)
{

    int lenght;
    bool is_crescente = false;

    cin >> lenght;

    int *phi = new int[lenght];
    int *sigma = new int[lenght];

    for(int i = 0; i < lenght; i++)
    {

         cin >> phi[i];
    }

    for(int i = 0; i < lenght; i++)
    {
        cin >> sigma[i];
    }

    int result = 0;

    for(int i = 0; i < lenght; i += 2)
        if((phi[i] < phi[i+1] && sigma[i] > sigma[i+1])||(phi[i] > phi[i+1] && sigma[i] < sigma[i+1]))
            is_crescente = true;
        else
        {
            is_crescente = false;
            break;
        }


    if(is_crescente)
        result = lenght;
    else
        for(int i = 0; i < lenght; ++i)
            for(int j = i; j < lenght; ++j)
                if((phi[i] < phi[j] && sigma[i] > sigma[j])||(phi[i] > phi[j] && sigma[i] < sigma[j]))
                    result++;


    cout << result <<endl;
}
