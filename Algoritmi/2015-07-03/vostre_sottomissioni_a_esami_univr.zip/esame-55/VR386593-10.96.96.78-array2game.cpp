#include <iostream>
#include <stdio.h>
#include <stdlib.h>

//#define PRINT 1

#ifdef PRINT
void print_field(int m,int n, int **field ){
    for(int k = 0; k < m; k++){
        for(int q = 0; q < n; q++){
           std::cout << field[k][q] << " ";
        }
        std::cout << std::endl;
    }
}
#endif

bool Game(int i,int j, int turn,int m,int n,int** field,int **mem){

    if(i == 0 && j == 0 && ( turn%2 == 1 ) ){
        return true;
    }
    
    if(mem[i][j] != -1 && turn % 2 == 0)
        return mem[i][j] == 0 ? false : true;
    
    if(turn % 2 == 1){
        bool ok = true;
        for(int s = 1; s <= field[i][j]; s++){
            if((i-s) >= 0){
                ok = Game(i-s,j,turn+1,m,n,field,mem) && ok;
            }
            if((j-s) >= 0){
                ok = Game(i,j-s,turn+1,m,n,field,mem) && ok;
            }
        }

        return ok;
    }
        
        
    for(int s = 1; s <= field[i][j]; s++){
        if((i-s) >= 0){
            if( Game(i-s,j,turn+1,m,n,field,mem) ){
                mem[i][j] = 1;
                return true; 
            }
        }
        if((j-s) >= 0){
            if( Game(i,j-s,turn+1,m,n,field,mem) ){
                mem[i][j] = 1;
                return true;
            }
        }
    }
    
    mem[i][j] = 0;
    return false;

}

int main(int argc, char* argv[]){

    int m,n,i,j;
    int **field;
    int **mem;

    scanf("%d %d %d %d",&m,&n,&i,&j);
    
    mem = new int*[m];
    field = new int*[m];
    for(int k = 0; k < m; k++){
        field[k] = new int[n];
        mem[k] = new int[n];
        for(int q = 0; q < n; q++){
            scanf("%d",&field[k][q]);
            mem[k][q] = -1;
        }
    }
    
#ifdef PRINT
    std::cout << std::endl;
    print_field(m,n,field);
#endif 
    
    i--;
    j--;

    bool ok = Game(i,j,0,m,n,field,mem);
    
    if(ok)
        std::cout << "WINNING STARTING POSITION";
    else
        std::cout << "LOST";

    return 0;
}
