#include <iostream>
#include <stdio.h>
#include <stdlib.h>

//#define PRINT 1


#ifdef PRINT
void print_field(int m,int n, int **field ){
    for(int k = 0; k < m; k++){
        for(int q = 0; q < n; q++){
           std::cout << field[k][q] << " ";
        }
        std::cout << std::endl;
    }
}
#endif

bool Game(int i,int j, int turn,int m,int n,int** field){

    if(i == 0 && j == 0 && ( turn%2 == 1 ) ){
        return true;
    } 
    
    for(int s = 1; s <= field[i][j]; s++){
        if((i-s) >= 0){
            if( Game(i-s,j,turn+1,m,n,field) )
                return true; 
        }
        if((j-s) >= 0){
            if( Game(i,j-s,turn+1,m,n,field) )
                return true;
        }
    }
    
    return false;

}

int main(int argc, char* argv[]){

    int m,n,i,j;
    int **field;

    scanf("%d %d %d %d",&m,&n,&i,&j);
    
    field = new int*[m];
    for(int k = 0; k < m; k++){
        field[k] = new int[n];
        for(int q = 0; q < n; q++){
            scanf("%d",&field[k][q]);
        }
    }
    
#ifdef PRINT
    std::cout << std::endl;
    print_field(m,n,field);
#endif 
    
    i--;
    j--;

    bool ok = Game(i,j,0,m,n,field);
    
    if(ok)
        std::cout << "WINNING STARTING POSITION";
    else
        std::cout << "LOST";

    return 0;
}
