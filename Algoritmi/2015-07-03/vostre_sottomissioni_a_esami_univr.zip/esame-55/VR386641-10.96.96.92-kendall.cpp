#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main(int argc, char *argv[]) {

    int n=0;
	vector <int> Pi;
    vector <int> Si;
    int KendalTauDistance = 0;

    int input = scanf("%d", &n);

    Pi.assign(n,0);
    Si.assign(n,0);

	for (int i = 0; i < n; i++) {
	     input = scanf("%d", &Pi[i]);
    }

	for (int i = 0; i < n; i++) {
        input = scanf("%d", &Si[i]);
    }

    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++)
            if(((Pi[i]<Pi[j])&&(Si[i]>Si[j])) || ((Pi[i]>Pi[j])&&(Si[i]<Si[j])))
                KendalTauDistance ++;    
    }

    printf("%d\n", KendalTauDistance);
	return 0;
}

