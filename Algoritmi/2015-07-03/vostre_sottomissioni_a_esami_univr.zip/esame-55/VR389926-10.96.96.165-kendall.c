#include <stdio.h>

#define INPUT_FILE "input.txt"
#define OUTPUT_FILE "output.txt"

#define MAX_N 1000000

static unsigned int i,j;
static unsigned int n;
static int sum;

int main(){

    FILE *fp_in, *fp_out;
    int array1[MAX_N], array2[MAX_N];

    if(fopen(INPUT_FILE, "r"))
        fp_in = fopen(INPUT_FILE, "r");

    if(fopen(OUTPUT_FILE, "w+"))
        fp_out = fopen(OUTPUT_FILE, "w+");

   // printf("ciao\n");

    fscanf(fp_in, "%d\n", &n);

    //printf("letto n \n");

    for(i=0; i<n; ++i)
        fscanf(fp_in, "%d ",&array1[i]);

    for(i=0; i<n; ++i)
        fscanf(fp_in, "%d ",&array2[i]);


    //for(i=0; i<n; ++i)
        //printf("array1[%d] = %d , array2[%d] = %d \n", i, array1[i], i, array2[i]);

    int controllo;
    controllo = 0;
    for(i=0; i<n; ++i)
        if(array1[i] != array2[i])
            controllo = 1;

    if(!controllo){
        //printf("array uguali\n");
        sum = 0;
    }
    else{
        //printf("array diversi\n");
        sum = 0;
        for(i=0; i<n-1; ++i)
            for(j=i; j<n; ++j){
                if( (array1[i] < array1[j]) && (array2[i] > array2[j]))
                    ++sum;
                if(array1[i] > array1[j] && array2[i] < array2[j])
                    ++sum;        
                //printf("sum vale ora : %d \n", sum);
            }
    }

    
   // printf("%d", sum);

    fprintf(fp_out, "%d", sum);

    fclose(fp_in);
    fclose(fp_out);

   
    return 0;

}

/*int kendall(int n, int *array1, int *array2){
    
    int sum = 0;
    for(i=0; i<n; ++i)
        if(array1[i]>=array2[i])
            sum += array1[i] - array2[i];
        else
            sum += array2[i] - array1[i];

    return sum;

}*/
