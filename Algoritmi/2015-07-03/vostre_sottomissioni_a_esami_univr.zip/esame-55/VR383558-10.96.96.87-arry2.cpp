
#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

long n,m, is,js,tmp; 

int main() {
  cin >> m >> n >> is >> js;
  int scacc [is][js];
  int mos_pos;
  bool win [is][js];
  bool www; // variabile per sapere se la cella i,j e vincente
  
  for(int i=0;i<m;i++){
    if(i>=is){continue;}
    for(int j=0;j<n;j++){
        if(j>=js){continue;} // in verita' non mi servono piu' questi valori, ma devo ciclare per la corretta acquisizione dei successivi js valori della riga i+1
        www=0;
        cin >> mos_pos;
        if(i==0 && j==0){win[i][j]=0;continue;} //prima iterazione, so gia' che e' zero        
        for(int k=1;k<=mos_pos;k++){
        //prima provo a spostarmi a sinistra
        if((j-k)>=0 && win[i][j-k]==0){ //ho trovato una casella che fa perdere in cui mi posso spostare
          www=1;
          break;          
        }
        //provo ad andare su ora se possibile
        if((i-k)>=0 && win[i-k][j]==0){ //ho trovato una casella che fa perdere in cui mi posso spostare
          www=1;
          break;          
        }        
      }
      win[i][j]=www;        
    }
  }
  /*
  cout << "\n";
  for(int i=0;i<is;i++){
    for(int j=0;j<js;j++){
      cout << win[i][j] << "\t";
    }
    cout << "\n";
  }*/
  if(win[is-1][js-1]==0){
    cout << "LOST\n";
  }
  else{
    cout << "WINNING STARTING POSITION\n";
  }
}
