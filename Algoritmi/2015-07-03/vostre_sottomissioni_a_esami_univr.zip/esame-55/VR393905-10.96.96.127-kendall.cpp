#include <stdio.h>

using namespace std;

int merge(int* a, int* b, int l, int m, int r) {

    int i = l, j = m, k = l, c = 0;

    while (i <= m-1 && j <= r) {
        if (a[i] <= a[j])
            b[k++] = a[i++];
        else {
            b[k++] = a[j++];
            c += m-i;
        }
    }

    while (i <= m-1)
        b[k++] = a[i++];

    while (j <= r)
        b[k++] = a[j++];

    for (i = l; i <= r; i++)
        a[i] = b[i];

    return c;
}

int count(int* a, int* b, int l, int r) {

    int m, c = 0;

    if (r > l) {
        m = (r+l)/2;
        c = count(a, b, l, m);
        c += count(a, b, m+1, r);
        c += merge(a, b, l, m+1, r);
    }

    return c;
}

int main() {

    int len, i;
    int* a;
    int* b;
    int* ai;
    int* bn;

    scanf("%d", &len);
    a = new int[len];
    b = new int[len];
    ai = new int[len];
    bn = new int[len];

    for(i = 0; i < len; i++) {
        scanf("%d", &a[i]);
        a[i]--;
    }

    for(i = 0; i < len; i++) {
        scanf("%d", &b[i]);
        b[i]--;
    }

    for(i = 0; i < len; i++)
        ai[a[i]] = i;

    for(i = 0; i < len; i++)
        bn[i] = ai[b[i]];

    printf("%d", count(bn, a, 0, len-1));

    return 0;
}
