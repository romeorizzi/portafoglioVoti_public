#include <iostream>

using namespace std;

#define MAXN 1000010

static int N ;
static int prima [MAXN] ;
static int seconda[MAXN] ;


int sign(int x){
    if (x>0) return 1;
    if (x<0) return -1;
    return 0;
}

int differenza(int x){
    if(x < 0) return 1;
    return 0;
}


int main(){
    //cout << "inserisci N: ";
    cin >> N;
    //cout << "inserisci prima riga di " << N <<" elementi: ";
    for(int i=0; i<N; i++)
        cin >> prima[i];
    //cout << "inserisci seconda riga di " << N <<" elementi: ";
    for(int i=0; i<N; i++)
        cin >> seconda[i];



    int num = 0;
    for(int i = 0; i<N; i++){
        for(int j = i+1; j < N; j++){
            num = num + differenza(sign(prima[i] - prima[j]) * sign(seconda[i] - seconda[j]));
            //cout << num << endl;
        }
    }
    cout << num << endl;

  return 0;
}

