/*

IDEA:

Inizialmente tocca a p1 muovere.
Se ci troviamo nella cella (0,0) ed è il turno di p2 ha vinto perchè p2 non può fare nulla.
Se ci troviamo nella prima riga e può spostarsi a sx in modo da arrivare in (0,0) con una mossa ha vinto perchè poi p2 è in (0,0)
Se ci troviamo nella prima colonna e può spostarsi in su in modo da arrivare in (0,0) con una mossa ha vinto perchè poi p2 è in (0,0)

Fine dei casi base.
Caso iterativo:

P1 non è ne nella prima colonna ne nella prima riga (quindi non è neanche in (0,0)) allora si ricorre con i casi precedenti fino a quando
non si vede se ESISTE una mossa per cui p1 può vincere.
In particolare se non esiste alcuna mossa successiva in cui p1 può vincere allora vince P2, viceversa esiste una strategia per P1.

*/


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

#define MAX 1000

void stampaRisultato();
int trovaVincitore(int riga, int colonna);
int turno = 1;

int vinceP1 = 0;
int matrice[MAX][MAX];

int main()
{
    int numRighe, numColonne, riga, colonna;
    int i,j,k;

    scanf("%d %d %d %d", &numRighe, &numColonne, &riga, &colonna);

    for(i=0;i<numRighe;i++) // scorro le righe
        for(j=0;j<numColonne;j++) // scorro le colonne
            scanf("%d", &matrice[i][j]); // salvo il valore

    vinceP1 = trovaVincitore(riga-1, colonna-1);
    stampaRisultato();

    return 0;
}

void stampaRisultato()
{
    if(vinceP1==0)
        printf("LOST");
    else // esiste una strategia di vittoria per p1
        printf("WINNING STARTING POSITION");
}

int trovaVincitore(int i, int j) // ritorna 1 se esiste la strategia di vittoria per p1; 0 altrimenti
{
    int spostamentoMax = matrice[i][j];
    int spostamentoMaxSx = (j<=spostamentoMax) ? j : spostamentoMax;
    int spostamentoMaxSu = (i<=spostamentoMax) ? i : spostamentoMax;

    int k;
    int tmpSx=1, tmpDx=1;
    int ricorsioniSx[MAX], ricorsioniSu[MAX];

    ricorsioniSx[0] = 0;
    ricorsioniSu[0] = 0;

    if(j==0 && i==0) // se ci troviamo in (0,0) e tocca p2 allora ha vinto p1
    {
        if(turno==2)
            return 1;
        else
            return 0;
    }
    else if(i==0 && j>0 && matrice[i][j]>=j) // p1 può vincere spostandosi a sinistra
    {
        if(turno==1)
            return 1;
        else
            return 0;
    }
    else if(j==0 && i>0 && matrice[i][j]>=i) // p1 può vincere spostandosi in alto
    {
        if(turno==1)
            return 1;
        else
            return 0;
    }
    else // caso iterativo spiegato nell'idea a inizio file
    {
        for(k=1; k<=spostamentoMaxSx; k++) // posso scegliere di spostarmi a sx di un n° di celle che va da 1 a spostamentoMaxSx
        {
            turno = (turno==1) ? 2 : 1; // indico che il prossimo turno è quello dell'avversario
            if (trovaVincitore(i,j-k)==1) // Se vince p1 con uno spostamento che ha scelto, allora esiste una strategia di vittoria per lui
                vinceP1 = 1;

        }

        for(k=1; k<=spostamentoMaxSu; k++) // posso scegliere di spostarmi in su di un n° di celle che va da 1 a spostamentoMaxSu
        {
           turno = (turno==1) ? 2 : 1; // indico che il prossimo turno è quello dell'avversario
           if (trovaVincitore(i-k,j)==1) // Se vince p1 con uno spostamento che ha scelto, allora esiste una strategia di vittoria per lui
                vinceP1 = 1;
        }

        // se non ho trovato nessun caso di vittoria per p1 allora vince p2
        return 0;
    }
}
