int *head;
int n;
int i = 0;
int visita_ric(int *pre, int *post, int *simm) {
	int child = 0;
	if (*pre == *post) {
		*(simm + i) = *pre;
		//cout << *pre;
		i++;
		return 1;
	} else {
		if (*(head + (n - 1)) == *pre)
			return 0;
		child += visita_ric(pre + 1, post, simm);
	}
	*(simm + i) = *pre;
	i++;
	//cout << *pre;
	child += visita_ric(pre + child + 1, post + child, simm);
	return child + 1;
}


void visita(int N, int *PRE, int *POST, int *SIMM) {
	head = PRE;
	n = N;
	visita_ric(PRE, POST, SIMM);
}

