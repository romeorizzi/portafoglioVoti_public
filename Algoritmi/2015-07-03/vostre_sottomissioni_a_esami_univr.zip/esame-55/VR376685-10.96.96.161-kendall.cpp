//#define NDEBUG
#include<cassert>
#include<fstream>
#include<vector>
#ifndef NDEBUG
	 #include<iostream>
#endif

using namespace std;

ofstream fout;
const int MAX = 100000;
//int a[MAX],b[MAX];
int *a, *b;
int dimensione;


int kendall (int *a, int *b){
    int score = 0;
    for(int i =0; i< dimensione; i++){
        for(int j=0; j<dimensione; j++){

            if( (a[i] < a[j] && b[i] > b[j] )|| (a[i] > a[j] && b[i] < b[j]))
                score++;
        }
    }

    return (score / 2);
}



int main() {
	ifstream fin;
	fin.open("input.txt"); assert( fin );
    fin >> dimensione;
    a = (int *) (malloc(sizeof(int)* dimensione));
    b = (int *) (malloc(sizeof(int)* dimensione));
    // leggo la prima riga
    for (int i =0; i < dimensione; i++ ){
        fin >> a[i];
    }

    // leggo la permutazione
    for (int i =0; i < dimensione; i++ ){
        fin >> b[i];
    }


    fin.close();

	fout.open("output.txt"); assert( fout );

    fout << kendall(a,b) << endl;
	fout.close();

	return 0;
}
