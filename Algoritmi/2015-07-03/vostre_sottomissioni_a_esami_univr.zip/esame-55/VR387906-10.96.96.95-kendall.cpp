#include <iostream>
#include <cstdlib>
#include <string.h>


using namespace std;


int main() {
    int N;
    cin >> N;

    int A[N];
    int B[N];

    int K = 0;



    for(int i = 0; i < N; i++) {
        cin >> A[i];

    }

    for(int i = 0; i < N; i++) {
        cin >> B[i];

    }



    for(int i = 0; i < N-1; i++) {
        for(int j = i+1; j < N; j++) {
            if((A[i] < A[j] && B[i] > B[j]) || (A[i] > A[j] && B[i] < B[j])) {
                K++;
            }
        }
    }


    cout << K;

}
