#include <stdio.h>
#include <assert.h>
#include <iostream>
#include <algorithm>
#define MAXN 1000000

using namespace std;

static int N,i,K=0;
static int p[MAXN] ; // pi greco
static int s[MAXN] ; // sigma

/**
 * @brief kendall_0 versione 1: greedy
 * @param N numero elementi
 * @param p stringa pi greco
 * @param s stringa sigma
 * @return kendall tau rank
 */
void kendall(int N, int *p, int *s){
    for(int j = 0; j < N; j++){
        for(int i = 0; i < j; i++){
            if(  ( p[i]<p[j] && s[i]>s[j] ) || ( p[i]>p[j] && s[i]<s[j] ) )
                K++;
        }
    }

}

int main(){
    FILE *fin, *fout;
    fin = stdin;
    fout = stdout;

    assert(1==fscanf(fin, "%d", &N));

    for( i = 0 ; i < N ; i++ ) assert( 1 == fscanf(fin,"%d",p+i) );
    for( i = 0 ; i < N ; i++ ) assert( 1 == fscanf(fin,"%d",s+i) );

    kendall(N, p, s);

    fprintf(fout,"%d",K);
    return 0;
}

