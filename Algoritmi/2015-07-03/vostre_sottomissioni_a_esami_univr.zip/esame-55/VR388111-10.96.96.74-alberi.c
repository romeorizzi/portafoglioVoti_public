#include <stdio.h>
#include <stdlib.h>

int simm_idx = 0;

void risolvi(int pre_start, int pre_end, int post_start, int post_end, int* PRE, int* POST, int* SIMM)
{
	if(pre_start == pre_end)
	{
		SIMM[simm_idx++] = PRE[pre_start];
		return;
	}
	
	++pre_start;
	--post_end;
	
	int offset = 0;
	while(PRE[pre_start] != POST[post_start + offset])
		offset++;
	
	risolvi(pre_start, pre_start + offset, post_start, post_start + offset, PRE, POST, SIMM);
	SIMM[simm_idx++] = PRE[pre_start-1];
	risolvi(pre_start + offset + 1, pre_end, post_start + offset + 1, post_end, PRE, POST, SIMM);
}

void visita(int N, int *PRE, int *POST, int *SIMM)
{
	risolvi(0, N-1, 0, N-1, PRE, POST, SIMM);
}

/*
int main()
{
	int N, i;
	int* pre_v,* post_v,* simm_v;

    FILE* f= fopen("input.txt", "r");
    fscanf(f,"%d\n", &N);
    
    pre_v = (int*) malloc(N*sizeof(int));
    post_v = (int*) malloc(N*sizeof(int));
    simm_v = (int*) malloc(N*sizeof(int));

    for(i=0; i<N; i++)
    {
       	fscanf(f,"%d", pre_v+i);
    }
    
    for(i=0; i<N; i++)
    {
       	fscanf(f,"%d", post_v+i);
    }
    
    fclose(f);
    
    visita(N, pre_v, post_v, simm_v);
    
    for(i=0; i<N; i++)
    {
    	printf("%d ", simm_v[i]);
    }
    
    return 0;
}
*/
