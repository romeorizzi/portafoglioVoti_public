//Il parametro N è il numero di nodi dell’albero.
//Gli array PRE e POST contengono la visita in preordine e postordine
//L’array SIMM da riempire con la visita simmetrica   

#include <vector>

using namespace std;

void visita(int N, int *PRE, int *POST, int *SIMM){

    vector <bool> giaVisto;

    //metto a false tutto il vector che mi indicherà se un elemento è già stato visitato
    giaVisto.assign(N+1,false);

    int k=0;

    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++){
            if(POST[i] == PRE[j]){
                if(!giaVisto[PRE[j]]){
                    SIMM[k] = PRE[j];
                    k++;
                    giaVisto[PRE[j]]=true;
                }
                if(!giaVisto[PRE[j-1]]){
                    SIMM[k] = PRE[j-1];
                    k++;
                    giaVisto[PRE[j-1]]=true;
                }
            }
        }   
    }
}
