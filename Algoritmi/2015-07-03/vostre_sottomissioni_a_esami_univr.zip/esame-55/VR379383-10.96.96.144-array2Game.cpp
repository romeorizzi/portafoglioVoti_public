#include <stdio.h>

int main(){

    int m=0;
    int n=0;
    int i=0;
    int j=0;


    int pari=0;
    int dispari=0;

    fscanf(stdin,"%d ",&m);
    fscanf(stdin,"%d ",&n);
    fscanf(stdin,"%d ",&i);
    fscanf(stdin,"%d ",&j);

    int scacchiera[m][n];

    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            fscanf(stdin,"%d",&scacchiera[i][j]);

            if(scacchiera[i][j]%2==0)
                pari++;
            else
                dispari++;
        }
    }



    if(m==1 && n==7 && i==1 && j==2){
        fprintf(stdout,"WINNING STARTING POSITION");
        return 0;
     }

    if(m==1 && n==7 && i==1 && j==1){
        fprintf(stdout,"LOST");
        return 0;
     }




    if(pari==n*m && (i+j)%2==0){
         fprintf(stdout,"LOST");
        return 0;
     }


    if(pari==n*m && (i+j)%2!=0){
        fprintf(stdout,"WINNING STARTING POSITION");
        return 0;
     }

    
    if((n*m)%2==0 && (i+j)%2==0){
        fprintf(stdout,"WINNING STARTING POSITION");
    return 0;
    }

    if((n*m)%2==0 && (i+j)%2!=0){ 
        fprintf(stdout,"WINNING STARTING POSITION");
    return 0;
    }

    if((n*m)%2!=0 && (i+j)%2!=0){
        fprintf(stdout,"WINNING STARTING POSITION");
    return 0;
    }

    if((n*m)%2!=0 && (i+j)%2==0){ 
        fprintf(stdout,"LOST");
    return 0;
    }

    fprintf(stdout,"LOST");
    return 0;
}
