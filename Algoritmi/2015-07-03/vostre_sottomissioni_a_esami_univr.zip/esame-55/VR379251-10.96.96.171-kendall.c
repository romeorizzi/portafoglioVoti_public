#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
int kendallSmallN( int arr1[], int arr2[], int len );
int main(){
    long int n;
    int i=0,j=0,COUNTER=0;
    //leggo il valore di n    
    scanf("%ld",&n);
    //dichiaro e alloco due array di dim n
    int *Array_1=(int *) malloc(n * sizeof(int));
    int *Array_2=(int *) malloc(n * sizeof(int));
    //leggo da stdin i valori per i due array  
    for(i=0;i<n;i++)
        scanf("%d",&Array_1[i]);
    for(i=0;i<n;i++)
        scanf("%d",&Array_2[i]);
    
    for(i=0;i<n;i++)
       for(j=i+1;j<n;j++)
           if(((Array_1[i]>Array_1[j]) && (Array_2[i]<Array_2[j])) || ((Array_1[i]<Array_1[j]) && (Array_2[i]>Array_2[j])))
             COUNTER++;
  
    printf("%d\n",COUNTER);
return 0;
}
