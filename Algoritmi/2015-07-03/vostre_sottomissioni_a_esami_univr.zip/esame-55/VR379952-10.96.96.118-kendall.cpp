#include <iostream>

using namespace std;

int main()
{
    int tmp=0,i,j;
    int lunghezza;

    cin >> lunghezza;

    int matrice[2][lunghezza];

    for(i=0;i<lunghezza;i++){
        cin >> matrice[0][i];
    }

    for(i=0;i<lunghezza;i++){
        cin >> matrice[1][i];
    }



    for(i=0;i<lunghezza;i++){
        for(j=i+1;j<lunghezza;j++){
            if(matrice[0][i]<matrice[0][j] && matrice[1][i]>matrice[1][j]) tmp++;
            if(matrice[0][i]>matrice[0][j] && matrice[1][i]<matrice[1][j]) tmp++;
        }
    }


    cout << tmp;

}
