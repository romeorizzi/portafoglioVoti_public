#include<stdio.h>
#include<stdlib.h>
#include<assert.h>

#define MAXN 1500
#define MAXM 1500

int m,n,r,c,s[MAXM][MAXN],g=1, stop=1, mv, mo;

int changePlayer()
{
    if(g==1) return 2;
    else return 1;
}

void input()
{
    int i,j;
    assert(fscanf(stdin,"%d",&m));
    assert(fscanf(stdin,"%d",&n));
    assert(fscanf(stdin,"%d",&r));
    assert(fscanf(stdin,"%d",&c));
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            assert(fscanf(stdin,"%d",&s[i][j]));
        }
    }
    r--;
    c--;
}

int min(int a, int b)
{
    if(b>=a) return a;
    else return b;
}

int loseoppo(int rn, int cn)
{
    if(rn==0 && cn==0)
        return 1;
    else
        return 0;
}

int loseme(int rn, int cn)
{
    if(cn!=0 && rn==0)
    {
        if(loseoppo(rn,cn-min(s[rn][cn],cn)))
        {
            return 1;
        }
    }
    if(cn==0 && rn!=0)
    {
        if(loseoppo(rn-min(s[rn][cn],rn),cn))
        {
            return 1;
        }
    }
    return 0;
}

void game()
{
    int mossa;
    int i;
    while(stop)
    {
    //getchar();
    //printf("GIOCATORE: %d\n",g);
    //printf("r: %d,c: %d\n",r,c);
        if(r==0 && c!=0)
        {
            mossa=0;
            for(i=min(s[r][c],c);i>=1;i--)
            {
                if(loseoppo(r,c-i) || !loseme(r,c-i) || i==1)
                {
                    //printf("sx:%d\n",i);
                    c-=i;
                    mossa=1;
                    break;
                }
            }
            //if(!mossa) c-=min(s[r][c],c);
        }
        else if(r!=0 && c==0)
        {
            mossa=0;
            for(i=min(s[r][c],r);i>=1;i--)
            {
                if(loseoppo(r-i,c) || !loseme(r-i,c) || i==1)
                {
                    //printf("up:%d\n",i);
                    r-=i;
                    mossa=1;
                    break;
                }
            }
            //if(!mossa) r-=min(s[r][c],r);
        }
        else if(r!=0 && c!=0)
        {

            mossa=0;
            for(i=min(s[r][c],c);i>=1;i--)
            {
                if(loseoppo(r,c-i) || !loseme(r,c-i))
                {
                    //printf("sx:%d\n",i);
                    c-=i;
                    mossa=1;
                    break;
                }
            }
            if(!mossa){
                for(i=min(s[r][c],r);i>=1;i--)
                {
                    if(loseoppo(r-i,c) || !loseme(r-i,c)  || i==1)
                    {
                        //printf("up:%d\n",i);
                        r-=i;
                        mossa=1;
                        break;
                    }
                }
            }
            //if(!mossa) c-=min(s[r][c],c);
        }
        else if(r==0 && c==0)
            break;//stop=0;
        g=changePlayer();
    }
    if(g==2) fprintf(stdout,"WINNING STARTING POSITION");
    else fprintf(stdout,"LOST");
}

int main()
{
    input();
    game();
    return 0;
}
