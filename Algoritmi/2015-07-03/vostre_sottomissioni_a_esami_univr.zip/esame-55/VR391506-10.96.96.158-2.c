/**

/usr/bin/gcc -DEVAL -static -O2 -o 2 2.c -lm

m n e cella_iniziale (i, j)

mosse consentite: sx o alto
chi non può più muovere, perde la partita
*/
#include <stdio.h>
//#include <stdlib.h>
#include <assert.h>

// MAXN e MAXM di grandezza = 1000 per non andare fuori memoria... ma per i casi in cui devo risolvere istanze con n e m = 3000 come faccio a salvarmi l'input???
#define MAXM 1000
#define MAXN 1000

int matrice[MAXM][MAXN];
int vinci[MAXM][MAXN];

int main() {
	int n, m, i, j;
	int k, z, l, prec;
	char* winner = "WINNING STARTING POSITION";
	char* loser = "LOST";
	
	
	
	scanf("%d %d %d %d", &m, &n, &i, &j);
	for (z = 0; z < m; z ++) {
		for (k = 0; k < n; k ++) {
			scanf("%d", &matrice[z][k]);
			vinci[z][k] = 0;
		}
	}

	vinci[0][0] = 0; // chi ci entra perde
	
	// la prima riga NON cambia
	vinci[0][0] = 0; // chi ci entra perde
	for (l = 0; l < j; l ++) {
		for (prec = l-1; prec >= 0 && (l-prec <= matrice[0][l]) && vinci[0][l] == 0; prec --)
			if (vinci[0][prec] == 0)
				vinci[0][l] = 1;
	}
	
	for (z = 1; z < i; z ++) {	// seconda riga e successive
		for (l = 0; l < j; l ++) {
			for (prec = l-1; prec >= 0 && (l-prec <= matrice[z][l]) && vinci[z][l] == 0; prec --)
				if (vinci[z][prec] == 0)
					vinci[z][l] = 1;
			
			if (vinci[z][l] == 0) {
				//printf("z=%d l=%d\n",z,l);
				for (prec = z-1; prec >= 0 && (z-prec <= matrice[z][l]) && vinci[z][l] == 0; prec --) {
					//printf("test z=%d l=%d\n",z,l);
					if (vinci[prec][l] == 0)
						vinci[z][l] = 1;
				}
			}
		}
	}
	
	
	if (vinci[i-1][j-1] == 1)
		printf("%s\n",winner);
	else printf("%s\n",loser);
	//printf("vinci[i][j]=%d\n vinci[2][2]=%d\n",vinci[i-1][j-1]);
	
	return 0;
}
