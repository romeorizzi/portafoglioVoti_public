/*class Nodo{
    private:
        int right = -1; 
        int left = -1;
        int sons = 0;
     
     public:
        void set_right_son(int right){
            this->right = right;
        }
        void set_left_son(int left){
            this->left = left;
        }
        
        bool set_son(int son){
            if(this->sons == 2)
                return false;
                
            if(this->sons = 0)
                this->set_left_son(son);
            if(this->sons = 1)
                this>set_right_son(son);
            
            return true;
        }
        
        bool is_completed(){
            return this->sons == 2 ? true : false;
        }
}*/

#include <stdlib.h>
#include <stdio.h>
#include <iostream>

//#define PRINT 1

typedef struct _StackElement{
    int value = -1;
    struct _StackElement *next = NULL;
}StackElement;

class Stack{

    private:
        StackElement* el = NULL;
        StackElement* inv = NULL;
    
    public:
    
        void push(int value){
            StackElement* newEl = new StackElement;
            newEl->value = value;
            newEl->next = el;
            this->el = newEl;
        }
        
        int top(){
            if(this->el == NULL)
                return -1;
            return this->el->value;
        }
        
        void pop(){
            StackElement *supp = this->el->next;
            delete(this->el);
            this->el = supp;
        }

};

#ifdef PRINT 
void print_result(int N, int* result){
    for(int i =0; i < N; i++){
        std::cout << result[i] << " ";
    }
    std::cout << std::endl;
}
#endif

void visita(int N, int *PRE, int *POST, int *SIMM )
{
	int i = 0;
	int j = 0;
	
	Stack stack;

	int k = 0;
	while(i < N && j < N){
	    
	    if(POST[i] == stack.top()){
	        stack.pop();
	        i++;
	        continue;
        }
        else if(stack.top() != -1){
            #ifdef PRINT	        
	            std::cout << stack.top() << std::endl;
            #endif
            SIMM[k++] = stack.top();
            //stack.pop();
        }
	
	    while(j < N && PRE[j] != POST[i]){
	        stack.push(PRE[j]);
	        j++;
	    }
	    if(j < N){
#ifdef PRINT	        
	        std::cout << PRE[j] << std::endl;
#endif
	        SIMM[k++] = PRE[j++];
        }
        i++;
	}
#ifdef PRINT	
	print_result(N,SIMM);
#endif	
}
