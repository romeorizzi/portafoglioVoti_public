#include<stdio.h>
#include<stdlib.h>

#define MAX_N 1000000
#define INPUT "input.txt"
#define OUTPUT "output.txt"
#define lsb(x) (x & (-x))

int pi[MAX_N];
int sigma[MAX_N];

int n;




FILE *fp_in,*fp_out;

int 

int main(){
    
    int i,j;
    fp_in=fopen(INPUT,"r");
    fp_out=fopen(OUTPUT,"w+");

    fscanf(fp_in,"%d",&n);

    for(i=0;i<n;++i){
        fscanf(fp_in,"%d",&pi[i]);

    }
    for(i=0;i<n;++i){
        fscanf(fp_in,"%d",&sigma[i]);

    }
    
    int kendall=0;
    
for(i=0;i<n;++i)
        for(j=i+1;j<n;++j)
            if((pi[i]<pi[j] && sigma[i]>sigma[j]))++kendall;
            else if(pi[i]>pi[j] && sigma[i]<sigma[j])++kendall;
    fprintf(fp_out,"%d",kendall);
        
    fclose(fp_in);
    fclose(fp_out);
    return 0;
}
