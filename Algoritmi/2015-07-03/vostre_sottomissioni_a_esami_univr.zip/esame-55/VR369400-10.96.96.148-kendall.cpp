
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <fstream>
#include <math.h>
using namespace std;

const int MAX = 1000000;
int pi[MAX];
int sigma[MAX];
int n;

int main() {
	cin >> n;
	for (int i = 0; i < n; i++)
		cin >> pi[i];
	for (int i = 0; i < n; i++)
		cin >> sigma[i];

	int distance = 0;


	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if ((pi[i] < pi[j] && sigma[i] > sigma[j])
					|| (pi[i] > pi[j] && sigma[i] < sigma[j]))
				distance++;
		}
	}
	cout << distance;

	return 0;
}
