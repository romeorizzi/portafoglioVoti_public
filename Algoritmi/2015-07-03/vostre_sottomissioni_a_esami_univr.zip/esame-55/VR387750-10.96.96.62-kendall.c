#include<stdio.h>
#include<stdlib.h>

//void kendallPer(int j, int val);

int *pi;
int *sig;
int nCoppie = 0;


int main(void) {
    int n,i,k,tmp;

    scanf("%d", &n);
    pi = malloc(n * sizeof(int));
    sig = malloc(n * sizeof(int));

    for(i=0; i< n; i++) 
        scanf("%d", &pi[i]); 
    for(i=0; i< n; i++) {
        scanf("%d", &sig[i]);
        //kendallPer(i, tmp);
    }
    
    for(i=0; i<n; i++) {    
        for(k=0; k < i; k++) {
            if((pi[k] < pi[i]) && (sig[k] > sig[i]))
                nCoppie++;
            if((pi[k] > pi[i]) && (sig[k] < sig[i]))
                nCoppie++;        
        }   
    }
    printf("%d", nCoppie);
    return 0;
}

/*void kendallPer(int j, int val) {
    int pos;
    for(pos = 0; pos < j; pos++) {
        if((pi[pos] < val) && ())    
    }

}*/
