#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

void visita(int N, int *PRE, int *POST, int *SIMM );

int N;
class Node{
public:
    int data;
    Node* father;
    Node* left;
    Node* right;
    Node(int n){data = n;};
    void simmVisit(){
        cout << "simmVisit on node " << data << endl;
        if(left->data != -1)
            left->simmVisit();
        cout << "VISITING => " << data << endl;
        if(right->data != -1)
            right->simmVisit();
    };
};

int main(){
    ifstream input("input.txt");
    input >> N;
    
    int ant[N];
    int antPos[N];
    int post[N];
    //CAN I USE THIS IN K DISTANCE?
    int postPos[N];
    bool created[N];
    Node *nodes[N];
    
    
    
    for(int i = 0;i < N;i++){
        created[i] = false;
        input >> ant[i];
        antPos[ant[i]-1] = i;
    }
    
    for(int i = 0;i < N;i++){
        input >> post[i];
        postPos[post[i]-1] = i;
    }
    
    
    Node* endNode = new Node(-1);
    Node* unassigned = new Node(0);
    Node* root = new Node(ant[0]);
    created[ant[0]-1] = true;
    nodes[ant[0]-1] = root;
    cout << "root = " << ant[0] << endl;
    root->father = endNode;
    root->right = new Node(post[N-2]);
    cout << "root->right = " << post[N-1] << endl;
    root->left = unassigned;
    created[post[N-2]-1] = true;
    nodes[post[N-2]-1] = root->right;
    nodes[post[N-2]-1]->left = unassigned;
    nodes[post[N-2]-1]->right = unassigned;
    Node* temp = root;
    
    
    for(int i = 0;i < N;i++){
        if(ant[i] == post[0]){
            temp->left = endNode;
            temp->right = endNode;          
            break;
        }
            
        Node* node = new Node(ant[i]);
        created[ant[i]-1] = true;
        cout << "just put created["<<(ant[i]-1)<<"] to true"<<endl;
        nodes[ant[i]] = node;
        temp->left = node;
        node->father = temp;
        temp = temp->left;
        cout << "creating node -> " << ant[i] << endl;
    }
    
    for(int i = 1;i < N;i++){
    
        if(!created[post[i]-1]){
            for(int j = i+1; j < N;j++){
            cout << "here j = " << j << " i = " << i << " post[i] = " << post[i] << " post[j] = " << post[j] << endl;
            cout << "antPos[post[i]-1] = " << antPos[post[i]-1] << " antPos[post[j]-1] = " << antPos[post[j]-1] << endl;
                if(!created[post[i]-1] && antPos[post[i]-1] > antPos[post[j]-1]){
                    //then its true
                    cout << "IF" << endl;
                    Node *node = new Node(post[i]);
                    nodes[post[i]] = node;
                    
                    created[post[i]-1] = true;
                    cout << "just put created["<<(post[i]-1)<<"] to true"<<endl;
                    node->left = endNode;
                    node->right = endNode;
                    node->father = nodes[post[j]-1];
                    if(created[post[j]-1]){
                        cout << "|||||||||||||||||| nodes[post[j]] = " << nodes[post[j]-1]->data << endl;
                        if(nodes[post[j]-1]->left == NULL || nodes[post[j]-1]->left->data == 0)
                            nodes[post[j]-1]->left = node;
                        else
                            nodes[post[j]-1]->right = node;
                    }
                    else{
                                                
                        cout << "BUGGGGGG!!!! ??? " << endl;
                    
                    }
                }
            }        
        } 
        
       
        
//        root->simmVisit();
    }
     for(int i = 0;i < N;i++)
            cout << "created[" << i << "] = " << created[i-1] << endl;
    
    root->simmVisit();
    
    
}
