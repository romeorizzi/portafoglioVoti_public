#/usr/bin/env python3

def componenti(L, visited, start):
    if visited[start] == 0:
        visited[start] = 1
        for i in L[start]:
            componenti(L, visited, i)      

T = int(input())
for t in range(T):
    N, M = map(int, input().split())
    L = [[] for _ in range(N)]
    visited = [0 for _ in range(N)]
    for i in range(M):
        a, b = map(int, input().split())
        L[a].append(b)
        L[b].append(a)
    
    start = 0
    componenti(L, visited, start)
    if 0 not in visited:
        print(1)
        print(visited[0])
    else:
        count = 1
        result = '0'
        for i in range(len(visited)):
            if visited[i] == 0:
                count += 1
                result += ' ' + str(i)
                componenti(L, visited, i)

        print(count)
        print(result)