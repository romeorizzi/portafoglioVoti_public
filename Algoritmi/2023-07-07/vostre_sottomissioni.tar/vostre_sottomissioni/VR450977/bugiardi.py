#!/usr/bin/python3

def find_the_number_liars(upperbound, liars_list, module, idx_module = 0, lowerbound = 1):

    #print(f"upperbound: {upperbound}")
    #print(f"liars_list: {liars_list}")
    #print(f"module: {module}")
    #print(f"idx_module: {idx_module}")
    #print(f"lowerbound: {lowerbound}")


    if upperbound == lowerbound:
        return upperbound
    median_result = (upperbound + lowerbound) // 2

    print(f"?{median_result}")
    response = input().strip()
    assert(len(response)==1)

    if response == '<':
        if liars_list[idx_module] == True:
            return find_the_number_liars(median_result - 1, liars_list, module, (idx_module+1) % module, lowerbound)
        else:
            return find_the_number_liars(upperbound, liars_list, module, (idx_module+1) % module, median_result + 1)
    elif response == '>':
        if liars_list[idx_module] == True:
            return find_the_number_liars(upperbound, liars_list, module, (idx_module+1) % module, median_result + 1)
        else:
            return find_the_number_liars(median_result - 1, liars_list, module, (idx_module+1) % module, lowerbound)
    return median_result

#v01_assert liar = 0
def find_the_number_clean(upperbound, lowerbound = 1):
    
    if upperbound == lowerbound:
        return upperbound
    median_result = (upperbound + lowerbound) // 2

    print(f"?{median_result}")
    response = input().strip()
    assert(len(response)==1)

    if response == '<':
        return find_the_number_clean(median_result - 1, lowerbound)
    elif response == '>':
        return find_the_number_clean(upperbound, median_result + 1)
    return median_result

#test case number
test_case = int(input().strip())

for i in range(test_case):

    upperbound, module, liar = map(int, input().strip().split())

    assert(upperbound > 0)
    assert(module > 0)

    if upperbound == 1:
        print("!1")
    elif liar == 0:
        correct_value = find_the_number_clean(upperbound)
        print(f"!{correct_value}")
    #elif module == 1:
    else:
        liars_list = [False] * module
        unexpected = False

        #looking for the liars
        for i in range(module):
            print(f"?{upperbound}") #N = 1..12 -> X == 12 ? -> risposta: ">" -> -.-' | "<" -> :)
            response = input().strip()
            assert(len(response)==1)
            if response == '<':
                liars_list[i] = True
            elif response == '=':
                unexpected = True
                break
            upperbound -= 1
        
        if unexpected == True:
            print(f"!{upperbound}")
        else:
            correct_value = find_the_number_liars(upperbound, liars_list, module)
            print(f"!{correct_value}")
