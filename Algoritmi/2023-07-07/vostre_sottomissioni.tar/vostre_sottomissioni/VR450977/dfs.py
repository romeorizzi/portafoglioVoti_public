#!/usr/bin/python3

#print("Running dfs.py")

#from a node a jump in each other node connected
#with another dfs() call
def dfs(graph, node, visited, component):

    #print(f"graph: {graph}")
    #print(f"node: {node}")
    #print(f"visited: {visited}")
    #print(f"component: {component}")
    #interr = input()

    visited[node] = True
    component.append(node)

    for linked_node in graph[node]:
        if not visited[linked_node]:
            dfs(graph, linked_node, visited, component)

#for each element of the graph
def find_connect_components(graph):
    #
    visited = [False] * len(graph)
    #print(f"visited: {visited}")

    unique_component = set()

    #components = []

    for node in range(1, len(graph)):

        #print(f"node: {node}")
        #print(f"visited[<#node>{node}]: {visited[node]}")
        already_exists = False

        #guardo ogni componente creata
        for uc in unique_component:
            #print(f"uc: {uc}")
            #print(f"node: {node}")
            #cerco se la singola componente contiene il nodo 
            if uc.find(str(node)+";") != -1:
                already_exists = True

        if already_exists == False:
            if not visited[node]:
                component = []

            dfs(graph, node, visited, component)
            
            #print(f"component returned: {component}")
            str_component = ""
            for element in component:
                str_component += str(element)+";"

            #print(f"uniq c: {str_component}")

            #components.append(component)
            unique_component.add(str_component)

    return unique_component

#test case number
test_case = int(input().strip())

for i in range(test_case):

    #extract |V| and |E|
    vertex_number, edges_number = map(int, input().strip().split())
    assert(vertex_number > 0)
    assert(edges_number > 0)

    #create the graph:
    #   graph[<node>] = [<linked node list>] 
    graph = {}
    for j in range(edges_number):
        #the input has the template "N M"
        node_first, node_second = map(int, input().strip().split())
        #create the empty <linked node list> for graph[N] and graph[M]
        #but only if doesn't exists
        if node_first not in graph:
            graph[node_first] = []
        if node_second not in graph:
            graph[node_second] = []
        #add graph[N] = <N's linked node list> + M
        #and reverse
        #add graph[M] = <M's linked node list> + N
        graph[node_first].append(node_second)
        graph[node_second].append(node_first)

    #print(f"len(graph): {len(graph)}")
    #print(f"graph: {graph}")

    connect_components = find_connect_components(graph)
    print(len(connect_components))
    #looking for a single vertex of component
    output = ""
    for component in connect_components:
        limit = component.find(";")
        output += str(component)[0:limit] + " "
    print(output.strip())