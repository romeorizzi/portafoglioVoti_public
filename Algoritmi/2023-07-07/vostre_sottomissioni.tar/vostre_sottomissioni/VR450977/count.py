#!/usr/bin/python3

def add_2_set(all_rank, upperbound, lowerbound, skip = 1):

    str_seq = ""
    #print(f"lowerbound: {lowerbound} upperbound: {upperbound} skip: {skip}")
    for i in range(lowerbound, upperbound, skip):
        str_seq += str(i + 1) + " "
        all_rank_set.add(str_seq.strip())

def all_rank(all_rank_set, upperbound, lowerbound = 1):
        
    for i in range(upperbound):
        for j in range(upperbound):
            for k in range(1, upperbound):
                add_2_set(all_rank_set, i, j, k)
    
    return

#test case number
test_case = int(input().strip())

for i in range(test_case):

    n, c, r, u = map(int, input().strip().split())

    #assert(n > 0)
    #assert(c == 0 or c == 1)
    #assert((r >= 0 and u == 0) or (u >= 0 and r == 0))

    all_rank_set = set()
    all_rank(all_rank_set, n + 1)

    if (c == 1):
        print(len(all_rank_set))
    else:
        all_r = sorted(all_rank_set)
        print(all_r)