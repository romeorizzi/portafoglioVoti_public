import random

def handle_response(response, responses, y, n, k, b, min, max):

    if response == "<":
        max = y - 1

    elif response == ">":
        min = y + 1

    return int(min), int(max)


T = int(input())

for _ in range(T):

    responses = []

    n, k, b = map(int, input().split())

    min = 1
    max = n

    if n == 1:
        print(f'!{n}')

    else:   
        while True:

            y = int(max+min)/2

            if max == min:
                print(max, min)
                print(f'!{int(max)}')
                break

            print(f'?{int(y)}')
            response = str(input())

            if (response != "="):
                min, max = handle_response(response, responses, y, n, k, b, min, max)        

            elif (response == "="):
                print(f'!{y}')
                break