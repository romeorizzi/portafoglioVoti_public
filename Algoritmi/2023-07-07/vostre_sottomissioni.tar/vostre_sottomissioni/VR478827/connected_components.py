def expand_node(G, v, visited, component):
    
    visited[v] = True
    component.append(v)

    for neighbor in G[v]:
        if not visited[neighbor]:
            expand_node(G, neighbor, visited, component)

def conn_comp(G, n):
    visited = [False] * n
    components = []

    for v in range(n):
        if not visited[v]:
            component = []
            expand_node(G, v, visited, component)
            components.append(component)

    not_conn = []

    for i in components:
        not_conn.append(i[0])

    return not_conn

T = int(input())

for _ in range(T):

    n, m = map(int, input().split())
    G = {i: [] for i in range(n)}

    for _ in range(m):
        u, v = map(int, input().split())
        G[u].append(v)
        G[v].append(u)    

    not_conn = conn_comp(G, n)

    print(len(not_conn))
    print(' '.join(str(v) for v in not_conn))