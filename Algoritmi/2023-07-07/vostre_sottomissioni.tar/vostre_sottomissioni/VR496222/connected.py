global flag, count, S, G
T= int (input())

for _ in range(T):
    n,m = map(int,input().split())
    G= [[] for _ in range (n)]
    for _ in range(m):
        u,v = map(int,input().split())
        G[u].append(v)
        G[v].append(u)
    flag = [0]*n
    count = 0
    S=[]
    def dfs(node, s):    
        flag[node]= s
        for next in G[node]:
            if not flag[next]:
                dfs(next,s)

    for i in range(n):
        if flag[i] == 0:
            count = count +1
            dfs(i, count)
            S.append(i)
    print(count)
    for j in S:
        print(j, end=" ")




    
    


