T= int (input())
s=[]
def ricBin(a,c,v,k):
    t = int((a+c)/2)
    if a==c:
        print('!',a)
        return
    print('?',t)
    res = input()
    if res == '=':
        print('!',t)
        return
    if res == '>' and s[v] == True:
        ricBin(t+1,c,(v+1)%k,k)
    else:
        if res == '<' and s[v] == True:
            ricBin(a,t-1,(v+1)%k,k)
        else:
            if res == '>' and s[v] == False:
                ricBin(a,t-1,(v+1)%k,k)
            else:
                ricBin(t+1,c,(v+1)%k,k)

for _ in range(T):
    n,k,b = map(int,input().split())
    response = ''
    if b == 0:
        s = [True]*k 
        ricBin(1,n,0,k)   
    else:
        for i in range(k):
            if n == i+1:
                print('!',i+1)
                response = '='
                break
            else:
                print('?',i+1)
                response = input()
                if response == '=':
                    print('!',i+1)
                    break
                if response == '<':
                    s.append(False)
                else:
                    s.append(True)

        if response != '=':
            ricBin(k+1,n,0,k)

    
