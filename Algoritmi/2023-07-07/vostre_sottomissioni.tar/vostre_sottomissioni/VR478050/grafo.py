#/usr/bin/env python3
import sys, os
import resource

resource.setrlimit(resource.RLIMIT_STACK, (2**29,-1))
sys.setrecursionlimit(10**6)

#vr478050



def trova_cicli(L, n, m):
    cycles = []

    def dfs(nodo, path):
        if nodo in path:
            cycle_start = path.index(node)
            cycle = path[cycle_start:]
            cycles.append(cycle)
            return

        path.append(nodo)

        neighbours = L[nodo]

        if nodo in range(n):
            for neighbour in neighbours:
                dfs(neighbour, path)
        
        path.pop()




    for node in range(n):
        dfs(node, [])

    return cycles

      


def visita(visited, ciclo):

    for nodo in ciclo:
        if visited[nodo] == False:
            visited[nodo] == True

            
    
def prendi_cicli_massimi(cicli, n, m):

    #visited = [False for _ in range(n)]
    
    cicli_trovati = []

    k = 0

    #Prendo il primo
    #print(f"Appendo {cicli[k]}")
    cicli_trovati.append(cicli[k])
    
    #visita(visited, cicli[k])


    for i in range(1, len(cicli)):

        #print(f"Cicli trovati {cicli_trovati}")
        #if cicli[i][0] in cicli_trovati[k]:
            #Vado avanti
        
        if cicli[i][0] not in cicli_trovati[k]:
            #print(f"{cicli[i][0]} not in {cicli_trovati[k]}")
            cicli_trovati.append(cicli[i])
            k = k+1

    return k+1, cicli_trovati

    





# Numero di istanze del problema
T = int(input())


for t in range(T):
    n,m = map(int, input().split())
    L = [[] for _ in range(n)] #lista di adiacenza

    for e in range(m):
        a, b = map(int, input().split())
        L[a].append(b)
        L[b].append(a)

        cicli = trova_cicli(L, n, m)     
     
    
    #print(cicli)
    
    cicli.sort()

    cicli.reverse()


    kk,cicli_sistemati = prendi_cicli_massimi(cicli, n, m)
 
    print(kk) #Numero di cicli trovati
    #print(cicli_sistemati)
    stringa = ""
    for ciclo_singolo in cicli_sistemati:
        stringa = stringa+str(ciclo_singolo[0])+" "

    print(stringa)


    
           

