#/usr/bin/env python3
import sys, os
import resource
import random

resource.setrlimit(resource.RLIMIT_STACK, (2**29,-1))
sys.setrecursionlimit(10**6)

#VR478050

def individua_x(n):
    """
    if n == 1:
        lista = range(1, n+1)
    else:
        lista = range(1, n)
    
    return random.choice(lista)
    """
    return(int(input("Inserisci il numero da indovinare: ")))

#T, T ho finito
def ricerca_binaria(n, k, b, x):

    def binary_search(lista, simbolo, utente):
        
        if x == utente:
            return "="
        if x > utente:
            return ">"
        if x < utente:
            return "<"

    def inverted_binary_search(lista, simbolo, utente):
        #print(f"{x} e utente {utente}")
        if x == utente:
            return "="
        if x > utente:
            return "<"
        if x < utente:
            return ">"

        

    def risposta_server(simbolo, utente):
        if b == 0:
            #tutti gli strumenti dicono il vero
            L = [i for i in range(1,n)]
            return(binary_search(L, simbolo, utente))

        if b != 0:
            #mentitori seriali
            L = [i for i in range(1,n)]
            return(inverted_binary_search(L, simbolo, utente))

        

    #x è il numero da indovinareindividua_x
    utente = input().split()
    utente = utente[0]

    simbolo = str(utente[0])
    utente = int(utente[1:])

    fine = False
    while(not(fine)):

        

        if simbolo == "!":

            if n == 1 and utente == 1:
                return True
            
            if utente>n:
                #Out of range
                return False

            if utente == x:
                #esco
                return True
            else:
                return False

        if simbolo == "?":
            simbolo_server = risposta_server(simbolo, utente)
            if simbolo_server == True:
                return True
            else:
                print(simbolo_server)
        
        


        utente = input("").split()
        utente = utente[0]

        simbolo = str(utente[0])
        utente = int(utente[1:])
    



    


T = int(input())



for t in range(1,T+1):
    n, k, b = map(int, input().split())
    
    #numero da indovinare!!
    indovina = individua_x(n)
    
    risposta = ricerca_binaria(n, k, b, indovina)


    if risposta == True:
        print(f"x={indovina%k}")
    else:
        print("Hai sbagliato")
