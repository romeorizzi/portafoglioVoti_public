#!/usr/bin/env python3
import sys
sys.setrecursionlimit(2**9)


def dfs(current_node, counter):
    global Graph, visited, connected_components

    if visited[current_node]:
        return
    
    visited[current_node] = True
    connected_components[counter].append(current_node)


    for neighbour in Graph[current_node]:
        dfs(neighbour, counter)




testcase_num = int(input().strip())

for _ in range(testcase_num):
    nodes_num, edges_num = map(int, input().strip().split())
    Graph = [[] for _ in range(nodes_num)]
    connected_components = []

    for edge in range(edges_num):
        u, v = map(int, input().strip().split())
        visited = [None for n in range(nodes_num)]

        # grafo non orientato
        Graph[u].append(v)
        Graph[v].append(u)
        #print(Graph)

    # credo che la tattica sia trovare le componenti connesse e poi restituire un rappresentante per componente connessa
    i = 0
    for node in range(nodes_num):
        if visited[node] is None:
            connected_components.append([])
            dfs(node, i)
            i += 1

    print(len(connected_components))
    result = ""
    for component in connected_components:
        result += str(component[0]) + " "

    print(result.strip())
        



