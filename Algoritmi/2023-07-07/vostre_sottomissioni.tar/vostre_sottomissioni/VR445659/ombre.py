#!/usr/bin/env python3
import sys
from functools import lru_cache

sys.setrecursionlimit(2**9)


@lru_cache
def countIncreasingSubsequences(currentIndex, previous_choice = None):
    global sequence, memo
    # scelto l'elemento corrente posso decidere se prendere quello successivo o meno

    if currentIndex >= len(sequence):
        return 1

    elif previous_choice is None:
        # in questo caso posso sempre prendere l'elemento corrente
        takeCurrentIndex = countIncreasingSubsequences(currentIndex + 1, currentIndex)
        discardCurrentIndex = countIncreasingSubsequences(currentIndex + 1, previous_choice)
        return takeCurrentIndex + discardCurrentIndex % 1000000007
    
    elif sequence[currentIndex] > sequence[previous_choice]:
        takeCurrentIndex = countIncreasingSubsequences(currentIndex + 1, currentIndex)
        discardCurrentIndex = countIncreasingSubsequences(currentIndex + 1, previous_choice)
        return takeCurrentIndex + discardCurrentIndex % 1000000007
    
    return countIncreasingSubsequences(currentIndex + 1, previous_choice) 
    

def unrank(queriedRank, current_index, previous_choice ,  history = ""):
    """ Dato un indice nell'ordinamento mi restituisce la sottosequenza corrispondente."""
    global sequence

    print(f" queriedRank: {queriedRank}, current_index: {current_index}, previous_choice: {previous_choice}, history: {history}")
    if current_index == len(sequence):
        return history

    if queriedRank < countIncreasingSubsequences(current_index + 1, current_index) and sequence[current_index] > sequence[previous_choice]:
        # caso in cui la sottosequenza richiesta comincia prendendo l'elemento corrente
        unrank(queriedRank, current_index + 1, current_index, history + " " + str(sequence[current_index]))
    elif queriedRank >= countIncreasingSubsequences(current_index + 1, current_index) and sequence[current_index] > sequence[previous_choice]:
        # la sottosequenza richiesta scarta l'elemento corrente
        unrank(queriedRank - countIncreasingSubsequences(currentIndex + 1, previous_choice), current_index + 1, previous_choice, history)
    else:
        unrank(queriedRank, current_index + 1, previous_choice, history)



def rank(current_index, queried_rank):
    """ Data una sottosequenza mi restituisce il suo indice nell'ordinamento """










sequence = [1, 6, 2, 5, 3, 4]
memo = [[[] for el in sequence] for element in sequence]
print(memo)
print(f"Numero sottosequenze: {countIncreasingSubsequences(0)}")
print(f"Uranking 0: {unrank(0, 0, 0)}")

"""
testcase_num =  int(input().strip())

for _ in range(testcase_num):
    n, c, r, u = map(int, input().strip().split())
    sequence = list(map(int, input().strip().split()))
    R = [None for v in range(r)]
    U = []


    
    print(f"Il numero di sottosequenze crescenti è: {countIncreasingSubsequences(0, )}")

    for row in range(r):
        R[row] = list(map(int, input().strip().split()))

    if u != 0:
        U = list(map(int, input().strip().split()))

"""