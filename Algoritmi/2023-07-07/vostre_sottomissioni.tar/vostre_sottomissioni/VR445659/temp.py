#!/usr/bin/env python3
import sys
from functools import lru_cache

sys.setrecursionlimit(2**9)

#@lru_cache
def countIncreasingSubsequences(currentIndex, previous_choice = None):
    global sequence, memo
    # scelto l'elemento corrente posso decidere se prendere quello successivo o meno
    print(f"currentIndex: {currentIndex} previous_choice: {previous_choice}")
    if currentIndex >= len(sequence):
        return 1

    elif previous_choice is None:
        if memo[currentIndex][previous_choice] is None:
            # in questo caso posso sempre prendere l'elemento corrente
            takeCurrentIndex = countIncreasingSubsequences(currentIndex + 1, currentIndex)
            discardCurrentIndex = countIncreasingSubsequences(currentIndex + 1, previous_choice)
            memo[currentIndex][previous_choice] = takeCurrentIndex + discardCurrentIndex % 1000000007
        return memo[currentIndex][previous_choice]
    
    elif sequence[currentIndex] > sequence[previous_choice]:
        if memo[current_index][previous_choice] is None:
            # in questo caso posso sempre prendere l'elemento corrente
            takeCurrentIndex = countIncreasingSubsequences(currentIndex + 1, currentIndex)
            discardCurrentIndex = countIncreasingSubsequences(currentIndex + 1, previous_choice)
            memo[current_index][previous_choice] = takeCurrentIndex + discardCurrentIndex % 1000000007
        return memo[current_index][previous_choice]
    
    return countIncreasingSubsequences(currentIndex + 1, previous_choice) 
    


sequence = [1, 6, 2, 5, 3, 4]
memo = [[None for el in sequence] for element in sequence]
print(f"memo: {memo} ")
print(f"Numero sottosequenze: {countIncreasingSubsequences(0)}")
"""
testcase_num =  int(input().strip())

for _ in range(testcase_num):
    n, c, r, u = map(int, input().strip().split())
    sequence = list(map(int, input().strip().split()))
    R = [None for v in range(r)]
    U = []


    
    print(f"Il numero di sottosequenze crescenti è: {countIncreasingSubsequences(0, )}")

    for row in range(r):
        R[row] = list(map(int, input().strip().split()))

    if u != 0:
        U = list(map(int, input().strip().split()))

"""