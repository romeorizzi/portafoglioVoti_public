#/usr/bin/env/python3

def dfs(n):
    if V[n]:
        if S[n]:
            return n
        
        return None

    V[n] = True
    S[n] = True

    for e in G[n]:
        c = dfs(e)

        if c is not None:

            if n == c:
                return None
            
            else:
                return c

    S[n] = False

T = int(input())

for _ in range(T):
    N, M = map(int, input().split())
    
    G = [[] for _ in range(N)]
    R = []

    for _ in range(M):
        a, b = map(int, input().split())

        G[a].append(b)
    
    i = 0

    while i < N:
        V = [False for _ in range(N)]
        S = [False for _ in range(N)]

        dfs(i)
        
        r = []
        for j in range(len(V)):
            if V[j]:
                r.append(j)

        c = 0
        if len(R) > 0:
            for e in R:
                if set(r).issubset(set(e)):
                    c = c + 1
                    break
        
        if c == 0:
            R.append(r)

        i = i + 1

    print(f"{len(R)}")
    print(" ".join([str(R[z][0]) for z in range(len(R))]))
        
    
