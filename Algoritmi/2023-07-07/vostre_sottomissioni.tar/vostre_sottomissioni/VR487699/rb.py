#/usr/bin/env/python3

T = int(input())

for _ in range(T):
    n, k, b = map(int, input().split())

    start = 1
    end = n

    if n > 2:
        if b == 0:
            while end - start > 0:
                m = (start + end) // 2
                print(f"?{m}")

                c = input()

                if c == ">":
                    if m == end -1:
                        m = end

                    start = m + 1
                
                elif c == "<":
                    if m == start + 1:
                        m = start

                    end = m - 1

                elif c == "=":
                    break

            print(f"!{m}")
            
        elif b == 1:
            print("To do")
                
    elif n > 1:
        
        print(f"?2")

        c = input()

        if c == "=":
            print(f"!2")
            
        elif c == "<":
            print(f"!1")
            
    else:
        print("!1")