class Graph:
        # Inizializzo il grafo con il numero di nodi che fornisco in input 
        def __init__(self, V):
            self.V = V
            self.adj = [[] for i in range(V)] 
        
        def DFSUtil(self, temp, v, visited):
            #Segno il vertice corrente come visitato
            visited[v] = True

            #Memorizzo il vertice in una lista
            temp.append(v)

            for i in self.adj[v]:
                if visited[i] == False:
                    temp = self.DFSUtil(temp, i , visited)
            return temp

        def addEdge(self, v, w):
            self.adj[v].append(w)
            self.adj[w].append(v)

        
        def numconnectedComponents(self):
            visited = []
            cc =[]
            count = 0

            for i in range(self.V):
                visited.append(False)
            for v in range(self.V):
                if visited[v] == False:
                    temp = []
                    cc.append(self.DFSUtil(temp, v, visited))
                    count += 1                    
            return count



        def connectedComponents(self):
            visited = []
            cc =[]
            vv = []
            for i in range(self.V):
                visited.append(False)
            for v in range(self.V):
                if visited[v] == False:
                    temp = []
                    cc.append(self.DFSUtil(temp, v, visited))
                    vv.append(v)
            return vv
        

if __name__ == "__main__":
    count = 0
    num_testcases = int(input())
    for t in range(num_testcases):
        n,m = map(int, input().strip().split())
        g = Graph(n)
        for _ in range(m):
            u, v = map(int, input().strip().split())
            g.addEdge(u,v)

        count = g.numconnectedComponents()
        print(count)
        cc = g.connectedComponents()
        for c in cc:
            print(c, end = " ")
        print()

