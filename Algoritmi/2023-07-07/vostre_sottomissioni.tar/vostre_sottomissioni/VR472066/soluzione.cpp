#include <bits/stdc++.h>
using namespace std;

class Graph {
    int V;
    list<int>* adj;
    void DFS(int v, bool visitati[]);

    public:
        Graph(int V);
        ~Graph();
        void addEdge(int v, int w);
        int numCompConn();
        void compConn();
};

Graph::Graph(int V) {
    this->V = V;
    adj = new list<int>[V];
}

void Graph::addEdge(int v, int w) {
    adj[v].push_back(w);
    adj[w].push_back(v);
}

void Graph::DFS(int v, bool visitati[]) {
    visitati[v] = true;

    list<int>::iterator i;
    for(i = adj[v].begin(); i != adj[v].end(); ++i) {
        if(!visitati[*i]) {
            DFS(*i, visitati);
        }
    } 
}

int Graph::numCompConn() {
    bool* visitati = new bool[V];
    int conto = 0;
    for(int v = 0; v < V; v++) {
        if(visitati[v] == false) {
            DFS(v, visitati);
            conto += 1;
        }
    }
    return conto;
}

void Graph::compConn() {
    bool* visitati = new bool[V];
    for(int v = 0; v < V; v++) {
        visitati[v] = false;
    }

    for(int v = 0; v < V; v++) {
        if(visitati[v] == false) {
            DFS(v, visitati);
            cout << v << " ";
        }
    }
    delete[] visitati;
}

Graph::~Graph() { delete[] adj; }

int main() {
    int t, n, m;
    int v, w;
    int conto;

    cin >> t;
    for (int i = 0; i < t; i++) {
        cin >> n >> m;
        Graph g(n);
        for(int j = 0; j < m; j++) {
            cin >> v >> w;
            g.addEdge(v, w);
        }
        conto = g.numCompConn();
        cout << conto << "\n";
        g.compConn();
        cout << "\n";
    }
}