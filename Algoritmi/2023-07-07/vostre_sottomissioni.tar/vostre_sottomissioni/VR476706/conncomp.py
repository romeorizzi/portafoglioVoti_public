GRAPH = {}
VISITED = []
RIS = []
LOCAL_VISITED = []


def search(n, node, sub):
    global GRAPH, VISITED, LOCAL_VISITED, RIS

    if node == None:
        if LOCAL_VISITED not in RIS:
            RIS.append(LOCAL_VISITED)
    else:
        VISITED.append(node)
        LOCAL_VISITED.append(node)
        for child in GRAPH[node]:
            if child not in VISITED:
                search(n, child, [child] + sub)
        search(n, None, sub)



def search_node(n):
    global VISITED, RIS, LOCAL_VISITED

    for node in range(n):
        if node not in VISITED:
            LOCAL_VISITED = []
            search(n, node, [node])
            if node == 0 and len(VISITED) == n:
                RIS = [VISITED]
                return



def main():
    global GRAPH, RIS, VISITED

    t = int(input())
    for _ in range(t):
        GRAPH = {}
        RIS = []
        VISITED = []

        temp = list(map(int, input().split()))
        n, m = temp[0], temp[1]
        
        for e in range(m):
            temp = list(map(int, input().split()))
            v1, v2 = temp[0], temp[1]
            if v1 not in GRAPH.keys():
                GRAPH[v1] = [v2]
            else:
                GRAPH[v1].append(v2)
            
            if v2 not in GRAPH.keys():
                GRAPH[v2] = [v1]
            else:
                GRAPH[v2].append(v1)

        search_node(n)

        print(len(RIS))
        ris = ""
        for r in RIS:
            ris += str(r[0]) + " "
        print(ris)


if __name__ == '__main__':
    main()