SHADOWS = []


def ranking(r):
    global SHADOWS

    s = ""
    for x in r:
        s+= str(SHADOWS.index(x)) + " "
    return s


def unranking(u):
    global SHADOWS

    for x in u:
        s = ""
        for y in SHADOWS[x]:
            s += str(y) + " "
        print(s)
        


def count_rec(S, num, i, l):
    global SHADOWS

    if i == len(S):
        if l not in SHADOWS:
            SHADOWS.append(l)
    else:
        for j in range(i+1, len(S)):
            if S[j] > S[num] and S[j] > S[l[-1]]:
                if l not in SHADOWS:
                    SHADOWS.append(l)
                count_rec(S, num, j, l + [j])
            else:
                count_rec(S, num, j, l)
        count_rec(S, num, len(S), l)


def count(S):
    global SHADOWS

    for s in range(len(S)):
        count_rec(S, s, s, [s])
    
    SHADOWS.append([])
    return len(SHADOWS)


def main():
    global SHADOWS

    t = int(input())
    for _ in range(t):
        SHADOWS = []

        temp = list(map(int, input().split()))
        n, c, r, u = temp[0], temp[1], temp[2], temp[3]
        S = list(map(int, input().split()))
        
        R = []
        for _ in range(r):
            R.append(list(map(int, input().split())))

        U = []
        if u > 0:
            U = list(map(int, input().split()))
        

        if c == 0:
            print()
        else:
            count(S)
            print(len(SHADOWS) % 1000000007)
            #print(SHADOWS)
        
        if len(R) == 0:
            print()
        else:
            print(ranking(R))
        
        if len(U) == 0:
            print()
        else:
            unranking(U)


if __name__ == '__main__':
    main()