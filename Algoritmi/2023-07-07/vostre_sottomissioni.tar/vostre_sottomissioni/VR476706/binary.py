import math


FINISHED = False
TOOLS = {}


def read_from_server():
    return input()      # risposta del server


def guess(server_answer, last_answ, start, end, tool):
    global FINISHED

    if TOOLS[tool]:
        if server_answer == '<':
            return start, last_answ
        elif server_answer == '>':
            return last_answ, end
        elif server_answer == '=':
            return last_answ, last_answ
        else:
            return start, end
    else:
        pass # non implementato

    return start, end


def propose(start, end):
    global FINISHED
    
    if end == start:
        FINISHED = True
        return start, "!"
    else:
        return start + math.ceil((end-start)/2), "?"


def main():
    global FINISHED, TOOLS

    t = int(input())
    for _ in range(t):
        FINISHED = False
        turn = 0
        count = 1

        temp = list(map(int, input().split()))
        n, k, b = temp[0], temp[1], temp[2]

        for i in range(k):
            if b == 0:
                TOOLS[i] = True
            else:
                TOOLS[i] = None
        
        last_read = ""
        last_answ = None
        start = 1
        end = n
        while not FINISHED:
            if turn == 0:
                start, end = guess(last_read, last_answ, start, end, count % k)
                last_answ, prefix = propose(start, end)

                print(prefix + str(last_answ))   # risposta del problem solver

                turn = 1
                count+=1
            else:
                last_read = read_from_server()
                turn = 0


if __name__ == '__main__':
    main()