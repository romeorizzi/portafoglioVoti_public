# (NAME_ERASED_FOR_PRIVACY) VR463860


T = int(input())

for _ in range(T):
    V,E = map(int,input().split())

    ADJ_LIST = [[] for _ in range(V)]

    # BUILDING ADJ LIST
    for _ in range(E):
        v1,v2  = map(int,input().split())
        ADJ_LIST[v1].append(v2)
        ADJ_LIST[v2].append(v1)

    # SOLUTION
    VISITED = [False for _ in range(V)]

    def dfs(v):
        VISITED[v] = True
        for neighbor in ADJ_LIST[v]:
            if not VISITED[neighbor]:
                dfs(neighbor)
    def not_cc():
        sol = []
        for v in range(V):
            if not VISITED[v]:
                dfs(v)
                sol.append(v)
        return sol

    sol = not_cc()

    output = str(len(sol)) + "\n"

    for v in sol:
        output += str(v) + " "

    print(output)
