# (NAME_ERASED_FOR_PRIVACY) VR463860

T = int(input())

for _ in range(T):

    N,C,R,U = map(int,input().split())

    S = list(map(int,input().split()))

    I = []
    if R != 0:
        for _ in range(R):
            I.append(list(map(int,input().split())))

    F = []
    if U != 0:
        F = list(map(int,input().split()))
    else:
        input()

    # COUNT NAIVE IMPLEMENTATION
    def count_n(i,limit):
        if i == N:
            return 1

        include_it = 0
        not_include_it = 0

        if S[i] > limit: 
            include_it += count(i+1,S[i]) 

        not_include_it += count(i+1,limit)

        return include_it + not_include_it

    # COUNT BOTTOM UP DYNAMIC PROGRAMMING
    def count_dp():
        M = [0 for _ in range(N)]

        for i in reversed(range(N)):
            sol = 1
            for j in range(i+1,N):
                if S[i] < S[j]:
                    sol += M[j]
            M[i] = sol+1

        return M[0]

    def rank(indexes,output):

        if not indexes:
            return count_dp()

        M = [None for _ in range(count_dp())]

        global t 

        t = 0

        def visit(i,limit,l):

            global t

            if i == N:
                M[t] = l[:]
                t+=1
                return 

            if S[i] > limit: 
                l.append(S[i])
                visit(i+1,S[i],l[:]) 

            visit(i+1,limit,l[:])

        visit(0,-1,[])
        
        return 0

    def unrank():
        # TODO
        pass

    # OUTPUT
    output = ""
    
    if C != 0:
        output += str(count_dp())
    else:
        output += "\n"

    if R != 0:
        for i in range(R):
            rank(I[i],output)
    if U != 0:
        pass

    print(output)
