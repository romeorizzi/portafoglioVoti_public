#/usr/bin/env python3

def ricerca(end, strumenti, vero):

    t = end
    if(end == 1):
        return "1"

    if(vero == 0): #non ci sono falsi
        start = 0
        temp = 0
        while(end - start > 0):
            #print(f"{start} != {end}")
            temp = (start + end) // 2
            print(f"?{temp}")
            choice = input()
            #print(f"temp:{temp} start:{start} end:{end}")
            if(choice == "="):
                return temp
            elif(choice == "<"):
                end = temp
                if end == 1:
                    return 1
            else:
                start = temp
                if(start == 1):
                    return start+1
                if(end-start == 1):
                    return t

        
    elif(vero == 1): #ho degli strumenti falsi
        #cerco di capire chi mente ponendo una domanda "assurda" -> soluzione > del limite n
        #se mi risponde vero, palesemente è un falso tale strumento
        #viceversa so che quello strumento è affidabile.
        risposte = [[] for _ in range(strumenti)]
        for i in range(strumenti):
            print(f"?{n+1}")
            risposte[i] = input()

        #print(risposte)
        #Proseguo con la mia indagine, ponendo domande sensate a tutti
        start = 1
        temp = 0
        ct = 0
        while(end-start > 0):
            #print(f"{start} != {end}")
            #print(ct)
            temp = (start + end) // 2
            print(f"?{temp}")
            choice = input()
            #print(f"temp:{temp} start:{start} end:{end}")
            #print(test_con_falsi(temp, risposte[ct]))
            #print(risposte[ct])
            if(choice == "="):
                return temp
            elif(choice == "<" and risposte[ct] == "<"): #strumento affidabile
                end = temp
                if end == 1:
                    return 1
            elif(choice == "<" and risposte[ct] == ">"): #strumento inaffidabile, domanda al contrario
                start = temp
                if(start == 1):
                    return start+1
                if(end-start == 1):
                    return t
            elif(choice == ">" and risposte[ct] == "<"): #strumento affidabile
                start = temp
                if(start == 1):
                    return start+1
                if(end-start == 1):
                    return t
            elif(choice == ">" and risposte[ct] == ">"): #strumento inaffidabile, domanda al contrario
                end = temp
                if end == 1:
                    return 1
            if(ct == strumenti -1):
                ct = 0
            else:
                ct = ct + 1
    
    return temp




T = int(input())

for _ in range(T):
    n,k,b = map(int, input().split())
    #print(n)
    #print(k)
    #print(b)

    #b = 0 -> tutti gli strumenti dicono il vero
    #b = 1 -> potrebbero mentire, dice il vero solo se x=x indovino il numero

    print(f"!{ricerca(n,k,b)}")