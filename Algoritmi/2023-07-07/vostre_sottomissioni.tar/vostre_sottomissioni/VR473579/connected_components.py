#/usr/bin/env python3


T = int(input())
visitato = set()
componenti = []

def dfs(nodo, componente):
    global L
    visitato.add(nodo)
    componente.append(nodo)

    for vicino in L[nodo]:
        if vicino not in visitato:
            dfs(vicino, componente)

def componenti_connesse(g):
    global visitato, componenti
    ct = 0
    for nodo in g:
        if nodo not in visitato:
            dfs(nodo, componenti)
            ct = ct + 1
            #print(componenti)
    return ct


for _ in range(T):
    N,M = map(int, input().split())
    #print(N)
    #print(M)
    L = [[] for _ in range(N)]
    for i in range(M):
        a1, a2 = map(int, input().split())
        L[a1].append(a2)
        L[a2].append(a1)
    
    

    #print(L)
    sol = componenti_connesse(range(N))
    print(sol)

    if sol == 1: #Tutti i nodi sono connessi, ho 1 sola componente
        print(componenti[0]) #stampo un nodo a caso in quanto sono tutti connessi
    else: #I nodi non sono tutti connessi, ci sono più componenti
        #print(componenti)
        print(f"{componenti[0]} {componenti[-1]}")
    
