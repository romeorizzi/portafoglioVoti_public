import sys

def binary_search(n,k,b):
    low = 1
    high = n

    while low <= high:
        mid = (low + high) // 2

        query = "?{}".format(mid)
        print(query)
        sys.stdout.flush()

        response = input().strip()

        if response == "<":
            high = mid - 1
        elif response == ">":
            low = mid + 1
        else:
            if mid == 1:
                print("!{}".format(mid-1))
                sys.stdout.flush()
                return
            else:
                query = "?{}".format(mid)
                print(query)
                sys.stdout.flush()
                response = input().strip()

                if response == "<":
                    print("!{}".format(mid-1))
                    sys.stdout.flush()
                elif response == ">":
                    print("!{}".format(mid-1))
                    sys.stdout.flush()
    print("!{}".format(low))
    sys.stdout.flush()


T = int(input())

for _ in range(T):
    n, k, b = map(int, input().split())
    binary_search(n,k,b)

