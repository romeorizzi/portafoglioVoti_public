from collections import defaultdict
from collections import deque

def no_connected(graph):
    n = len(graph)
    visited = [False] * n
    subset = []

    for node in range(n):
        if not visited[node]:
            queue = deque([node])
            visited[node] = True
            subset.append(node)

            while(queue):
                curr_node = queue.popleft()

                for neighbor in graph[curr_node]:
                    if not visited[neighbor]:
                        visited[neighbor] = True
                        queue.append(neighbor)
    return subset


T = int(input())

for _ in range(T):
    n_nodi, n_archi = map(int, input().split())
    # grafo = [[] for _ in range (n_nodi)]
    graph = defaultdict(set)
    for _ in range(n_archi):
        u, v = map(int, input().split())
        graph[u].add(v)
        graph[v].add(v)
    
    subset = no_connected(graph)

    print(len(subset))

    print(" ".join(str(node) for node in subset))