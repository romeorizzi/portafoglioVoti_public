#include <stdio.h>
#include <stdlib.h>

void dfs(int node, int** graph, int* visited, int p, int n) {
    visited[node] = p;
    for(int i = 0; i < n; ++i) {
        if(graph[node][i] && !visited[i]) {
            dfs(i, graph, visited, p, n);
        }
    }
}

int main() {
    int T;
    scanf("%d", &T);

    for(int t = 0; t < T; ++t) {
        int n, m;
        scanf("%d %d", &n, &m);

        int** graph = (int**)malloc(n * sizeof(int*));
        for(int i = 0; i < n; ++i) {
            graph[i] = (int*)calloc(n, sizeof(int));
        }

        for(int i = 0; i < m; ++i) {
            int u, v;
            scanf("%d %d", &u, &v);
            graph[u][v] = 1;
            graph[v][u] = 1;
        }

        int* visited = (int*)calloc(n, sizeof(int));
        int count = 0;
        int* P = (int*)malloc(n * sizeof(int));
        int p_index = 1;

        for(int i = 0; i < n; ++i) {
            if(!visited[i]) {
                count++;
                dfs(i, graph, visited, count, n);
            }
        }

        P[0] = 1;

        printf("%d\n", count);
        for(int j = 0; j < p_index; ++j) {
            printf("%d", P[j]);
        }
        printf("\n");

        for(int i = 0; i < n; ++i) {
            free(graph[i]);
        }
        free(graph);
        free(visited);
        free(P);
    }
    return 0;
}