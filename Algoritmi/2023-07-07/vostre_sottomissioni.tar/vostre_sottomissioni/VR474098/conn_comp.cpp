#include <bits/stdc++.h>

using namespace std;

class Graph {

    int V;
    list<int>* lista_adiacenza;
    void dfs(int v, bool visitati[]);

    public:
        Graph(int V);

        ~Graph();

        void aggiungi_arco(int v, int u);

        int n_componenti();

        void componenti_connesse();
};

    Graph::Graph(int V) {

        this->V = V;
        lista_adiacenza = new list<int>[V];

    }


    void Graph::dfs(int v, bool visitati[]) {

        visitati[v] = true;

        list<int>::iterator i;

        for(i = lista_adiacenza[v].begin(); i != lista_adiacenza[v].end(); ++i) {
            if(!visitati[*i]) {
                dfs(*i, visitati);
            }
        }
    }

    //aggiungo nella lista di adiacenza i nodi
    void Graph::aggiungi_arco(int v, int u) {

        lista_adiacenza[v].push_back(u);
        lista_adiacenza[u].push_back(v);

    }

    //ritorno il conteggio per i visitati
    int Graph::n_componenti() {

        bool* visitati = new bool[V];
        int conteggio = 0;
        for(int v = 0; v < V; v++){
            if(visitati[v] == false){
                dfs(v, visitati);
                conteggio += 1;
            }
        }
        return conteggio;

    }

    //cerco visitati ed elimino
    void Graph::componenti_connesse() {

        bool* visitati = new bool[V];

        for(int v = 0; v < V; v++){
            if(visitati[v] == false){
                dfs(v, visitati);
                cout << v << " ";
            }
        }

        delete[] visitati;

    }

    Graph::~Graph() { 
        
        delete[] lista_adiacenza; 
        
    }

    //passo nel main e calcolo conteggio
    int main() {

        int t, n, m, v, u, conteggio;

        cin >> t;

        for(int i = 0; i < t; i++){

            cin >> n >> m;

            Graph g(n);

            for(int j = 0; j < m; j++){
                cin >> v >> u;
                g.aggiungi_arco(v, u);
            }

            conteggio = g.n_componenti();
            cout << conteggio << "\n";
            g.componenti_connesse();
            cout << "\n";

        }

    }
