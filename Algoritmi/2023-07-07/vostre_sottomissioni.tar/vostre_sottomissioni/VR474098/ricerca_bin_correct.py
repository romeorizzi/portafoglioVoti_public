import sys, os
import resource

resource.setrlimit(resource.RLIMIT_STACK, (2**29, -1))
sys.setrecursionlimit(10**6)

#chiedo input per indovinare
def x_ind(n):
    return(int(input("Inserisci un numero per indovinare: ")))


def ric_bin(n, k, b, x):

    def bs(lis, simbolo, utente):

        #eseguo controlli su x
        if x == utente:
            return True
        if x > utente:
            return ">"
        if x < utente:
            return "<"

    def invert_bs(lis, simbolo, utente):
        #eseguo controlli su x
        if x == utente:
            return True
        if x > utente:
            return ">"
        if x < utente:
            return "<"



    def risposta_s(simbolo, utente):

        if b == 0:
            L = [i for i in range (1, n)]
            return(bs(L, simbolo, utente))

        if b != 0:
            L = [i for i in range (1, n)]
            return(invert_bs(L, simbolo, utente))


    utente = input().split()
    utente = utente[0]

    simbolo = str(utente[0])
    utente = int(utente[1:])

    fine = False

    #finche non ho finito
    while(not(fine)):

        if simbolo == "!":
            if n == 1 and utente == 1:
                return True

            if utente > n :
                return False

            if utente == x:
                return True
            else:
                return False

        if simbolo == "?":
            simbolo_se = risposta_s(simbolo, utente)
            if simbolo_se == True:
                return True
            else:
                print(simbolo_se)


        utente = input("").split()
        utente = utente[0]

        simbolo = str(utente[0])
        utente = int(utente[1:])

T = int(input())

#prendo input
for t in range(T+1):
    n,k,b = map(int, input().split())

    indo = x_ind(n)

    risp = ric_bin(n, k, b, indo)

    if risp == True:
        print(f"x={indo%k}")
    else:
        print("Hai sbagliato")


