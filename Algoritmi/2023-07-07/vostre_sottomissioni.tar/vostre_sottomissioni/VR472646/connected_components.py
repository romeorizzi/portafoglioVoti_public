T = int(input())
for i in range(T):
    # nodi n, archi e
    n,e = map(int, input().split())
    # prendo il primo arco e creo la prima cc
    soluz = [set(input().split())]
    #per ogni arco prendo v e u
    for j in range(e-1):
        v,u = input().split()
        vi = -1
        ui = -1
        # controllo se uno dei due archi o entrambi compare 
        #nella lista delle cc e salvo la posizione della cc relativa
        for k in range(len(soluz)):
            if v in soluz[k]:
                vi = k
            if u in soluz[k]:
                ui = k
        # se i due nodi sono nella stessa cc non è necessario fare nulla
        if ui == vi and vi != -1:
            continue
        # se non ci sono cc che hanno entrambi i due nodi ne creo uno nuovo
        if ui == -1 and vi == -1:
            soluz.append(set([u,v]))
        # se trovo solo un solo nodo in un cc aggiungo l'altro nodo a quel cc
        elif ui == -1:
            soluz[vi].add(u)
        elif vi == -1:
            soluz[ui].add(v)
        # se entrambi i nodi sono in cc diverse unisco le due cc 
        else:
            soluz[min(ui,vi)] = soluz[ui].union(soluz[vi])
            del soluz[max(ui,vi)]
    print(len(soluz))
    if len(soluz) == 1:
        print('0')
    else:
        result = ' '.join(map(str, [list(sol)[0] for sol in soluz])) 
        print(result)