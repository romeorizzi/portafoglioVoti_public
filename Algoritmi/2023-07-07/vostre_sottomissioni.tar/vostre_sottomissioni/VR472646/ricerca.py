T = int(input())

for test in range(T):
    n, k, b = map(int, input().split()) # prendo i valori che mi servono

    # se n = 1 la soluzione può essere solo che 1
    if n == 1:
        print('!1')
        continue


    end = True

    # se forse un bugiardo glielo chiedo chiedendogli se la sua soluzione  è n (il massimo)
    #le risposte attese corrette possono essere =, < ma se mi risponde con > so che è un bugiardo
    # non ci possono essere soluzioni maggiori di n
    tipo = []

    if b == 1:
        for i in range(k):
            print(f'?{n}')
            ris = input()
            if ris == '<':
                tipo.append(0)
            elif ris == '>':
                tipo.append(1)
            else:
                print(f'!{n}')
                end = False
                i = k
                continue
        n -= 1
    
    m = 0
    i = 0
    end = True

    while end:
        l = (n + m) // 2
        print(f'?{l}')
        ris = input()

        # non bugiardo, se > sposto il limite inf (m) se < sposto il limite sup (n)
        if b == 0:
            if ris == '>':
                m = l + 1
            elif ris == '<':
                n = l - 1
            else:
                print(f'!{l}')
                end = False
        # bugiardo, se < (in realtà >) sposto il limite inf (m) se > (in realtò <) sposto il limite sup (n)
        else:
            if tipo[i % k] == 1:
                if ris == '<':
                    m = l + 1
                elif ris == '>':
                    n = l - 1
                else:
                    print(f'!{l}')
                    end = False
            else:
                if ris == '>':
                    m = l + 1
                elif ris == '<':
                    n = l - 1
                else:
                    print(f'!{l}')
                    end = False
        
        if n == m:
            print(f'!{n}')
            end = False
        i += 1

