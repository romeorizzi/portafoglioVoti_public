

def dfs(n):
    if V[n]:
        return
    
    V[n]=True
    con.append(n)
    # print(L,V)

    for nbr in L[n]:
        # print(n," -- >", nbr)
        if V[nbr] == False:
            dfs(nbr)



T = int(input())
for _ in range(T):

    N,M = map(int,input().strip().split())
    L = [[] for _ in range(N)]
    V = [False for _ in range(N)]
    con = []
    comp = []

    # construiamo il grapho
    for _ in range(M):
        u,v = map(int,input().strip().split())
        L[u].append(v)
        L[v].append(u)  # non-directed


    for i in range(N):
        if V[i]:
            continue

        
        dfs(i)
        comp.append(str(i)) # scelgo uno a caso per restituirlo
        
        # ho coperto tutto il grapho
        if all(V):
            # print(con) 
            break

    print(len(comp))
    print(" ".join(comp))
    # s = ""
    # for i in comp:
    #     s += str(i) + " "

    # print(s)


    # for node in range(N):
    #     print(node)



    









