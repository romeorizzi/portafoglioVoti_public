from itertools import chain,combinations


T = int(input())
for _ in range(T):
    MOD = 1000000007


    memo = {}
    def counting(n,current):
        if n == 0:
            return 0
        if n == 1:
            return 1
        if (n,current) not in memo:
            memo[(n,current)] = (counting(n-1,current) + counting(n-1,current-1) +1)
        return memo[(n,current)]


    def getsubsequence(S):
        subs = [[]]
        for num in S:
            subs.extend([subseq + [num] for subseq in subs if not subseq or subseq[-1] < num])
        # print("Pssibilities",subs)
        return subs

        # for r in range(1,len(S)+1):
        #     subs.extend(combinations(S,r))
        # print("Pssibilities",subs)
        # return subs

    def rank(S,subs):
        possible_subs = getsubsequence(S)
        possible_subs.sort()
        
        rank = possible_subs.index(subs)

        return rank


    def unrank(S,rank_nr):
        possible_subs = getsubsequence(S)
        possible_subs.sort()
        # print(possible_subs)
        res = possible_subs[rank_nr]

        return res


    num, calc_fs, ranking_nr, unranking_nr = map(int,input().strip().split())
    # print(num, calc_fs, ranking_nr, unranking_nr)

    seq = input().split()
    S = []
    for n in seq:
        S.append(int(n))
    
    # print("seq real",S)


    if ranking_nr > 0:
        ranks =[[] for _ in range(ranking_nr-1)]
        print("Ranks\n")
        for i in range(ranking_nr-1): 
            temp = input().split()
            for n in temp:
                ranks[i].append(int(n))

        for seq_i in range(ranking_nr-1):
            print(ranks[seq_i])

    if unranking_nr > 0:
        print("Unranks\n")
        unranks =[]
        temp = input().split()
        for n in temp:
            unranks.append(int(n))

        print(unranks)



    if calc_fs == 1:
        t = counting(5,5) % MOD
        print(t)

    if unranking_nr <= 0:
        print("\n")
    else:
        for i in range(unranking_nr-1):
            print(unrank(S,i))
            # print("unrank(",unranks[i],")")


    if ranking_nr <= 0:
        print("\n")
    else:
        for i in range(ranking_nr-1):
            print(rank(S,ranks[i]))
            # print("rank(",ranks[i],")")
            




    # print("Ranks")
    # print(rank([1,6,2,5,3,4],[1]))
    # print(rank([1,6,2,5,3,4],[2,4]))
    # print(rank([1,6,2,5,3,4],[5]))

    # print("Unranks")
    # print(unrank([1,2,3],0))
    # print(unrank([1,2,3],1))
    # print(unrank([1,2,3],2))
    # print(unrank([1,2,3],3))
    # print(unrank([1,2,3],4))
    # print(unrank([1,2,3],5))
    
