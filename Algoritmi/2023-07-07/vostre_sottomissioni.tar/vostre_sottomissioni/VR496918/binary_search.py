def binary_search_with_lies(high,k,low = 1):
    while low <= high:
        if high == low:
            return high
        # print(low,high)
        mid =( low + high) // 2
        print("?"+ str(mid))
        res = input()

        if "=" in res:
            return mid
        elif "<" in res:
            print("?"+ str(mid+1))
            temp = input()

            if ">" in temp: # server lied
                return mid +1

            else:
                high = mid - 1
        elif ">" in res:
            if mid == 1:
                return 2
            print("?"+ str(mid-1))
            temp = input()

            if "<" in temp: # server lied
                return mid - 1
            else:
                low = mid + 1
        else:
            print(res)


def binary_search(high,low = 1):
    while low <= high:
        if high == low:
            return high

        mid =( low + high) // 2
        print("?"+ str(mid))
        res = input()

        if "=" in res:
            return mid

        elif "<" in res:
            high = mid - 1

        elif ">" in res:
            low = mid + 1

        else:
            print("Raise",res)



T = int(input())
for _ in range(T):
        
    num, k, lies = map(int,input().strip().split())

    found = False


    if lies == 1:
        res = binary_search_with_lies(num,k) # checks the server if he lied by suggesting a false number    
    else:
        res = binary_search(num)

    print("!" + str(res))   
