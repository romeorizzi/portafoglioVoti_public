

def crea_insiemi(numero_nodi,numero_archi,S,visitati,insiemi):
    
    coppia_nodi = input().split(' ')
    nodo1 = coppia_nodi[0]
    nodo2 = coppia_nodi[1]


    # Caso di fine ricerca
    if(visitati == numero_archi):
        print(str(S))

        str1 = ""

        for i in range(S):
            if str1 == "":
                str1 = str1 +insiemi[i][0]
            else:
                str1 = str1 + " "+insiemi[i][0]

        print(str1)
        return ""

    #  Primo passaggio
    if(visitati == 0):
        string = nodo1+nodo2
        insiemi.append(string)
        visitati = visitati + 1
        S = 1

    else:
        string = nodo1 + nodo2

        f1 = False
        f2 = False

        for i in range(len(insiemi)):
            for insieme in insiemi[i]:
                if nodo1 == insieme:
                    f1 = True
                if nodo2 == insieme:
                    f2 = True
                
        
        if f1 or f2:
            insiemi[0] = insiemi[0] + string
        else:
            insiemi.append(string)

        lista = []

        for insieme in insiemi:
            for i in range(len(insieme)):
                lista.append(insieme[i])


        k = 0
        for insieme in insiemi:
            for i in range(len(insieme)):
                if insieme[i] in lista:
                    k = 1
                    break

        S = len(insiemi) -k


    crea_insiemi(numero_nodi,numero_archi,S,visitati+1,insiemi)


testcases = int(input())
print("Numero di casi di Test:"+str(testcases))

for testcase in range(testcases):

    new_instance = input().split(' ')
    print("Nuova istanza:"+ new_instance[0]+' '+ new_instance[1])
    numero_nodi = int(new_instance[0])
    numero_archi = int(new_instance[1])
    crea_insiemi(numero_nodi,numero_archi,0,0,[])

