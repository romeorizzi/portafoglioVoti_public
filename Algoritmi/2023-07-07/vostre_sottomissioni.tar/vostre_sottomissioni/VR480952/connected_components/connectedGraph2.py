def N(nodo, listed, n):
    miss = list()
    for i in range(0, n):
        insert = True
        for lis in listed:
            if(i == lis or i == nodo):
                insert = False
        if(insert): miss.append(i)

    return miss[0]



def notIn(lista, nodo):
    for l in lista:
        if(l == nodo):
            return False
    return True

def find(grafo, nodo, listedNode):
    count = 0
    for (v1, v2) in grafo:
        if(v1 == nodo and notIn(listedNode, v2)): return list(map(int, [v1, v2]))
        if(v2 == nodo and notIn(listedNode, v1)): return list(map(int, [v1, v2]))
        count += 1
    return list()

def findConnected(grafo, nodo, listedNode, n):
    if (len(listedNode) == n):
        return []
    else:
        findNode = find(grafo, nodo, listedNode)
        if(len(findNode) == 0):
            return list(map(int, [nodo, N(nodo, listedNode, n)]))
        if(findNode[0] == nodo):
            listedNode.append(nodo)
            return findConnected(grafo, findNode[1], listedNode, n)
        if(findNode[1] == nodo):
            listedNode.append(nodo)
            return findConnected(grafo, findNode[0], listedNode, n)
        return list(map(int, [nodo, N(nodo, listedNode, n)]))


n = int(input())

for i in range(0, n):
    v, e = map(int, input().split())
    E = list()
    for i in range(0, e):
        E.append(list(map(int, input().split())))
    res = findConnected(E, E[0][0], list(), v-1)
    if(res == []):
        print(1)
        print(E[0][0])
    else:    
        print(len(res))
        print(str(res[0]) + ' ' + str(res[1]))
