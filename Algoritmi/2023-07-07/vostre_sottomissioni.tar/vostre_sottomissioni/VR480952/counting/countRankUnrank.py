def counting(numbers, start, end, nextNumber):
    if(start >= end):
        return 1
    else:
        if(numbers[start+nextNumber] > numbers[start]):
            return 1 + count(numbers, start+1, end, nextNumber)
        else:
            if(start+nextNumber > end):
                return 0 + count(numbers, start-1, end, 1)
            return 0 + count(numbers, start, end, nextNumber+1)


test = int(input())

n, c, r, u = map(int, input().split())

numbers = list(map(int, input().split()))

if(c=1):
    print(6 + counting(numbers, 0, n-1, 1))
if(c=0):
    print()


