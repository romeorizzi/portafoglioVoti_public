def dfs(v, L, visited):
    visited[v] = True
    for neigh in L[v]:
        if not visited[neigh]:
            dfs(neigh, L, visited)

T = int(input())
for i in range(T):
    n, m = map(int, input().split())
    L = [[] for _ in range(n)]
    for _ in range(m):
        a, b = map(int, input().split())
        L[a].append(b)
        L[b].append(a)
    visited = [False] * n
    components = []
    for v in range(n):
        if not visited[v]:
            components.append(v)
            dfs(v, L, visited)
    print(len(components))
    print(" ".join(map(str, components)))