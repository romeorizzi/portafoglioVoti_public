T = int(input())
for _ in range(T):
    n, k, b = map(int, input().split())
    sx, dx = 1, n
    if b == 1:
        while sx <= dx:
            cr = (sx + dx) // 2
            if sx == dx:
                print(f"!{cr}")
                break
            else:
                print(f"?{cr}")

            server = input()
            
            if server == "<":
                dx = cr - 1
            elif server == ">":
                sx = cr + 1
            elif server == "=":
                print(f"!{cr}")
                break
    elif b == 0:
        while sx <= dx:
            cr = (sx + dx) // 2
            if sx == dx:
                print(f"!{cr}")
                break
            else:
                print(f"?{cr}")

            server = input()
            
            if server == "<":
                dx = cr - 1
            elif server == ">":
                sx = cr + 1
            elif server == "=":
                print(f"!{cr}")
                break