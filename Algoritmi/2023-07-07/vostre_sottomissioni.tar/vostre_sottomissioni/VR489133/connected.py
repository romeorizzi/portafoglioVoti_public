import resource, sys
resource.setrlimit(resource.RLIMIT_STACK, (2**29,-1))
sys.setrecursionlimit(10**6)

def find_disjoint_nodes(graph):
    n=len(graph)
    visited=[False]*n 
    disjoint_set=[]
    
    def dfs(node):
        visited[node]= True
        for neighbor in graph[node]:
            if not visited[neighbor]:
                dfs(neighbor)

    for node in range(n):
        if not visited[node]:
            dfs(node)
            disjoint_set.append(node)
            
    return disjoint_set

T= int(input())

for _ in range(T):
    n,m = map(int, input().split())
    graph =[[]for _ in range(n)]
    for _ in range (m):
        u,v = map(int, input().split())
        graph[u].append(v)
        graph[v].append(u)

    disjoint_set=find_disjoint_nodes(graph)
    s=len(disjoint_set)
    print(s)
    print(' '.join(map (str, disjoint_set)))