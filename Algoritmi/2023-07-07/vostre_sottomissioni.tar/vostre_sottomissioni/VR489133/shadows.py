def find_shadows(sequence):
    shadows=[[]]
    ranks = [[]]

    for num in sequence:
        new_shadows = []
        new_ranks = []

        for i, shadow in enumerate(shadows):
            if len(shadow) == 0 or shadow[-1] < num:
                new_shadow = shadow + [num]
                new_ranks = ranks[i] + [len(new_shadows)+1]
                new_shadows.append(new_shadow)
                new_ranks.append(new_rank)
            
        shadows.extend(new_shadows)
        ranks.extend(new_ranks)

        shadows_with_ranks = zip (shadows, ranks)
        sorted_shadows = sorted(shadows_with_ranks, key = lambda x : x[1])

        return sorted_shadows

def get_shadows_rank(sequence, shadow):
    ranks = [1]*len(sequence)
    for i in range (1, len(sequence)):
        for j in range(i):
            if (sequence[i] > sequence[j] and ranks[i] <= ranks[j]):
                ranks[i]= ranks[j]+1
    rank =[ranks[i] for i in range(len(sequence)) if sequence[i] in shadow]
    return max(rank)

T=int(input())

for _ in range(T):
    n, c, r, u = map(int, input().split())
    sequence = list (map(int, input().split()))   
    shadows = find_shadows(sequence)
     
if c == 1:
    print(len(shadows))

if c == 0:
    rank = list(map(int, input().split()))
    for rank in ranks:
        print(rank, end=' ')