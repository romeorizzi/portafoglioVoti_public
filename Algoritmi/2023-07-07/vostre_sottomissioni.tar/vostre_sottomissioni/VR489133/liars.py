import sys

# il programma da una soluzione e io rispondo con >, < o =
def question(tool, number):
    print(f"?{number}")
    sys.stdout.flush()
    answer = input()
    return answer

# il programma verifica qual è stata la mia risposta e in base a questa fornisce nuovi valori per interval_lower e interval_higher
def resolver(n, k, b):
    interval_lower =1
    interval_higher = n
    while interval_lower <= interval_higher:
        num = (interval_lower + interval_higher)//2  #prendo il valore intermedio dell'intervallo ogni volta finchè trovo la soluzione
        answer = question(num % k, num)
        if answer == '=':
            return num
        if answer == '<':
            interval_higher = num -1
        else:
            interval_lower = num + 1
    return 'liar'                                    # se le risposte fornite non sono corrette il programma ritorna la stringa liar

T= int(input())

for _ in range(T):
    n, k, b = map(int, input().split())
    x = resolver (n, k, b)
    print(f"!{x}")
    sys.stdout.flush()
        

