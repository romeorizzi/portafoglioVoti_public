T = int(input())

for _ in range(T):

    N, C, R, U = list(map(int, input().split()))
    S = list(map(int, input().split()))
    
    def count_seq(s, s_idx = None):
        #print(f"count_seq {s[s_idx:]}, {s_idx} {s[s_idx] if s_idx is not None else 'none'}")
        if len(s) == 0:
            return 1
        res = 1
        for n in range(len(s)):
            i = s[n]
            if s_idx == None or n > s_idx and i > s[s_idx]:
                res += count_seq(s, n)
        #print(f"res : {res}")
        return res

    def rank(rs, s, start = 0):
        print(f"call rank({rs},{s})")
        
        if len(rs) < 1:
            return 0

        if rs[0] == start :
            return rank(rs[1:], s, 2)
        
        r = 0
        print(f"rs {rs}")
        last_i = start
        for i in range(start, rs[0]):
            print(f"call count_seq({s},{i})")
            call_res = count_seq(s, i)
            print(f"call res {call_res}")
            r += call_res
            last_i = i

        print(f"last i {last_i}")
        r = r + rank(rs[1:], s, last_i)
        print(f"r {r}")
        return r



    rs = [0, 4, 5]
    print(rank(rs,S))

    #I = [list(map(int, input())) for _ in R]

    #if C == 1:
    #    print(count_seq())
    #else :
    #    print("")



