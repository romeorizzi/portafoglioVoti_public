T = int(input())

for _ in range(T):

    N, E = list(map(int, input().split()))
    
    G = [[] for _ in range(N)]
    for e in range(E):
        a, b = list(map(int, input().split()))
        if b not in G[a] :
            G[a].append(b)
        if a not in G[b] :
            G[b].append(a)

    def dfs(start):
        q = []
        v = []
        q.append(start)

        while len(q) > 0:
            curr = q.pop(0)
            v.append(curr)
            for n in G[curr]:
                if n not in v and n not in q:
                    q.append(n)
        return v

    visits = []
    to_visit = [i for i in range(N)]

    while len(to_visit) > 0:
        v = to_visit[0]
        res = dfs(v)
        visits.append(res)
        for i in res:
            to_visit.remove(i)

    count = 0
    for i in visits:
        count += 1

    print(count)

    for i in visits:
        print(i[0], end=" ")
    
    print("")
