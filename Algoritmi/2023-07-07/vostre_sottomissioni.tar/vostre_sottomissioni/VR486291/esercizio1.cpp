#include <iostream>
#include <vector>

using namespace std;

void dfs(int node, vector<vector<int>>& graph, vector<bool>& visited) {
    visited[node] = true;
    for (int neighbor : graph[node]) {
        if (!visited[neighbor]) {
            dfs(neighbor, graph, visited);
        }
    }
}

vector<int> findIndependentSet(vector<vector<int>>& graph) {
    int n = graph.size();
    vector<bool> visited(n, false);
    vector<int> independentSet;

    for (int node = 0; node < n; ++node) {
        if (!visited[node]) {
            independentSet.push_back(node);
            dfs(node, graph, visited);
        }
    }

    return independentSet;
}

int main() {
    int T;
    cin >> T;

    for (int t = 0; t < T; ++t) {
        int n, m;
        cin >> n >> m;

        vector<vector<int>> graph(n);

        for (int i = 0; i < m; ++i) {
            int u, v;
            cin >> u >> v;
            graph[u].push_back(v);
            graph[v].push_back(u);
        }

        vector<int> independentSet = findIndependentSet(graph);

        cout << independentSet.size() << endl;
        for (int node : independentSet) {
            cout << node << " ";
        }

        cout << endl;
    }
    
    return 0;
}