#include <iostream>
#include <vector>

void ricerca_binaria(std::vector<int>& elenco, int k, int b) {
    int primo = 1;
    int ultimo = elenco.size();

    if(b==0) {
        if(k==1) {
            std::cout << "!1" <<std::endl;
        } else {
            int mezzo = (primo + ultimo)/2;
            std::cout << "? " << mezzo << std::endl;
            std::string io;
            std::cin >> io;

            while (primo < ultimo -1) {
                if (io == "<") {
                    ultimo = mezzo - 1;
                } else if (io == ">") {
                    ultimo = mezzo + 1;
                }

                mezzo = (primo + ultimo)/2;
                std::cout << "? " << mezzo << std::endl;
                std::cin >> io;
            }

            if (primo == ultimo) {
                std::cout << "!" << primo << std::endl;
            } else if (primo == ultimo -1){
                std::cout << "!" << primo << std::endl;
            }
        }
    }
}

int main() {
    int T;
    std::cin >> T;

    for (int i = 0; i < T; i++) {
        int n, k, b;
        std::cin >> n >> k >> b;

        std::vector<int> elenco(n);
        for (int j = 0; j < n; j++) {
            elenco[j] = j + 1;
        }

        ricerca_binaria(elenco, k, b);
    }

    return 0;
}