def ricerca_binaria(n, elenco, k, b):
    primo = 1
    ultimo = len(elenco)

    # implementazione con b == 0
    if b == 0:
        if n == 1:
            print ("!1")
        else:
            mezzo = (primo+ultimo)//2
            while primo < ultimo:
                if (mezzo-primo+1 == 0):
                    break
                else: 
                    print(f"?{mezzo}")
                    io = input()
                    if (io == "<"):
                        ultimo = mezzo-1
                        mezzo = (primo+ultimo)//2
                    elif (io == ">"):
                        primo = mezzo+1
                        mezzo = (primo+ultimo)//2
                    elif (io == "="):
                        primo = mezzo
                        ultimo = mezzo
            if (primo == ultimo):
                print(f"!{primo}")
            elif (primo == ultimo+2):
                print(f"!{primo}")

    # manca l'implementazione con b == 1
    
T = int(input()) # num partite

for _ in range(T):
    n, k, b = map(int, input().split())

    elenco = [int(i) for i in range (1,n+1)]

    ricerca_binaria(n, elenco, k, b)