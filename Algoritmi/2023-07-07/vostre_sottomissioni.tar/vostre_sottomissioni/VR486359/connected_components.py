def dfs (nodo, grafo, visitati):
    visitati[nodo] = True
    for collegati in grafo[nodo]:
        if not visitati[collegati]:
            dfs(collegati, grafo, visitati)

def indipendenti (grafo, n):
    visitati = [False]*n
    set_indipendente = []

    # ogni volta che esco dalla dfs è perchè non ho più cammini possibili da quei nodi che sto studiando
    # quindi quando mi accorgo di aver un nodo non ancora visitato so che non è connesso e lo aggiungo al set_indipendente
    for nodo in range(n):
        if not visitati[nodo]:
            # aggiungo il nodo che sto valutando nel set indipendente in quanto mal che vada, 
            # che il grafo sia completamente connesso, stamperò il primo nodo che leggo, cioè 0
            set_indipendente.append(nodo)
            # applico la dfs
            dfs(nodo, grafo, visitati)
    return set_indipendente


T = int(input()) # num di testcase da risolvere

for _ in range(T):
    n, m = map(int, input().split()) # n = vertici, m = archi
    grafo = [[] for _ in range(n)]

    # creo la lista di adiacenza, per ogni nodo scrivo quelli connessi ad esso
    for _ in range (m):
        u, v = map(int, input().split())
        grafo[u].append(v)
        grafo[v].append(u)

    # cerco un sottoinsieme dei vertici tale che nessun cammino nel grafo connette due nodi del sottoinsieme
    set_indipendente = indipendenti(grafo, n)

    print(len(set_indipendente))
    print(' '.join(map(str, set_indipendente)))