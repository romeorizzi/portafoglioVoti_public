def count_shadow(S):
    n = len(S)
    f = [1] * n

    for i in range (n):
        for j in range (i):
            if S[j] < S[i]:
                f[i] += f[j]
    
    return sum(f)+1 % 1000000007

def rank_shadow(S, I):
    n = len(S)
    f = [0] * n
    rank = 0

    for i in range (n):
        for j in range (i):
            if S[j] < S[i]:
                f[i] += f[j]
        if i in I:
            rank += f[i]
        
    return rank

def unrank_shadow(S, R):
    n = len(S)
    f = [0] * n
    rank = 0

    for i in range (n):
        for j in range (i):
            if S[j] < S[i]:
                f[i] += f[j]
        if R[i] >= f[i]:
            R[i] -= f[i]
        else:
            R.append(i)
        
    return R

T = int(input()) # num di testcase da risolvere

for _ in range(T):
    n, c, r, u = map(int, input().split())

    S = [int(numero) for numero in input().split()]
    count = count_shadow(S)
    print(count)
        
    for i in range(r):
        I = [int(numero) for numero in input().split()]
        rank = rank_shadow(S, I)
        print(rank)

    if (u!=0):
        R = [int(numero) for numero in input().split()]
        unrank = unrank_shadow(S, R)
        print(unrank)

