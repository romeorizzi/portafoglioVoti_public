import sys


def remove_value(list_num, value):
    if value in list_num:
        list_num.remove(value)

list_num=[]
def binary_search(n, k, b, low, high, liar):
    if(n == 1):
        print(f"!1")
        sys.stdout.flush()
        return
    
    if (b==1):
        if(len(list_num)==1):
            print(f"!{list_num[0]}")
            sys.stdout.flush()
            return

        if(1 in list_num):
            query= f"?1"
            print(query)

            sys.stdout.flush()
            

            response = input().strip()

            if(response == '>'):
                liar= False
                low=low+1
            else:
                liar=True
                list_num.pop(0)

                
        if(liar):        

            #select a random in list_num
            mid = list_num.pop(0)
            query= f"?{mid}"
            print(query)

            sys.stdout.flush()

            response = input().strip()

            if(response == '<'):
                return binary_search(n,k,b,low,mid,liar)

            elif response== '>':
                return binary_search(n,k,b,low,mid, liar)
            
            elif response == '=':
                print(f"!{mid}")
                return
        else:
            b=0

    if(b==0):
        if(low== high):
            print(f"!{low}")

            sys.stdout.flush()
            return
        else:
            mid = (low + high) // 2
            query= f"?{mid}"
            print(query)
            sys.stdout.flush()

            response = input().strip()

            if(response == '<'):
                    return binary_search(n,k,b,low,mid-1, liar)
            elif response== '>':
                    return binary_search(n,k,b,mid+1,high, liar)

            elif response == '=':
                print(f"!{mid}")
                return
  



T = int(input())
for _ in range(T):
    n, k, b = map(int, input().split())
    for i in range(1,n+1):
        list_num.append(i)

    binary_search(n,k,b,1,n, False)
    list_num= []