#from collections import defauldict

def search_ind_set(graph, node, visited):
    visited[node]= True
    for neighbor in graph[node]:
        visited[neighbor]=True


def max_indipendent_set(graph):
    n=len(graph)
    visited = [False] * n
    independent_set = []

    for node in range(n):
        if not visited[node]:
            independent_set.append(node)
            search_ind_set(graph, node, visited)
    
    return len(independent_set), independent_set

T = int(input())
for _ in range(T):
    n, m= map(int, input().split(" "))

    graph= {}
    for node in range(n):
        graph[node]= []

    print(graph)

    for _ in range(m):
        u, v = map(int, input().split())
        graph[u].append(v)
        graph[v].append(u)
    

    s, node_set = max_indipendent_set(graph)

    print(s)
    print(' '.join(map(str, node_set)))
        


    
