#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;
using namespace std;

int X[MAXN];
int magg(int a,int pos, int r){
  for(int j = pos; j < N; j++){
    if(a < X[j] ){
//      printf("%d < %d\n",a ,X[j] );
      r = magg(X[j], j+1, r)+1;
    }
  }
  //printf("    R = %d\n",r );
  return r;
}

int main() {

  //FILE* fi = fopen("input1.txt", "r"); 
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

//leggo lista
  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }

  int count = 0;
   
   
for(int i = 0; i < N; i++) {
      //printf("-------------- %d < %d\n",X[i] ,X[j] );
      count = count +magg(X[i],i+1,0);
        
      count++;
}

 

  printf("%d\n", count%1024);
  return 0;
}

