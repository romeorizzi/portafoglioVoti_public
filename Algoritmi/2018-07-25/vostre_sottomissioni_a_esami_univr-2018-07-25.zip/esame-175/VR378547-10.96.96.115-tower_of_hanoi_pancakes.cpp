/**
 *  Un template per la soluzione di tower_of_hanoi_pancakes
 *
 *  Autore: Romeo Rizzi, 2018-07-19
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 100

int N;
int flip[MAXN +1]; // flip[i] = 1 se nello spostamento della torre la frittalla i deve ritrovarsi flippata, flip[i] = 0 altrimenti.

void spostaDisco(int n, int from, int to) {
  printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}

unsigned long long int N_mosse(int N){
  assert(N >= 0);
  if(N == 0){
  return 0; }
  return 1 + 2 * N_mosse(N - 1);

}

void sTorre(int N, int from, int to, int pioloApp) {
  assert(N >= 0);
  if(N == 0) {
    return;
  }

  assert (N >= 1);
  sTorre(N - 1, from, pioloApp, to);
  spostaDisco(N, from, to);
  sTorre(N - 1, pioloApp, to, from);
  
}


int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       scanf("%d", &flip[i]);
    }   

    unsigned long long int m = N_mosse(N);
    // soluzione corretta per N=1 quando nessuna frittella debba ritrovarsi infine flippata:
    printf("%llu\n", m*2 );
    sTorre(N, 1, 2, 3);
    sTorre(N, 2, 3, 1);
    //sTorre(N, 3, 1, 2);
        
    return 0;
}

