#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

std::ifstream in("input.txt");
std::ofstream out("output.txt");
std::vector<int> girate;
int moves = 0;
std::string s;

void move(int m, int a, int b, int c){
    moves++;
    if(m == 1) {
        s += ("Muovi il disco ");
        s += std::to_string(m);
        s += " dal piolo ";
        s+= std::to_string(a);
        s+= (" al piolo ");
        s+= std::to_string(c);
        s+= ("\n");
    }
    else {
        move(m - 1, a, c, b);
        //s << "Muovi il disco "<< m << " dal piolo "<< a <<" al piolo " << c << std::endl;
        s += ("Muovi il disco ");
        s += std::to_string(m);
        s += " dal piolo ";
        s+= std::to_string(a);
        s+= " al piolo ";
        s+= std::to_string(c);
        s+= "\n";
        move(m - 1, b, a, c);
    }
}
void stampa(int m, int a, int c){
    s += ("Muovi il disco ");
    s += std::to_string(m);
    s += " dal piolo ";
    s+= std::to_string(a);
    s+= (" al piolo ");
    s+= std::to_string(c);
    s+= ("\n");
}

void muovi(int m, int from, int to, int support){
    if(m == 0) return;
    moves++;
    if(girate[m]) {
        // se devo portarla di la`, passo da 2 prima di andare in 3
        //stampa(m,a,b);
        //move(m-1,a,b,c);
        //stampa(m,a,c);
        //move(m-1,a,c,b);
        muovi(m-1, from, support, to);
        stampa(m, from, support);
        muovi(m-1, from, to, support);
        stampa(m, from, to);
    }
    else {
        //stampa(m-1,a,c);
        //move(m - 1, a, c, b);
        //move(m - 1, b, a, c);
    }
}

int main(){
    int discs;
    in >> discs;
    girate.resize(discs);
    std::fill(girate.begin(), girate.end(), 0);
    for(int i = 0; i < discs; i++){
        in >> girate[i];
    }

    // devo leggere anche i bit, l'idea e`: se e` zero non ho bisogno di controllare
    // se si gira la frittella, se invece e` 1 si.

    move(discs, 1, 2, 3);

    //for(int i =0; i < discs; i++){
    //    std::cout << girate[i];
    //}
    out << moves << std::endl << s;
    return 0;
}