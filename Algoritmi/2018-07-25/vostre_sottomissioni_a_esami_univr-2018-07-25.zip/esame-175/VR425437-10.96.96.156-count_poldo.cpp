#include <iostream>
#include <fstream>

using namespace std;

int N;
const int MAX_N = 100000;

int V[MAX_N];
int memo[MAX_N];

int main() {
    ifstream in;
    in.open("input.txt");

    in >> N;
    for(int i=0 ; i<N ; i++) {
        in >> V[i];
    }

    for(int i=0 ; i<N ; i++) {
        memo[i] = 1;
    }

    for(int i=N-2 ; i>=0 ; i--) {
        for(int j=i+1 ; j<N ; j++) {
            if(V[i] < V[j]) {
                memo[i] = (memo[i] + memo[j]) % 1024;
            } else if(V[i] == V[j]) {
                memo[i] = (memo[i] + memo[j] - 1) %1024;
                break;
            }
        }
    }

    int somma = 0;
    for(int i=0 ; i<N ; i++) {
        somma = (somma + memo[i]) % 1024;
    }

    ofstream out;
    out.open("output.txt");
    out << somma << endl;

    return 0;
}