#include <vector>
#include <fstream>
#include <set>
#include <iostream>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

const int MAXN = 1000000;
int N,M;
vector<int> adj[MAXN];

bool visited[MAXN];
vector<int> visited_nodes;
int cnt=0;
bool inizio=true;

void make_dfs(int node) {

    // solo per sicurezza..
    if (node == 0 && cnt%2==0 && !inizio) {
        cout << "questo mai\n";
        return;
    }

    //visited_nodes.insert(vicino);
    inizio=false;
    for (int vicino : adj[node]) {
        
        if (visited[vicino] == false) {
            //cout << vicino << " " << "visited[0]: " << visited[0] << endl;
            if (vicino == 0 && cnt%2==0) {// se ho un vicino che è 0 e ho visitato un numero pari di nodi
              //  cout << "fine\n";
                return;
            }
            if (vicino != 0) {
                visited_nodes.push_back(vicino);
                visited[vicino] = true;
                cnt++;
                make_dfs(vicino);
            }
        }
    }

}


int main() {

    in >> N;
    in >> M;

    int u,v;
    for (int i=0; i<M; i++) {
        in >> u;
        in >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    /** caso in cui il nodo 0 è adiacente ad ogni altro nodo **/
    // mi basta andare in un nodo, andare in un suo vicino e ritornare in 0 (tanto anche il vicino sarà adiacente)

    if (adj[0].size() == N-1) {
        out << "3\n";
        int k=0;
        int origine_vicino=0;
        do {
            origine_vicino = adj[0][k++];
        }  while (adj[origine_vicino].size() < 2);
        
        out << "0 " << origine_vicino << " " << adj[origine_vicino][1] << " 0\n";
        return 0;
    }

    /** gestisci il caso in cui il grafo sia completamente connesso, senza dover fare l'algoritmo **/
    bool ok=true;
    for (int i=0; i<N; i++) {
        if (adj[i].size() != N-1) {
           ok=false;
        } 
    }

    if (ok) {
        out << "3\n";
        out << "0 2 1 0\n";
        return 0;
    }
    
    /** gestisci il caso in cui il grafo non è completamente connesso **/

    // funziona per il caso in cui il grado è sempre 2

    //cout << N << " " << M;
    //cout << "inizio\n";
    inizio = true;
    make_dfs(0);

    out << visited_nodes.size()+1 << "\n";
    out << "0 ";
    for (int v : visited_nodes)
        out << v << " ";
    out << "0 ";
    out << "\n";
    // out << "3\n";
    // out << "0 2 1 0\n";
    

}