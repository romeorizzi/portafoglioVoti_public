/**
 *  Un template per la soluzione di tower_of_hanoi_pancakes
 *
 *  Autore: Romeo Rizzi, 2018-07-19
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 100

int N;
int flip[MAXN +1]; // flip[i] = 1 se nello spostamento della torre la frittalla i deve ritrovarsi flippata, flip[i] = 0 altrimenti.

int numMosse(int n){
    if(n==0) return 0;
    return 1+2*numMosse(n-1);
}

void spostaDisco(int n, int from, int to) {
    if(flip[n]==0)
        flip[n]=1;
    else
        flip[n]=0;
  printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}

void stampamosse(int n, int a, int b, int c){
    if (n==0) return;
    

    if(flip[n]==1){
        stampamosse(n-1,a,b,c);
        spostaDisco(n,a,c);
        stampamosse(n-1,b,c,a);
    }
    else{
        stampamosse(n-1,a,c,b);
        spostaDisco(n,a,b);
        stampamosse(n-1,c,a,b);
        spostaDisco(n,b,c);
        stampamosse(n-1,a,c,b);
    }
}

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       scanf("%d", &flip[i]);
    }  
    printf("%d\n", numMosse(N));
    
    stampamosse(N,1,2,3);



    return 0;
}

