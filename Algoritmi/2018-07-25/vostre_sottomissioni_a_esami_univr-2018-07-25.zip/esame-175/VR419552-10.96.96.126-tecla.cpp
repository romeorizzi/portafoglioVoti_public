#include <iostream>
#include <cassert>
#include <vector>
#include <fstream>

using namespace std;

const unsigned MAXN = 1000000;




int mof[MAXN];
int visitato[MAXN];
int ciclo[MAXN], posW = 0;

int N, M, L;
vector<int> adj[MAXN];

bool ciclo_dispari(int node, int me){
    if (visitato[node]) {
        if (mof[node] != me) {
            ciclo[posW++] = node;
            L = posW;
            return 1;
        }
        else
            return 0;
    }
    visitato[node] = 1;
    mof[node] = me;
    ciclo[posW++] = node;

    vector<int>::iterator i;
    for(i = adj[node].begin(); i < adj[node].end(); i++)
        if ( ciclo_dispari(*i , 1-me))
            return 1;
    posW--;
    return 0;
}


int main() {

    ifstream in ("input.txt");
    ofstream out ("output.txt");

    in >> N >> M;

    for(int i=0; i<M; i++){
        int a,b;
        in >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    assert (ciclo_dispari(0, 0));

    int visitatoduevolte = ciclo[L-1];
    bool r = false;

    for(int i=L-2; i>=0; i--){
        if (r)
            ciclo[L++] = ciclo[i];
        if (ciclo[i] == visitatoduevolte)
            r = true;
    }

    out << L-1 << endl;

    for (int i=0; i<L; i++)
        out << ciclo[i] << ' ';
    out << endl;

    return 0;
}