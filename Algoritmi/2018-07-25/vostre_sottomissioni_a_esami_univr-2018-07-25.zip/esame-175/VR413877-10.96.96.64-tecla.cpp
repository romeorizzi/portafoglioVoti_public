#include <cassert>
#include <cstdio>
#include<vector>
#include <iostream> 
 
using namespace std;
#define MAXN 50
int ciclo[MAXN];
int s[MAXN];
int visto[MAXN];
int pos=0;

int N,M,L;
vector<int> ad[MAXN];

bool ciclo_f(int nodo,int ms){

if(visto[nodo]){
    if(s[nodo]!=ms){

     ciclo[pos++]=nodo;
     L=pos;
     return true;
    } 
   else return false;
}

s[nodo]=ms;
ciclo[pos++]=nodo;
visto[nodo]=1;

for(int i=0;i<ad[nodo].size();i++){
  int el=ad[nodo].at(i);
  if(ciclo_f(el,1-ms)) return true;
}
}

int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif


  scanf("%d", &N);
  scanf("%d", &M);
  for(int i = 0; i < M; i++) {
    int a,b;
     scanf("%d", &a);
     scanf("%d", &b);
     ad[a].push_back(b);
     ad[b].push_back(a);
  }

  ciclo_f(0,0);

  int visitato=ciclo[L-1];
  bool continua=false;

  for(int i = L-2; i >= 0; i--) {
    if(continua) ciclo[L++]=ciclo[i];
    if(ciclo[i]==visitato) continua=true;
  }
  cout<<L-1<<endl;

  for(int i=0;i<L;i++) cout<<ciclo[i]<<" ";
 
  return 0;
}



