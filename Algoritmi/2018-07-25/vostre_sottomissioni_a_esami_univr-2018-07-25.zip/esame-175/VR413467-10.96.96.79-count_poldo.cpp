/*
count_poldo
Miglioranzi Davide
VR413467
*/

//#include <cassert>
//#include <cstdio>

//#define EVAL

#include <vector>
#include <fstream>
#ifndef EVAL
#include <iostream>
#endif

using namespace std;

#define MAXN 1000000
int N;
//int x[MAXN];

int main() {
#ifdef EVAL
  ifstream in("input.txt");
  ofstream out("output.txt");
#else
  ifstream in("att/input1.txt");
#endif

//  int max = 0;  //salvo il valore max presente nella sequenza
  
  vector<int> lista;

  in >> N;

  int mat[N];
  int tmp;
  for(int i = 0; i < N; i++){
    in >> tmp;
    lista.push_back(tmp);
    mat[i] = 0;
    for(int j = i-1; j >=0; j--){
      if(lista[j] < tmp){
        mat[i] += (mat[j] + 1)%1024;
      }
    }
  }

  int count = N;
  for(int i = 0; i < N; i++){
    count = (count + mat[i])%1024;
  }


#ifdef EVAL
  out << count << endl;
#else
  cout << count << endl;
#endif
  return 0;
}

