#include<bits/stdc++.h>

using namespace std;

#define MAX_N 20

int N;

ifstream in("input.txt");
ofstream out("output.txt");

bool lato[MAX_N];

int numMosse(int n){
    
    if(n<1)return 0;

    if(n==1)
        return 1;

    return 2*numMosse(n-1)+1;
}


//cout<<"Muovi il disco "<<  <<" dal piolo "<<  <<" al piolo "<<  <<"\n";

void stampaDisco(int n, int from, int to) {
    //printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
    out<<"Muovi il disco "<< n <<" dal piolo "<< from <<" al piolo "<< to <<"\n";
}



void stampaMosse(int n,int from, int to){

    if(n<0)return;

    if(n==0)
        return;

    int terzo = 6-from-to;
    stampaMosse(n-1,from,terzo);
    stampaDisco(n,from,to);
    stampaMosse(n-1,terzo,to);

}


int main(){
    
    in >> N;
    
    for(int i=0; i<N; i++){
        int a;        
        in >> a;
        if(a==0) {
            lato[i]=false;
        } else if (a==1) {
            lato[i]=true;
        } else {}
    }
    out<< numMosse(N) << "\n";
    stampaMosse(N,1,3);

    int m[3][N];
    int ris[3][N];
    
    for(int i=0; i<N; i++){
        for(int j=0; j<3; j++){
            m[j][i]=0;            
            ris[j][i]=0;
        }    
    }

    for(int i=0; i<N; i++){
        m[0][i]=i;
    }

    





    
    return 0;
}
