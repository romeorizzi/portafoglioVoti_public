#include<bits/stdc++.h>

using namespace std;

#define MAX_N 100000

int N;

ifstream in("input.txt");
ofstream out("output.txt");

vector<int> d;
vector<int> m;


int risolvi(){

    for(int i=N-2; i>=0; i--){
        for(int j=i+1; j<N; j++){
            if(d[i] < d[j]){
                m[i] = (m[i] + m[j]) %1024;
            } else if(d[i] == d[j]){
                m[i] = (m[i] + m[j] -1) %1024;
                break;
            }
        }
    }

    int ris=0;
    for(int i=0; i<N; i++){
        ris = (ris + m[i])%1024;
    }
    return ris;
}

int main(){
    
    in >> N;
    
    for(int i=0; i<N; i++){
        int a;        
        in >> a;
        d.push_back(a);
        m.push_back(1);
    }

    out << risolvi() << endl;
    
    return 0;
}
