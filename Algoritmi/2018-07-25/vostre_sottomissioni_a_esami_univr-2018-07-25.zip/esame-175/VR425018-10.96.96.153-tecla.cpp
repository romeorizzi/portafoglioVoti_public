#include<bits/stdc++.h>

using namespace std;

#define MAX_N 1000000

int N,M;

ifstream in("input.txt");
ofstream out("output.txt");


vector<int> d[MAX_N];
//int v[MAX_N];
//int ris[MAX_N*2];

bool vis[2][MAX_N];

void resVis(){
    for(int i=0; i<MAX_N; i++){
        vis[0][i]=false;
        vis[1][i]=false;
    }
}


bool visita(int n, int cont, int dispari){

    if(vis[dispari][n]){
        return false;
    }
    vis[dispari][n] = true;
    //ris[cont] = n;

    if(n==0 && dispari==1){
        out << cont << "\n0 ";
        return true;
    }

    bool esitoTot=false;
    
    if(dispari==0){
        dispari = 1;
    } else {
        dispari = 0;    
    }
    
    for(int v : d[n]){
        bool esito = visita(v,cont+1,dispari);
        esitoTot = esito || esitoTot;
        if(esito) out <<n<<" ";
    }
    
    return esitoTot;
/*
    if(esitoTot){     
        return true;
    }
    else{
        return false;
    }
*/
}

int main(){
    
    in >> N;
    in >> M;
    
    for(int i=0; i<M; i++){
        int a, b;
        in >> a;
        in >> b;
        d[a].push_back(b);
        d[b].push_back(a);
    }


    resVis();
    visita(0,0,0);
    out<<"\n";
    
    return 0;
}
