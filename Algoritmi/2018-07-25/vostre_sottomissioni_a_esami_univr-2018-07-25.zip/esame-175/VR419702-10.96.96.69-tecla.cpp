#include <iostream>
#include <cassert>
#include <vector>

#define DEBUG 0
using namespace std;

const unsigned MAXN = 30;
int vista[MAXN];
int g[MAXN];
int cycle[MAXN], pos = 0;
int N, M, L;
vector<int> adj[MAXN];

bool cicloPari(int node, int miog){
    if(vista[node]){
        if(g[node] != miog){
            cycle[pos++] = node;
            L = pos;
            return true;
        }
        else
            return false;
    }
    vista[node] = 1;
    g[node] = miog;
    cycle[pos++] = node;
    for(int next: adj[node])
        if(cicloPari(next, 1-miog))
            return true;
    pos--;
    return false;
}

int main(){
    assert(freopen("input.txt", "r", stdin));
    assert(freopen("output.txt", "w", stdout));
    cin >> N >> M;
    for(int i = 0; i < M; i++){
        int a, b;
        cin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    assert(cicloPari(0,0));
    int visitedTwice = cycle[L-1];
    bool repeat = false;
    for(int i = L-2; i >= 0; i--){
        if(repeat)
            cycle[L++] = cycle[i];
        if(cycle[i] == visitedTwice)
            repeat = true;
    }
    cout << L-1 << endl;
    for(int i = 0; i < L; i++)
        cout << cycle[i] << " ";
    cout << endl;
    return 0;
}
