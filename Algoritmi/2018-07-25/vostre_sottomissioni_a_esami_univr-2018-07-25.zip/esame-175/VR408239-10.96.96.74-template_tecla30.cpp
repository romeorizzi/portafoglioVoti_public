#include <cassert>
#include <cstdio>
#include <map>
#include <vector>

#define MAXN 1000001

int N,M,a,b;
using namespace std;

vector<int> percorso_vincente;
int percorsi[MAXN][3];
int dist;

bool street(int start, int count){
  if(start == 0 && count%2!=0){
    percorso_vincente.push_back(start);
    dist = count;
    return true;
  }
  else{  
    for(int j = 0; j < M; j++){
      if(percorsi[j][2] == 0 && (percorsi[j][0]==start || percorsi[j][1]==start)){
        percorsi[j][2]=1;
        if(percorsi[j][0]==start){
          percorso_vincente.push_back(percorsi[j][1]);
          bool a = street(percorsi[j][1], count+1);
          if(a){
            return true;
          }
        }else{
          percorso_vincente.push_back(percorsi[j][0]);
          bool a = street(percorsi[j][0], count+1);
          if(a){
            return true;
          }
        }
        percorsi[j][2]=0;
      }
    }
    return false;
  }
}

int main() {

  //FILE* fi = fopen("input1.txt", "r"); 
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

//leggo lista
  scanf("%d %d", &N, &M);
  for(int i = 0; i < M; i++) {
    scanf("%d %d", &percorsi[i][0], &percorsi[i][1]);
    percorsi[i][2]=0;
  }


  
  percorso_vincente.push_back(0);
  street(0,0);

 printf("%d\n",dist);

  for(int j = 0; j < percorso_vincente.size()-1; j++){
        printf("%d ", percorso_vincente[j]);
  }
  //printf("%d\n", nodi.find(0)->second[0]);
  
  return 0;
}

