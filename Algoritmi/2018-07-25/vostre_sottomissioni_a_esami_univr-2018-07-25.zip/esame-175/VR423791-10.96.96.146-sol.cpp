#include <iostream>
#include <vector>
using namespace std;
const unsigned maxn = 1000000;
int visti[maxn];
int s[maxn];
int ciclo[maxn];
int posw=0;
int n, m, l;
vector<int> adj[maxn];
bool pari (int nodo, int s1){
    if(visti[nodo]){
        if(s[nodo] != s1){
            ciclo[posw++] = nodo;
            l = posw;
            return true;
        }
        else
            return false;
    }
    visti[nodo]=1;
    s[nodo] = s1;
    ciclo[posw++] = nodo;
    for(int next: adj[nodo])
        if(pari(next, 1-s1))
            return true;
    posw--;
    return false;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "r", stdout);
    cin >> n >> m;
    for (int i =0; i<m; i++){
        int a, b;
        cin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    pari(0,0);
    int visitato = ciclo[l-1];
    bool ripeti = false;
    for (int i =0; i< l; i++)
        cout << ciclo[i] << " ";
    cout << endl;
    return 0;
}
    
