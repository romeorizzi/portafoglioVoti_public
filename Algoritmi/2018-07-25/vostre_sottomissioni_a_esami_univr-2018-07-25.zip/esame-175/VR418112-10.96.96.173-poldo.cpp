
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>

std::ifstream in("input.txt");
std::ofstream out("output.txt");
std::vector<int> arr;
std::vector<long> supp;

int countsub(int n){
    for (int i=0; i < n; i++){
        for(int j =arr[i]-1; j >= 0; j--){
            supp[arr[i]] += supp[j];
        }
        supp[arr[i]]++;
    }
    long long result = 0;
    for(int i =0; i < n; i++){
        result += supp[i];
    }
    return result%1024;
}

int main(){
    int n;
    in >> n;
    arr.resize(n);
    supp.resize(n);
    //std::fill(supp.begin(), supp.end(), 0);

    for(int i =0; i < n; i++){
        in >> arr[i];
    }

    int res = countsub(n);
    out << res;
    return 0;

}