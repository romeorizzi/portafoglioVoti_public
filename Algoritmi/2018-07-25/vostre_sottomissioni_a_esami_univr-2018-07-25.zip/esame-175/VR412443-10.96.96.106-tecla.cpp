#include <fstream>
#include <cassert>
#include <vector>

using namespace std;

const unsigned MAXN = 1000000;

int tecla = 0;
int sex[MAXN];
int visitato[MAXN];
int cycle[MAXN];

int N, M, L;
vector<int> adj[MAXN];

bool odd_cycle(int node, int mysex){
    if(visitato[node]){
        if(sex[node] != mysex){
            cycle[tecla++] = node;
            L = tecla;
            return true;
        }
        else
            return false;
    }

    visitato[node] = 1;
    sex[node] = mysex;
    cycle[tecla++] = node;

    for(int next: adj[node]){
        if(odd_cycle(next,1-mysex))
            return true;
    }

    tecla--;
    return false;
}

int main(){

    ifstream inputfile("input.txt");
    int p = 0;
    inputfile >> N;
    inputfile >> M;
    for(int i = 0; i < M; i++){
        int a, b;
        inputfile >> a;
        inputfile >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
        p++;
    }

    inputfile.close();

    odd_cycle(0,0);

    int secondoPassaggio = cycle[L-1];
    bool repeat = false;

    for(int i = L-2; i >= 0; i--){
        if(repeat)
            cycle[L++] = cycle[i];
        if(cycle[i] == secondoPassaggio)
            repeat = true;
    }

    ofstream outputfile("output.txt");

    outputfile << L-1 << '\n';
    for(int i=0; i < L; i++)
        outputfile << cycle[i] << " ";
    outputfile << '\n';

    outputfile.close();

    return 0;
}