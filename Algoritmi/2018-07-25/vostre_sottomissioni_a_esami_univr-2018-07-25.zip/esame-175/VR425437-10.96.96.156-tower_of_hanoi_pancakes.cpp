#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

const int MAX_N = 100;
int flip[MAX_N + 1];
int verso[MAX_N + 1]; // 0 = bruciatura giù

int N;
int massimo;
ofstream out;

void sposta_disco(int n, int from, int to) {
    out << "Muovi il disco " << n << " dal piolo " << from << " al piolo " << to << "\n";
}

int numero_mosse(int n, int from, int to) {
    if(n==0) {
        return 0;
    }

    int terzo = 6-from-to;
    int tot=0;

    if(n == massimo && to==3 && verso[n] == flip[n]) {
        tot += numero_mosse(n-1, from, to);
        tot += 1;
        verso[n] = !verso[n];
        tot += numero_mosse(n-1, to, from);
        tot += 1;
        verso[n] = !verso[n];
        massimo--;
        tot += numero_mosse(n-1, from, to);
    }
    else {
        tot += numero_mosse(n-1, from, terzo);
        tot += 1;
        verso[n] = !verso[n];
        if(to==3 && n==massimo) {
            massimo--;
        }
        tot += numero_mosse(n-1, terzo, to);
    }

    return tot;
}

void stampa_mosse(int n, int from, int to) {
    if(n==0) {
        return;
    }

    int terzo = 6-from-to;
    if(n == massimo && to==3 && verso[n] == flip[n]) {
        stampa_mosse(n-1, from, to);
        sposta_disco(n, from, terzo);
        verso[n] = !verso[n];
        stampa_mosse(n-1, to, from);
        sposta_disco(n, terzo, to);
        verso[n] = !verso[n];
        massimo--;
        stampa_mosse(n-1, from, to);
    }
    else {
        stampa_mosse(n-1, from, terzo);
        sposta_disco(n, from, to);
        verso[n] = !verso[n];
        if(to==3 && n==massimo) {
            massimo--;
        }
        stampa_mosse(n-1, terzo, to);
    }
}

int main() {
    ifstream in;
    in.open("input.txt");

    in >> N;
    for(int i=1 ; i<=N ; i++) {
        in >> flip[i];
        verso[i] = 0;
    }

    out.open("output.txt");

    massimo = N;
    out << numero_mosse(N, 1, 3) << endl;

    for(int i=1 ; i<=N ; i++) {
        verso[i] = 0;
    }
    massimo = N;
    stampa_mosse(N, 1, 3);

    return 0;
}