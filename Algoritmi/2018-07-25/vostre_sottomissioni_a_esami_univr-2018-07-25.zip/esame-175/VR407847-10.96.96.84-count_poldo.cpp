#include <stdio.h>
#include <vector>

std::vector<int> sequenze;
FILE* input;
FILE* output;
int N;
int result=0;
int main() {
 
  input = fopen("input.txt", "r");
 
 

  fscanf(input, "%d", &N);
  
  int aux[N];
  result=N;
  
  
  for(int i = 0; i < N; i++) {
    int a;
    fscanf(input, "%d", &a);
    sequenze.push_back(a);
    aux[i]=0;
    for(int j=i-1; j>=0; j--){
          if(sequenze[j] < a){
              aux[i]++;
              aux[i]+=aux[j];
          }
    
    }
  }
 
  fclose(input);
 
  for( int i=0; i<N; i++){
      result+=aux[i]%1024;
  }


    
    FILE* fo = fopen("output.txt", "w");
   
  fprintf(fo, "%d", result % 1024);
  fclose(fo);
  
  return 0;

  
}