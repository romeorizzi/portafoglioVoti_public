#include <cstdio>
#include <cassert>

#define MAXN 1000000

int N;

int vettore[MAXN];
int secondovett[MAXN];

int main(){

    assert(freopen("input.txt", "r", stdin));
    assert(freopen("output.txt", "w", stdout));

    scanf("%d", &N);
    
    int somma;
    somma = 0;

    for(int i = 0; i < N; i++){

        scanf("%d", &vettore[i]);

        secondovett[i] = 1;

        for(int j = i -1; j >= 0; j--){

            if(vettore[j] == vettore[i]){

                secondovett[i] = (secondovett[i] + secondovett[j] - 1)%1024;break;
            }
            else if(vettore[j] < vettore[i]){
                secondovett[i] = (secondovett[i] + secondovett[j])%1024;

            }
        }
        somma = (somma + secondovett[i]) % 1024;
    }

    printf("%d\n", somma%1024);

    return 0;
}