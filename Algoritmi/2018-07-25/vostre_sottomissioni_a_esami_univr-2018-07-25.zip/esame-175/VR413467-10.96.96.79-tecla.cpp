/*
count_poldo
Miglioranzi Davide
VR413467
*/

//#define EVAL

#include <vector>
#include <fstream>
#ifndef EVAL
#include <iostream>
#endif

using namespace std;

#define MAXN 1000000
int N, M;
vector<int> s;
int dist;
int rete[1000000][3];

bool tecla(int x, int k){
  if((x == 0) && (k%2 != 0)){
    s.push_back(x);
    dist = k;
    return true;
  }else{
    for(int i = 0; i < M; i++){
      if((rete[i][2] == 0) && ((rete[i][0] == x) || (rete[i][1] == x))){
        rete[i][2] = 1;
        if(rete[i][0] == x){
          s.push_back(rete[i][1]);
          bool test = tecla(rete[i][1], k+1);
          if(test){
            return true;
          }
        }else{
          s.push_back(rete[i][0]);
          bool test = tecla(rete[i][0], k+1);
          if(test){
            return true;
          }
        }
        rete[i][2] = 0;
      }
    }
    return false;
  }
}



int main() {
#ifdef EVAL
  ifstream in("input.txt");
  ofstream out("output.txt");
#else
  ifstream in("att/oddcycle.input0.txt");
#endif

//  int max = 0;  //salvo il valore max presente nella sequenza
  
  vector<int> lista;

  in >> N >> M;

  for(int i = 0; i < M; i++){
    in >> rete[i][0] >> rete[i][1];
    rete[i][2] = 0;
  }

  s.push_back(0);
  tecla(0,0);
#ifndef EVAL
  cout << dist << endl;
#else
  out << dist << endl;
#endif

#ifndef EVAL
  for(int i = 0; i < (s.size()-1); i++){
    cout << s.at(i) << " ";
  }
  cout << endl;
#else
  for(int i = 0; i < (s.size()-1); i++){
    out << s.at(i) << " ";
  }
  out << endl;
#endif

  



  return 0;
}

