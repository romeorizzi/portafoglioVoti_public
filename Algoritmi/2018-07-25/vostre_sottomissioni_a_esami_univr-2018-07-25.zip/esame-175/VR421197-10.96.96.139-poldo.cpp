#include <cassert>
#include <cstdio>
#include <vector>

#define MAXN 100000
#define MAXNum 1000000
using namespace std;

int N;

int X[MAXN];
vector<int> memo[MAXNum];


int search_sub(int pos, int num, int max){
    int count= 1;
    if(pos == N){
        return count;
    }

    for(int i = num; i <= max ;i++){
        if(memo[i+1].size() > 0){
            for(vector<int>::iterator it = memo[i+1].begin(); it != memo[i+1].end();it++){
                if(*it > pos){
                     count += search_sub(*it, X[*it], max);
                }


            }

        }

    }

    return count;





}


int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
    int letto = 0;
    int max=-1;

    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
        scanf("%d", &letto);
        X[i]=letto;

        if(letto > max)
            max = letto;

        memo[letto].push_back(i);
    }

    int count = 0;

    for(int i = 1; i <= N; i++){
        count += search_sub(i, X[i], max);
        //printf("X[i]:%d - count:%d \n", X[i], count);

    }

    printf("%d\n", count % 1024);
    return 0;
}
