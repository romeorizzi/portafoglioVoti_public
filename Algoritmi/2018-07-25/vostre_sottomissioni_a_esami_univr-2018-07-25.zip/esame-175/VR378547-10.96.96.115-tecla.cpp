#include <iostream>
#include <cassert>
#include <vector>
#include <stdio.h>

#define DEBUG 0

using namespace std;

const unsigned  MAXNUMBER = 1000000;
int visti[MAXNUMBER];
int pippo[MAXNUMBER];
int ciclo[MAXNUMBER];
int posiz = 0;

int N;
int M;
int U;
vector<int> adiac[MAXNUMBER];

bool odd_ciclo(int nodo, int mypippo) {
    if(visti[nodo]) {
        if(pippo[nodo] != mypippo) {
            ciclo[posiz++] = nodo;
           U = posiz;
            return true;
        }
        else
            return false;
    }
    visti[nodo] = 1;
    pippo[nodo] = mypippo;
    ciclo[posiz++] = nodo;
    for(int succ: adiac[nodo])
        if(odd_ciclo(succ, 1 - mypippo)){
            return true;
        }
    posiz--;
    return false;
}

int main() {
    
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  cin >> N >> M;

  for(int i= 0; i< M; i++){
      int a;
      int b;
      cin >> a >> b;
      adiac[a].push_back(b);
      adiac[b].push_back(a);
  }
  assert(odd_ciclo(0, 0));

  int doppie = ciclo[U-1];
  bool ripetizioni = false;
  for(int i=U-2; i>= 0; i--){
      if(ripetizioni){
        ciclo[U++] = ciclo[i];}
      if(ciclo[i] == doppie){
        ripetizioni = true;}
     } 
  cout <<U-1 << endl;
  for(int i= 0; i<U; i++)
        cout << ciclo[i] << " ";
    cout << endl;
    return 0;
  }
