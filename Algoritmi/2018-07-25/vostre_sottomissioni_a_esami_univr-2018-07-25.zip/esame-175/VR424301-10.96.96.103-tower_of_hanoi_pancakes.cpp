/**
 *  Un template per la soluzione di tower_of_hanoi_pancakes
 *
 *  Autore: Romeo Rizzi, 2018-07-19
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 100

int N;
int flip[MAXN +1]; // flip[i] = 1 se nello spostamento della torre la frittalla i deve ritrovarsi flippata, flip[i] = 0 altrimenti.

void spostaDisco(int n, int from, int to) {
  printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}

void mossa(int N, int from, int to, int temp){

    if(N==0)
        return;
    mossa(N-1, from, temp, to);
    spostaDisco(N, from, to);
    mossa(N-1, temp, to, from);
}
unsigned long long int contaMosse(int N){
    if(N == 0)
        return 0;
    return 1+2*contaMosse(N-1);
}


int main() {
#ifdef EVAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       scanf("%d", &flip[i]);
    } 
    

unsigned long long int azioni = contaMosse(N);
    // soluzione corretta per N=1 quando nessuna frittella debba ritrovarsi infine flippata:
    printf("%llu\n", azioni*2 );
    mossa(N, 1, 2, 3);
    mossa(N, 2, 3, 1);
        
    return 0;
}

