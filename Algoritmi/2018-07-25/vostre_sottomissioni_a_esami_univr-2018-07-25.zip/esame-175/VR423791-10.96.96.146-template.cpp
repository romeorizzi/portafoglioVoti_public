#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;

int X[MAXN];
int res=0;
int count[MAXN];


int conta(int n){
    count[MAXN] = 0;
    for (int i = 0; i < n; i++){
        for(int j = X[i]-1; j >= 0; j--){
            count[X[i]] += count[j];
        }
        count[X[i]]++;
    }
    res = 0;
    for (int i = 0; i<MAXN; i++)
        res += count[i];
    return res;
}

/*void conta(int ct, int k){
    if (k == N) return;
    
    // conteggio
    for (int j = k+1 ; j < N; j++){
        if (X[k] < X[j]){
            conta(tot++, j);
        }
    }
}*/



int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &N);
    for(int i = 0; i < N; i++) {
        scanf("%d", &X[i]);
    }

    printf("%d\n", conta(N)%1024);
    /*for(int i = 0; i < N; i++){
        conta(0, i);
    }

    tot = (tot+N) % 1024;
    printf("%d\n", tot);*/
    return 0;
}

