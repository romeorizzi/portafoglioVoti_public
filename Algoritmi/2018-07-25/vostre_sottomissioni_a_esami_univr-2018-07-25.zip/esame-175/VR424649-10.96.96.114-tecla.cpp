#include <cassert>
#include <cstdio>
#include <vector>
#include <algorithm>

using std::vector;

int N; 
int M;
int passi;
vector <vector <int> > adj;
vector <bool> visitato;
vector <int> soluzione;

void dfs(int start, int p){
  
  soluzione.push_back(start);
  
  if(start == 0 and passi%2==1){
    return;
  }
  passi++;
  for(int v : adj[start]){
    if(v==p) continue;
    dfs(v, start);
    break;
  }
  
   return;
}
int main(){
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif

  scanf("%d %d", &N, &M);
  adj.resize(N);

  for(int i = 0; i < M; i++) {
    int u, v;
    scanf("%d %d", &u, &v);
    adj[u].push_back(v);
    adj[v].push_back(u);
  }
  passi = 0;
  dfs(0, -1);
   
  printf("%d\n", passi);

  for(int i=0; i<soluzione.size(); i++) {
    printf("%d ", soluzione[i]);
  }


  return 0;
}
