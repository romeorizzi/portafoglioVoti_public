#include <stdio.h>
#include <vector>

int N; //numero nodi
int M; //numero filamenti
FILE* fi;

std::vector<int> matrice;
int d;
int grafo[1000000][3];




bool percorso(int inizio, int archi){
    if(inizio==0 && archi%2!=0){
        matrice.push_back(inizio);
        d= archi;
        return true;
    }
    else{
        for(int i=0; i<M; i++){
            if((grafo[i][0]==inizio || grafo[i][1]==inizio) && grafo[i][2]==0 ){
                grafo[i][2]=1;
                if(grafo[i][0]==inizio){
                    matrice.push_back(grafo[i][1]);
                    bool p = percorso(grafo[i][1], archi+1);
                    if(p){
                        return true;
                    }
                }
                else{
                    matrice.push_back(grafo[i][0]);
                    bool p = percorso(grafo[i][0], archi+1);
                    if(p){
                        return true;
                    }                
                }
                matrice.pop_back();
                grafo[i][2]=0;
            }
        }
        return false;
    }
}
int main(){

    fi = fopen("input.txt", "r");
    fscanf(fi, "%d", &N);
    printf("%d", N);
    fscanf(fi, "%d", &M);
    printf("%d", M);
    for(int i=0; i<M; i++){
            fscanf(fi, "%d %d", &grafo[i][0],&grafo[i][1]);
            
            grafo[i][2]=0;
        
    }

    matrice.push_back(0);
    percorso(0,0);

    FILE* fo = fopen("output.txt", "w");
    fprintf(fo,"%d\n", d);
    std::vector<int>::iterator ite;
    for(ite=matrice.begin(); ite!= matrice.end(); ite++){
        fprintf(fo, "%d ", *ite);
    }
    return 0;
}