//count poldo

#include <iostream>
#include <fstream>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
#define MAXN 1000000

std:: vector<int> arr;
std:: vector<long> supp;

int countsub_dp(int n){
    for(int i=0; i<n; i++){
        for(long long j = arr[i]-1; j>=0; j--){
            supp[arr[i]] += supp[j];
        }
        supp[arr[i]]++;
    }
    long long result = 0;
    for (int i =0; i<n; i++){
        result += supp[i];
    }
    result = result%1024;

    return result;
}

int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    int N;

    in >> N;
    arr.resize(N);
    supp.resize(N);

    std::fill(supp.begin(), supp.end(), 0);

    for(int i = 0; i<N; i++){
        in>>arr[i];
    }

    int res = countsub_dp(N);
    out<<res;
  return 0;
}
