#include <fstream>
#include <vector>
#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
const int MAXN = 1000000;

ifstream in("input.txt");
ofstream out("output.txt");

int posizione = 0;
int num, val, L;
int nodi_visitati[MAXN];
int stato[MAXN];
int ris[MAXN];
vector<int> grafo[MAXN];


int pari(int nodoCorrente, int statoCorrente){
    if(nodi_visitati[nodoCorrente]){
        if(stato[nodoCorrente] != statoCorrente){
            ris[posizione++] = nodoCorrente;
            L = posizione;
            return true;
        }
        else{
            return false;
        }
    }
    nodi_visitati[nodoCorrente] = 1;
    stato[nodoCorrente] = statoCorrente;
    ris[posizione++] = nodoCorrente;
    
    for(int next : grafo[nodoCorrente]){
        if(pari(next, 1-statoCorrente)){
            return true;
        }

    }
    posizione --;
    return false;

}

int main(){
    in >> num >> val;
    for(int i=0; i<val; i++){
        int a, b;
        in >> a >> b;
        grafo[a].push_back(b);
        grafo[b].push_back(a);
    }
    pari(0,0);
    
    int visitedTwice = ris[L-1];
    bool repeat = false;
    for(int i = L-2; i >= 0; i--){
        if(repeat){
            ris[L++] = ris[i];
        }
        if(ris[i] == visitedTwice){
            repeat = true;
        }
    }
    out << L-1 << endl;
    for(int i=0; i<L; i++){
        out << ris[i] << " ";
    }
    out << endl;
    return 0;
}
