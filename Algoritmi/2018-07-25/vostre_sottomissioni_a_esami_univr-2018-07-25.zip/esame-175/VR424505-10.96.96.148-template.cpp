#include <cassert>
#include <cstdio>

#define MAXN 1000000


int N;

int X[MAXN];
int nseq = 0;

int count_seq(int counter, int k) {
    // array finito
    if (k == N) 
        return nseq;
    
    for (int j = k + 1; j < N; j++) {
        if (X[j] > X[k])
            count_seq(nseq++,j);
    }
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
    
    
  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }

    // conteggio seq
    for (int i = 0; i < N; i++)
        count_seq(0,i);
    
    // seq singole
    nseq = (nseq + N) % 1024;
    printf("%d", nseq);
        
  return 0;
}





