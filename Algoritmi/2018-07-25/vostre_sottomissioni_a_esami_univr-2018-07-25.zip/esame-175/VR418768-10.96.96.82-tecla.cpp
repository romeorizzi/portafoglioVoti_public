#include<stdio.h>
#include<vector>
FILE* fi;
int N,M;
std::vector<int> sol;
int dist;
int rete[1000000][3];

bool ricorsione(int x,int k){
    if(x==0 && k%2!=0){
        sol.push_back(x);
        dist=k;
        return true;
    }else{
        for(int i=0; i<M;i++){
            if(rete[i][2]==0 &&(rete[i][0]==x || rete[i][1]==x)){
                rete[i][2]=1;
                if(rete[i][0]==x){
                    sol.push_back(rete[i][1]);
                    bool a=ricorsione(rete[i][1],k+1);
                    if(a){
                        return true;
                    }
                }else{
                    sol.push_back(rete[i][0]);
                    bool a=ricorsione(rete[i][0],k+1);
                    if(a){
                        return true;
                    }
                }
                sol.pop_back();
                rete[i][2]=0;
            }
        }
        return false;
    }
}

int main(){
    fi=fopen("input.txt","r");
    fscanf(fi,"%d %d",&N,&M);

    for(int i=0;i<M;i++){
        fscanf(fi,"%d %d",&rete[i][0],&rete[i][1]);
        printf("%d %d\n",rete[i][0],rete[i][1]);
        rete[i][2]=0;
    }

    sol.push_back(0);
    ricorsione(0,0);

    FILE* fo=fopen("output.txt","w");
    fprintf(fo,"%d\n",dist);
    std::vector<int>::iterator it;
    for(it=sol.begin();it!=sol.end();it++){
        fprintf(fo,"%d ",*it);
    }


    return 0;
}
