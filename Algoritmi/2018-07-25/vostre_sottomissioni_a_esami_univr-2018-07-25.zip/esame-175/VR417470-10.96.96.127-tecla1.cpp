#include <cassert>
#include <vector>
#include <iostream>
#include <stdio.h>
using namespace std;

const int MAXN = 1000000;

int open[MAXN];
int close[MAXN];
int ciclo[MAXN];
int pos = 0;
int N, M, L;
vector<int> lista[MAXN];

bool ciclo_dispari(int node, int count) {
    if(open[node]) {
        if(close[node] != count) {
            ciclo[pos++] = node;
            L = pos;
            return true;
        } else 
            return false;
    }
    open[node] = 1;
    close[node] = count;
    ciclo[pos++] = node;
    for(int a: lista[node])
        if(ciclo_dispari(a, 1-count))
            return true;    
    pos--;
    return false;
}

int main() {
    assert(freopen("input.txt", "r", stdin));
    assert(freopen("output.txt", "w", stdout));
    
    cin >> N >> M;
    for(int i = 0; i < M; i++) {
        int x, y;
        cin >> x >> y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }
    assert(ciclo_dispari(0,0));

    int alreadyV = ciclo[L-1];
    bool ripeti = false;
    for(int i = L-2; i >= 0; i--) {
        if(ripeti)
            ciclo[L++] = ciclo[i];
        if(ciclo[i] == alreadyV)
            ripeti = true;
    }
    cout << L-1 << endl;
    for(int i = 0; i < L; i++) {
        cout << ciclo[i] << " ";
    }
    cout << endl;
    return 0;
}
