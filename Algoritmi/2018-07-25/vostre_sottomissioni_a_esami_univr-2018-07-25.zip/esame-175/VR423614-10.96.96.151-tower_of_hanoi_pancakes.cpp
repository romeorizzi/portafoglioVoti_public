/**
 *  Un template per la soluzione di tower_of_hanoi_pancakes
 *
 *  Autore: Romeo Rizzi, 2018-07-19
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 100

int N;
int flip[MAXN +1]; // flip[i] = 1 se nello spostamento della torre la frittalla i deve ritrovarsi flippata, flip[i] = 0 altrimenti.

long long int numero_mosse(int n){
  if(n==1) return 1;
  return 2*numero_mosse(n-1)+1;
}


void spostaDisco(int n, int from, int to) {
  printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}

void stampa_mosse(int n, int a, int b, int c){
  if(n==0) return;
  stampa_mosse(n-1,a,c,b);
  spostaDisco(n,a,b);
  stampa_mosse(n-1,c,b,a);
}

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       scanf("%d", &flip[i]);
    }
    
    printf("%lld\n", numero_mosse(N));
    stampa_mosse(N,1,3,2);
    return 0;
}

