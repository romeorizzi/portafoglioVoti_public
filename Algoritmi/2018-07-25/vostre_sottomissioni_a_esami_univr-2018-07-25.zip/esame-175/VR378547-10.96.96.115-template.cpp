#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;

int X[MAXN];

int P[MAXN];

int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
int count= 0;
    scanf("%d", &N);
    
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
    P[i] =1;
    for(int a= i -1; a >= 0; a --){
      if(X[a]== X[i]){
           P[i] =(P[i]+ P[a] - 1)%1024;
         break;
      } else if(X[a] <X[i]){
        P[i] =(P[i]+ P[a]) %1024;
      }
    }
         count = (count + P[i])%1024;
  }

  //int count;

  //count = 0;

  printf("%d\n", count);

  return 0;
  /*
  for(int i = 0; i< N; i ++){
    P[i] = 1;
  }
  int plus = 1;
  for(int i =1; i<N; i++){
    for(int b =0; b< i; b++){
      if(X[i] >X[b]){
        P[i]= P[i] +P[b];
      }
    }
    plus +=P[i];
  }

  printf("%d\n", plus%1024);
  return 0;
  */
}

