
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>

std::ifstream in("input.txt");
std::ofstream out("output.txt");

using namespace std;

const int MAXN = 1000000;

int visited[MAXN];
int state[MAXN];
int res[MAXN];
vector<int> graph[MAXN];

int pos = 0;

int N, M ,L;

bool verifica_parita(int currentNode, int currentState);

void debug(){
    int dim = std::max(N,M);
    cout << "visited: ";
    for(int i = 0; i < dim; i++){
        cout << visited[i] << " ";
    }
    cout << "state: ";
    for(int i = 0; i < dim; i++){
        cout << state[i] << " ";
    }
    cout << "res: ";
    for(int i = 0; i < dim; i++){
        cout << res[i] << " ";
    }

    system("pause");

}

int main(){
    in >> N >> M;
    //visited.resize(M);
    //state.resize(M);
    //res.resize(M);
    //graph.resize(M);

    for(int i=0; i < M; i++){
        int a, b;
        in >> a >> b;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
    
    //debug();
    
    verifica_parita(0,0);
    
    //debug();
    
    int visitedTwice = res[L-1];
    bool repeat = false;
    for(int i = L-2; i>=0; i--){
        if(repeat){
            res[L++] = res[i];
        }
        if(res[i] == visitedTwice){
            repeat = true;
        }
    }

    //debug();
    
    out << L-1 << endl;
    for(int i =0; i <L; i++){
        out << res[i] << " ";
    }
    out << endl;
    return 0;
}

bool verifica_parita(int currentNode, int currentState){
    if(visited[currentNode]){
        if(state[currentNode] != currentState){
            res[pos++] = currentNode;
            L = pos;
            return true;
        }
        else{
            return false;
        }
    }
    visited[currentNode] = 1;
    state[currentNode] = currentState;
    res[pos++] = currentNode;
    
    for(int next : graph[currentNode]){
        if(verifica_parita(next, 1-currentState)){
            return true;
        }
    }
    pos--;
    return false;
}