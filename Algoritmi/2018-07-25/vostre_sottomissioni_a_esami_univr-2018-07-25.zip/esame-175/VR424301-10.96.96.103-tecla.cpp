#include <cassert>
#include <cstdio>
#include <vector>
#include <iostream>
#include <fstream>

using namespace std;


const unsigned MAXN = 100000;
int nodivisti[MAXN];
int sex[MAXN];
int ciclo[MAXN]; 
int peso = 0;

int N, M, L;
vector<int> adj[MAXN];

bool ciclo_dispari(int node, int mysex){
    if(nodivisti[node]){
        if(sex[node] != mysex){
            ciclo[peso++] = node;
            L = peso;
            return true;
        }
        else
            return false;
    }
    nodivisti[node]=1;
    sex[node]= mysex;
    ciclo[peso++]=node;
    for(int next: adj[node])
        if(ciclo_dispari(next,1-mysex) )
            return true;
    peso--;
    return false;
}

int main() {

  ifstream inputfile("input.txt");

  int p = 0;
  inputfile >> N;
  inputfile >> M;
  for(int i = 0; i < M; i++) {
    int a,b;
    inputfile >> a;
    inputfile >> b;
    adj[a].push_back(b);
    adj[b].push_back(a);
  }
  inputfile.close();

  ciclo_dispari(0, 0);

  int visitatoDue = ciclo[L-1];
  bool repeat = false;
  for(int i = L-2; i>= 0; i--){
    if(repeat)
        ciclo[L++] = ciclo[i];
    if(ciclo[i] == visitatoDue)
        repeat = true;
    }

  ofstream outf("output.txt");
  
  outf << L-1 << endl;
  for(int i = 0; i<L; i++)
    outf << ciclo[i] << " " ;


  outf << "\n";
  outf.close(); 

  return 0;
}

