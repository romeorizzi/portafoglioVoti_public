#include <cassert>
#include <cstdio>
#include <vector>

#define MAXN 1000000

using std::vector;

int N;
int cost[MAXN];
int X[MAXN];
vector <vector <int> > sottosequenza;

int sottosequenze(int numero,int pos){
  int count = 1;
  for(int i = pos + 1; i<N; i++){
    if(numero < X[i]){
      count++;
      sottosequenza[pos].push_back(i);
    }
    count %= 1024;
  }
 
  return count;
}

int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif

  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }
  sottosequenza.resize(N);
  for(int i = 0; i < N; i++){
    cost[i]= sottosequenze(X[i], i);
  }
  int count = 0;

  for(int i = N-1; i >= 0; i--){
    for(int j : sottosequenza[i]){
      cost[j] %= 1024;
      cost[i] = cost[i]+(cost[j] - 1);
      cost[i] %= 1024;
    }
   
    count += cost[i];
    count %= 1024;
  }

  printf("%d\n", count);
  return 0;
}


