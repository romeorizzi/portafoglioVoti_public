/*ragnatela di tecla*/

#include <cassert>
#include <cstdio>
#include <vector>
#include <iostream>


using namespace std;
const unsigned MAXN = 1000000;
int visitato[MAXN];
int stomaco[MAXN];
int ciclo[MAXN], pos = 0;
int N;
int M;
int S;
vector<int> vettore[MAXN];


bool funzione_ragnatela(int node, int appetito){
  if(visitato[node]){
    if(stomaco[node] != appetito){
      ciclo[pos++] = node;
      S = pos;
      return true;
    }
    else{
      return false;
    }
  }
  visitato[node] = 1;
  stomaco[node] = appetito;
  ciclo[pos++] = node;
  for(int next: vettore[node]){
    if(funzione_ragnatela(next, 1-appetito)){
      return true;
    }
  }
  pos--;
  return false;
}


int main() {
//#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
//#endif

  /*scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }*/

  cin >> N >> M;

  for(int i = 0; i<M; i++){
    int x, y;
    cin >> x >> y;
    vettore[x].push_back(y);
    vettore[y].push_back(x);
  }

  assert(funzione_ragnatela(0,0));

  int giavisitato = ciclo[S-1];
  bool repeat = false;

  for(int i=S-2; i>=0; i--){
    if(repeat){
      ciclo[S++] = ciclo[i];
    }
    if(ciclo[i] == giavisitato){
      repeat = true;
    }
  }

  cout << S-1 << endl;

  for(int i=0; i<S; i++){
    cout << ciclo[i] << " ";
  }
  cout << endl;

  /*int count;

  count = 0;

  printf("%d\n", count);*/
  return 0;
}

