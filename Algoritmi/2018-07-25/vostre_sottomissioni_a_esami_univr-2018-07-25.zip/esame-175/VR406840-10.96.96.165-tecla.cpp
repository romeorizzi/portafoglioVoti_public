#include <iostream>
#include <cassert>
#include <vector>

#define DEBUG 0

using namespace std;

const unsigned MAXN = 30;
int visto[MAXN];
int sesso[MAXN];
int ciclo[MAXN], posW = 0;

int N,M,L;
vector<int> adj[MAXN];

bool ciclo_dispari(int node, int miosesso){
    if ( visto[node] ){
        if(sesso[node] != miosesso ){
            ciclo[posW++] = node;
            L = posW;
            return true;
        }
        else
            return false;
    }
    visto[node] = 1;
    sesso[node] = miosesso;
    ciclo[posW++] = node;
    for(int next: adj[node])
        if(ciclo_dispari(next, 1-miosesso) )
            return true;
    posW--;
    return false;
}

int main(){
    assert(freopen("input.txt", "r", stdin));
    assert(freopen("output.txt", "w", stdout));

    cin >> N >> M;

    for(int i = 0; i < M; i++){
        int a,b;
        cin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    assert(ciclo_dispari(0,0) );

    int visitatoDueVolte = ciclo[L-1];
    bool ripetuto = false;
    
    for(int i = L - 2; i >= 0; i--){
        if (ripetuto)
            ciclo[L++] = ciclo[i];
        if(ciclo[i] == visitatoDueVolte )
            ripetuto = true;
    }

    cout << L-1 << endl;

    for(int i = 0; i<L; i++)
        cout << ciclo[i] << " ";
    cout << endl;

    return 0;

}
