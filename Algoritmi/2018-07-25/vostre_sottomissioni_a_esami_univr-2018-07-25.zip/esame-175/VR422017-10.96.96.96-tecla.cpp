#include <iostream>
#include <cassert>
#include <vector>
#include <stdio.h>

using namespace std;


const unsigned MAXN = 1000000;
int visto[MAXN];
int azione[MAXN];
int ciclo[MAXN];
int posizione = 0;

int I, K, J;
vector<int> ausiliare[MAXN];


bool agg_ciclo(int node, int miaazione){


    if(visto[node]){

        if(azione[node] != miaazione){
            ciclo[posizione++] = node;
            J = posizione;
            return true;
        }
        else
            return false;
    }

    visto[node] = 1;

    azione[node] = miaazione;

    ciclo[posizione++] = node;

    for(int prossimo: ausiliare[node])
        if(agg_ciclo(prossimo, 1-miaazione))
            return true;


    posizione--;

    return false;
}

int main(){
    assert(freopen("input.txt", "r", stdin));
    assert(freopen("output.txt", "w", stdout));

    cin >> I >> K;

    for(int i = 0; i <K; i++){
        int a, b;
        cin >> a >> b;
        ausiliare[a].push_back(b);
        ausiliare[b].push_back(a);
    }
    assert( agg_ciclo(0,0));

    int visitedTwice= ciclo[J-1];
    bool ripeti = false;
    for(int i=J -2; i >= 0; i--){
        if(ripeti){
            ciclo[J++] = ciclo[i];
        }
        if(ciclo[i] == visitedTwice){
            ripeti = true;
        }
    }

    cout << J-1 << endl;
    for(int i=0; i < J; i++)
        cout << ciclo[i] << " ";
    cout << endl;

    return 0;

}