#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;

int X[MAXN];
int t=0;

int conta( int c,int k){
    if(k==N){
    return t;
    }
    #pragma omp parallel for
      for (int j=k+1; j<N; j++){
      if(X[k] <X[j]){
      conta(t++,j);
      }
    }
}



int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif
  scanf("%d", &N);
  #pragma omp parallel for
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }
    #pragma omp parallel for
    for(int i = 0; i < N; i++){
      conta(0,i);
    }
    t = (t+N) % 1024;
   
  printf("%d\n", t);
  return 0;
}

