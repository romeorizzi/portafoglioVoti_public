#include <iostream>
#include <vector>
#include <cassert>

#define DEBUG 0

using namespace std;

const unsigned MAXN = 1000000;
int seen[MAXN];
int sex[MAXN];
int cycle[MAXN];
int pos = 0;

int L;
int M;
int N;

vector<int> adj[MAXN];

bool fun_cycle(int node, int actual){
    if(seen[node]){
        if(sex[node] != actual){
            cycle[pos++] = node;  
            L = pos;
            return true;
	}
	else{
	  return false;
	}
    }
    seen[node] = 1;
    sex[node] = actual;
    cycle[pos++] = node;
    for(int next: adj[node])
        if(fun_cycle(next, 1-actual))
            return true;
     
    pos--;
    return false;
 }

int main(){
     assert(freopen("input.txt", "r", stdin));
     assert(freopen("output.txt", "w", stdout));
   
     cin >> N >> M;
    
    for(int i = 0; i < M; i++){
        int a;
        int b;
        cin >> a >> b;
        adj[a].push_back(b);    
        adj[b].push_back(a);
    }

    assert(fun_cycle(0,0));
    int visitedTwice = cycle[L-1];
    bool repeat = false;
    for(int i = L-2; i>= 0; i--){
        if(repeat){
            cycle[L++] = cycle[i];
         }
        if(cycle[i] == visitedTwice){
            repeat = true;
        }
    }
    
    cout << L-1 << endl;
    for(int i =0; i < L; i++){
        cout << cycle[i] << " ";
    }
    
    cout << endl;
    return 0;
}
