#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>
#include<stdint.h>
#include<iterator>
#include<string>
#include<cstring>

using namespace std;

#define MAXN 1000000

ifstream in("input.txt");
ofstream out("output.txt");

int N;

int v[MAXN];
int conta[MAXN];

int conta_sottosequenze(int n,int m){
  for(int i=0; i<n;i++){
    for (int j=v[i]-1; j>=0; j--){
      conta[v[i]]=(conta[j]+conta[v[i]])%1024;
    }

    (conta[v[i]]++)%1024;

  }
  
  int result=0;
  for(int i=0; i<m; i++){
    result=(conta[i]+result)%1024;
  }

  return (result%1024);

}

int main(){

  in>>N;
  for(int i=0; i<N; i++){
    in>>v[i];
  }

  int M=*std::max_element(v, v+N);

  int totale = 0;
  
  totale = conta_sottosequenze(N,MAXN);

  out<<totale;

}
