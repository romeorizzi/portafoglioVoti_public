#include <iostream>
#include <fstream>

using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");
int N;
int valori[100001];
int ind=0;

int main(){

    in>>N;
    for(int i=0;i<N;i++){
        in>>valori[i];
    }

    for(int i=0;i<N;i++){
        in>>valori[i];
    }

    int aiuto[100001];

    for(int i=N-1;i>=0;i--){
        if(valori[i]>0){
            aiuto[i]=1;
            if(i<N-1)
                for(int j=i+1;j<N;j++){
                 if(valori[i]<valori[j])
                     aiuto[i]=(aiuto[i]+aiuto[j])%1024;
            }
        
        }
    }

    int risultato=0;
    for(int i=0;i<N;i++){
        cout<<aiuto[i]<<" ";
        risultato+=aiuto[i];
    }

    out<<risultato%1024;
}