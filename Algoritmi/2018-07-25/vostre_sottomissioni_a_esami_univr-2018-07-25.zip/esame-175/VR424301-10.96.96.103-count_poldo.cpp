#include <cassert>
#include <cstdio>

#define MAXN 1000000


int N;

int X[MAXN];
int sotto[MAXN];


int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif

  scanf("%d", &N);
  int count = 0;

  for(int i = 0; i < N; i++){
    scanf("%d", &X[i]);
    sotto[i] = 1;
    for(int j = i-1; j>=0; j--){
      if(X[j] == X[i]){
        sotto[i] =(sotto[i]+sotto[j] -1) %1024;
        break;
      }
      else if(X[j] < X[i]){
        sotto[i] = (sotto[i]+sotto[j])%1024;
      }
    }
    count = (count + sotto[i]) % 1024;
  }

  printf("%d\n", count);
  return 0;
}

