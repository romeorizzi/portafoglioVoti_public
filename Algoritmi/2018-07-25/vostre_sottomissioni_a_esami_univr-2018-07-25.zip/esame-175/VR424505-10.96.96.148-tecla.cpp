#include <iostream>
#include <fstream>
#include <vector>
#include <utility>

using namespace std;

int NODI;
int ARCHI;

struct arco {
    int sn;
    int en;
};

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
    
        
    bool stato = false;
    int walk_length = 0;

    scanf("%d %d", &NODI, &ARCHI);
    arco archi[ARCHI];
    int nodi[NODI];  // 0 = mai, 1 = non del tutto, 2 = del tutto
    
    
    for (int i = 0; i < ARCHI; i++) {
        scanf("%d %d", &archi[i].sn, &archi[i].en);
    }
    
    // DFS per trovare un cammino di lunghezza dispari
    int wl = 0;
    vector<int> path;
    int current_node = 0;
    do {
        for (int i = 0; i < NODI; i++) {
            if (archi[i].sn == current_node) {
                nodi[0] = 1;
                path.push_back(archi[i].en);
                wl++;
                current_node = archi[i].en;
            }
        }
    } while(current_node != 0 && wl % 2 != 1);
    
    
    
}
