#include <cstdio>


const int maxn = 1000000;
int N;
int array[maxn+1];
int res;
int count[maxn];

int conta_sottostringhe(int n){
    count[maxn] ={0};
    for (int i = 0; i<N; i++){
        for (int j=array[i]-1; j>=0;j--)
            count[array[i]]+=count[j];
        count[array[i]]++;
    }
    res = 0;
    for (int i = 0; i<maxn; i++)
        res+= count[i];
    return res;
}


int main(){

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &N);

    for(int i = 0; i <N; i++) {
       scanf("%d", &array[i]);
    }   
    
    printf("%d\n", conta_sottostringhe(N)%1024);

    return 0;
}
