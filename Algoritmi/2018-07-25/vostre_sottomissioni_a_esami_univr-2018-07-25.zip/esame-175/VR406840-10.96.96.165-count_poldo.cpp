#include <cstdio>

const int nmax = 1000000;

int number;
int vector[nmax+1];
int result;
int counting[nmax];

int countsub(int n){
    counting[nmax] = {0};
    for(int i = 0; i < n; i++){
        for(int j = vector[i] - 1; j >=0; j--)
            counting[vector[i]] += counting[j];
        counting[vector[i]]++;
    }
    result = 0;
    for(int i = 0; i < nmax; i++)
        result += counting[i];
    return result;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d",&n);
    for(int i = 0; i < n; i++ )
        scanf("%d", &arr[i]);
    printf("%d\n", countsub(n)%1024);

    return 0;
}   
