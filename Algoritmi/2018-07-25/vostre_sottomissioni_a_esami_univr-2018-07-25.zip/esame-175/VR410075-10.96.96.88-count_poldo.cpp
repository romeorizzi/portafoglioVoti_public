#include <cassert>
#include <cstdio>
#include <iostream>

#define MAXN 1000000

int N;

#define EVAL

int arr[MAXN];
int S[MAXN]; // numero di sottosequenza da i in poi

using namespace std;

int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif

  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &arr[i]);
  }

  int cnt=0;
  
  S[N-1] = 1;
  for (int i=N-2; i>=0; i--) {
      S[i] = 1;
      for (int j=i+1; j<N; j++) {
          if (arr[j] > arr[i]) {
              S[i] += S[j];
          }
      }
    }

  for (int i=0; i<N; i++) {
      cnt = (cnt + S[i])%1024;
  }
  //cout << "\n";

  printf("%d\n", cnt);
  return 0;
}

