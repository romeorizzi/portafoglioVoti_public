#include <cassert>
#include <cstdio>
#include <fstream>
#include <iostream>

using namespace std;
ifstream in("input.txt");
ofstream out("output.txt");

#define MAXN 1000000

int N;
int countVector[MAXN];
int X[MAXN];

int main() {
  int count=0;
  in >> N;
  for(int i =0; i< N; i++){
    in >> X[i];
    countVector[i]=1;
  }
  for(int i =0; i <N;i++){
    for(int k=i-1;k>=0;k--){
      if(X[k]==X[i]){
        countVector[i]=(countVector[i] +countVector[k]-1)%1024;
        break;
      }
      else if(X[k]<X[i]){
        countVector[i]=(countVector[i] +countVector[k])%1024;
      }
    }
    count=(count+countVector[i])%1024;
  }
  out << count;
  return 0;

}