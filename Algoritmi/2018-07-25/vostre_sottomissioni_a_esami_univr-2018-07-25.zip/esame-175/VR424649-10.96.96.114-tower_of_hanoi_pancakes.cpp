/**
 *  Un template per la soluzione di tower_of_hanoi_pancakes
 *
 *  Autore: Romeo Rizzi, 2018-07-19
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 100

int N;
int flip[MAXN +1]; // flip[i] = 1 se nello spostamento della torre la frittalla i deve ritrovarsi flippata, flip[i] = 0 altrimenti.
int palo1;
int palo2;
int palo3;
void spostaDisco(int n, int from, int to) {
  printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}


int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &N);
    for(int i = 1; i <= N; i++) {
       scanf("%d", &flip[i]);
    }   
    int n_zero = 0;
    for(int i = 1; i <= N; i++) {  
      if(flip[i] == 0){
	n_zero++;
      }
    }
    int n_mosse = N + n_zero;
    printf("%d\n", n_mosse);
    for(int i = 1; i <= N; i++) {  
      if(flip[i] == 0){
	spostaDisco( i, 1, 2); 
      }
      if(flip[i] == 1){
	spostaDisco( i, 1, 3);
      }
    } 
    for(int i = N; i > 0; i--) {  
      if(flip[i] == 0){
       	spostaDisco( i, 2, 3);
      }
    }
        
    return 0;
}

