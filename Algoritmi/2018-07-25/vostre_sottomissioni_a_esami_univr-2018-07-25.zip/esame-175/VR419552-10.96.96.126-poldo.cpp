#include <fstream>
#include <vector>

#define MAXN 1000000
using namespace std;

int count[MAXN];
int panini[MAXN];
int N;

int main() {
    
    ifstream in ("input.txt");
    ofstream out ("output.txt");

    in >> N;

    int c = 0;

    for(int i = 0; i<N; i++){
        in >> panini[i];
        count[i]=1;
        for (int j = i-1; j >= 0; j--){
            if(panini[j] == panini[i]){
                count[i] = (count[i] + count[j] - 1)%1024;
                break;
            }
            else if (panini[j] < panini[i]){
                count[i] = (count[i] + count[j]) %1024;
            }
        }
        c = (c + count[i]) % 1024;
    }    
    // for(int i = 0; i < N; i++){
    //      in >> panini[i]; 

    //  }
    // for (int i = 0; i< N; i++)
    //     count[i]=1;

    // int sum = 1;
    // for (int i = 1; i<N; i++){
    //     for(int j = 0; j<i; j++){
    //         if(panini[i]>panini[j])
    //             count[i] = count[i]+count[j];
    //     }
    //     sum += count[i];
    // }
    

    // for(int i = 0; i<N; i++){
    //     for (int j=panini[i]-1; j>=0; j--)
    //         count[panini[i]] += count[j];
    //     count[panini[i]]++; 
    // }

    // int result = 0;

    // for (int i=0; i<N; i++)
    //     result += count[i];


    out << c;

    return 0;
}
