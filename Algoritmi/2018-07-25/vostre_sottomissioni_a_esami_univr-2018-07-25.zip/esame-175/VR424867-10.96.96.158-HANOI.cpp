#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");
int N;
int contatore=0;
int rovesciato[1000];
string risultato="";

void sposta_disco(int n, int a, int b){
        contatore++;
    if(rovesciato[n]==1)
        rovesciato[n]=0;
    else 
        rovesciato[n]=1;
    risultato+="Muovi il disco " + to_string(n)+ " dal piolo " + to_string(a) + " al piolo "+ to_string(b)+"\n";
}


void stampa_mosse(int n, int a, int c, int b){

    if(n==0)
        return; 

    if(rovesciato[n-1]){
        stampa_mosse(n-1,a,b,c);
         sposta_disco(n,a,c);
        stampa_mosse(n-1,b,c,a);
    }
    else{
        stampa_mosse(n-1,a,c,b);
        sposta_disco(n,a,b);
        stampa_mosse(n-1,c,b,a);
       // stampa_mosse(n,b,c,a);
    }


}




int main(){

    in>>N;

    for(int i=0;i<N;i++){
        in>>rovesciato[i];

    }
    stampa_mosse(N,1,3,2);

    out<<contatore<<endl<<risultato;
}