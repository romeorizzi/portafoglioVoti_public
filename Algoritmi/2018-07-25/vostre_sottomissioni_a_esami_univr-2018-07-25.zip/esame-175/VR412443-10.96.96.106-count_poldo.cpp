#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;

int X[MAXN];

int sottoinsiemi[MAXN];

int main() {

    freopen("input.txt", "r", stdin);


  int count;
  count = 0;

  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
    sottoinsiemi[i] = 1;

    for(int j = i-1; j >= 0; j--){
      if(X[j] == X[i]){
        sottoinsiemi[i] = (sottoinsiemi[i] + sottoinsiemi[j] - 1) %1024;
        break;
      }

      else if(X[j] < X[i])
        sottoinsiemi[i] = (sottoinsiemi[j] + sottoinsiemi[i]) %1024;
    }
    count = (count + sottoinsiemi[i]) %1024;
  } 

    freopen("output.txt", "w", stdout);
  printf("%d\n", count);
  return 0;
}

