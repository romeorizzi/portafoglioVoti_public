/* 
contare sotto-sequenze non vuote e strettamente crescenti 
count-poldo
*/

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;

int X[MAXN];

int C[MAXN];


int main() {
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif

  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
  }

  //int count;

  //count = 0;

  //printf("%d\n", count);


  for(int i = 0; i < N; i++){
     C[i]=1;
   }
   int somma = 1;
   for(int i = 1; i<N; i++){
     for(int j = 0; j < i; j++){
       if(X[i] > X[j]){
         C[i] = C[i] + C[j];
       }
     }
     somma += C[i];
   }


  printf("%d\n", somma%1024);

  return 0;

}

