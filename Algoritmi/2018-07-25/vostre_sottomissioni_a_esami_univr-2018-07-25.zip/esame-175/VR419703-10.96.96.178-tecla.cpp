
#include <cassert>
#include <iostream>
#include <vector>

#define DEBUG 0

using namespace std;

const unsigned MAXN = 1000000;

int N,M; //Nodi ed archi
int L; //Lunghezza ciclo
int visitati[MAXN];
int tesla[MAXN];
int ciclo[MAXN];
vector<int> vett[MAXN];

int pos = 0;


bool DFS(int nodo, int attuale){
    if( visitati[nodo]){
        if (tesla[nodo]!=attuale){
            ciclo[pos++] = nodo;
            L = pos;
            return true;
        }
        else
            return false;
    }

    visitati[nodo]=1;
    tesla[nodo] = attuale;
    ciclo[pos++] = nodo;
    int figlio;
    for(int next : vett[nodo])
        if (DFS(next, 1-attuale))
            return  true;
    pos--;
    return false;
}


int main(){
    assert(freopen("input.txt","r",stdin));
    assert(freopen("output.txt","w",stdout));
    cin>>N>>M;
    
    for (int i = 0; i<M;i++){
        int a,b;
        cin>>a>>b;
        
        vett[a].push_back(b);
        vett[b].push_back(a);
    }

    DFS(0,0);


    int ripasso = ciclo[L-1];
    bool ripeti = false;
    for(int i = L-2; i>=0;i--){
        if(ripeti)
            ciclo[L++] = ciclo[i];
        if (ciclo[i] == ripasso)
            ripeti = true;
    }


    cout << L-1 << endl;
    for (int i = 0; i<L; i++)
        cout<<ciclo[i]<<" ";
    cout<<endl;
    
    return 0;
}
