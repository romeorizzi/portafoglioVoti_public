#include<stdio.h>
#include<vector>
std::vector<int> val;
FILE* fi;
FILE* fo;
int N;
int max=0;
int conteggio;


/*void ricorsione(int k){
    if(k==N){
        return;
    }else{
        if(val[k]>val[k-1]){
            conteggio++;
            for(int i=k+1; i<N;i++){
                ricorsione(i);
            }
        }else{
            return;
        }
    }
}*/


int main(){
    fi=fopen("input.txt","r");
    fscanf(fi,"%d", &N);

    int mat[N]; //arry per la seconda riga

    for(int i=0; i<N; i++){
        int tmp;
        fscanf(fi,"%d",&tmp);
        val.push_back(tmp);
        mat[i]=0;
        for(int j=i-1;j>=0;j--){
            if(val[j]<tmp){
                mat[i]++;
                mat[i]+=mat[j];
            }
        } 
        /*if(tmp>max){
            max=tmp;
        } */ 
    }

    fclose(fi);

    for(int i=0;i<N;i++){
        conteggio+=mat[i]%1024;
    }
    conteggio+=N;


    /*for(int i=0; i<N; i++){
        conteggio++;
        actual_pos=i;
        actual_val=val[i];
        if(actual_val!=max){
            for(int j=i+1;j<N;j++){
                    ricorsione(j);
            }
        }
        
    }*/

    //std::vector<int>::iterator it;
    //std::vector<int>::iterator aux; 
    /*for(it=val.begin();it!=val.end();it++){
        int a=*it;
        bool seq=true;
        for(aux=it; aux!=val.end(); aux++){
            int b=*aux+1
        }
    }*/
    /*for(int i=0; i<N; i++){
        int a=val[i];
        conteggio++;
        printf("\nindice su: %d\n",a);
        bool seq=true;
        for(int j=i+1; j<N; j++){

            if(val[j]>val[j-1] && seq==true){
                printf("    [%d %d] seq\n",val[j-1],val[j]);
                conteggio++;
            }else{
                if(seq==true){
                    seq=false;
                }
            }
            if(val[j]>a && i!=j-1){
                printf("    [%d %d]\n",a,val[j]);
                conteggio++;
            }
        }
    }*/

    fo=fopen("output.txt","w");
    fprintf(fo,"%d",conteggio%1024);
    fclose(fo);

    for(int i=0; i<N; i++){
        printf("%i ",mat[i]);
    }
    printf("\n");

}