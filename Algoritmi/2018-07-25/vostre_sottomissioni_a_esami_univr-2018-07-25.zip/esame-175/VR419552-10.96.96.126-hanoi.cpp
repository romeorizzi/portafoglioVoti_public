#include <iostream>
#include <cassert>
#include <vector>
#include <fstream>

#define MAXN 100

using namespace std;


int N;
int flip[MAXN +1];

unsigned long long int nummosse(int N) {
    assert(N>=0);
    if(N==0)
        return 0;
    return 1 + 2 * nummosse(N-1);

}


void muovidisco(int n, int from, int to){
    printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, from, to);
}
void muovi(int N, int from, int to, int pioloappoggio){
    assert(N>=0);
    if (N==0) return;
    
    muovi(N-1, from, pioloappoggio, to);
    muovidisco(N, from, to);
    muovi(N-1, pioloappoggio, to, from);
}

int main(){
    freopen("input.txt","r", stdin);
    freopen("output.txt","w", stdout);

    scanf("%d", &N);
    for (int i= 1; i <= N; i++) {
        scanf("%d", &flip[i]);
    }

    unsigned long long int mosse = nummosse(N);

    printf("%llu\n", mosse*2);

    muovi(N, 1, 2 ,3);
    muovi(N, 2, 3 ,1);

    return 0;
}