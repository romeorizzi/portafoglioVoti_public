#include<cstdio>
#include<cassert>

const int MAXN = 1000000;

int N;
int v[MAXN+1];
int res;
int count[MAXN+1];

int fun_count(int n){
    count[MAXN] = {0};
    for(int i=0; i < N; i++){
        for(int j=v[i]-1; j>=0; j--){
            count[v[i]] += count[j];
        }
        count[v[i]]++;
    }
    res = 0;
    for(int i=0; i<MAXN; i++){
        res += count[i];
    }
    return res;
}

int main(){
    #ifdef EVAL
        assert(freopen("input.txt", "r", stdin));
        assert(freopen("output.txt", "w", stdout));
    #endif

    scanf("%d", &N);

    for(int i=0; i<N; i++){
        scanf("%d", &v[i]);
    }

    printf("%d\n", fun_count(N)%1024);

    return 0;
}
