#include <cstdio>

#define MAXN 100000

int N;
int X[MAXN];
int subseqarray[MAXN];

int main() {

  freopen("input.txt", "r", stdin);

  scanf("%d", &N);

  int count = 0;

  int matrix[MAXN][MAXN];

  int matrixcounters[MAXN];

  for(int i = 0; i < N; i++) {
    scanf("%d", &X[i]);
    subseqarray[i] = 1;
    matrixcounters[i] = 0;
    for (int k = i - 1; k >= 0; k--){
      if  (X[k] == X[i] ){
        // Avrò le stesse sue +1.
        subseqarray[i] = (subseqarray[i] + subseqarray[k] - 1) % 1024;
        break;
      }
      else if ( X[k] < X[i]){
        subseqarray[i] = (subseqarray[i] + subseqarray[k]) % 1024;
      }
    }
    count = ( count + subseqarray[i] ) % 1024;
  }

  freopen("output.txt", "w", stdout);
  printf("%d\n", count);
  return 0;
}

// Ogni volta che ho un nuovo numero faccio un check su tutti i precedenti.
// Mi servirebbe quindi un modo per poter evitare questo check su tutti i precedenti,
// che mi fa andare fuori tempo. Quale potrebbe essere la soluzione? Devo trovare
// qualcosa che sto riutilizzando. Potrei provare con un check sul numero. Se è uguale
// da lì in poi potrei aggiungere il suo numero senza scorrere ulteriormente.
// se lavoro su un 10 e trovo un 10 so che posso aggiungere le sue, levando un 1.
// Posso trovare più sottosequenze con numeri uguali grazie alle ripetizioni.

// Idea: E se facessi una matrice gigante con dentro per ogni casella
// tutte le caselle che sono inferiori? Ho lo spazio sufficiente?