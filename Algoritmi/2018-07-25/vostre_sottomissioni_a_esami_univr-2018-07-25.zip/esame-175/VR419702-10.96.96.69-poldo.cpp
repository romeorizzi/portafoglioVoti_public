#include <cstdio>

const int max = 1000000;

int n;
int arr[max+1];
int result;
int conta[max];

int contaSeq(int n){
    conta[max] = 0;
    for(int i = 0; i < n; i++){
        for(int j = arr[i]-1; j >=0; j--) conta[arr[i]] += conta[j];
        conta[arr[i]]++;
    }
    result = 0;
    for(int i = 0; i < max; i++) result += conta[i];
    return result;
}

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &n);
    for(int i = 0; i < n; i++) scanf("%d", &arr[i]);
    printf("%d\n", contaSeq(n)%1024);
    return 0;
}
