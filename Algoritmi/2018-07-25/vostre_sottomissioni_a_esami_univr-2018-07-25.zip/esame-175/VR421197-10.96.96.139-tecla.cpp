#include <iostream>
#include <vector>
#include <cstdio>
#include <cassert>
#include <vector>



using namespace std;
const unsigned MaxN = 1000000;

int seen[MaxN];
int sex[MaxN];
int cycle[MaxN];

int M,N,L;
vector<int> adj[MaxN]; int posV=0;

bool odd_cycle(int node, int mysex){
    if(seen[node]){
        if(sex[node]!= mysex){
            cycle[posV++] = node;
            L=posV;
            return true;

        }else{

            return false;
        }

    }
    seen[node]=1;
    sex[node] = mysex;
    cycle[posV++]=node;
    for(int next:adj[node]){
        if(odd_cycle(next,1-mysex)){
            return true;
        }

    }
    posV--;
    return false;


}

int main()
{
#ifdef EVAL
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
#endif


    cin >> N >> M;

    for(int i = 0; i<M; i++){
        int a,b;
        cin>>a>>b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }


    assert(odd_cycle(0,0));

    int visitedTwice= cycle[L-1];
    bool repeat=false;

    for(int i = L-2; i>=0; i--){
        if(repeat)
            cycle[L++]= cycle[i];
        if(cycle[i] == visitedTwice)
            repeat=true;
    }

    cout << L-1 <<endl;
    for(int i = 0; i<L; i++)
        cout<< cycle[i] << " ";

    cout<<endl;


    return 0;
}
