#include<cassert>
#include<vector>
#include<fstream>
using namespace std;

ifstream in("input.txt");
ofstream out("output.txt");

const unsigned MAXN=1000000;

int vettore[MAXN];
int visitato[MAXN];
int ciclo[MAXN] ,posW=0;

int N,M,L;

vector<int> adj[MAXN];

bool controllo(int node, int temp){
    if(visitato[node]){
        if(vettore[node]!= temp){
            ciclo[posW++]=node;
            L=posW;
            return true;
        }
        else
            return false;
    }
    visitato[node]=1;
    vettore[node]=temp;
    ciclo[posW++]=node;

    for(int next:adj[node])
        if(controllo(next,1-temp))
            return true;
    posW--;
    return false;
}
int main(){

    in >> N >> M;

    for(int i=0; i<M;i++){
        int a,b;
        in >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }

    assert(controllo(0,0));

    int ripetizione=ciclo[L-1];
    bool r =false;

    for(int i =L-2; i>=0; i--){
        if(r)
            ciclo[L++]=ciclo[i];
        if(ciclo[i]==ripetizione)
            r=true;
    }
    out << L-1 << endl;

    for (int i =0; i< L ;i++){
        out << ciclo[i] << " ";
    }
    out << endl;
    return 0;
}
