#include <cstdio>

const int nmax = 100000;
int n;
int arr[nmax+1];
int res;
int count[nmax];

int countsub(int n){
    count[nmax] = {0};
    for(int i=0;i<n;i++){
        for (int j=arr[i]-1;j>=0;j--)
            count[arr[i]] += count[i];
        count[arr[i]]++;
    }
    res = 0;
    for(int i=0; i<nmax;i++)
        res +=count[i];
    return res;
    
}
int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
   }

   printf("%d\n", countsub(n)%1024);
    
    return 0;
}


