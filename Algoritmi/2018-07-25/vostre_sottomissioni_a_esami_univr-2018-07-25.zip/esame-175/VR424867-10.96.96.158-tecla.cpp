#include <iostream>
#include <cassert>
#include <vector>
#include <fstream>

#define debug 0

using namespace std;

const unsigned mas=1000000;
int seen[mas];
int sex[mas];
int cycle[mas];
int posW=0;
ifstream in("input.txt");
ofstream out("output.txt");
int N,M,L;
vector<int> A[mas];



bool ciclo(int node, int mysex){
    if(seen[node]){
        if(sex[node]!=mysex){
            cycle[posW++]=node;
            L=posW;
            return true;
        }
    else
        return false;
    }
    seen[node]=1;
    sex[node]=mysex;
    cycle[posW++]=node;
    for(int next:A[node])
        if(ciclo(next,1-mysex))
            return true;
    posW--;
    return false;



}



int main(){

    in>>N>>M;

    for(int i=0;i<M;i++){
        int a,b;
        in>>a>>b;
        A[a].push_back(b);
        A[b].push_back(a);
    }

    ciclo(0,0);

    int visitato= cycle[L-1];
    bool ripetuto=false;

    for(int i=L-2;i>=0;i--){
        if(ripetuto)
            cycle[L++]= cycle[i];
        if(cycle[i]==visitato)
            ripetuto=true;
    }
    out<<L-1<<endl;
    for(int i=0;i<L;i++)
        out<<cycle[i]<<" ";            
    out<<endl;
    return 0;
    
}