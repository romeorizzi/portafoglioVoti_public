#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAX_N = 1000000;
vector<vector<int>> V;
bool visited[MAX_N][2];

int N, M, K;
ofstream out;

bool visita(int n, int count) {
    bool dispari = count%2 == 1;

    if(visited[n][dispari])
        return false;
    visited[n][dispari] = true;

    if(dispari && n==0) {
        out << count << "\n0 ";
        return true;
    }

    bool ok = false;

    for(int vi : V[n]) {
        bool ok1 = visita(vi, count+1);
        ok = ok || ok1;
        if(ok1){
            out << n << " ";
        }
    }

    return ok;
}



int main() {
    ifstream in;
    in.open("input.txt");

    in >> N >> M;
    V.resize(N);


    for(int i=0 ; i<M; i++) {
        int a, b;
        in >> a >> b;
        V[a].push_back(b);
        V[b].push_back(a);
    }

    for(int i=0 ; i<N ; i++) {
        visited[i][0] = false;
        visited[i][1] = false;
    }

    out.open("output.txt");

    visita(0, 0);
    out << endl;

    return 0;
}