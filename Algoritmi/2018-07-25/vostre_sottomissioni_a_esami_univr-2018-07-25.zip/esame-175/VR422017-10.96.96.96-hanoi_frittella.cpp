#include <cstdio>
#include <cassert>

#define MAXN 100

int N;
int bruciata[MAXN +1];



unsigned long long int numero_mosse(int N){
    assert(N >= 0);
    if(N==0) return 0;
    return 1 + 2 * numero_mosse(N-1);
}

void Muovi_Disco(int n, int da, int a){
    printf("Muovi il disco %d dal piolo %d al piolo %d\n", n, da, a);
}


void muovi_alla_torre(int N, int da, int a, int posizione){
    assert(N >= 0);
    if(N == 0) return;
    assert(N >=1);

    muovi_alla_torre(N-1, da, posizione, a);
    Muovi_Disco(N, da, a);
    muovi_alla_torre(N-1, posizione, a, da);
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d", &N);
    for(int i = 1; i <= N; i++){
        scanf("%d", &bruciata[i]);
    }

    unsigned long long int mosse = numero_mosse(N);

    printf("%llu\n", mosse*2);
    muovi_alla_torre(N, 1, 2, 3);
    muovi_alla_torre(N, 2, 3, 1);
    return 0;
}