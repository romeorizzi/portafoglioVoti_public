/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

const int DEBUG = 0;
//const int DEBUG = 1;

const int MAXN = 100000;
const int MAXQ = 100000;
int N,Q;
int p[MAXN];
int q[MAXQ][3];
int answer_to_query[MAXQ];
std::vector<int> children[MAXN];


int padre(int v) {
	if(p[v] == -1)
		return v;
	else
		return padre(p[v]);
}

int padre_with_children(int v, int children) {
	if(v == -1)
		return 0;
	if(v == children)
		return 1;
	else
		return padre_with_children(p[v], children);
}


int main() {
assert( freopen("input.txt", "r", stdin) );
assert( freopen("output.txt", "w", stdout) );

  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  
  int count_alberi = 0;
  for(int i = 0; i < N; i++) {
    scanf("%d", &p[i]);
    if(p[i] == -1)
		count_alberi++;
  }

  for(int v = 0; v < N; v++)
    children[p[v]].push_back(v);
  
  for(int n = 0; n < Q; n++)
	scanf("%d%d%d", &q[n][0], &q[n][1], &q[n][2]);
  
  int u=0, v=0;
  for(int n = 0; n < Q; n++) {
	if(q[n][2] == -1) {
		u = padre(q[n][0]);
		v = padre(q[n][1]);
		if(u != v)
			answer_to_query[n] = 1;
	}
	
	if(q[n][1] == q[n][2])
		answer_to_query[n] = padre_with_children(q[n][0], q[n][1]);
  }
  
  printf("%d\n", count_alberi);
  for(int i = 0; i < Q; i++)
    printf("%d\n", answer_to_query[i]);
  
  return 0;
}
