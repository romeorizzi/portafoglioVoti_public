/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <assert.h>
#include <math.h>
#include <stdio.h>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int MEMO[MAXN];

int rec_with_memo(int i) {
    if(i+2 >= N)
        MEMO[i] = GGG[i];
    else if(i+3 >= N && i+2 < N) {
        if(MEMO[i+2] == -1)
            rec_with_memo(i+2);
        MEMO[i] = MEMO[i+2] + GGG[i];
    } else {
        if(MEMO[i+2] == -1)
            rec_with_memo(i+2);
        if(MEMO[i+3] == -1)
            rec_with_memo(i+3);
        MEMO[i] = (MEMO[i+2]-MEMO[i+3] >= 0)? MEMO[i+2] + GGG[i] : MEMO[i+3] + GGG[i];// + GGG[i];
    }
    
    return MEMO[i];

}

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++) {
     scanf("%d", &GGG[i]);
     MEMO[i] = -1;
  }




  printf("%d\n", rec_with_memo(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}
