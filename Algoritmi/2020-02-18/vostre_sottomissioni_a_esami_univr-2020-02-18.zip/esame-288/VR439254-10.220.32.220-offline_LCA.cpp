/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 0;

const int MAXN = 1000000;
const int MAXQ = 1000000;
int N,Q;
int p[MAXN];
int answer_to_query[MAXQ];
std::vector<int> children[MAXN];
int trees = 0;
int u, v, w;

//se hanno stessa radice sono nello stesso albero
int find_root(int node){
  if(p[node] != -1) {
    find_root(p[node]);
  }
  return node;
}

//risalgo l'albero da u e vedo se incontro v
int is_ancestor(int u, int v){
  if(p[u] == -1)
    return 0;
  else if(p[u] == v)
    return 1;
  else
    is_ancestor(p[u], v);
}

//non completato
int lca(int u, int v, int w){
  return 0;
}
// int lca(int u, int v, int w){
//   if(is_ancestor(u,w) == 0 || is_ancestor(u,v) == 0)
//     return 0;
//   else{
//     if(u == v && v == w)
//       return 1;
//     if(is_ancestor(p[u], w)
//   }
// }


int main() {
  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  for(int i = 0; i < N; i++){
    scanf("%d", &p[i]);
    if(p[i] == -1) {
      trees++;
    }
  }

  for(int v = 0; v<N; v++) {
    //print(v,p[v]);
    children[p[v]].push_back(v);
  }

  // if(DEBUG)
  //     for(int v = 0; v<N; v++) {
  //       printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
  //       for (int u : children[v])
  //         printf("%d ",u);
  //       printf("\n");
  //     }
  
  for(int x = 0; x < Q; x++){
    scanf("%d%d%d", &u, &v, &w);
    //printf("%d %d %d\n", u,v,w);
    if(w == -1) {
      if(find_root(u) == find_root(v)){
        answer_to_query[x] = 0;
      }
      else {
        answer_to_query[x] = 1;
      }
    }
    else if(w == v){
      answer_to_query[x] = is_ancestor(u, v);
    }
    else{
      answer_to_query[x] = lca(u, v, w);
    }

  }

  printf("%d\n", trees);
  for(int i = 0; i < Q; i++)
    printf("%d\n", answer_to_query[i]);

  return 0;
}

