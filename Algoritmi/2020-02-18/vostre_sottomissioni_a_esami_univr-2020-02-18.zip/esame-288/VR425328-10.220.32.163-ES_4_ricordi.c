#include <assert.h>
#include <stdio.h>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int MEMO[MAXN];



int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

 
  for(int a = 0; a < MAXN; a++){
     MEMO[a]=-1;
  }
  scanf("%d",&N);
  for(int i=0; i<N;i++){
      scanf("%d",&GGG[i]);
  }

  printf("%d\n", ricordi(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}
int ricordi(int i){

    if(i+2>=N)
    MEMO[i] =GGG[i];
    else if (i+3 >= N && i+2 <N){
        if(MEMO[i+2]==-1)
        ricordi(i+2);
    MEMO[i]=MEMO[i+2] +GGG[i];
    }else{
        if(MEMO[i+2]==-1)
        ricordi(i+2);
        if(MEMO[i+3]==-1)
         ricordi(i+3);
        MEMO[i]=(MEMO[i+2] -MEMO[i+3] >= 0)?MEMO[i+2] + GGG[i] : MEMO[i+3] + GGG[i];


    }
    return MEMO[i];
    
}