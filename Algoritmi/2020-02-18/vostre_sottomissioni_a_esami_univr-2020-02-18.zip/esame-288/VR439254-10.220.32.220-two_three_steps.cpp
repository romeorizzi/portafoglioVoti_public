/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int sum = 0;

int max(int x, int y){
  if(x >= y)
    return x;
  else 
    return y;
}

int passeggiata(int i){
  if(i == N-1)
    return GGG[N-1];
  else if(i > N-1)
    return 0;
  else  
    return max(GGG[i] + passeggiata(i+2), GGG[i] + passeggiata(i+3));
}


int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);

  sum = passeggiata(0);
  printf("%d\n", sum); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}

