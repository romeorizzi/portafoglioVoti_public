/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int temp[MAXN/2];
int max_2, max_3;
int n;

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);
     
  max_2 = GGG[0];
  n = 0;
  for(int i = 0; i < N/2; i++) {
	n = n + 2;
	max_2 = max_2 + GGG[n];
  }
  
  max_3 = GGG[0];
  n = 0;
  for(int i = 0; i < N/3; i++) {
	n = n + 3;
	max_3 = max_3 + GGG[n];
  }
  
  if(max_2 > max_3)
	printf("%d\n", max_2); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  else
	printf("%d\n", max_3);
  
  return 0;
}

