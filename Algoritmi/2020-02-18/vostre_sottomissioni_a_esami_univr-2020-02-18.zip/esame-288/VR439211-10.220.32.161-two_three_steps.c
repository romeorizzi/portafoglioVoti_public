

#include <assert.h>
#include <stdio.h>


#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++){
     scanf("%d", &GGG[i]);

  }
  
  int somma=0;
  int i=2;
  if(GGG[i] < GGG[i+1])
      i=3;
  somma+=GGG[i];
  while(i<MAXN){
      if(GGG[i]+GGG[i+2] < GGG[i]+GGG[i+3])
        i=i+3;
      else
        i=i+2;
      somma+=GGG[i];
  
  }



  
  printf("%d\n", somma);
  
  return 0;
}
