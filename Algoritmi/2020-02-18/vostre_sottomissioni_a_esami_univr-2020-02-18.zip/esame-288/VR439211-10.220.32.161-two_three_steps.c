

#include <assert.h>
#include <stdio.h>
#include <math.h>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int ARCV[MAXN];

int ricors_arc(int i){
    if(i+2 >=N){
        ARCV[i] = GGG[i];
    }
    else if (i+3 >=N && i+2 <N){
        if(ARCV[i+2]==-1){
            ricors_arc(i+2);
        }
        ARCV[i] = ARCV[i+2] + GGG[i];
    }
    else{
        if(ARCV[i+2] == -1){
            ricors_arc(i+2);

        }
        if(ARCV[i+3] == -1){
            ricors_arc(i+3);

        }
        if(ARCV[i+2] - ARCV[i+3] >= 0){
            ARCV[i] =  ARCV[i+2] + GGG[i];
        }
        else{
            ARCV[i] = ARCV[i+3] + GGG[i];
        }
        

    }

    return ARCV[i];
}


int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  for (int ii=0; ii<MAXN; ii++){
      ARCV[ii]=-1;
  }

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);

  printf("%d\n", ricors_arc(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}
