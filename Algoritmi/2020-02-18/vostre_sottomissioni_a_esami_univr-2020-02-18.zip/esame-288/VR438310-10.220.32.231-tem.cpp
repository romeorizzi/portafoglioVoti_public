/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <bits/stdc++.h>

#define MAXN 1000010

using namespace std;

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int max_here[MAXN];

int calc_max(int n)
{

  //cout << "n:" << n << " ";

  if (n > N) return -1;

  if (max_here[n] != 0)
    return max_here[n];

  // In N o N-1 non posso andare più da nessuna parte
  if (n == N || n == N-1)
  {
    max_here[n] = GGG[n];
    return max_here[n];
  }

  int p1 = calc_max(n+2);
  int p2 = calc_max(n+3);

  max_here[n] = (p1 > p2 ? p1 : p2);
  max_here[n] += GGG[n];

  return max_here[n];
  
}

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);


  //printf("%d\n", max_here[1]); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 

  //calc_max(0);

  //for(int i = 1; i <= N; i++) cout << max_here[i] << " ";

  printf("%d\n", calc_max(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}

