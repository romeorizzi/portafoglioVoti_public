/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 1;

const int MAXN = 100000;
const int MAXQ = 100000;
int N,Q;
int p[MAXN];
int answer_to_query[MAXQ];

/**************************************************************/
//0 se sono nello stesso albero, 1 altrimenti
int are_same_tree(int u, int v){

  int node2 = v;
  int node1 = u;

  if(u == v){
    return 0;
  }

  //cerco la radice del nodo u
  while(p[node1] != -1){
    //printf("nodo = %d, genitore = %d\n", node1, p[node1]);
    node1 = p[node1];
  }

  //printf("radice albero = %d\n", node1);

  while(p[node2] != -1){
    //printf("nodo = %d, genitore = %d\n", node2, p[node2]);
    node2 = p[node2];
  }

  //printf("radice albero = %d\n", node2);

  if(node1 == node2){
    return 0;
  }

  return 1;
  
}
/**************************************************************/
int is_ancestor(int u, int v){
  //v è un antenato di u? 1 se vero, 0 altrimenti

  int node = u;

  if(u == v){
    return 1;
  }
  while(true){
    node = p[node];
    if(node == -1){
      return 0;
    }
    if(node == v){
      return 1;
    }
  }

}
/**************************************************************/
int min_ancestor(int u, int v, int w){
  //ritorna 1 se w è il minimo antenato in comune tra u e v, 0 altrimenti
  int ancestors_u[MAXN];
  int ancestors_v[MAXN];
  int node1 = u;
  int node2 = v;
  int i = 0, j = 0;

  if(are_same_tree(u, v) == 1){
    return 0;
  }

  if(u == v == w){
    return 1;
  }

  //printf("Antenati di u = ");
  if (p[node1] == -1){
    ancestors_u[i] = node1;
    i++;
  }
  else{
    while(p[node1] != -1){
      node1 = p[node1];
      //printf("%d ", node1);
      ancestors_u[i] = node1;
      i++;
    }
  }

  //printf("\nAntenati di v = ");
  if(p[node2] == -1){
    ancestors_v[j] = node2;
    j++;
  }else{
  while(p[node2] != -1){
      node2 = p[node2];
      //printf("posizione %d, valore %d ", j, node2);
      //printf("%d ", node2);
      ancestors_v[j] = node2;
      j++;
    }
  }

  //printf("\n");

  bool found_min = false;
  int min = ancestors_u[i];
  j--;
  i--;

  while(!found_min){
    if(i == -1 || j == -1){
      found_min = true;
    }else if(ancestors_u[i] == ancestors_v[j]){
      min = ancestors_u[i];
      //printf("min = %d\n", min);
      i--;
      j--;
    }else{
      found_min = true;
    }
  }

  //printf("Min tra u = %d e v = %d --> %d\n", u, v, min);
  if(min == w){
    return 1;
  }

  return 0;

}
/**************************************************************/
int main() {
  int num_of_tree = 0;
  int u, v, w;

  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);

  for(int i = 0; i < N; i++){

    scanf("%d", &p[i]);
    if(p[i] == -1){
      num_of_tree+= 1;
    }

  }

  /*if(DEBUG)
  for(int v = 0; v<N; v++) {
        printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
	for (int u : children[v])
          printf("%d ",u);
	printf("\n");
  }*/

  printf("%d ", num_of_tree);
 /**************************************************************/
 if (Q > 0){
  for(int i = 0; i < Q; i++){

    scanf("%d %d %d", &u, &v, &w);
    if(w == -1){
      if(num_of_tree == 1){
        answer_to_query[i] = 0;
      }else{
        answer_to_query[i] = are_same_tree(u, v);
      }
    }
    else if(w == v){
      answer_to_query[i] = is_ancestor(u, v);
    }else
      answer_to_query[i] = min_ancestor(u, v, w);
  
  }
  for(int i = 0; i < Q; i++){
    printf("%d ", answer_to_query[i]);
  }
 }
  /**************************************************************/
  return 0;
}

