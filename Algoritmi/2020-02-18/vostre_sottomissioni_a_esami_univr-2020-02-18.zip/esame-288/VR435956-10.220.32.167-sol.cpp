#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

const int MAXN = 1000000;
int N;
int p[MAXN];
int opt[MAXN];

int max(int a, int b){
    if (a > b){
        return a;
    }
    return b;
}

int max_value(int i, int sum){
    if(i >= N){
        return sum;
    }
    sum += p[i];
    return max(max_value(i+2, sum), max_value(i+3, sum));
}

int max_value_opt(int i){
    if(i >= N){
        return p[i];
    }

    if(opt[i] != -1){
        return opt[i];
    }
    opt[i] = p[i] + max(max_value_opt(i+2), max_value_opt(i+3));

    return opt[i];
}

int main() {

  scanf("%d", &N);
  assert(N>=1); assert(N<=MAXN);

  for(int i = 0; i < N; i++){
    scanf("%d", &p[i]);
    opt[i] = -1;
  }

  printf("--> %d \n",max_value(0, 0));
  printf("%d \n", max_value_opt(0));
  
  for(int i = 0; i < N; i++){
    printf("%d ", opt[i]);
  }
}

