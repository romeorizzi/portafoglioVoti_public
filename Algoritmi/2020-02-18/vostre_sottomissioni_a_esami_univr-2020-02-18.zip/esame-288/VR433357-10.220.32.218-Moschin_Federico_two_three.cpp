/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <cassert>
#include <cstdio>
#include <string.h>

#define MAXN 1000000
int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
long int max_value[MAXN];
long int total = 0;

int solve(int n){

  if(n>N){
    return -1;
  }
  if(max_value[n] != 0){
    return max_value[n];
  }
  if(n == N || n == N-1){
    max_value[n] = GGG[n];
    return max_value[n];
  }

  int step2 = solve(n+2);
  int step3 = solve(n+3);

  if(step2>step3){
    max_value[n] = step2;
  }
  else{
    max_value[n] = step3;
  }

  max_value[n]+=GGG[n];
  return max_value[n];
}



int main() {
  
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);

  printf("%d\n", solve(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}
