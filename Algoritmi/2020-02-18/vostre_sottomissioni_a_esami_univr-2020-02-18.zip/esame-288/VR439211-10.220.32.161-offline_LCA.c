#include <stdio.h>

int n, q, u, v, w;
int TREE[300005];




int query(int a, int b, int antenato);




int main (int argc, char const *argv[]){
    //leggo
    scanf("%d %d",&n,&q);
    int quanti_alberi=0;

    for(int i = 0; i<n;i++){
        scanf("%d",&TREE[i]);
        if(TREE[i] == -1){
            quanti_alberi++;
        }
    }

    printf("%d\n",quanti_alberi);

    for (int qq = 0; qq < q; qq++){
        scanf("%d %d %d", &u, &v, &w);
        printf("%d\n", query(u,v,w));
    }
    return 0;
}







int query(int a, int b, int antenato){
    if (a==b && a== antenato){
        return 1;
    }
    if (a==b && a!= antenato){
        return 0;
    }
    if((a==-1 || b==-1) && antenato != -1){
        return 0;
    }


    if (a!=b && a==antenato){
        return query(a, TREE[b], antenato);
    }
    else if(a!=b && b == antenato){
        return query(TREE[a], b, antenato);
    }
    else{
        return (    query(TREE[a], TREE[b], antenato)   +    query(a, TREE[b], antenato )  +    query(TREE[a], b, antenato)   )/3;
    }
}




