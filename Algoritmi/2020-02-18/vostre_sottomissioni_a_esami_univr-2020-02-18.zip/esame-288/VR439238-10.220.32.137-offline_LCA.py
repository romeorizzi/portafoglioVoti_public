#!/usr/bin/env python3
# -*- coding: latin-1 -*-

from __future__ import print_function
import sys
sys.setrecursionlimit(100000)
if sys.version_info < (3, 0):
    input = raw_input # in python2, raw_input svolge la funzione della primitiva input in python3

"""Template per soluzione in python per il problema tree_split_out
Romeo Rizzi, per l'appello di algoritmi 2019-09-04
"""

MAX_N = 1000000

fin = open('input.txt', 'r')
fout = open('output.txt', 'w')

global forest

#seq = list(map(int,input().split()))


def query(nodeA, nodeB, anc):
    #casi base
    if nodeA == nodeB and nodeA == anc:
        return 1
    elif nodeA == nodeB and nodeA != anc:
        return 0
    if (nodeA == -1 or nodeB == -1) and anc != -1:
        return 0

    if nodeA != nodeB and nodeA == anc:
        #query da una parte sola
        return query(nodeA, int(forest[nodeB]), anc)
    elif nodeA != nodeB and nodeB == anc:
        #query dall'altra parte
        return query(int(forest[nodeA]), nodeB, anc)
    else:
        #query da entrambe le parti
        return int(
                (query(int(forest[nodeA]), int(forest[nodeB]), anc) + 
                query(nodeA, int(forest[nodeB]), anc) + 
                query(int(forest[nodeA]), nodeB, anc))/3
            )


# in questo template di soluzione mi limito a ricopiare l'input in output (non sar� mai la soluzione corretta tranne che per alberi di un solo nodo):
first = fin.readline().split()
forest = fin.readline().split()
counter = 0

for e in forest:
    if int(e) == -1:
        counter += 1

fout.write(str(counter)+'\n')

for i in range(int(first[1])):
    temp = fin.readline().split()
    result = query(int(temp[0]), int(temp[1]), int(temp[2]))
    fout.write(str(result)+'\n')
    

fin.close()
fout.close()