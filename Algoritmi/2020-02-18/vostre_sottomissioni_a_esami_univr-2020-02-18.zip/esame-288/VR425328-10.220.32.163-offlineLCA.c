#include <stdio.h>
#include <stdlib.h>

#define MAX 300010

int nodo, computazione, u, v, w;
int TREE[MAX];



int main(){
    fscanf(stdin, "%d %d", &nodo, &computazione);
    int TREE_number = 0;
        for(int i=0; i< nodo;i++){
            fscanf(stdin, "%d", &TREE[i]);
            if(TREE[i] == -1)
                TREE_number++;
    

        }
        printf("%d\n",TREE_number);

        for(int q= 0; q < computazione; q++){
            fscanf(stdin, "%d %d %d", &u, &v,&w);
            printf("%d\n",computa(u, v, w));
            
        }
return 0;
 
}
int computa(int a, int b, int ancestor){
    if(a == b && a == ancestor)
    return 1;
    if(a == b && a != ancestor)
    return 0;
    if((a == -1 || b == -1) && ancestor != -1)
    return 0;

    if(a != b && a == ancestor)
        return computa(a, TREE[b],ancestor);
    else if (a != b && b == ancestor)
         return computa(TREE[a],b,ancestor);
     else
    return (computa(TREE[a], TREE[b],ancestor)+computa(a,TREE[b],ancestor)+computa(TREE[a],b,ancestor)) / 3;
}