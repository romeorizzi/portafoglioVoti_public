#include <stdio.h>
#include <stdlib.h>
#define MAX 300010

int nodes_number, query_number, u, v, w;
int tree[MAX];

int query(int node_a, int node_b, int ancestor) {
    // first we have to cover tha base cases
	if (node_a == node_b && node_a == ancestor)
		return 1;
	if ((node_a == node_b && node_a != ancestor) || ((node_a == -1 || node_b == -1) && ancestor != -1))
		return 0;

    // now we can recursively call the queries
	if (node_a != node_b && node_a == ancestor)
		return query(node_a, tree[node_b], ancestor);
	else if (node_a != node_b && node_b == ancestor)
		return query(tree[node_a], node_b, ancestor);
	else
		return (query(tree[node_a], tree[node_b], ancestor) + query(node_a, tree[node_b], ancestor)
				+ query(tree[node_a], node_b, ancestor)) / 3;
}

int main() {
	fscanf(stdin, "%d %d", &nodes_number, &query_number);
	int tree_number = 0;
	for (int i = 0; i < nodes_number; i++) {
		fscanf(stdin, "%d", &tree[i]);
		if (tree[i] == -1)
			tree_number++;
	}
	printf("%d\n", tree_number);

	for (int q = 0; q < query_number; q++) {
		fscanf(stdin, "%d %d %d", &u, &v, &w);
		printf("%d\n", query(u, v, w));
	}
	return 0;
}

