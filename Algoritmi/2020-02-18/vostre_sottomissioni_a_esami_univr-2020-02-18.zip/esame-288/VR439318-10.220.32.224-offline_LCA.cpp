/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 0;

const int MAXN = 1000000;
const int MAXQ = 1000000;
int N,Q;
int p[MAXN];
int query[MAXQ][3];           // aggiungi
int answer_to_query[MAXQ];
std::vector<int> children[MAXN];

int miopadre(int x){
  if(p[x] == -1)
    return x;
  else 
    return miopadre(p[x]);
}

int miopadre_2(int x, int figlio){
    if (x == -1)
        return 0;
    if (x == figlio)
        return 1;
    else 
        return miopadre_2(p[x], figlio);

}

int main() {
  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  for(int i = 0; i < N; i++)
    scanf("%d", &p[i]);

    
  for(int i = 0; i < Q; i++)
    for(int j = 0; j < 3; j++)
      scanf("%d", &query[i][j]);
      


  for(int v = 0; v<N; v++) {
    //print(v,p[v]);
    children[p[v]].push_back(v);
  }



//   if(DEBUG){
//       for(int v = 0; v<N; v++) {
//         printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
// 	      for (int u : children[v])
//           printf("%d ",u);
// 	      printf("\n");
//       }
//       printf(" aaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaa \n");
//       for(int i = 0; i < Q; i++){
//         for(int j = 0; j < 3; j++)
//           printf("%d", query[i][j]);
//         printf("\n");
//       }
//   }
  int count = 0;
  
  for(int i = 0; i < N; i++)
    if(p[i] == -1)
      count++;

  printf("%d\n", count);

  

  // printf("%i",miopadre(3));
  

  // alberi diversi ?
  int a1 = 0;
  int a2 = 0;
  for(int i = 0; i < Q; i++){
    
    if(query[i][2]==-1){
    a1 = miopadre(query[i][0]);
    a2 = miopadre(query[i][1]);
    if(a1!=a2)
      answer_to_query[i] = 1;
    }

    if(query[i][2]==query[i][1]){
        answer_to_query[i] = miopadre_2(query[i][0], query[i][1]);
    }

  }

  for(int i = 0; i < Q; i++)
    printf("%d\n", answer_to_query[i]);




  return 0;
}

