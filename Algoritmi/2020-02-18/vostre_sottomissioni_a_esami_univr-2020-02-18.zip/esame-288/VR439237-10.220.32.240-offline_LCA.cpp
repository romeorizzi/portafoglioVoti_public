#include<iostream>
#include<cassert>

using namespace std;
const int N = 1000000;
const int Q = 1000000;
int node_list[N];
int query_list[N];
int anch_list[N];
int number_of_nodes;
int number_of_queries;
int i, j;

void verifier(int w, int v, int u) {
	anch_list[0] = u;
	i = 0;
	
	//MEMORIZZO GLI ANCHESTORS DI U
	while(anch_list[i++] != -1) {
		anch_list[i] = node_list[anch_list[i-1]];
	}
	
	i--;
	anch_list[i] = v;
	j = i;
	
	//MEMORIZZO GLI ANCHESTORS DI V
	while(anch_list[j++] != -1) {
		anch_list[j] = node_list[anch_list[j-1]];
	}

	if(w == -1) { 
		//VERIFICO SE U E V SONO NELLO STESSO ALBERO
		for(int z = 0; z < i; z++) {
			for(int r = i; r < j; r++) {
				if(anch_list[z] == anch_list[r]) {
					cout << "0" << "\n";
					return;
				} 
			}
		}
		cout << "1" << "\n";
		return;
	}

	else if(w == v) {
		//VERIFICO SE V È ANTENATO DI U
		i = u;
		
		if(v == u) {
			cout << "1" << "\n";
			return;
		}

		else {

			while(i != -1) {
				i = node_list[i];
				if(i == v) {
					cout << "1" << "\n";
					return;
				}
			}
			cout << "0" << "\n";
			return;
		}
	}

	else {
		//VERIFICO SE W È LCA
		if((anch_list[1] == w) && (anch_list[i+1] == w)) {
			cout << "1" << "\n";
			return;
		}
		cout << "0" << "\n";
		return;
	}
} 

int main() {
	cin >> number_of_nodes;
	cin >> number_of_queries;
    	assert(number_of_nodes >= 1); assert(number_of_nodes <= N);
	assert(number_of_queries >= 0); assert(number_of_queries <= Q);
	for(int i = 0; i < number_of_nodes; i++) {
		cin >> node_list[i];
    	}
	
	for(int i = 0; i < number_of_queries * 3; i++) {
		cin >> query_list[i];
	}

    	int number_of_trees = 0;
    	for(int i = 0; i < number_of_nodes; i++) {
		if(node_list[i] == -1){
			number_of_trees += 1;
		}
    	}
	
	cout << number_of_trees << "\n";
	
	int count = 0;
	while(count != (number_of_queries * 3)) {
		verifier(query_list[count++], query_list[count++], query_list[count++]);
        }
    
return 0;
}

