/**
 * Un template per la tua soluzione di hanoi_clockwise
 * Romeo Rizzi, 2020-02-18
 *
 */

#include <bits/stdc++.h>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 0;
const int MAXN = 100000;

typedef long long unsigned int llu;

int t, N;
char peg[MAXN+1];
char d[MAXN+1];
llu n_mosse[MAXN+1];

void sposta_disco(int n, char peg_from, char peg_to) {
  assert(peg[n]==peg_from);
  printf("sposta il disco %d dal peg %c al peg %c\n", n, peg_from, peg_to);
  peg[n] = peg_to;
}

char next_peg(char peg) {
  if(peg == 'A') return 'B';
  if(peg == 'B') return 'C';
  if(peg == 'C') return 'A';
}

void sposta_intera_torre(int n, char peg_from, char peg_to)
{
  //assume che tutti i dischi i <= n siano uno sopra l'altro in torre sul peg <peg_from>.
  //Sposta questa intera torre sul peg <peg_to>, impiegando il minor numero di mosse possibile.
  //Si assume che <peg_aux> indichi il terzo peg."""
  if(DEBUG) 
  {
    printf("called sposta_intera_torre(n=%d, peg_from=%c, peg_to=%c)\n", n, peg_from, peg_to);
  }

  //passo base: sposto solo il disco 1
  if (n ==1)
  {
    //mi sposto di 1 passo
    //sposta_disco(n, peg_from, peg[n]=next_peg(peg[n]))
    sposta_disco(n, peg_from, next_peg(peg[n]));
    //peg[n]=next_peg(peg[n]);

    //può essere che mi debba spostare di 2
    if (peg[n] != peg_to)
    {
      sposta_disco(n, peg[n], next_peg(peg[n]));
      //peg[n]=next_peg(peg[n]);
    }

    return;

  }

  //se sposto la torre devo spostare in avanti di 2 tutta la torre più piccola
  //in avanti di 1 il disco n
  sposta_intera_torre(n-1, peg[n-1], next_peg(next_peg(peg[n-1])));
  sposta_disco(n, peg_from, next_peg(peg[n]));

  //se non ho finito (non sto spostando l'ultimo disco)
  if (peg[n] != peg_to)
  {
    //sposto di 1 la torre sottostante
    //e di 1 il disco attuale
    sposta_intera_torre(n-1, peg[n-1], next_peg(peg[n-1]));
    sposta_disco(n, peg[n], next_peg(peg[n]));
  }

  //infine allineo la torre sottostante al disco attuale
  sposta_intera_torre(n-1, peg[n-1], next_peg(next_peg(peg[n-1])));

  return;
}

void smista_torre(int n)
{
  //assume che tutti i dischi i <= n siano uno sopra l'altro in torre, tutti collocati su peg[n].
  //Li consegna tutti alla loro destinazioni finali, come indicate in d.

  //sposto iterativamente tutte le basi delle torri nel posto giusto
  for (int i = n; i > 0; --i)
  {
    if (peg[i] != d[i])
      sposta_intera_torre(N, peg[i], d[i]);
  }

  return;
}

//mosse per spostare di 1 le torri di varia dimensione
llu mosse_sposta_torre(int n)
{
  //se ho già calcolato le mosse per quel disco, le ritorno
  if (n == 0)
    return 0;

  if (n_mosse[n] != 0)
    return n_mosse[n];

  //se sto cercando di calcolare le mosse di 1
  if (n == 1)
  {
    n_mosse[n] = 1;
    return 1;
  }

  n_mosse[n] = 4 * mosse_sposta_torre(n-1) + 1;
  return n_mosse[n];
}
/*
llu num_steps_smista_torre2(int n)
{
  //Assume che tutti i dischi i <= n siano uno sopra l'altro in torre, tutti collocati su peg[n].
  //Ritorna il numero di passi per smistare ciascun disco i <= n come specificato dalla destinazione d[i]""" 

  //se ho già calcolato le mosse per quel disco, le ritorno
  if (n_mosse[n])
    return n_mosse[n];

  //se sto cercando di calcolare le mosse di 1
  if (n == 1)
  {
    n_mosse[n] = 1;
    return 1;
  }

  //devo andare avanti solo di 1
  if (d[n] == next_peg(peg[n]))
  {
    re
  }

  return 42;
}
*/
llu num_steps_smista_torre(int n)
{
  //se sono già sul piolo giusto con il disco più grande
  if (DEBUG) cout << "peg:" << peg[n] << " n:" <<  n << endl;

  if (n == 1)
    return 1;

  if (d[n] == peg[n])
    return num_steps_smista_torre(n-1);
  
  peg[n] = next_peg(peg[n]);
  
  for (int i = 1; i < n; ++i)
    peg[i] = next_peg(peg[n]);

/*
  for (int i = 1; i < n; ++i)
    peg[i] = peg[n];
*/
  return 2 * mosse_sposta_torre(n-1) + num_steps_smista_torre(n);

}

int main() {

  scanf("%d%d", &t, &N);
  bool allB_final_conf = true;
  for(int i = 1; i <= N; i++) {
    peg[i] = 'A';
    do {
      scanf("%c", &d[i]);
    } while(d[i] != 'A' && d[i] != 'B' && d[i] != 'C');
    if(d[i] != 'B') allB_final_conf = false;
  }
  if(t==0)
    printf("%llu\n", num_steps_smista_torre(N));
  else {
    if(allB_final_conf) {
      sposta_intera_torre(N, 'A', 'B');
    }
    else{
      smista_torre(N);
    }
  }
        
  return 0;
}
