/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 0;

const int MAXN = 300000;
const int MAXQ = 100000;
int N,Q;
int p[MAXN];
int answer_to_query[MAXQ];
int roots[10];
std::vector<int> children[MAXN];
long unsigned int n_alberi = 0;

//Risale da a e segna la root per ogni suo figlio e per ogni precedente
//da richiamare solo se la root non esiste gia
int trovaRoots(int a){
  if(p[a] == -1){
    roots[a] = a;
    return a;
  }
  roots[a] = trovaRoots(p[a]);
  return roots[a];
}


int alberiDiversi(int a,int b){
  int rootA = a;
  int rootB = b;

  while(p[rootA] != -1){
        rootA = p[rootA];
  }

  while(p[rootB] != -1){
      rootB = p[rootB];
  }
  return rootA!=rootB;

}


int main() {
  //memset(roots,-1,MAXN*sizeof(int));

  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  for(int i = 0; i < N; i++){
    scanf("%d", &p[i]);
    if(p[i] == -1){
      n_alberi++;
      //roots[i] = i;
    }
  }

  //Stampa numero di alberi nella foresta
  printf("%lu\n",n_alberi);

  for(int v = 0; v<N; v++) {
    //print(v,p[v]);
    children[p[v]].push_back(v);
  }

  int u,v,w;
  //Leggo query
  for(int j = 0;j<Q;j++){
    scanf("%d %d %d",&u,&v,&w);
    if(w == -1){
      if(u == v){
        answer_to_query[j] = 0;
      }
      else{
        answer_to_query[j] = alberiDiversi(u,v);
      }
    }
  }





  if(DEBUG)
      for(int v = 0; v<N; v++) {
        printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
	for (int u : children[v])
          printf("%d ",u);
	printf("\n");
      }
  

  for(int i = 0; i < Q; i++)
    printf("%d\n", answer_to_query[i]);
 

  
  return 0;
}

