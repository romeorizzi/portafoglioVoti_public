#include <stdio.h>
#include<assert.h>
#include <cassert>
#include <cassert>
#include <iostream>
#include <vector>
#define MAXN 1000000


int GGG[MAXN];
int N;

int memo[MAXN];


int rec (int i)
{
  if (i+2 >=N)
    memo[i] = GGG[i];
  else if(i+3 >= N && i+2 < N)
  {
    if(memo[i+2] == -1)
      rec(i+2);
    memo[i] = memo[i+1] + GGG[i];
  }
  else
  {
    if(memo[i+2] == -1)
      rec(i+2);
    if(memo[i+3] == -1)
       rec(i+3);
    memo[i] = (memo[i+2] - memo[i+3] >= 0) ? memo[i+2] + GGG[i] : memo[i+3] + GGG[i];
  }
  return memo[i];
}

int main() 
{
  assert( freopen("input.txt","r",stdin) );
  assert(freopen("output.txt","w",stdout));


  for(int i = 0; i < MAXN; i++)
  {
     memo[i] = -1;
  }

  scanf("%d",&N);

  for(int i = 0; i<N; i++)
  {
    scanf("%d", &GGG [i]);
  }


  printf("&d\n",rec(0));

  return 0;
}

