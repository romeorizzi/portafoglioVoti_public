/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 1;

const int MAXN = 100000;
const int MAXQ = 100000;
int N,Q;
int p[MAXN];
int answer_to_query[MAXQ];
std::vector<int> children[MAXN];

int main() {
	int lung_u, lung_v, u,v,w,uter,vter;
	int camm_u[MAXN], camm_v[MAXN];
	
  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  int count=0;
  for(int i = 0; i < N; i++){
    scanf("%d", &p[i]);
    if(p[i]==-1)
			count ++;
	}
  


  /*for(int v = 0; v<N; v++) {
    //print(v,p[v]);
    children[p[v]].push_back(v);
  }

  if(DEBUG)
      for(int v = 0; v<N; v++) {
        printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
	for (int u : children[v])
          printf("%d ",u);
	printf("\n");
      }


  for(int i = 0; i < Q; i++)
    printf("%d ", answer_to_query[i]);
    */
    
	printf("%d\n", count);
	
	for(int q=0; q<Q; q++){
		scanf("%d %d %d", &u, &v, &w);
		lung_u=0;
		lung_v=0;
		//cammini u
		for(int j=u; j!=-1; lung_u++){
			camm_u[lung_u]=j;
			j=p[j];
			
		}
		camm_u[lung_u++]=-1;/////
		//cammini v
		for(int j=v; j!=-1; lung_u++){
			camm_v[lung_v]=j;
			j=p[j];
			
		}
		camm_v[lung_v++]=-1;
		
		uter=lung_u-1;
		vter=lung_v-1;
		
		int result = 0;
		
		while (uter>=0 && vter>=0){
			if(uter==0 || vter==0){
				if(camm_u[uter]==w)
					result=1;
				uter=0;
			}
			if(camm_u[uter] != camm_v[vter]){
			if(camm_u[uter+1]==w)
				result=1;
			uter=0;
		}
		uter--;
		vter--;
	}
		printf("%d", result);
	}
  
  return 0;
}

