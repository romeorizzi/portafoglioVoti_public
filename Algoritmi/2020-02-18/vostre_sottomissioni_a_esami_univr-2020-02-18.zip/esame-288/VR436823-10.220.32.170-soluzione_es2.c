#include<stdio.h>
#include<stdlib.h>

#define MAX 300010


//definisco variabili
int numero_nodi, numero_query_execute ,u,v,w;
int pathTree[MAX];

int query_execute(int a,int b , int c)
{
  //controllo che devo fare per i casi base
  if(a==b && a==c)
    return 1;
  if((a == b && a != c) || (a == -1 || b == -1) && c != -1)
    return 0;

  //finiti i casi base controllo i vari nodi come sono nell'albero

  //procedura ricorsiva
  if (a != b && a == c)
    return query_execute(a, pathTree[b], c);
  else if (a != b && b == c)
    return query_execute(pathTree[a],b,c);
  else
    return (query_execute(pathTree[a],pathTree[b],c) + query_execute(a, pathTree[b],c) + query_execute(pathTree[a],b,c))/3;

}


int main(int argc, char const *argv[])
{
  //inserisco i valori delle varibili numero N intero e Query Q
  fscanf(stdin,"%d %d",&numero_nodi,&numero_query_execute);
  int pathTree_number = 0;

  //inserisco i nodi dell'albero
  for(int i = 0; i < numero_nodi; i++)
  {
    fscanf(stdin,"%d",&pathTree[i]);
    if(pathTree[i] == -1)
      pathTree_number++;
  }

  printf("%d \n", pathTree_number);

  //Stampo risultato
  for(int i = 0; i < numero_query_execute; i++)
  {
    fscanf(stdin,"%d %d %d",&u,&v,&w);
    printf("%d\n",query_execute(u,v,w));
  }
  return 0;
}