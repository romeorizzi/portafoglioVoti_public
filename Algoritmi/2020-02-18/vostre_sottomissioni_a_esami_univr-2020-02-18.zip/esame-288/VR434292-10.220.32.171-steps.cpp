/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int steps(int i){
  //non posso piu saltare
    //if pos+2 eccedo
  if (i+2>N)
      return GGG[i];
  //posso fare passo piu 2
  int step2,step3;
  step2=steps(i+2)+ GGG[i];
      //if pos+3 eccedo
    if (i+3>N)
     step3= GGG[i];
    else//passo standard
      step3=steps(i+3)+ GGG[i];
    if (step3> step2)
      return step3;
    return step2;
}
int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
  scanf("%d", &N);
  for(int i=0; i < N; i++)
     scanf("%d", &GGG[i]);

  printf("%d\n",steps(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  
  return 0;
}

