/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 */

#include <cassert>
#include <cstdio>
#include <bits/stdc++.h>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
int max=0;
int dp[MAXN];

int fun(int n)
{
  if(n > N) return -1;

  if(dp[n] != 0)
    return dp[n];

  if(n==N || n==N-1)
  {
    dp[n] = GGG[n];
    return dp[n];
  }

  int p1 = fun(n+2); int p2 = fun(n+3);

  dp[n] = (p1 > p2 ? p1:p2);
  dp[n] += GGG[n];

  return dp[n];
}

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);

  //function(0);  
  printf("%d\n", fun(0)); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  return 0;
}

