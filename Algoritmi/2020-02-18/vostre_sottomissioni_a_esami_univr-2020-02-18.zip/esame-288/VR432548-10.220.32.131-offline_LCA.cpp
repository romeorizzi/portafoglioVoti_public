/**
 *  Template per soluzione in c++ per il problema offline-LCA
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2020-02-18
 *
 */

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

//const int DEBUG = 0;
const int DEBUG = 0;

const int MAXN = 100000;
const int MAXQ = 100000;
int N,Q;
int p[MAXN];
int answer_to_query[MAXQ];
std::vector<int> children[MAXN];
int u, v, w;



int stessoAlbero(int u, int v)
{
	//printf("%d, %d, %d, %d \n", u, v, p[u], p[v]);
	if ((u == -1) && (v== -1))
		return 1;
	if ((u == v) || (p[u] == p[v]) || (p[u] == v) || (p[v] == u))
	{
			return 0;
	}
	else if (p[u] == -1)
	{
			return stessoAlbero(-1, p[v]);
	}
	else if (p[v] == -1)
	{
			return stessoAlbero(p[u], -1);
	}
	
}


int main() {
  scanf("%d%d", &N, &Q);
  assert(N>=1); assert(N<=MAXN);
  assert(Q>=0); assert(Q<=MAXQ);
  for(int i = 0; i < N; i++)
    scanf("%d", &p[i]);


  for(int v = 0; v<N; v++) {
    //print(v,p[v]);
    if (p[v] != -1)
		children[p[v]].push_back(v);
  }
  
  

  if(DEBUG)
    for(int v = 0; v<N; v++) {
        printf("nodo v=%d, p[%d] = %d\n%lu figli: ",v,v,p[v],children[v].size());
	for (int u : children[v])
          printf("%d ",u);
	printf("\n");
      }
	
	int count = 0;
	for (int i = 0; i < N;i++)
		if (p[i] == -1)
			count++;
	printf("%d \n", count);
	//printf("N = %d, Q = %d\n", N, Q);
  for(int i = 0; i < Q; i++)
  {
	scanf("%d%d%d", &u, &v, &w);
	//printf("%d %d %d", u, v, w);
	//printf("prova for");
	if (w == -1)
	{
	// se u e v in alberi diversi
	//printf("%d \n", stessoAlbero(u, v));
		answer_to_query[i] = stessoAlbero(u, v);
	}
	if (w == v)
	{
		//v antenato di u
	//printf("%d \n", padre_ric(u, w) & padre_ric(v, w));
		//answer_to_query[i] = w = LCA(u,v) ? 1 : 0;
	}
	printf("%d \n", answer_to_query[i]);
  }
  return 0;
}
