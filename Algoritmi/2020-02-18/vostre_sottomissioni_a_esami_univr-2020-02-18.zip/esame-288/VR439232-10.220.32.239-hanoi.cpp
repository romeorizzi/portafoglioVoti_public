/**
 * Un template per la tua soluzione di hanoi_clockwise
 * Romeo Rizzi, 2020-02-18
 *
 */

#include <cassert>
#include <cstdio>

//const int DEBUG = 0;
const int DEBUG = 0;
const int MAXN = 100000;

typedef long long unsigned int llu;

int t, N;
char peg[MAXN+1];
char d[MAXN+1];
int n_mosse[MAXN+1];
llu memo_num2[MAXN+1];

void sposta_disco(int n, char peg_from, char peg_to) {
  assert(peg[n]==peg_from);
  printf("sposta il disco %d dal peg %c al peg %c\n", n, peg_from, peg_to);
  peg[n] = peg_to;
}

char next_peg(char peg) {
  if(peg == 'A') return 'B';
  if(peg == 'B') return 'C';
  if(peg == 'C') return 'A';
}

void sposta_intera_torre(int n, char peg_from, char peg_to) {
  //assume che tutti i dischi i <= n siano uno sopra l'altro in torre sul peg <peg_from>.
  //Sposta questa intera torre sul peg <peg_to>, impiegano il minor numero di mosse possibile.
  //Si assume che <peg_aux> indichi il terzo peg."""
  
  if(n==1){
    sposta_disco(n, peg_from, next_peg(peg[n]));

  if(peg[n] != peg_to) 
    sposta_disco(n, peg[n], next_peg(peg[n]));
    return;
  }
  
  sposta_intera_torre(n-1, peg[n-1], next_peg(next_peg(peg[n-1])));
  sposta_disco(n, peg_from, next_peg(peg[n]));

  if(peg[n] != peg_to)
  {
    sposta_intera_torre(n-1, peg[n-1], next_peg(peg[n-1]));
    sposta_disco(n, peg[n], next_peg(peg[n]));
  }

  sposta_intera_torre(n-1, peg[n-1], next_peg(next_peg(peg[n-1])));

  return;

}

void smista_torre(int n) {
  //assume che tutti i dischi i <= n siano uno sopra l'altro in torre, tutti collocati su peg[n].
  //Li consegna tutti alla loro destinazioni finali, come indicate in d.
  for(int i=n; i >0; --i)
    if(peg[i] != d[i])
      sposta_intera_torre(N, peg[i], d[i]);

  return;
}

llu mosse_sposta_torre(int n)
{
  if(n==0) return 0;

  if(n_mosse[n] != 0) return n_mosse[n];

  if(n==1)
  {
    n_mosse[n] = 1;
    return 1;
  }

  n_mosse[n] = 4*mosse_sposta_torre(n-1) +1;
  return n_mosse[n];

}


llu num_steps_smista_torre(int n) {
  //Assume che tutti i dischi i <= n siano uno sopra l'altro in torre, tutti collocati su peg[n].
  //Ritorna il numero di passi per smistare ciascun disco i <= n come specificato dalla destinazione d[i]""" 
  if(n==1)
    return 1;

    if(d[n] == peg[n])
      return num_steps_smista_torre(n-1);
    
    peg[n] = next_peg(peg[n]);

    for(int i=1; i<n; ++i)
      peg[i] =next_peg(peg[n]);

    return 2*mosse_sposta_torre(n-1) + num_steps_smista_torre(n);
}

int main() {
  scanf("%d%d", &t, &N);
  bool allB_final_conf = true;
  for(int i = 1; i <= N; i++) {
    peg[i] = 'A';
    do {
      scanf("%c", &d[i]);
    } while(d[i] != 'A' && d[i] != 'B' && d[i] != 'C');
    if(d[i] != 'B') allB_final_conf = false;
  }
  if(t==0)
    printf("%llu\n", num_steps_smista_torre(N));
  else {
    if(allB_final_conf) {
      sposta_intera_torre(N, 'A', 'B');
    }
    else{
      smista_torre(N);
    }
  }
        
  return 0;
}
