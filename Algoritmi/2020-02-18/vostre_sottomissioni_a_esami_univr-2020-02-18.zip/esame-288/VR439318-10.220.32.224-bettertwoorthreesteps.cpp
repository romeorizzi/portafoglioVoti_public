/**
 *  Soluzione farlocca di two_three_steps (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-06-14
 *
 6
0 0 2 3 1 1
 */

#include <cassert>
#include <cstdio>
#include <vector>

#define MAXN 1000000

int N;
int GGG[MAXN]; // GGG[i] = valore del ricordo i-esimo.
std::vector<int> vet;

void somma(int x, int pos){
  if(pos+2<N){
    vet.push_back(x+GGG[pos+2]);
    if(pos+3<N)
      vet.push_back(x+GGG[pos+3]);
  }

  if(pos+2<N){
    somma(x+GGG[pos+2], pos+2);
    if(pos+3<N)
      somma(x+GGG[pos+3], pos+3);
  }
  

}

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );


  scanf("%d", &N);
  for(int i = 0; i < N; i++)
     scanf("%d", &GGG[i]);

  somma(GGG[0], 0);
  int max = 0;

 // printf("%d\n", 0); // giusto quando tutti i ricordi sono scialbi tranne al più il secondo. 
  for(int i = 0; i<vet.size();i++){
    if(vet.at(i)>max)
      max = vet.at(i);
    // printf("%d", vet.at(i));
  }

  printf("%d", max);
  
    

  return 0;
}

