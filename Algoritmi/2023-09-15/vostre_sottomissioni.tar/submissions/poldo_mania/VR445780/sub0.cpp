#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

vector<int> inp;


int conta_prima(int pos, int x){

    int max=0;
    int att;
    int p=0;

    for (int i=0;i<pos;i++){
        vector<int> tmp;
        if (inp[i] < x){ 
            tmp.push_back(inp[i]);  
            p++;
            for(int z=i+1;z<pos;z++){
                int a=inp[z];
                if(a<x && a>tmp.back()){tmp.push_back(a);}
                else if(a<x && a<tmp.back()){tmp.pop_back();tmp.push_back(a);}
            }       
        }
        att= tmp.size();
        if(max<att){
            max=att;
        }

    }      
    return max;

}

int conta_dopo(int pos,int x){
    
    int max=0;
    int att;
    int p=0;

    for (int i=pos;i<inp.size();i++){
        vector<int> tmp;
        if (inp[i] > x){ 
            tmp.push_back(inp[i]); 
            for(int z=i+1;z<inp.size();z++){
                int a=inp[z];
                if(a>x && a>tmp.back()){tmp.push_back(a);}
                else if(a>x && a<tmp.back()){tmp.pop_back();tmp.push_back(a);}
            }       
        }
        att= tmp.size();
        if(max<att){
            max=att;
        }

    }      
    return max;
}


int calc(int x, int pos){
    
    int res;
    

    if((pos !=0)&& (pos !=(inp.size()-1))){
        res=conta_prima(pos,x)+conta_dopo(pos,x);
        
        }
    else if(pos == 0 ){
        res=conta_dopo(pos,x);
       
    }
    else if(pos == inp.size()-1){
        res=conta_prima(pos,x);
        
    }
    return res;
}

int main(){

    int ist, l;
    cin >> ist;    
    
    int n;
    

    for (int x=0; x<ist;x++){
        vector<int> rst;
        cin >> l;
        int j=0;
        
        while(j<l){
        cin >> n;
        inp.push_back(n);
        j++;
        }
        
        for(int i=0; i < inp.size(); i++){
            rst.push_back(calc(inp[i],i)+1);
        }
        inp.erase(inp.begin(),inp.end());
        for(int i : rst){
        cout << i << " ";
        }
        cout << endl;
    }

    

    return 0;
}