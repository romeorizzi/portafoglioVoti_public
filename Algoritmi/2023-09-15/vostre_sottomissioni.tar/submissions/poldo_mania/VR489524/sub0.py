#Leggo quante istanze devo ciclare

n_istanze = int(input())

for istanza in range(n_istanze):

    #Leggo quanti interi devo ciclare
    n_interi = int(input())
    lista = input().split(' ')


    solutions = []
    

    for i in range(len(lista)):

        count = 0
        last_n = -1
        lista_i = int(lista[i])

        for j in range(len(lista)):

            lista_j = int(lista[j])

            if j == i:
                count = count + 1
                last_n = lista_i
            elif j < i:
                if lista_j < lista_i and lista_j > last_n:
                    count = count + 1
                    last_n = lista_j
            elif j > i:
                if lista_j > lista_i and lista_j > last_n:
                    count = count + 1
                    last_n = lista_j

            

        solutions.append(count)
    
    print(' '.join(map(str,solutions)))

