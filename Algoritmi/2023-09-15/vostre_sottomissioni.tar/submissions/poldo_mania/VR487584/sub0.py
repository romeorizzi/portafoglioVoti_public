
L=[]
M=0
N = int(input()) 
sol=""
import resource, sys
resource.setrlimit(resource.RLIMIT_STACK, (2**29,-1))
sys.setrecursionlimit(10**6)

Mem = []

def trova_max_seq(n,last_v,l,massimo):
    max1=0
    global L,M,Mem
    if l==M:
        return massimo
    if Mem[n] is not None:
        return Mem[n]
        
    if l<=L.index(n) and L[l]<=n:
        if L[l]>=last_v:
               max1+=trova_max_seq(n,L[l],l+1,massimo)+1
            
    elif (l>L.index(n)) :
        if L[l]>last_v and L[l]>n:
            max1+=trova_max_seq(n,L[l],l+1,massimo)+1
            
    
    max2 = trova_max_seq(n,last_v,l+1,massimo)
    massimo=max(max1,max2)
    Mem[n]=massimo
    return massimo




def main():
    global max1,L,M,Mem
    
    for i in range(N):
        sol=""
        M = int(input())
        L = list(map(int,input().split()))
        Mem=[None for _ in range(M+1)]
        for t in L:
            max1=0
            value=trova_max_seq(t,0,0,0) #trova la massima seq per ogni posizione della lista
            sol+=str(value) + " "
        print(sol)
            

main()