def ord(S, i, sol, last):
    for j in range(i, len(S)):
        if S[j] >=last:
            s=sol.copy()
            s.append(j)
            ord(S, j+1,s, S[j])
    lsol = len(sol)

    for j in sol: 
        soluz[j] = max(soluz[j],lsol)

T = int(input())

for t in range(T):
    n= int(input())
    soluz = [1]*(n)
    S = list(map(int, input().split()))

    for i in range(len(S)):
        ord(S, i+1, [i], S[i])
    str_sol = ''
    for i in soluz:
        str_sol+= f'{i} '
    print(str_sol)