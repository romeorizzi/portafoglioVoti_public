import sys
import os
import resource, sys
resource.setrlimit(resource.RLIMIT_STACK, (2**29, -1))
sys.setrecursionlimit(10**6)


def comunicazioneUtenteDiminuito(i):
    while(i!=0):
        print("?"+ str(i))

        risposta = input()

        if(risposta == "n"):
            break

        if(risposta == "y"):
            print("!"+ str(i)) #eseguo cambio
            i = (i - 1)//2 #padre


def comunicazioneUtenteAumentato(n, i):
    while(i < n):
        i = (i * 2) + 1 # figliosinistra
        if(i > n):
            break

        print("?"+ str(i))

        risposta = input()

        if(risposta == "n"):
            i = i + 1 # figliodestra

            print("?"+ str(i))

            risposta = input()

            if(risposta == "n"):
                break 
            if(risposta == "y"):
                print("!"+ str(i)) #eseguo cambio
                continue

        if(risposta == "y"):
            print("!"+ str(i)) #eseguo cambio

            i = i + 1 #figlio destra
            if(i > n):
                continue

            print("?"+ str(i))

            risposta = input()

            if(risposta == "n"):
                i = i - 1 
            if(risposta == "y"):
                print("!"+ str(i - 1)) #eseguo cambio con padre iniziale
                print("!"+ str(i)) #eseguo cambio con padre nuovo


        

        
T = int(input())
#exit(0)
for _ in range(T):
    c,n,i = map(int, input().strip().split())
    
    if(c == 0):
        comunicazioneUtenteDiminuito(i)
    if(c == 1):
        comunicazioneUtenteAumentato(n, i)
    if(c == 2):
        comunicazioneUtenteDiminuito(i)
        comunicazioneUtenteAumentato(n, i)

    print("!0")
    sys.stdout.flush()
    