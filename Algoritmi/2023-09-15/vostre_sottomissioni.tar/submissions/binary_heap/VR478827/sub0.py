import sys

def query(i):
    print("?"+str(i))
    res = str(input())
    return res

def update(i):
    print("!"+str(i))
    sys.stdout.flush()
    
def heap(n, i):

    while i < n:

        left_child = 2*i + 1
        right_child = 2*i + 2
        child = 0
        i_prev = i
        left_query = ""
        right_query = ""

        if left_child > n: 
            break

        else:

            left_query = query(left_child)

            if left_query=="y":
                child = left_child
                update(left_child)

            if right_child <= n:
                right_child = query(right_child)
                if right_child=="y":
                    update(left_child*2 + 1)
                    update(right_child)
                    i = right_child

            if (i == i_prev) and (left_query=="y" or right_query=="y"):
                i = child

            else:
                break  
                
    while i > 0:
        if i == 1 or i == 2:
            padre = 0
        else:
            padre = (i - 1)//2
        if query(i)=="y":
            update(i)
            i = padre

        else:
            break

T = int(input())
for j in range(T):
    c, n, i = map(int, input().split())
    heap(n, i)
    print("!"+str(0))
