import  sys


def check_i(m, i, c):
    close= False
    if(i>m):
        print("!0")
        return 0

    if(i == 0 and c==0):
        print("!0")
        return 0
    if(i == 0):
        c=1


    if c == 2:
        child_sx= (2*i)+1
        

        str_node= "?"+ str(i)
        print(str_node)

        sys.stdout.flush()

        answ= str(input())

        if(answ == "n"):
            if(child_sx <m):
                str_child_sx= "?"+ str(child_sx)
                print(str_child_sx)
                sys.stdout.flush()
                answ_f = str(input())
                if(answ_f == "y"):
                    move_child_sx= "!"+ str(child_sx)
                    print(move_child_sx)
                    sys.stdout.flush()

                    check_i(m,child_sx,1)
                elif(answ_f == "n"):
                    print("!0")
                    sys.stdout.flush()
                    return 0
            else:
                print("!0")
                sys.stdout.flush()
                return 0
            return 0

        elif answ == "y":
            move_node= "!"+ str(i)
            print(move_node)
            sys.stdout.flush()

            father= int((i -1)/2) 
            check_i(m, father,0)

   
    if c == 0: #diminuito, scambiarlo con i genitore
        if(i==0):
            print("!0") #close
            sys.stdout.flush()
            close=True
            return 0

        str_node= "?"+ str(i)
        print(str_node)

        sys.stdout.flush()
        answ= str(input())

        if answ == "y":  #A[child] < A[father]
            move_node= "!"+ str(i)
            print(move_node)

            sys.stdout.flush()
            father= int((i -1)/2)
            check_i(m, father,c)
        elif answ == "n":
            print("!0") #close

            sys.stdout.flush()
            close=True
            return 0







        
            
    if c == 1: # incrementato (scambiarlo con i figli)
        child_sx= (2*i)+1
        child_dx= (2*i)+2


        if child_sx >= m :
            print("close")
            print("!0") #close

            sys.stdout.flush()
            close=True
            return 0

        str_child_sx= "?"+ str(child_sx)
        str_child_dx= "?"+ str(child_dx)
        move_child_sx= "!"+ str(child_sx)
        move_child_dx= "!"+ str(child_dx)
        print(str_child_sx) # A[child_sx] < A[i]?

        answ_sx= str(input())
        if(answ_sx == "n"):
            print("!0") #close
            sys.stdout.flush()
            close=True
            return 0

        elif(answ_sx == 'y'):
            print(move_child_sx)

            sys.stdout.flush()
            if 2*child_sx+1 < m :
                check_i(m, child_sx, c)
            else:
                print("!0") #close

                sys.stdout.flush()
                close=True
                return 0
        return 0






def main():
    T= int(input())

    for _ in range(T):
        #spoon = input().strip().split()
        #print(spoon, file=sys.stderr)

        c, n, i= map(int, input().split())

        check_i(n,i,c)
        


main()