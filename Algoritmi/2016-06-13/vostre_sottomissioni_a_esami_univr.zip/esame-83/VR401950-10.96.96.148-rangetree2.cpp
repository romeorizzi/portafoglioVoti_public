#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int N, Q;
const int MAX_N = 100000;
const int MAX_Q = 100000;
vector<vector<int> > commands;
vector<int> seq;

void print () {
    for (int i = 0; i < Q; i++)
        for (int j = 0; j < 3; i++)
            cout << commands[i][j] << " ";

    cout << endl;
}

void increase(int a, int b) {
    for (int i = a; i <= b; i++)
        seq[i]++;
}

int divisible(int a, int b) {
    int res = 0;

    for (int i = a; i <= b; i++) {
        if (seq[i] % 3 == 0)
            res++;
    }
}

void calculate() {
    ofstream outstream("output.txt");
    for (int i = 0; i < Q; i++) {
            if (commands[i][0] == 0) {
                increase(commands[i][1], commands[i][2]);
            } else if (commands[i][0] == 1) {
                outstream << divisible(commands[i][1], commands[i][2]) << "\n";
            }
          
    }
}

int main () {
    ifstream instream("input.txt");
    ofstream outstream("output.txt");
    cout << "qui" << endl;
    instream >> N;
    instream >> Q;

    if (N > MAX_N || Q > MAX_Q)
        return 0;

    commands.resize(Q);

    for (int i = 0; i < Q; i++) {
        commands[i].resize(3);
    }

    for (int i = 0; i < Q; i++) {
        for (int j = 0; j < 3; i++) {
            instream >> commands[i][j];
            cout << commands[i][j] << " ";
        }
        cout << endl;
    }

    seq.resize(N);

    for (int i = 0; i < N; i++) {
        seq[i] = 0;
    }

    //print();
    calculate();


    return 0;
}
