#include <cstdio>
#include <cstdlib>
#include <climits>
#include <algorithm>
#define MAX_DIM 501
using namespace std;

int n, s[MAX_DIM], memo[MAX_DIM] [MAX_DIM], Sum[MAX_DIM], picco;

#define SOMMA(a,b) (Sum[b]-Sum[a-1])
#define SUM(a,b) abs(SOMMA(a,b))

int rec(int i, int j)
{
    if (memo[i][j]>=0) return memo[i][j];
    if (j==i+1) return memo[i][j]=abs(s[i]+s[j]);
    if (j==i+2) return memo[i][j]=max(SUM(i,j), min(rec(i,i+1), rec(i+1,j)));
    memo[i][j]=INT_MAX;
    for (int k=i+1; k<j-1; k++){
    memo[i][j]=min(memo[i][j], max(SUM(i,j), min(rec(i,k), rec(k+1,j))));    
    }
    return memo[i][j];
}

int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt", "w",stdout);

    int i,j,k,g,val,t=0;
    scanf("%d",&n);
    Sum[0]=0;
    for(i=1; i<=n; i++){
        scanf("%d",s+i);
        t += s[i];
        Sum[i] = t;
    }

    for (i=1;i<=n;i++) for(j=i;j<=n;j++) memo[i][j]=-1;
    
    printf("%d\n", rec(1,n));
    return 0;

}
