#include <cstdlib>
#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;


struct nodo{
    int update;
    int mod0;   //Divisibili per 0
    int mod1;
    int mod2;
};

nodo* RANGE_TREE=NULL;

void costruisci_albero(int index, int s, int e){
    RANGE_TREE[index].update=0;
    RANGE_TREE[index].mod0=e-s+1;
    RANGE_TREE[index].mod1=0;
    RANGE_TREE[index].mod2=0;

    if(s==e){
        return;
    }

    costruisci_albero(2*index, s, s+ (e-s)/2);
    costruisci_albero(2*index+1, s+ (e-s)/2 +1, e);
}

void rotate(int &mod0, int &mod1, int &mod2){
    int c=mod0;
    int l=mod1;

    mod0=mod2;
    mod1=c;
    mod2=l;
}

//Ritorna quanti valori nel range sono divisibili per 0
int query(int start, int fine, int s, int e, int index){
    if(start>e || fine<s){
        return 0;
    }

    if(RANGE_TREE[index].update!=0){
        RANGE_TREE[index].update%=3;

        for(int i=0; i<RANGE_TREE[index].update; i++){
            rotate(RANGE_TREE[index].mod0, RANGE_TREE[index].mod1, RANGE_TREE[index].mod2);
        }

        if(start!=fine){
            RANGE_TREE[index*2].update+=RANGE_TREE[index].update;
            RANGE_TREE[index*2+1].update+=RANGE_TREE[index].update;
        }
        RANGE_TREE[index].update=0;
    }


    if(start>=s && fine<=e){
        return RANGE_TREE[index].mod0;
    }

    return query(start, start+(fine-start)/2, s, e, index*2) +
        query(start+(fine-start)/2+1, fine, s, e, index*2+1);
}

//Incrementa i valori nel range
void incrementa_range(int inizio, int fine, int s, int e, int index){


    if(RANGE_TREE[index].update!=0){
        RANGE_TREE[index].update%=3;

        for(int i=0; i<RANGE_TREE[index].update; i++){
            rotate(RANGE_TREE[index].mod0, RANGE_TREE[index].mod1, RANGE_TREE[index].mod2);
        }

        if(inizio!=fine){
            RANGE_TREE[index*2].update+=RANGE_TREE[index].update;
            RANGE_TREE[index*2+1].update+=RANGE_TREE[index].update;
        }

        RANGE_TREE[index].update=0;
    }

    if(inizio>e || fine <s){
        return;
    }

    if(inizio>=s && fine<=e){
        rotate(RANGE_TREE[index].mod0, RANGE_TREE[index].mod1, RANGE_TREE[index].mod2);

        if(inizio!=fine){
            RANGE_TREE[index*2].update++;
            RANGE_TREE[index*2+1].update++;
        }
        return;
    }

    incrementa_range(inizio, inizio+(fine-inizio)/2, s, e, index*2);
    incrementa_range(inizio+(fine-inizio)/2+1, fine, s, e, index*2+1);

    RANGE_TREE[index].mod0=RANGE_TREE[index*2].mod0+RANGE_TREE[index*2+1].mod0;
    RANGE_TREE[index].mod1=RANGE_TREE[index*2].mod1+RANGE_TREE[index*2+1].mod1;
    RANGE_TREE[index].mod2=RANGE_TREE[index*2].mod2+RANGE_TREE[index*2+1].mod2;
}

int main(){
    ifstream in ("input.txt");
    ofstream out ("output.txt");

    int N, Q;
    int com, start_index, end_index;
    int dimensione_tree =2;

    in>>N>>Q;

    //Calcolo dimensione tree
    while(dimensione_tree<2*N){
        dimensione_tree*=2;
    }

    //Costruzione tree
    RANGE_TREE= new nodo[dimensione_tree];
    costruisci_albero(1, 0, N-1);

    //Esecuzione dei comandi
    for(int i=0; i<Q; i++){
        in>>com>>start_index>>end_index;
        if(com==0){
            incrementa_range(0, N-1, start_index, end_index, 1);
        }else{
            out<<query(0, N-1, start_index, end_index, 1)<<endl;
        }
    }

    return 0;
}
