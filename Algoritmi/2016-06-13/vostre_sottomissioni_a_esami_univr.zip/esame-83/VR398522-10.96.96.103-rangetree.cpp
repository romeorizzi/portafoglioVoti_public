#include <iostream>
#include <fstream>

using namespace std;

// Variabili globali
int N , Q;
ifstream fin("input.txt");
ofstream fout("output.txt");

// Definisco la struttura edl nodo
struct node
{
    // Resti della divisione intera di n (n%1, n%2, n%3)
    int resto1;
    int resto2;
    int resto3;
    // Flag per decidere se aggiornare o meno il nodo    
    int update_flag;
};

// Prototipi delle funzioni

// Crea l'albero e, ricorsivamente, i relativi sottoalberi
void crea_albero(int init_node, int end_node, int indice_nodo, node albero[]);

// Ruotare l'albero mi serve per poterlo aggiornare, mi servono i resti per riferimento così da poterne modificare il valore
void ruota_albero(int &resto1, int &resto2, int &resto3);

// Aggiunge uno ai nodi nell'intervallo start-end e aggiorna l'albero di conseguenza
void somma_uno(int start, int end, int init_node, int end_node, int indice_nodo, node albero[]);

// Restituisce la somma dei valori tra start e end
int somma_parziale(int start, int end, int init_node, int end_node, int indice_nodo, node albero[]);


int main()
{
    int dimensione = 2;
    fin >> N >> Q;
    cout << N << " " << Q;

    // Calcolo il numero di nodi raddoppiando sempre la dimensione 
    while(dimensione < 2*N)
    {
        dimensione *=2;
    }

    node range_tree[dimensione];

    crea_albero(0, N-1, 1, range_tree);

    int operazione, init_node, end_node;

    for(int i = 0; i< Q; i++)
    {
        fin >> operazione >> init_node >> end_node;
        
        // Se operazione è 1calcolo la somma tra gli estremi e la stampo su file 
        if(operazione == 1)
            fout << somma_parziale(0, N-1, init_node, end_node, 1, range_tree) << endl;
        // Altrimenti sommo 1 tra init_node e end_node
        else
            somma_uno(0, N-1, init_node, end_node,1, range_tree);
            
    };

    return 0;
    
}

void ruota_albero(int &resto1, int &resto2, int &resto3)
{
    int temp1 = resto1;
    int temp2 = resto2;
    resto1 = resto3;
    resto2 = temp1;
    resto3 = temp2;
}

void crea_albero(int init_node, int end_node, int indice_nodo, node albero[])
{
    // Inizializzo nodo
    albero[indice_nodo].update_flag = 0;
    
    albero[indice_nodo].resto1 = end_node-init_node+1;

    albero[indice_nodo].resto2 = 0;

    albero[indice_nodo].resto3 = 0;

    // Se sono una foglia termino
    if(init_node==end_node) return;

    // Altrimenti creo i figli destro e sinistro
    crea_albero(init_node, init_node + (end_node-init_node) / 2 , 2*indice_nodo , albero);

    crea_albero(init_node + (end_node-init_node) / 2+1 ,end_node , 2*indice_nodo+1, albero);
}

int somma_parziale(int start, int end, int init_node, int end_node, int indice_nodo, node albero[])
{
    if(start > end_node  || end < init_node) return 0;
    
    if(albero[indice_nodo].update_flag > 0)
    {
        albero[indice_nodo].update_flag %= 3;
        for(int i = 0;i< albero[indice_nodo].update_flag; ++i)
        {
            ruota_albero(albero[indice_nodo].resto1, albero[indice_nodo].resto2, albero[indice_nodo].resto3);
        }

        if(start != end)
        {
            albero[indice_nodo*2].update_flag += albero[indice_nodo].update_flag;
            albero[indice_nodo*2+1].update_flag += albero[indice_nodo].update_flag;
        }

        albero[indice_nodo].update_flag = 0;
    }

    if(start >= init_node && end <= end_node)
    {
        return albero[indice_nodo].resto1;
    }

    return somma_parziale(start, start + (end-start)/2, init_node, end_node, indice_nodo*2, albero) + somma_parziale(start+(end-start)/2+1,end, init_node, end_node, indice_nodo*2+1, albero);
}

void somma_uno(int start, int end, int init_node, int end_node, int indice_nodo, node albero[])
{
    if(albero[indice_nodo].update_flag > 0)
    {
        albero[indice_nodo].update_flag %= 3;
        for(int i = 0; i <albero[indice_nodo].update_flag; ++i)
        {
            ruota_albero(albero[indice_nodo].resto1, albero[indice_nodo].resto2, albero[indice_nodo].resto3);
        }

        if(start != end)
        {
            albero[indice_nodo*2].update_flag += albero[indice_nodo].update_flag;
            albero[indice_nodo*2+1].update_flag += albero[indice_nodo].update_flag;
        }

        albero[indice_nodo].update_flag = 0;
    }

    if(start > end_node || end < init_node) return;

    if(start >= init_node && end <= end_node)
    {
        ruota_albero(albero[indice_nodo].resto1, albero[indice_nodo].resto2, albero[indice_nodo].resto3);

        if(end != start)
        {
            albero[indice_nodo *2].update_flag ++;
            albero[indice_nodo*2+1].update_flag ++;
        }
        return;
    }

    somma_uno(start, start +(end-start)/2, init_node, end_node, indice_nodo*2, albero);
    somma_uno(start +(end-start)/2 + 1,end,  init_node, end_node, indice_nodo*2+1, albero);

    albero[indice_nodo].resto1 = albero[indice_nodo*2].resto1 + albero[indice_nodo*2+1].resto1;
    albero[indice_nodo].resto2 = albero[indice_nodo*2].resto2 + albero[indice_nodo*2+1].resto2;
    albero[indice_nodo].resto3 = albero[indice_nodo*2].resto3 + albero[indice_nodo*2+1].resto3;
}
















