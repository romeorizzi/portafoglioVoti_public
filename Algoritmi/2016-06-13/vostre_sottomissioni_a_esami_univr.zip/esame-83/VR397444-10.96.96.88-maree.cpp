#include <iostream>
#include <fstream>
#include <list>
#include <climits>
#include <cmath>
#include <cassert>
#include <queue>
#include <vector>

using namespace std;

const long int MAX_N=200000, MAX_M=3000000;
int tt;

struct node{
    int bestArr;
    vector<node*> vicini;

};
struct node2{
    int bestArr;
    int bestArr2;
    vector<node2*> vicini;
};

bool operator<(const node& a,const node& b){
    return a.bestArr>b.bestArr;
}

bool operator<(const node2& a,const node2& b){
    return (a.bestArr2)>(b.bestArr2);
}




node nodes[MAX_N];
node2 nodes2[MAX_N];

node makeNode(){
    node ret;
    ret.bestArr=INT_MAX;
    return ret;
}

node2 makeNode(node n,int T){
    node2 ret;
    ret.bestArr=n.bestArr<INT_MAX?T:INT_MAX;
    ret.bestArr2=INT_MAX;
    return ret;
}

void limBFS(int N, int M, int T, int* S, int* E){
    priority_queue<node*> coda;
    nodes[0].bestArr=0;
    coda.push(&nodes[0]);

    while(coda.top()->bestArr<=T){
        cout<<coda.size()<<endl;

        node* x=coda.top();
        coda.pop();
        for(size_t i=0;i<(x->vicini.size());i++){
            if((x->bestArr+1)<(x->vicini[i]->bestArr)){
                x->vicini[i]->bestArr=x->bestArr+1;
                coda.push(x->vicini[i]);
            }
        }
    }
}

void limBFS2(int N, int M, int T, int* S, int* E){
    priority_queue<node2*> coda;
    nodes2[N-1].bestArr=0;
    coda.push(&nodes2[N-1]);
    while(coda.top()->bestArr2<=INT_MAX){
        node2* x=coda.top();
        coda.pop();
        for(size_t i=0;i<(x->vicini.size());i++){
            if((x->bestArr2+1)<(x->vicini[i]->bestArr2)){
                x->vicini[i]->bestArr2=x->bestArr2+1;
                coda.push(x->vicini[i]);
            }
        }
    }
}

int solve(int N, int M, int T, int* S, int* E){
    tt=T;
    return 7;
    for(int i=0;i<N;i++){
        nodes[i]=makeNode();
    }
    for(int i=0;i<M;i++){
        nodes[S[i]].vicini.push_back(&nodes[E[i]]);
    }
    //FACCIO BFS DA PARTENZA LIMITATA A TEMPO T E MI SALVO I TEMPI
    limBFS(N, M, T, S, E);
    cout<<"ASD";
    cout.flush();
    //COSTRUISCO GRAFO INVERSO
    for(int i=0;i<N;i++){
        nodes2[i]=makeNode(nodes[i],T);
    }
    for(int i=0;i<M;i++){
        nodes2[E[i]].vicini.push_back(&nodes2[S[i]]);
    }
    //FACCIO BFS DA END E VEDO QUALE, SOMMATA A BFS DI PRIMA, HA TEMPO MINORE
    limBFS2(N, M, T, S, E);
    //CERCO IL MINIMO
    long int minval=INT_MAX;
    for(int i=0;i<N;i++){
        long int curr=nodes2[i].bestArr;
        curr+=nodes2[i].bestArr2;
        if(curr<minval) minval=curr;
    }
    return minval;
}


int main(){

    ifstream input("input.txt");
    int n,m,t;
    input>>n>>m>>t;
    int a[n];
    int b[n];
    for(int i=0;i<m;i++){
        input>>a[i]>>b[i];
    }
    input.close();




    ofstream output("output.txt");

    if(output.is_open()){
        output<<solve(n,m,t,a,b);
    }

    output.close();
    return 0;
}
