#include <cstdio>
#include <string>
#include <cmath>

#define BUFF_SIZE 500*2*100

using namespace std;

int m;
int steps;
int max_sum = 0;
int sequence[500]={};
bool fin;

void collapse(int i, int j){
    int n1 = sequence[i];
    int n2 = sequence[j];
    sequence[i] = n1+n2;
    sequence[j] = 0;
    if(abs(n1+n2)>max_sum)
        max_sum=abs(n1+n2);
    steps++;
}

int next(int i){
    for(int j=i+1; j<m;j++){
        if(sequence[j]!=0)
            return j;
    }
    return -1;
}

void solve(){
    int temp_sum;
    int temp_min_sum = 0xffff;
    int min_i = 0;
    int min_j = 0;
    int j;
    for(int i=0; i<m-1;i++){
        if(sequence[i]!=0)
            j = next(i);
            if(j!=-1){
                temp_sum = abs(sequence[i]+sequence[j]);
                if(temp_sum<temp_min_sum){
                    temp_min_sum = temp_sum;
                    min_i = i;
                    min_j = j;
                }
            }
    }
    if(min_i != min_j)
        collapse(min_i,min_j);
    else
        fin = false;
}

int main(){

    //INPUT
    char buf[BUFF_SIZE];
    int tmp;
    FILE* in = fopen("input.txt","r");

    steps = 0;
    fscanf(in, "%d\n",&m);
    fgets(buf,BUFF_SIZE,in);
    int l = 0;
    for(int j=0; j<m;j++){
        sscanf(buf+l,"%d ",&tmp);
        l+=string(buf+l).find(' ')+1;
        sequence[j] = tmp;
    }

    //COMPUTATION
    FILE* out = fopen("output.txt","w");
    fin = true;
    while(steps < m+1+1 && fin){
        solve();
       for(int j=0; j<m;j++){
           fprintf(out,"%d ",sequence[j]);
       }
        fprintf(out,"\n");

    }

    //OUTPUT
    //FILE* out = fopen("output.txt","w");
    fprintf(out,"%d\n",max_sum);
    return 0;
}
