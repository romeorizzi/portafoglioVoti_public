//rangetree2
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int N, Q, count = 0;
vector<vector<int> > matrix;
vector<int> arr;
vector<int> temp;

int divThree(int A, int B) {
    int count_div=0;

    for (int i=A; i<B+1; i++)
        if ((arr[i] % 3) == 0)
            count_div++;
        
    return count_div;
} 

void sumOne(int A, int B) {

    for (int i=A; i<B+1; i++)
        arr[i] += 1;
}

void output(vector<int> temp) {
    ofstream outFile("output.txt");

    for (int i=0; i<count; i++)
        outFile << temp[i] << "\n";
}

int main() {
    ifstream openFile("input.txt");
       
    openFile >> N;
    cout << N << endl;

    arr.resize(N);
    for (int i=0; i<N; i++)
        arr[i] = 0;

    openFile >> Q;
    cout << Q << endl;

    matrix.resize(Q);
    for (int i=0; i<Q; i++) {
        matrix[i].resize(3);
    }

    for (int i=0; i<Q; i++) {
        for (int j=0; j<3; j++) {
            openFile >> matrix[i][j];
            cout << matrix[i][j];

            if (matrix[i][j] == 1 && j == 0)
                count++;
        }
    
        cout << "\n";
    }

    temp.resize(count);
    int z=0;
    //risolvo il problema
    for (int i=0; i<Q; i++) {
        for (int j=0; j<3; j++) {
           if (matrix[i][j] == 0 && j == 0)
                sumOne(matrix[i][j+1], matrix[i][j+2]);
            else if (matrix[i][j] == 1 && j == 0)
                 temp[z++] = divThree(matrix[i][j+1], matrix[i][j+2]);
        }
    }
 
    output(temp);
}
