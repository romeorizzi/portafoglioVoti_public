#include <cassert>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstdio>
using namespace std;


int main(){

    FILE*input=fopen("input.txt","r");
    int N, Q;
    fscanf(input, "%d %d",&N, &Q);

    int* nums = new int[N]();
    int C,A,B,cnt;
    FILE* output=fopen("output.txt","w");

    for(int i = 0;i<Q;i++){
        fscanf(input,"%d %d %d",&C, &A,&B);
        if(C==0){
            for (int j=A;j<=B;j++)
            nums[j]++;
         }
        else {
            cnt=0;
             for(int j=A; j<=B; j++){
                if(nums[j]%3 ==0)
                    cnt++;
            }
            fprintf(output,"%d \n", cnt);
        }
    }
}
