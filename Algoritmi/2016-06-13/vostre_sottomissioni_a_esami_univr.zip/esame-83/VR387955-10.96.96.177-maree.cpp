int solve(int N, int M, int T, int* S, int* E) {
    // costruisco il grafo
    

    return -1;
}
