#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

using namespace std;

std::vector<int> list;
ofstream outfile("output.txt");

using namespace std;

int globalMin;
int globalSum;

void printList() {
    for(int i = 0; i < list.size(); i++) {
        cout << list[i] << " ";
    }
    cout << endl;
}

void sxRun()
{
    int min;
    int tmp;
    int a,b;

    // Clique di sinistra
    // Valore assoluto dei primi due
    if (list.size() > 1 )
    {
        min = abs(list[0] + list[1]);
        a = 0;
        b = 1;
    }

    // Calcolo i valori per tutti e trovo il minimo
    for (int i = 2; i < list.size(); i = i+2)
    {
        tmp=abs(list[i-1]+list[i]);
        if (tmp < min )
        {       
            min = tmp;
            a = i-1;
            b = i;
        }                
    }


    // Clique di destra
    // Valore assoluto dei primi due
    if (list.size() > 1 )
    {
        min = abs(list[0] + list[1]);
        a = 0;
        b = 1;
    }

    // Calcolo i valori per tutti e trovo il minimo
    for (int i = list.size(); i > 0 ; i = i-2)
    {
        tmp=abs(list[i-1]+list[i]);
        if (tmp < min )
        {       
            min = tmp;
            a = i-1;
            b = i;
        }                
    }

    // Unisco chi ha dato il minimo
    list[a] = list[a]+list[b];
    if (abs(min) >= globalMin) {
        globalMin = abs(min);
    }
    list.erase(list.begin() + b);
    // Itero di nuovo


}
void dxRun()
{

}
void run() 
{
    int min;
    int tmp;
    int aS,bS, aD, bD;
    int minSx, minDx;
    int sumSx, sumDx;
    int offset = 0;

    // Clique di sinistra
    // Valore assoluto dei primi due
    if (list.size() > 1 )
    {
        minSx = list[0] + list[1];
        sumSx = list[0] + list[1];
        aS = 0;
        bS = 1;
    }
   // cout << "Sx F " << sumSx << endl << endl; 
    // Calcolo i valori per tutti e trovo il minimo
    for (int i = 3; i < list.size(); i = i+2)
    {
        tmp=list[i-1]+list[i];
        sumSx+=tmp;
        if (tmp < minSx )
        {       
            minSx = tmp;
            aS = i-1;
            bS = i;
        }     
//    cout << "Sx F tmp" << list[i-1] << " " << list[i] << " "<< tmp << "  " << sumSx << endl << endl;            
    }

    // per pari e dispari 
    if (list.size() %2 == 0)
    {
        offset = 1;
    }
    // Clique di Destra
    // Valore assoluto dei primi due
    if (list.size() > 1 )
    {
      //  cout << "=======P" << list[list.size()-1 - offset] << " " << list[list.size()-2-offset] << endl;
        minDx = list[list.size()-1 - offset] +list[list.size()-2 - offset];
        sumDx = list[list.size()-1- offset] +list[list.size()-2- offset];
        aD = 0;
        bD = 1;
    }

    // Calcolo i valori per tutti e trovo il minimo
    for (int i = list.size()-3 - offset; i > 0; i = i-2)
    {
     //   cout << list[i-1] << " " << list[i] << endl;
        tmp=list[i-1]+list[i];
        sumDx+=tmp;
        if (tmp < minDx )
        {       
            minDx = tmp;
            aD = i-1;
            bD = i;
        }     
   // cout << "Dx F tmp" << list[i-1] << " " << list[i] << " "<< tmp << "  " << sumDx << endl << endl;                
    }

   // cout << "Dx F " << sumDx << endl; 
    //cout << "Sx F " << sumSx << endl << endl; 
    // se il massimo di sinistra è minore di quello di destra allora vado a sinistra
    if (abs(sumSx) < abs(sumDx))
    {
     //  cout << "MinSx c " << list[aS] << " "<< list[bS] << endl;
        list[aS] = list[aS]+list[bS];
        if (abs(minSx) >= globalMin) {
            globalMin = abs(minSx);
        }
        list.erase(list.begin() + bS); 
    } else 
    {
       //cout << "MinDx c " << list[aD] << " "<< list[bD] << endl;
        list[aD] = list[aD]+list[bD];
        if (abs(minDx) >= globalMin) {
            globalMin = abs(minDx);
        }
        list.erase(list.begin() + bD);
    }
}

int main() {
   ifstream infile("input.txt");

    int n;
    infile >> n;

    int a;
    int sum;
    
    infile >> a;
    list.push_back(a);
    sum = a;

    while(infile >> a) 
    {
        list.push_back(a);
        sum+=a;
    }
    globalSum = sum;
    globalMin = 0;
    while(list.size() > 1)
    {
      //  printList();
        run();
    }
    //printList();
    outfile << globalMin << endl;
}
