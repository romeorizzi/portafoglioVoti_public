#include <iostream>
#include <fstream>

using namespace std;

int main(){

    int tot_numeri, tot_istruzioni, comando, r_inizio, r_fine;
    ifstream lettore("input.txt");
    ofstream scrittore("output.txt");
    lettore >> tot_numeri;
    lettore >> tot_istruzioni;
    int sequenza[tot_numeri],sequenza_risultati[tot_numeri];
    for(int i = 0;i < tot_numeri;i++){sequenza[i] = 0;sequenza_risultati[i] = 0;}
    for(int i = 0;i < tot_istruzioni;i++){
        lettore >> comando >> r_inizio >> r_fine;
        if(comando == 0){
            for(int k = r_inizio;k <= r_fine;k++){
                sequenza[k] += 1;
                sequenza_risultati[k] = sequenza[k] % 3;
            }
        }else{
            int conta_divisibili = 0;
            for(int k = r_inizio;k <= r_fine;k++){
                if(sequenza_risultati[k] == 0) conta_divisibili++;
            }
            
            scrittore << conta_divisibili << "\n";
        }
    }
    lettore.close();
    scrittore.close();

    return 0;
}
