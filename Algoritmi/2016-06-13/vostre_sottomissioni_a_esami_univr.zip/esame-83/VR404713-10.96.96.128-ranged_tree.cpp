#include<cassert>
#include<iostream>
#include<cstdio>
#include<fstream>
#include<list>
#include<climits>
#include<cfloat>
using namespace std;
const int MAX_N=100000;int n;
const int MAX_Q=100000;int q;
int array[MAX_N];
int comandi[3];

void incrementa(int a,int b){
    for(int i=a;i<=b;i++)
        array[i]++;
}

int divisibile(int a,int b){
    int n=0;
    for(int i=a;i<=b;i++)
         if(array[i]%3==0)
            n++;
    return n;
}

int main(){
//cout<<"ciao"<<endl;
    ifstream in("input.txt");
    ofstream myfile;
    myfile.open("output.txt");
    in>> n >> q;
    for(int i=0;i<q;i++){
        in>> comandi[0] >> comandi[1] >> comandi[2];
 //cout<< comandi[0] << comandi[1] << comandi[2];
        if(comandi[0]==0)
            incrementa(comandi[1],comandi[2]);
        else
            myfile<<divisibile(comandi[1],comandi[2])<<endl;
            
    }
    in.close();
    myfile.close();
    return 0;
}
