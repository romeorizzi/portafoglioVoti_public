#include <stdio.h>

FILE* in;
FILE* out;
int n;
int q;
static int tree[100000];

inline void execOp ();

int main (void)
{
    in = fopen("input.txt", "r");
    out = fopen("output.txt", "w");    
    fscanf(in, "%i", &n);
    fscanf(in, "%i", &q);

    for(int i = 0; i < q; ++i)
        execOp();

}

void execOp ()
{
    int counter = 0;
    int type;
    int start;
    int stop;

    fscanf(in, "%i %i %i", &type, &start, &stop);
    //fscanf(in, "%i", &start);
    //fscanf(in, "%i", &stop);

    if (type == 0)
        for (int i = start; i <= stop; ++i)
            tree[i]++;   
    else
    {
        for (int i = start; i <= stop; ++i)
            if (tree[i] % 3 == 0)
                counter++;

        fprintf(out, "%i\n", counter);   
    }
}
