#include <stdio.h>
#include <stdlib.h>

int main() {


    // Creo l'intero N, la quantità di numeri analizzati.
    
    int N = 0;

    // Creo l'intero Q, il numero di operazioni da eseguire.

    int Q = 0;

    // Creo un carattere per leggere il file.

    char character;

    // Creo un carattere di flag che mi permette di vedere quando sto
    //passando dal primo al secondo valore.

    int flag = 0;

    // Inizio la fase di lettura del file di input.

    FILE *fp;

    fp = fopen("input.txt","r");

    do {
        character = getc(fp);

        //printf ("%c",character);

        if (flag == 0){
            if (character == ' ')
                flag = 1;
            else{
                N = ( N * 10 ) + ( character - '0' );
            }
        }
        else {
            if (character == '\n')
                break;
            else{
                Q = ( Q * 10 ) + ( character - '0' );
            }
        }
        //printf("Intermedio: character = %c, N = %d, Q = %d.\n",character,N,Q);

    } while ( character != EOF );

    fclose(fp);

    //printf("\nN = %d, Q = %d.\n",N,Q);

    // Vado a creare un array di dimensione N per i numeri su cui lavoro.

    int numbers[N];

    // Creo una variabile di ciclo.

    int counter = 0;

    // Lo inizializzo a zero.

    for ( counter = 0; counter < N; counter++ )
        numbers[counter] = 0;

    // Controllo che sia a zero.
    /*
    for ( counter = 0; counter < N; counter++ )
        printf("%d",numbers[counter]);

    printf("\n");
    */
    // Vado a creare un array di dimensione [Q][3] per memorizzare operazione, inizio e fine.

    int operations[Q][3];

    // Lo inizializzo a zero.

    for ( counter = 0; counter < Q; counter++){
        operations[counter][0] = 0;
        operations[counter][1] = 0;
        operations[counter][2] = 0;
    }

    // Non c'è bisogno di inizializzarlo, lo farò dopo leggendo le cose dal file.

    // Reimposto la variabile di flag a zero.

    flag = 0;

    // Creo due varibile di indice per scorrere l'array in altezza e larghezza.

    int Qindex = 0;
    int OPindex = 0;

    fp = fopen("input.txt","r");

    do {
        character = getc(fp);

        //printf("PRIMA: flag: %d, character: %c, Qindex: %d, OPindex: %d\n",flag,character,Qindex,OPindex);

        if (flag == 0){
            if ( character == '\n' )
                flag = 1;
        }
        else{

            if ( character == '\n' ){
                Qindex++;
                OPindex = 0;
            }
            else{
                if ( character == ' ' )
                    OPindex++;
                else{

                    //printf("PRIMA: operations[%d][%d] = %d.\n",Qindex,OPindex,operations[Qindex][OPindex]);
                    operations[Qindex][OPindex] = ( operations[Qindex][OPindex] * 10 ) + ( character - '0' );
                    //printf("DOPO: operations[%d][%d] = %d.\n",Qindex,OPindex,operations[Qindex][OPindex]);
                }

            }

        }

        //printf("DOPO: flag: %d, character: %c, Qindex: %d, OPindex: %d\n",flag,character,Qindex,OPindex);

    } while ( character != EOF );

    fclose(fp);

    // Stampo l'array operations per essere sicuro di averlo letto correttamente.
    /*
    for (counter = 0; counter < Q; counter++){
        printf ("%d %d %d\n",operations[counter][0],operations[counter][1],operations[counter][2]);
    }
*/
    // OK! L'array è giusto!

    // Adesso è finita la parte di lettura, inizia l'algoritmo.

    // Creo una variabile che mi permetta di fare altri cicli.
    // counter la uso già per quello principale.

    int k = 0;

    // Creo un intero dove poter salvare il numero di elementi divisibili per tre.

    int div = 0;

    // Vado ad aprire il file output.txt in modalità scrittura.

    fp = fopen("output.txt","w");

    // Inizio un grande ciclo che scorre le istruzioni.

    numbers[0] = 0;

    for (counter = 0; counter < Q; counter++){

        // printf("numers[0]: %d\n",numbers[0]);

        if (operations[counter][0] == 0){
            // Eseguo l'operazione 0, +1 da A a B compresi.
            for (k = operations[counter][1]; k <= operations[counter][2]; k++){
                numbers[k]++;
            }
            printf("Adesso dopo l'operazione di incremento %d numbers vale:\n ",counter);
            for (k = 0; k < N; k++){
                printf("%d ",numbers[k]);
            }
            printf("\n");
        }
        else{
            // Nel ramo else eseguo l'operazione 1, il check della divisibilità.
            for (k = operations[counter][1]; k <= operations[counter][2]; k++){

                // Se l'operazione modulo mi dà come risultato 0 incremento div,
                // altrimenti non faccio niente.

                /*
                int temp = numbers[k] % 3;

                if (temp == 0)
                    div++;
                */
                if ( numbers[k] % 3 == 0 )
                    div++;

            }

            fprintf(fp,"%d\n",div);
            div = 0;

        }



    }


}
