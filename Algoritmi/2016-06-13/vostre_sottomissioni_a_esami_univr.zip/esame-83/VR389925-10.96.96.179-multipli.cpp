#include <cassert>
#include <iostream> 
#include <fstream>
#include <algorithm>

using namespace std;

int main() {
    int modifica = 0;
    int quantom = 0;
    int var = 0;
    int conta1=0;
    int N,Q;
    ifstream fin("input.txt");
    fin >> N >> Q;
    
    int valori [N];
    int tabella [Q][3];
    
    for(int i = 0; i< Q;i++){
        fin >> tabella[i][0];
        fin >> tabella[i][1];
        fin >> tabella[i][2];
        if(tabella[i][0]==1)
            conta1++;
    }
    int risultati [conta1];
    int rispar [conta1];
    int pos_ris=0;
    int sin,dest;
    int op = 0;
    int conta3 = N;
    sin=0;
    dest=0;
    
    fin.close();
    for(int i=0;i<N;i++){
        valori[i]=0;
        rispar[i] = 1+i;
    }
  
    for(int i = 0; i< Q;i++){
        op = tabella[i][0];
        sin = tabella[i][1];
        dest = tabella[i][2];
        //cout << "op " << op << " " << sin <<" "<< dest << endl;
        if(op == 0){
            
            for(int j=sin;j<= dest;j++)/*{
                if(valori[j] % 3 == 0){
                    modifica = 1;
                    quantom--;
                    conta3--;
                }
                if(valori[j] % 3 == 2){
                    modifica = 1;
                    quantom++;
                    conta3++;
                }
                valori[j]++;
                if(modifica == 1)
                    rispar[j] = rispar[j] + quantom;
            }
            if(dest != N-1){
                for(int j=dest+1;j< N;j++)
                    rispar[j]=rispar[j] +quantom;
            }
            quantom = 0;
            modifica = 0;*/
            valori[j]++;
        }
        else{
            for(int j=sin;j<= dest;j++){
                if(valori[j] % 3 == 0)
                    var++;
            }
           /* if(sin != 0){
                cout << "prova " << rispar[dest] << "-" << rispar[sin-1];
                risultati[pos_ris] = rispar[dest]-rispar[sin-1];
               
            }
            else{
                cout << "prova " << rispar[dest] << endl;
                risultati[pos_ris] = rispar[dest];
               
            }*/
            risultati[pos_ris] = var;
            var = 0;
            pos_ris++;
        }
    }
    ofstream fout("output.txt");
    for(int i=0;i<conta1;i++)
        fout << risultati[i] << endl;
    fout.close();
    return 0;
}

