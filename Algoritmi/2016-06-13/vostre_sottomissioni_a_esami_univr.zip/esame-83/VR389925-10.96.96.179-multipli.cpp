#include <cassert>
#include <iostream> 
#include <fstream>
#include <algorithm>

using namespace std;

int main() {
    int conta1=0;
    int N,Q;
    ifstream fin("input.txt");
    fin >> N >> Q;
    int valori [N];
    int tabella [Q][3];
    int risultati [conta1];
    int pos_ris=0;
    int sin,dest;
    int op = 0;
    int conta3 = N;
    sin=0;
    dest=0;
    for(int i = 0; i < Q; i++){
        
        fin >> tabella[i][0];
        fin >> tabella[i][1];
        fin >> tabella[i][2];
        if(tabella[i][0]==1)
            conta1++;
    }
    fin.close();

    for(int i=0;i<N;i++){
        valori[i]=0;
    }

    for(int i = 0; i< Q;i++){
        op = tabella[i][0];
        sin = tabella[i][1];
        dest = tabella[i][2];
        if(op == 0){
            for(int j=sin;j<= dest;j++){
                valori[j]++
                if(valori[j] % 3 == 0)
                    conta3++;
                else
                    conta3--;
            }
        }
        else{
            risultati[pos_ris] = conta3;
            pos_ris++;
        }
    }
    ofstream fout("output.txt");
    for(int i=0;i<conta1;i++)
        fout << risultati[i] << endl;
    fout.close();
    return 0;
}

