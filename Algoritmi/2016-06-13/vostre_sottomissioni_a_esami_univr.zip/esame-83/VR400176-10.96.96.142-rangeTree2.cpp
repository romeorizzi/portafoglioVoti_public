#include <bits/stdc++.h>
using namespace std;

#define N 100000
int arr[N];
int n;

void incArr(int a, int b);
int howManny(int a, int b);


void incArr(int a, int b){
  for(int i = a; i <= b; ++i)
    arr[i] = arr[i] + 1;
}


int howManny(int a, int b){
  int counter = 0;

  for(int i = a; i <= b; ++i)
    if((arr[i] % 3) == 0 || arr[i] == 0)
      counter++;

  return counter;
}


int main(){
  int q;
  ifstream input("input.txt");
  ofstream output("output.txt");

  input >> n >> q;

  // init array
  for(int i = 0; i < n; ++i)
    arr[i] = 0;

  int op, a, b;
  for(int i = 0; i < q; ++i){
      input >> op >> a >> b;

      if(op == 1)
        output << howManny(a,b) << endl;


      if(op == 0)
        incArr(a, b);
  }

  input.close();
  output.close();


  return 0;
}
