#include<stdio.h>

int n;
int vec[500];
int min;
int len;

int maxSum = -10000000;

inline int mod (int num);
inline void solve();
inline void solve3();

int mod(int num)
{
    if(num < 0)
        return 0 - num;

    return num;
}


void solve ()
{
    int pos = 0;
    int l = vec[0];
    int r = vec[1];
    min = mod(l + r);
    //maxSum = mod(min);

    for(int i = 1; i < len - 1; ++i)
    {
        if(mod(vec[i] + vec[i + 1]) < min)
        {
            l = vec[i];
            r = vec[i + 1];
            pos = i;
        }
    }

    vec[pos] = l + r;
    //printf("%i --- %i\n", mod(vec[pos]), maxSum);
    
    if (maxSum < mod(vec[pos]))
        maxSum = mod(vec[pos]);

    len--;
    
    for(int i = pos + 1; i < len; ++i)
        vec[i] = vec[i + 1];

  /*  
    // Stampa array
    for(int i = 0; i < len; ++i)
        printf("%i ", vec[i]);
    printf("\n");    
*/

    return;
}

void solve3()
{
    int localmin;
    int n1, n2, n3;
/*
    // Stampa array
    for(int i = 0; i < len; ++i)
        printf("%i ", vec[i]);
    printf("\n");    

*/
    n1 = vec[0] + vec[1];
    n2 = vec[1] + vec[2];
    n3 = vec[0] + n2;

  //  printf("\n%i %i %i\n", n1, n2, n3);


    if(n1 <= n2 && n1 <= n3)
        localmin = n1;
    else if(n1 <= n2 && n1 <= n3)
        localmin = n2;
    else localmin = n3;

    if (maxSum < mod(localmin))
        maxSum = mod(localmin);
}


int main ()
{
    FILE* in = fopen("input.txt", "r");
    fscanf(in, "%i", &n);
    len = n;

    for(int i = 0; i < n; ++i)
        fscanf(in, "%i", &vec[i]);

    if (n >= 3)
    {
        while (len > 3)
            solve();

        solve3();
    }
    else
        maxSum = vec[0] + vec[1];

    FILE* out = fopen("output.txt", "w");
    fprintf(out, "%i", maxSum);

}
