#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

std::vector<int> list;
ofstream outfile("output.txt");


void myPlus(int a, int b) {
    for ( int i = a; i <= b; i++) {
        list[i]++;
    }
}

void myTree(int a, int b) {
    int m = 0;
    for (int i = a; i <= b; i++) {
        if (list[i] % 3 == 0) m++;
    }
    outfile << m << endl;
}

void printList() {
    for(int i = 0; i < list.size(); i++) {
        cout << list[i] << " ";
    }
    cout << endl;
}
int main() {
   ifstream infile("input.txt");

    int n;
    int q;
    infile >> n >> q;
    list.resize(n);

    int a,b,op;
    
    while(infile >> op >> a >> b) 
    {
        if (op==1)
        {
            myTree(a,b);
        } else {
            myPlus(a,b);
        }
    }

}
