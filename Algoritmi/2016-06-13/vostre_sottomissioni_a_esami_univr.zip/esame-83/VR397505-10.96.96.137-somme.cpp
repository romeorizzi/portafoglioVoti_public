#include<fstream>
#include<algorithm>

using namespace std;

int arr[501];
long long int somme_residue[501];
int len;

/*long long int abs(long long int a){
    if (a>=0) return a;
    return -1*a;
}*/

long long int min(long long int a, long long int b){
    if(a<=b)
        return a;
    return b;
}

long long int max(long long int a, long long int b){
    if(a>=b)
        return a;
    return b;
}


void calcola_somme_residue(){
    for(int i=len-1; i>=0; i--)
        somme_residue[i]=arr[i]+somme_residue[i+1];
}

int minimo(int pos){
    if((len-1)==pos)
        return 0; //non sono sicuro
    
    if((len-pos)==3)
        return abs(arr[len]+arr[pos]);

    return min( max(abs(arr[pos]+arr[pos+1]) , minimo(pos+2) ) , ( abs(arr[pos] + somme_residue[pos+1]) + minimo(pos+1) ) );


}

int main (){
    ifstream infile("input.txt");
    ofstream outfile("output.txt");
    
    infile>>len;

    for(int i=0; i<len; i++)
        infile >> arr[i];

    somme_residue[len]=arr[len];

    calcola_somme_residue();

    outfile << minimo(0) << endl;

}
    
