#include <cstdlib>
#include <fstream>
#include <cassert>

using namespace std;

const int MAX_N = 1000000;
int n, k, vect[MAX_N];
int a, b, c;
ofstream fout("output.txt"); 

int maxSumFrom[MAX_N];  
void update(int s, int e, int a[]){
    int i;
    for(i=s; i<=e; i++)
        a[i]++;
}

void query(int s, int e, int a[]){
    int i, res=0;
    for(i=s; i<=e; i++)
        if(a[i]%3 == 0)
            res++;
    fout << res << "\n";
}
int main() {
  ifstream fin("input.txt"); assert(fin);
  
  fin >> n >> k;

  for(int i = 0; i < n; i++)
    vect[i]=0;

  for (int i=0; i<k; i++)
    {
        fin >> a >> b >> c;
        if(a==0)
            update(b,c,vect);
        else
            query(b,c,vect);
    }
  fin.close();
 
  fout.close();
  return 0;
}
