#include <cassert>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstdio>
#include <fstream>
using namespace std;


    const int MAX_N=500;
    int nums[MAX_N]; 
    int prov[MAX_N];
    int defin[MAX_N];
    int risp=0;
    int n;
    int val=n;
    int ok=0;

void somme(int a){
    for( int s=0; s<a; s++)
            prov[s-1]=(nums[s]+nums[s-1]);    
}

int main(){

    ifstream in("input.txt");
    in>>n;    
    int spoon;
    for( int i=0; i<n; i++){
        in>>spoon;
        nums[i]=spoon;   
        if (i!=0)        
            prov[i-1]=(nums[i]+nums[i-1]);    
    }
     for( int i=0; i<n; i++){
        for(int j=i;j<n;j++){
            if (ok==0){
                if(j==n-2){
                    nums[j]=prov[j];
                }
                else{
                     if(prov[j]<prov[j+1]){
                        nums[j]=prov[j];
                        }

                     else{
                        nums[j+1]=prov[j+1];
                         ok=2;
                    }            
                }
            }      
            else{
                ok=ok-1;
                if (ok==0){
                    nums[j]=0;
                }   
            }
        }
        val=val-1;
        somme(val);
for( int x=0; x<n; x++)
cout<<" "<<nums[x]; 
cout<<"\n"; 
    }
for( int x=0; x<n; x++)
cout<<"fine "<<nums[x]; 
cout<<"\n"; 
    
    ofstream myfile;
    myfile.open ("output.txt");
    myfile<<risp;
    myfile.close();
    return 0;
        
    }





