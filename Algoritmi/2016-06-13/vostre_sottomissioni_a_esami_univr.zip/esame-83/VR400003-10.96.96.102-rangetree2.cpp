#include <stdio.h>
#include <cstring>
#include <cassert>

#define MAX_N 100000
#define MAX_Q 100000


#warning SOLUZIONE IGNORANTE

FILE *fp;

int n, q;
int numeri[MAX_N];
int risposte[MAX_Q];
int domande = 0;

inline void op_zero(int a, int b)
{
    for(register int i = a; i <= b; ++i)
        ++numeri[i];
}

inline void op_uno(int a, int b)
{
    register int count = 0;
    for(register int i = a; i <= b; ++i)
       if(numeri[i] % 3 == 0)
            ++count;
    risposte[domande++] = count;
}

void leggi_input()
{
    int op, a, b;
    
    fp = fopen("input.txt", "r");
    assert(fp);

    fscanf(fp, "%d %d", &n, &q);

    memset(numeri, 0, n * sizeof(int));

    for(int i = 0; i < q; ++i)
    {
        fscanf(fp, "%d %d %d", &op, &a, &b);
        if(op)
            op_uno(a, b);
        else
            op_zero(a, b);
    }    
    

    fclose(fp);
}

void scrivi_output()
{
    fp = fopen("output.txt", "w");
    assert(fp);

    for(int i = 0; i < domande; ++i)
        fprintf(fp, "%d\n", risposte[i]);
    fclose(fp);
}

void calcola()
{
    
}

int main()
{
    leggi_input();
//    calcola();
    scrivi_output();    
    return 0;
}
