#include <cassert>
#include <iostream>
#include <fstream>

using namespace std;

int array[100000],n,q,riga[3];


//conto quante volte riesco a dividere per 3
int operazione_dividi(int a, int b){
	int n = 0;
	for(int i=a;i<=b;i++){
			if(array[i]%3 == 0){
				n++;
			}
	}
	return n;
}


//incremento tra a e b
void operazione_incrementa(int a, int b){
	for(int i=a;i<=b;i++){
		array[i]++;
	}
}


int main() {

    ifstream in("input.txt");
    ofstream outfile;

    //Apro il file
    outfile.open("output.txt");

    //Associo l'intero n e q
    in >> n >> q;

    //Ciclo per tutto q 
    for(int i=0; i<q; i++){
	    in >> riga[0] >> riga[1] >> riga[2];

        //Devo operazione_incrementare
        if(riga[0]==0){
	        operazione_incrementa(riga[1],riga[2]);

        }
        //Devo provare a dividere
        else {
	        outfile << operazione_dividi(riga[1],riga[2]) << endl; 
        }

    }

    outfile.close();
    in.close();
    return 0;
}
