#include <bits/stdc++.h>
#define DIM 100000
using namespace std;
int N, Q;
int m[DIM][3];
int v[DIM];

void calcolo();
int calcolaNumeriDivisibiliPerTre(int A, int B);
void incrementaValoreDiIndice(int A, int B);

int main() {
ifstream in("input.txt");
  in >> N >> Q;

  for (int pos = 0; pos < N; pos++)
    v[pos] = 0;

  for(int i = 0; i < Q; i++)
    for(int j = 0; j < 3; j++)
        in >> m[i][j];

  in.close();

  calcolo();


return 0;
}

void calcolo() {
    int res = 0;
    ofstream out("output.txt");
    for(int i = 0; i < Q; i++) {
        if(m[i][0] == 1) {
            int res = calcolaNumeriDivisibiliPerTre(m[i][1], m[i][2]);
            out << res << endl;
        }

        else
            incrementaValoreDiIndice(m[i][1], m[i][2]);

     }

     out.close();
}

int calcolaNumeriDivisibiliPerTre(int A, int B) {
int result = 0;
    if(A < B) {
       for(int pos = 0; pos < N; pos++)
            if(v[pos] >= A && v[pos]<= B)
                if(v[pos]%3 == 0)
                 result++;
    }
    else{
        if(A > B)
            for(int pos = A; pos >= B; pos--)
                if(v[pos] >= A && v[pos]<= B)
                    if(v[pos]%3 == 0)
                        result++;

        else {
            if(v[pos] == A)
                if(v[pos]%3 == 0)
                    result++;
        }
    }

    return result;

}

void incrementaValoreDiIndice(int A, int B){
    if(A < B) {
        for(int pos = A; pos <= B; pos++)
            v[pos]++;
    }
    else{
        if(A > B)
            for(int pos = A; pos >= B; pos--)
                v[pos]++;
        else {
            v[A]++;v[B]++;
        }
    }
}

