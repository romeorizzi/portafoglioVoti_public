#include <iostream>
#include <fstream>

using namespace std;

int N,Q;
const int MAX_N=100000,MAX_Q=100000;
int nums[MAX_N];
int acc[MAX_N];

void inc(int ind){
    nums[ind]++;
    nums[ind]=nums[ind]%3;
    if(nums[ind]==0){
        for(int i=ind;i<N;i++){
            acc[i]++;
        }
    }
    else{
        if(nums[ind]==1){
            acc[ind]--;
            for(int i=ind+1;i<N;i++){
                acc[i]=acc[i-1]+(nums[i]==0?1:0);
            }
        }
    }
}

void incRange(int a, int b){
    int diff=0;
    for(int i=a;i<N;i++){
        if(i<=b){
            nums[i]++;
            nums[i]=nums[i]%3;
            if(nums[i]==0){
                diff++;
            }
            else if(nums[i]==1){
                diff--;
            }
        }
        acc[i]+=diff;
    }
}

int inline readAcc(int i){
    return i<0?0:acc[i];
}

int rangeQuery(int a, int b){
    return readAcc(b)-readAcc(a-1);
}

void printAcc(){
    for(int j=0;j<N;j++){
        cout<<nums[j]<<" ";
    }
    cout<<endl;
    for(int j=0;j<N;j++){
        cout<<acc[j]<<" ";
    }
    cout<<endl;
}

int main(){

    ifstream input("input.txt");
    ofstream output("output.txt");
    input>>N>>Q;
    for(int i=0;i<N;i++){
        nums[i]=0;
        acc[i]=(i==0)?(1):(acc[i-1]+1);
    }
    int c, a, b;
    if(output.is_open()){
        for(int i=0;i<Q;i++){
            input>>c>>a>>b;
            if(c==1){
                output<<rangeQuery(a,b)<<endl;
                //printAcc();
            }
            else{
                //Ottimizza l'incremento
                //cout<<"inc "<<a<<"--"<<b<<endl;
                /*for(int j=a;j<=b;j++){
                    inc(j);
                    cout<<"inc "<<j<<endl;
                    printAcc();
                }*/
                //ANDREBBE USATO UN ALBERO DI FENWEEK PER UPDATE LOGARITMICO, MA NON RICORDO COME
                incRange(a,b);
            }
        }
    }
    input.close();
    output.close();
    return 0;
}
