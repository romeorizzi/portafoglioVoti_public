#include <bits/stdc++.h>

using namespace std;
int N, M, T;


int solve(int N, int M, int T, int *S, int *E){
  int counter = 0;
  int *e = E; // reverse mareea
  int *s = S;


  int pos = E[0];
  for(int i = 1; i < M; ++i){

      // alta mareea, reverse
      if(T == i){
        *S = e;
        *E = s;

      }else{


        if(S[i] == pos){
          counter++;
        }else{
          counter--;
        }
      }


  }


  return counter == 0 ? -1 : counter;

}

