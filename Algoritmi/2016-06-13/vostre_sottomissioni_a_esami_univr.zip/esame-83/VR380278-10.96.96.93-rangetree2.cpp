#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <string>
#include <cstdlib>
#include <cmath>
#include <ctype.h>
#include <stack>
#include <queue>
#include <limits.h>

#define rep(i,a) for(int i=0; i<a;i++)
#define fo(i,a,b) for(int i=a; i<b; i++)
#define defo(i,a,b) for(int i=a; i>=b; i--)
#define ll long long
#define pb push_back
#define mp make_pair
#define sz(a) ((int)(a.size()))
#define x first
#define y second
#define SET(x,a) memset(x,a, sizeof(x));

using namespace std;
const int MAX = 1<<18;

typedef vector<int> VI;
typedef vector<double> VD;
typedef vector<char> VC;
typedef pair<int, int> PI;

inline int next_int() {
    int n = 0;
    char c = getchar_unlocked();
    while(!('0' <= c && c<= '9')){
    c = getchar_unlocked();
    } 
    while('0' <= c && c<= '9'){
        n = n * 10 + c - '0';
         c = getchar_unlocked();
    }
    return n;
}

void init (int, int, int);
void update (int, int, int , int, int);
int query (int, int, int , int, int, int);

struct segnode{
    
    int d[3], flip;
} tree[MAX];

int main() {
    int n,q;
    n = next_int();
    q = next_int();
    init(1, 0, n-1);
    while(q--) {
    int op, xi, yi;
    op = next_int();
    xi = next_int();
    yi = next_int();
    if(op)
        printf("%d\n", query(1,0,n-1,xi,yi,0));
    else
        update (1,0,n-1,xi,yi);
    }
    return 0;
}

void init (int node, int b, int e){
    if (b==e){
        tree[node].d[0]=1;
        tree[node].d[1]=tree[b].d[2] = 0;
        tree[node].flip=0;
        return;
    }
    int mid, l, r;
    l = node << 1;
    r = l+1;
    mid = (b+e) >> 1;
    init(l, b, mid);
    init(r, mid +1, e);
    tree[node].d[0] = tree[l].d[0] + tree[r].d[0];
}

void update (int node, int b, int e, int xi, int yi) {
    printf("%d, %d, %d, %d, %d\n", node, b, e, xi, yi);
    if (b == xi && e == yi){
        tree[node].flip++;
        swap (tree[node].d[0], tree[node].d[1]);
        swap (tree[node].d[0], tree[node].d[2]);
        return;
    }
    int l,r,mid;
    l = node << 1;
    r = l+1;
    mid = (b+e) >> 1;
    if (yi <= mid) update(l,b,mid,xi,yi);
    else if (xi>mid) update(r,mid+1, e, xi,yi);
    else {
        update (l,b, mid, xi, mid);
        update (r, mid+1, e, mid+1, yi);
    }
    tree[node].d[0] = tree[l].d[0] + tree[r].d[0];
    tree[node].d[1] = tree[l].d[1] + tree[r].d[1];
    tree[node].d[2] = tree[l].d[2] + tree[r].d[2];
    switch (tree[node].flip % 3){
    case 1: swap (tree[node].d[0], tree[node].d[1]);
            swap (tree[node].d[0], tree[node].d[2]);
            break;
    case 2: swap (tree[node].d[0], tree[node].d[2]);
            swap (tree[node].d[0], tree[node].d[1]);
            break;
    }
}

int query (int node, int b, int e, int xi, int yi, int flips){
    if (b == xi && e == yi){
        switch(flips%3){
            case 0: return tree[node].d[0];
            case 1: return tree[node].d[2];
            case 2: return tree[node].d[1];
        }
    }
    int l, r, mid;
    l = node << 1;
    r = l+1;
    mid = (b+e) >> 1;
    flips += tree[node].flip;
    if (yi<=mid) return query (l,b,mid,xi,yi,flips);
    else if (xi > mid) return query(r, mid+1, e, xi, yi, flips);
    else
        return query(l, b, mid, xi, mid, flips) + query (r, mid+1, e, mid+1, yi, flips);
}
