#include <cstdio>
#include <cstdlib>
#include <string>
#include <cmath>

using namespace std;


void init(int* arr,int n){
    for(int i=0; i<n;i++){
         *(arr+i) = 0;
    }
}

void add(int* arr,int a,int b){
    for(int i=a; i<b+1;i++){
         *(arr+i) += 1;
    }
}
int div(int* arr,int a,int b){
    int count = 0;
    for(int i=a; i<b+1;i++){
        if(*(arr+i)%3 == 0)
            count++;
    }
    return count;
}

int main(){

    //INPUT
    FILE* in = fopen("input.txt","r");

    int n,q,cmd,a,b;
    fscanf(in, "%d %d\n",&n,&q);
    int* arr = (int*)malloc(n*sizeof(int));
    init(arr,n);
    FILE* out = fopen("output.txt","w");
    for(int j=0; j<q;j++){
        fscanf(in, "%d %d %d\n",&cmd,&a,&b);
        if(cmd == 0){
            add(arr,a,b);
        } else if(cmd == 1) {
            fprintf(out,"%d\n",div(arr,a,b));
        }
    }

    //COMPUTATION
    //FILE* out = fopen("output.txt","w");    //OUTPUT
    //FILE* out = fopen("output.txt","w");
    //fprintf(out,"%d\n",div(arr,a,b););
    return 0;
}
