#include <cstdlib>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int MAXN=502;
int N;
int PICCO=0;

vector<int> NUMERI(MAXN);
vector<int> TRASLATO(MAXN);
vector<int> DIFFERENZE(MAXN);


inline int posizione_primo_da_eliminare(int minimo){
    for(int i=0; i<N; i++){
        if(DIFFERENZE[i]==minimo){
            return i;
        }
    }
    //non ci va mai
    return -1;
}

inline void aggiorna_differenze(int pos){
    for(int i=0; i<N-1; i++){
        DIFFERENZE[i]=abs(NUMERI[i]+TRASLATO[i]);
    }
}

int main(){
    ifstream in ("input.txt");
    ofstream out ("output.txt");

    int temp;
    int minimo=0;
    int pos;

    //Prendo l'input
    in>>N;
    in>>temp;
    NUMERI[0]=temp;

    for(int i=1; i<N; i++){
        in>>temp;
        NUMERI[i]=temp;
        TRASLATO[i-1]=temp;
    }

    for(int i=0; i<N-1; i++){
        DIFFERENZE[i]=abs(NUMERI[i]+TRASLATO[i]);
    }


    while(N>0){
        minimo=*min_element(DIFFERENZE.begin(), DIFFERENZE.begin()+(N-1));

        pos=posizione_primo_da_eliminare(minimo);
        int a=*(NUMERI.begin()+pos);
        int b=*(NUMERI.begin()+pos+1);



        NUMERI.erase(NUMERI.begin()+pos, NUMERI.begin()+pos+2);
        NUMERI.insert(NUMERI.begin()+pos, a+b);
        TRASLATO.erase(TRASLATO.begin()+pos);
        N--;

        aggiorna_differenze(pos);

        if(a+b>PICCO){
            cout<<a+b<<" "<<PICCO<<endl;
            PICCO=a+b;
        }

    }

    out<<PICCO;
/*
    temp=*min_element(NUMERI.begin(), NUMERI.end());

    cout<<abs(temp);


    for(int i=0; i<N; i++){
        printf("%d ", NUMERI[i]);
    }
    cout<<endl;
    for(int i=0; i<N; i++){
        printf("%d ", TRASLATO[i]);
    }
*/
    return 0;
}
