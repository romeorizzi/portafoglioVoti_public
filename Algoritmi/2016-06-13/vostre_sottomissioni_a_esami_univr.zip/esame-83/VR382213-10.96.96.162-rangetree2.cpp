#include<iostream>
#include<fstream>
using namespace std;

int v[100000];
int N;

void aumenta(int x, int y) {
    // aumenta di 1 nell'intervallo x e y
    for(int j = x; j <= y; j++)
        v[j] = v[j] + 1;
    return;
}

int rispondi(int x, int y) {
    // quanti numeri tra x e y sono divisibili per 3
    int count = 0;
    for(int j = x; j <= y && j < N; j++)
        if( (v[j]) % 3 == 0)
            count++;
    return count;
}

int main() {
    int Q;
    int a, b, i;
    int op, t=0, count=0; 
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    fin >> N >> Q;
    // inizializzo il vettore
    for(i = 0; i < N; i++) 
        v[i] = 0;

    for(i = 0; i < Q; i++) {
        fin >> op >> a >> b;
        if(op == 0)
            aumenta(a, b);
        else {
            fout << rispondi(a, b);
            fout << endl;
        }
    }
    return 0;
}

