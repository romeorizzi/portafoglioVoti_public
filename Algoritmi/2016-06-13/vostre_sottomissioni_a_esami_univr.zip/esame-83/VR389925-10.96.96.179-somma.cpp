#include <cassert>
#include <iostream> 
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    long int N;
    ifstream fin("input.txt");
    fin >> N;
    vector<long int> valori;
    int temp = 0;
    
    for(int i=0;i<N;i++){
        fin >> temp;
        valori.push_back(temp);
    }
    fin.close();
    for(int i =0 ;i<N ;i++)
          cout << valori[i] << endl;
        cout << "ffffff" << endl;
    long int min=0;
    long int max=-1;
    long int pos1;
    long int pos2;

    for(long int j=0;j<N;j++){
        min =  valori[0] + valori[1];
        pos1=0;
        pos2=1;
        for(long int i=0;i<N-1;i++){
            temp = valori[i] + valori[i+1];
            if(fabs(temp) < fabs(min)){
                min = temp;
                pos1=i;
                pos2=i+1;
            }
        }
        valori[pos1]=min;
        valori.erase(valori.begin()+pos2);
        N = N-1;
        if(fabs(min) > max)
            max = fabs(min);
        for(int i =0 ;i<N ;i++)
          cout << valori[i] << endl;
        cout << "gggggg" << endl;
    }
    ofstream fout("output.txt");
    fout << max;
    fout.close();
    cout << max << endl;
    return 0;
}
