#include<cassert>
#include<iostream>
#include<cstdio>
#include<fstream>
#include<list>
#include<climits>
#include<cfloat>
using namespace std;
const int MAX_N=500;int n;
int array[MAX_N];
int costo_max=0;

void rezsum(int a,int b){
    array[a]+=array[b];
    cout<<array[a]<<" "<<a<<" "<<b<<endl;
    if(abs(array[a])>costo_max)
        costo_max=abs(array[a]);
    n--;
    for(int i=b;i<n;i++)
        array[i]=array[i+1];

}
void somma(){
    int x=INT_MAX,a,b;
    for (int i=0;i<n-1;i++){
        if(abs(array[i]+array[i+1])<=x){
            a=i;
            b=i+1;
            x=abs(array[i]+array[i+1]);
        }
    }
    rezsum(a,b);
    
}
        
    

int main(){
//cout<<"ciao"<<endl;
    ifstream in("input.txt");


    in>> n;
    for(int i=0;i<n;i++)
        in>>array[i];



    in.close();


    while(n>1){
        somma();
    }    
    ofstream myfile;
    myfile.open("output.txt");
    myfile<<costo_max;
    myfile.close();
    return 0;
}
