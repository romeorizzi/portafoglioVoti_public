#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int cheap_sum();

int n, sum=0;
vector<int> p_numbers;
vector<int> n_numbers;

int main(){

 ifstream input("input.txt");
 input>>n;
 int num=0;
 for(int i=0; i<n;i++){

  input>>num;
  if(num==0)continue;
  if(num>0)
  {
   p_numbers.push_back(num);
   sort(p_numbers.begin(), p_numbers.end());
  }
  else
  {
   n_numbers.push_back(num);
   sort(n_numbers.begin(), n_numbers.end());
  }
  sum+=num;
 }
/* cout<<n<<" "<<sum<<endl;
 for(int j=0;j<p_numbers.size();j++)
      cout<<p_numbers[j]<<endl;
 cout<<endl;
 cout<<endl;
 for(int k=0;k<n_numbers.size();k++)
      cout<<n_numbers[k]<<endl;*/
 
 
 ofstream output("output.txt");
 int peak=cheap_sum();
 output<<peak;
}

int cheap_sum(){

  int least_peak=sum;
  int partial=0, p_partial=0, n_partial=0;
  int max_p=p_numbers[p_numbers.size()-1];
  int max_n=n_numbers[0];
  bool go_with_positive=false;
  if(fabs(max_p)<=sum && fabs(max_n)<=sum) return least_peak;
  while(!p_numbers.empty() || !n_numbers.empty())
  {
  
   max_p=p_numbers[p_numbers.size()-1];
   max_n=n_numbers[0];
   p_partial=partial + max_p;
   n_partial=partial + max_n;
   cout<<endl;
   
   if(fabs(p_partial)<= fabs(n_partial))
   { 
     go_with_positive=true;
     cout<<" positive"<<endl;
   }
   else
   {
     go_with_positive=false;   
     cout<<" negative"<<endl;
   }

   if(p_numbers.empty())go_with_positive=false;
   if(n_numbers.empty())go_with_positive=true;
   if(go_with_positive)
   {
     partial+=max_p;
     p_numbers.erase(p_numbers.end()-1);
   }
   
   else
   {
     partial+=max_n;
     n_numbers.erase(n_numbers.begin());
   }
     
  }
  least_peak=partial;
  return least_peak;
}
