#include <iostream>
#include <cstdlib>
#include <cassert>
#include <cstdio>
#include <fstream>
//#include <climits>
//#include <string.h>
using namespace std;

int main(){
FILE*input =fopen("input.txt","r");

int N,Q;

fscanf(input,"%d %d",&N,&Q);

int* nums=new int[N]();
int C,A,B,count;

FILE* output =fopen("output.txt","w");
if (A-B>1){

for (int i=0;i<Q;i++){
fscanf(input,"%d %d %d",&C,&A,&B);
    if (C==0){

    for (int j=A;j<=B;j++)
    (A+j)++;
    }
    else{

    count=0;
        for (int j=A;j<=B;j++){
            if((A+j)%3==0)
                count++;

        }

fprintf(output,"%d \n",count);
}

}
}

}

