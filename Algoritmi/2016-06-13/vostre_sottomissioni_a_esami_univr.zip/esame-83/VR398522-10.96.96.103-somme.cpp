#include <iostream>
#include <fstream>
#include <math.h>

using namespace std;

#define MAXN 500

int n[MAXN];
int N;
int my_min;
int size;
int e1, e2;
int peak = 0;

//int max(int a, int b){return a>b? a : b ;)

void trova_min()
{
    int i;
    
    my_min = n[0]+n[1];
    e1 = 0;
    e2 = 1;
    
    for(i = 1; i<size-1; ++i)
    {
        if(n[i]+n[i+1] < my_min)
        {
            my_min = n[i]+n[i+1];
            e1 = i;
            e2 = i+1;
        }  
    }
    
    // Aggiorno il picco
    peak = fabs(my_min) > peak ? fabs(my_min) : peak;
    cout<<"my_min "<< my_min<<" peak "<<peak<<endl;
}

void somma()
{
    n[e1] = n[e1]+n[e2];
}

void compatta()
{
    int i;
    for(i = e2; i < size-1; ++i)
    {
        n[i] = n[i+1];
    }
    // Aggiorno la size
    size--;
}

int main()
{
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    fin >> N;
    size = N;
    int i;
    
    // Leggo
    for(i = 0; i<N; ++i)
    {
      fin >> n[i];
    }
    
    for(i = 0; i<N-1; ++i)
    {
        // Trovo
        trova_min();
        // Sommo
        somma();
        // Compatto    
        compatta();
    }
    
    fout << peak << endl;

    return 0;
    
}


