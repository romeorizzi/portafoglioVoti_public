#include <cassert>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstdio>
#include <fstream>
#include <queue>
#include <limits>
using namespace std;

struct vert{
    int dd;
    int ds;
    vector<int> adj;
    bool markedb;
    bool markeda;
    vert(){
    dd= ds = -1;
    markedb=markeda=false;    
    }
};
    vector<vert> vertl;
    queue<vert*> bfsq;

    int solve(int N, int M, int T, int* S, int* E){
        unsigned int i;
        int j, ris = numeric_limits<int>::max();
        vertl.assign(N, vert());
        vert* bfsv;
        
        for(int j=0;j<M;j++)
            vertl[S[j]].adj.push_back(E[j]);
            bfsq.push(&vertl[N-1]);
            vertl[N-1].markeda=true;
            vertl[N-1].dd=0;
            while(!bfsq.empty()){
                bfsv=bfsq.front();
                bfsq.pop();
                for(i=0;i<bfsv->adj.size();i++){
                    if(!vertl[bfsv->adj[i]].markeda){       
                        vertl[bfsv->adj[i]].markeda=true;
                        vertl[bfsv->adj[i]].dd=bfsv->dd+1;
                        bfsq.push(&vertl[bfsv->adj[i]]);
                    }
                }            
            }   
            bfsq.push(&vertl[0]);
            vertl[0].markedb=true;
            vertl[0].ds=0;
             while(!bfsq.empty()){
                bfsv=bfsq.front();
                bfsq.pop();
                if(bfsv->ds>T)
                    break;
                if(bfsv->dd!=-1&&ris>T+bfsv->dd)
                    ris=T+bfsv->dd;
                for(i=0;i<bfsv->adj.size();i++){
                    if(!vertl[bfsv->adj[i]].markedb){       
                        vertl[bfsv->adj[i]].markedb=true;
                        vertl[bfsv->adj[i]].ds=bfsv->ds+1;
                        bfsq.push(&vertl[bfsv->adj[i]]);
                    }
                }
            }
            if(vertl[N-1].ds != -1 && vertl[N-1].ds <= T)
                ris=vertl[N-1].ds;
            if(ris == numeric_limits<int>::max())
                ris=-1;

    return ris;
   }         
