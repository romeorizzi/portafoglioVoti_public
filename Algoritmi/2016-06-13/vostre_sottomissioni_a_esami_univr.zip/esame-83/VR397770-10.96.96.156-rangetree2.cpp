#define DEBUG

#include<fstream>
#include<cassert>
#include<vector>
#include<bitset>
#include<cmath>

using namespace std;

#define MAX_N 100000
#define MAX_Q 100000

int N, Q;

vector<int> numeri ( MAX_N, 0 );
vector<int> divisibili ( MAX_N + 1, 0 );

/*int divisibili_per_tre( int start, int end ) {

    return divisibili[end] - divisibili[start-1];
}*/

int divisibili_per_tre( int start, int end ) {

    int num_divisibili = 0;
    for( int i = start; i <= end; ++i ) {
        if( numeri[i] % 3 == 0 )
            ++num_divisibili;
    }

    return num_divisibili;
}

void aumenta_di_uno( int start, int end ) {
    for( int i = start; i <= end; ++i ) {
        ++numeri[i];
    }
/*
    int num_divisibili = divisibili[start-1];
    for( int i = start; i <= end; ++i ) {
        ++numeri[i];
        if( numeri[i] % 3 != 0 ) {
            divisibili[i] = num_divisibili;
        } else { // se è divisibile
            ++num_divisibili;
            divisibili[i] = num_divisibili;
        }
    }
    if( end + 1 < N && divisibili[end+1] != num_divisibili ) {
        num_divisibili -= divisibili[end+1];
        for( int i = end+1; i < N; ++ i ) {
            divisibili[i] += num_divisibili;
        }
    }
    */
    return;
}

int main() {

    ifstream inFile("input.txt");  assert(inFile);
    ofstream outFile("output.txt");  assert(outFile);

    inFile >> N >> Q;
    assert( 1 <= N && N <= MAX_N );
    assert( 1 <= Q && Q <= MAX_Q );

    int c, a, b;

    for( int i = 0; i < Q; ++i ) {
        inFile >> c >> a >> b;
        assert( c == 1 || c == 0 );
        assert( 0 <= a && a < N );
        assert( 0 <= b && b < N );
        assert( a <= b );
        if( c == 1 ) {
            int risp = divisibili_per_tre( a, b );
            outFile << risp << endl;
        } else if( c == 0 ) aumenta_di_uno( a, b );
    }

    inFile.close();
    outFile.close();

    return 0;
}
