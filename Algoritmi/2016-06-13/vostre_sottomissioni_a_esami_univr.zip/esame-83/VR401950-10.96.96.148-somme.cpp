#include <iostream>
#include <fstream>
#include <limits.h>
#include <cmath>
#include <vector>

using namespace std;

int N;
int posA, posB, posMax;
int energy = 0;
vector<int> S;

void print (vector<int> V) {
    for (int i = 0; i < V.size(); i++)
        cout << V[i] << " ";

    cout << endl;
}

int findPosMax() {
    int max = abs(S[0]);
    int posMax = 0;
        
    for (int i = 1; i < N; i++) {
        if (abs(S[i]) > max) {
            max = abs(S[i]);
            posMax = i;
        }
    }
    return posMax;
}

int minSum (int init, int end) {
    int minSum = INT_MAX;
    int tmp = 0;

    for (int i = init; i < end - 1; i++) {
        tmp = S[i] + S[i+1];
        cout << "tmp  = " << tmp << endl;
        if ( tmp < minSum ) {
            minSum = tmp;
            posA = i;
            posB = i+1;
        }
    }
    return minSum;
}

void updateVector(int e) {
    cout << "update" << endl;
    vector<int> T;
    T.resize(S.size() - 1);
    int j = 0;

    for (int i = 0; i < S.size(); i++) {
        if (i != posA && i != posB) {
            T[j] = S[i];
            j++;
        } else if (i == posA) {
            T[j] = e;
            j++;
        }
    }
    print(T);

    S.clear();    
    S.resize(T.size());
    copy(T.begin(), T.end(), S.begin());
    print(S);
}

void calculateEnergy(int posMax) {
    int e1 = INT_MIN;
    int e2 = INT_MIN;    

    cout << "size S = " << S.size() << endl;
    if (S.size() == 3) {
        e1 = S[0] + S[1];
        e2 = S[1] + S[2];

        cout << "e1 = " << e1 << endl;
        cout << "e2 = " << e2 << endl;
        if (abs(e1) < abs(e2)) {
            cout << "1" << endl;
            posA = 0;
            posB = 1;
            updateVector(e1);
            e2 = e1;
        } else {
            cout << "2" << endl;
            posA = 1;
            posB = 2;
            updateVector(e2);
            e1 = e2;
        }
    } else if (S.size() == 2) {
        print(S);
        e1 = S[0] + S[1];
        e2 = e1;
        S.clear();
    } else {

        cout << "posMax = " << posMax << endl;
    
        if ( posMax > 1 ) {
            e1 = minSum (0, posMax);
            cout << "e1 = " << e1 << endl;
            updateVector(e1);
            posMax--;
        }
        
        cout << "posMax = " << posMax << endl;

        if ( (posMax + 1 - S.size() ) > 1) {
            e2 = minSum (posMax + 1, S.size());    
            cout << "e2 = " << e2 << endl;
            updateVector(e2);
        }
    }
    

    if (e1 != INT_MIN)
        energy = abs(e1) > energy ? abs(e1) : energy;
    if (e2 != INT_MIN)
        energy = abs(e2) > energy ? abs(e2) : energy;
   
    cout << "energy = " << energy << endl;

    if( !S.empty() )
        calculateEnergy(posMax);
    else return;
        
}   

int main () {
    ifstream instream("input.txt");
    ofstream outstream("output.txt");

    instream >> N;
    S.resize(N);

    for (int i = 0; i < S.size(); i++)
        instream >> S[i];

    print(S);
    posMax = findPosMax();

    calculateEnergy(posMax);

    outstream << energy;    

    return 0;
}
