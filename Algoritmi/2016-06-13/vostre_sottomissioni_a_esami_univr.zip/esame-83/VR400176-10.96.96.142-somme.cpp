#include <bits/stdc++.h>

using namespace std;

#define N 500


int incArr(int arr[], int n){
  int vals[n-1];
  map<int, int> m;
  map<int, int> b;

  if(n == 1)
      return arr[0];

  int temp;
  for(int i = 1; i < n; ++i){
    temp = arr[i-1] + arr[i];
    b[i] = temp;
    vals[i-1] = abs(temp);
    m[vals[i-1]] = i;
  }


  int minVal = *min_element(vals, vals+(n-1));
  int pos = m[minVal];

  int newArr[n-1];

  int j = 0;
  for(int i = 0; i < n-1; i++){

    if(i == pos-1){
      newArr[i] = b[pos];
      j++;
    }else
      newArr[i] = arr[j];

    j++;
  }

   return incArr(newArr, n-1);
}


int main(){
  int n;
  ifstream input("input.txt");
  ofstream output("output.txt");
  input >> n;

  int arr[n];

  for(int i = 0; i < n; ++i)
    input >> arr[i];

  input.close();

  output << abs(incArr(arr, n)) << endl;

    return 0;
}
