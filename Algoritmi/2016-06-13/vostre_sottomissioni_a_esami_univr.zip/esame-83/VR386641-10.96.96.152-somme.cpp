#include <cstdlib>
#include <fstream>
#include <cassert>

using namespace std;

const int MAX_N = 1000000;
int n, k, vect[MAX_N];
int result;
ofstream fout("output.txt"); 

int main() {
  ifstream fin("input.txt"); assert(fin);
  
  fin >> n;
  int vector[n];

  for(int i = 0; i < n; i++)
    fin >> vector[i];

  fin.close();
  result=vector[n-1];
  for(int i = n-2; i >= 0; i--)
    result += vector[i];
  
  if(result<0)
    result *= -1;

  fout << result;
  fout.close();
  return 0;
}
