#define DEBUG

#include<fstream>
#include<cassert>
#include<vector>
#include<iostream>

using namespace std;

#define MAX_N 200000
#define MAX_M 300000
#define MAX_T 1000000000

void copia( int* source, int* dest, int dim ) {
    for( int i = 0; i < dim; ++i )
        dest[i] = source[i];
    return;
}

int solve( int N, int M, int T, int* S, int *E ) {

    assert( 2 <= N && N <= MAX_N );
    assert( 1 <= M && M <= MAX_M );
    assert( 0 <= T && T <= MAX_T );

    vector<bool> visitato( N, false );
    vector<int> tempi( N );
    int scorrere_tempo = 0;

    visitato[0] = true;
    tempi[0] = 0;

    for( int i = 0; i < M; ++i ) {
        //cout << "visitato[" << S[i] <<"]= " << visitato[S[i]] << " visitato[" << E[i] <<"]= " << visitato[E[i]] << " tempi[" << S[i] << "]= " << tempi[S[i]] << endl;
        if( tempi[S[i]] == T ) {
            break;
        }
        int myT = tempi[S[i]] + 1;
        if( visitato[S[i]] == true && ( visitato[E[i]] == false || ( visitato[E[i]] == true && myT < tempi[E[i]] ) ) ) {
                visitato[E[i]] = true;
                //cout << "visitato[" << E[i] << "] = true" << endl;
                tempi[E[i]] = myT;
                //cout<< "qui tempi[" << E[i] << "]= " << tempi[E[i]] << endl;
                //cout << "i= " << i << " E[i] = " << E[i] << " tempi[E[i]]= " << tempi[E[i]] << endl;
        }
    }

    if( tempi[N-1] != 0 )
        return tempi[N-1];

    int temp[M];
    copia( S, temp, M );
    copia( E, S, M );
    copia( temp, E, M );

    for( int i = 0; i < M; ++i ) {
        //cout << "visitato[" << S[i] <<"]= " << visitato[S[i]] << " visitato[" << E[i] <<"]= " << visitato[E[i]] << " tempi[" << S[i] << "]= " << tempi[S[i]] << endl;
        int myT;
        if( tempi[S[i]] <= T )
            myT = T + 1;
        else
            myT = tempi[S[i]] + 1;
        if( visitato[S[i]] == true && ( visitato[E[i]] == false || ( visitato[E[i]] == true && myT < tempi[E[i]] ) ) ) {
                visitato[E[i]] = true;
                //cout << "visitato[" << E[i] << "] = true" << endl;
                tempi[E[i]] = myT;
                //cout<< "qui tempi[" << E[i] << "]= " << tempi[E[i]] << endl;
                //cout << "i= " << i << " E[i] = " << E[i] << " tempi[E[i]]= " << tempi[E[i]] << endl;
        }
    }

    if( tempi[N-1] != 0 )
        return tempi[N-1];
    else
        return -1;


}
