#include <iostream>
#include <fstream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#define MAXN 100000
using namespace std;
int n,q,op,inizio,fine,tot;

int array[MAXN];

void aumenta(int inizio, int fine)
{
    if(inizio==fine)
    {
        array[inizio]++;       
    }
    else
    {
        for(int i=inizio; i<=fine; ++i)
            array[i]++;
    }
}

int divisibili(int inizio, int fine)
{
    if(inizio==fine)
    {
        if(array[inizio]%3==0) return 1;
        else return 0;        
    }
    else
    {
        int tot=0;
        for (int i=inizio; i<=fine; ++i)
        {
            array[i]%3==0?tot++:tot=tot;
        }
        return tot;
    }
}



int main()
{
    FILE *fp_in;
    FILE *fp_out;

    fp_in= fopen("input.txt","r");
    fp_out= fopen("output.txt","w");

    fscanf(fp_in,"%d %d", &n,&q);
    
    for(int i=0; i<n;++i)
        array[i]=0;

    for (int i=0; i<q; ++i){
        fscanf(fp_in,"%d %d %d", &op,&inizio,&fine);
        if(op==0)
            aumenta(inizio, fine);          
        else if(op==1)
        {
            tot=divisibili(inizio, fine);
            fprintf(fp_out,"%d\n", tot);
        }
    }
    return 0;
}

