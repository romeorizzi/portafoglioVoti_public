#include <bits/stdc++.h>
#define DIM 500
using namespace std;
int N;
int v[DIM];

int main() {

ifstream in("input.txt");
in >> N;
int pos;
for(pos = 0; pos < N; pos++)
    in >> v[pos];

in.close();

int somma = 0;
for(int i = 0; i < N; i++) {
    somma = v[i] + somma;
}


 ofstream out("output.txt");
 out << somma ;
 out.close();


return 0;
}
