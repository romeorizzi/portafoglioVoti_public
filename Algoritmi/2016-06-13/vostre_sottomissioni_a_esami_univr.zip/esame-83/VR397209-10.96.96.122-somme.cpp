#include <bits/stdc++.h>
#define DIM 500
using namespace std;
int N;
int v[DIM];

int main() {

ifstream in("input.txt");
in >> N;
int pos;
for(pos = 0; pos < N; pos++)
    in >> v[pos];

in.close();

int somma = 0;
for(int i = 0; i < N; i++) {
    somma = somma + v[i];

}

if(somma < 0)
        somma = somma * -1;

 ofstream out("output.txt");
 out << somma ;
 out.close();


return 0;
}
