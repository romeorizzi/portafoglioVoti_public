#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int num_sol;
const int MAX_M = 4000;
const int MAX_N = 4000;

int m,n;
int cell[MAX_M+2][MAX_N+2];

int main(){
    int numsol;
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    fin >> m >> n;
    int array[m];
    for(int i=0; i<n;i++)
        for(int j=0; j<3; j++)
            fin >> cell[i][j];
    fin.close();

    for (int g=0; g<m ; g++)
        array[g]=0;
    for (int i = 0 ; i<=n;i++){
        if(cell[i][0] == 0 ){
            int p = cell[i][1];
            int q = cell[i][2];
            for (p; p<=q;p++)
                array[p] = array[p]+1;
        }
        if(cell[i][0] == 1 ){
            int p = cell[i][1];
            int q = cell[i][2];
            int count = 0 ;
           for (p; p<=q;p++)
                if((array[p]%3) == 0)
                    count = count +1;
           fout<<count<<endl;
        }
    }
}









