#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

using namespace std;

//#define N_MAX 100000
//#define Q_MAX 100000

int main(){
    //long long int v[N_MAX];
    long long int n,q,u,d,t;

    ifstream fin;
    ofstream fout;
    
    fin.open("input.txt");
    //fin.open("input_bonus.txt");
    fout.open("output.txt");
    if(fin.fail()){
        cout<<"Errore nella lettura file input.txt";
    }else{
        if(fin >> n >> q ){
           //cout<< n << " - "<< q << endl;
            long long int v[n];
            for(int i=0; i<n; i++){
                v[i]=0;            
            }
            cout<<"azioni:\n";
            while(q>0){
                fin >> u >> d >> t ;
                cout << u  << " - "<< d  << " - "<< t <<endl;
                if(u==0){
                    for(int k=d; k<=t; k++){
                        v[k]++;                    
                    }
                }
                if(u==1){
                    int conta=0;                    
                    for(int k=d; k<=t; k++){
                        if(v[k]%3==0)
                            conta++;                  
                    }    
                    fout << conta << "\n";            
                }  

                q--;      
            }        
        }    
    }
    fin.close();
    fout.close();
    return 0;    
}

