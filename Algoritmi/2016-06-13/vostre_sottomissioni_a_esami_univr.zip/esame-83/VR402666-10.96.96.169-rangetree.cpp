#include <cassert>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstdio>
using namespace std;

    const int MAX_N=100000;
    const int MAX_Q=100000;
    int nums[MAX_N]; 

int main(){
    
    int N, Q;
    ifstream in("input.txt");
    in>>N>>Q; 

//    int* nums = new int[N]();
    int C,A,B,cnt;
    FILE* output=fopen("output.txt","w");

    for(int i = 0;i<Q;i++){
        in>>C>>A>>B;
        if(C==0){
            for (int j=A;j<=B;j++)
            nums[j]++;
         }
        else {
            cnt=0;
             for(int j=A; j<=B; j++){
                if(nums[j]%3 ==0)
                    cnt++;
            }
        }
    }
   ofstream myfile;
    myfile.open ("output.txt");
    myfile<<cnt;
    myfile<<"\n";
    myfile.close();

}
