//somme
#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

int N;
vector<int> arr;

int minSum() {
    int far_min=arr[0];
    int local_min=arr[0];

    for (int i=0; i<N; i++) {
        local_min = min(arr[i], local_min+arr[i]);
        far_min = min(far_min, local_min);       
    }

    return fabs(far_min);
}

int main() {
    ifstream openFile("input.txt");
       
    openFile >> N;
    cout << N << endl;

    arr.resize(N);
    for (int i=0; i<N; i++) {
        openFile >> arr[i];
        cout << arr[i];
    }

    int ris = minSum();
    
    cout << "\n" << ris << endl;
}
