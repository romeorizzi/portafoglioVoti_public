#include<fstream>
//#include<iostream>
#include<cassert>

using namespace std;

int arr[100010];
int len;
int n_query;

//sull'array memorizzo solo valori in modulo 3
void increase(int first, int second){
    for(int i=first; i<=second; i++){
        if(arr[i]==2) arr[i]=0;
        else arr[i]++;
    }
}

//conto solo dove vedo che il modulo è 0
int check(int first, int second){
    int res=0;
    for(int i=first; i<=second ; i++)
        if(arr[i]==0) res++;
    return res;
}


int main(){
    ifstream infile("input.txt");
    ofstream outfile("output.txt");

    //mi salvo la lunghezza dell'array
    infile >> len;
    //e il numero di query
    infile >> n_query;

    //per sicurezza azzero l'array di partenza
    for(int i=0; i<len; i++)
        arr[i]=0;
    
    //leggo tutte le query e le eseguo
    int type;
    int first;
    int second;
    for(int i=0; i<n_query; i++){
        infile >> type;
        assert(type==1 || type==0); //controlliamo di aver letto correttamente
        infile >> first;
        infile >> second;
        if(type==0) increase(first,second);
        if(type==1) outfile << check(first,second) << endl;
        
    }

}
















    
    
