/**
 *  Soluzione farlocca di piastrelle1xk (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N, K;

int chiamata(int n){
int sol;

if (n==0)
    return 0;

if (n==1) //base
    sol=1;
else if (n==2)
    sol=2;
else if (n==3)
    sol=3;
else
{
sol=2*chiamata(n-1)-1;
if (n%2==1) //n dispari
    sol=sol-1;
}
return sol;
}


int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d %d", &N, &K);

//ricorsiva
//praticamente fisso k=2

int sol=chiamata(N);



  printf("%d\n", sol);    
  
  return 0;
}


