/**
 *  Soluzione farlocca di piastrelle1xk (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <cassert>
#include <cstdio>


#define MAXN 1000000

long long int N, K;

int array[MAXN];

void piastrellature(long int n, long int k){
    if(n >= 0){
        if(array[n] == 0){
            if(n == 1 )
                array[1] = 1;
            else if(n == k)
                   array[n] = 2;
            else if(n < k)
                    array[n] = 1;
            else if(n>k){
                if(array[n-1] == 0)
                    piastrellature(n-1, k);
                if(array[n-k] == 0)
                    piastrellature(n-k, k);
                array[n] = array[n-1] + array[n-k]; 
            }
        }
    }
        
        
    
}

int main() {
    int risultato;
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
    N = 0;
    K = 0;
    scanf("%lld %lld", &N, &K);
    //assert(N > 0);
    //assert(K > 0);
        /*for(int i=0;i<=N;i++){
            array[i] =0;
        }*/
    risultato = 0; 
    piastrellature(N,K);
    risultato = array[N];

    printf("%d", risultato);     
  
  return 0;
}

