/**
 *  Soluzione farlocca di easyfall (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <cassert>
#include <cstdio>
#include <fstream>
#include <iostream>

#define MAXN 1000000

FILE *file;
int N;
int h[MAXN+1]; // altezze delle tessere
int tmpResults[MAXN + 1];
int results[MAXN + 1];

void resolveProblem(){
    int firstTarget = 0;    

    //Tessere che cadono colpendo un bersaglio    
    int fallDown = 0;

    
    for(int i = 0 ; i < N ; i++){
        //Conta le tessere che cadono compresa la tessera colpita        
        
        int tmpFallDown = 0; 
        
        if(h[i] < N - i)
            tmpFallDown = h[i];
        else
            tmpFallDown = N - i;
        
        //Controllo quante tessere abbattono le tessere abbattute dalla tessera i-esima
        for(int j = 1 ; j < tmpFallDown ; j++){
            
            if(h[i + j] == 1){}
            else{

                if(tmpFallDown + h[i + j] - 1 <= N - i)
                    tmpFallDown += h[i + j] - 1;
                else
                    tmpFallDown = N - i;
            }
        }
        tmpResults[i] = tmpFallDown;
    }
}

void setNullValue(int index, int nDomini){
    for(int i = index; i < index + nDomini ; i++){
        tmpResults[i] = -1;          
    }
}

void setResult(){
    int tmpMax;
    int index;

    
    for(int i = 0 ; i < N ; i++){
        tmpMax = 0;
        index = 0;
        for(int j = 0 ; j < N ; j++){
            if(tmpResults[j] > 0 && tmpResults[j] > tmpMax){
                tmpMax = tmpResults[j];
                index = j;
            }
        }
        
        setNullValue(index, tmpMax);
           
        if(i > 0)
            results[i] = results[i - 1] + tmpMax;
        else
            results[i] = tmpMax;
        
            
    }
}

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );
    
   file = fopen("input.txt", "r");
   fscanf(file , "%d", &N);
   
   for(int i = 0 ; i < N ; i++)
    fscanf(file , "%d", &h[i]);
    
   fclose(file);
   file = fopen("output.txt", "w");
   
   resolveProblem();
   setResult();
    
   
    for(int i = 0 ; i < N ; i++)    
      fprintf(file, "%d ", results[i]);
 
    fclose(file);
    
  return 0;
}


