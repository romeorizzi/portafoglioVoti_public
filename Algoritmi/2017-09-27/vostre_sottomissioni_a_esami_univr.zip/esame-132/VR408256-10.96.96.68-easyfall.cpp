/**
 *  Soluzione farlocca di easyfall (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int N;
int h[MAXN+1]; // altezze delle tessere

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 1; i <= N; i++)
     scanf("%d", &h[i]);

  for(int i = 1; i <= N; i++){

//prendi il numero i di valori più alti e ricorsivamente quelle che buttano giu
//per adesso considero le tessere alte al max 2, quindi non serve ricorsione, considero solo la tessera successiva
    int massimi[i];

for (int j = 1; j <= i; j++){ //popolo massimi;
massimi[j]=max(h);//non voglio solo il primo...voglio gli i massimi
//....



   printf("%d ", i);    // giusto quando tutte le tessere sono alte 1. 
}
}

/*
  for(int i = 1; i <= N; i++)
    printf("%d ", i);    // giusto quando tutte le tessere sono alte 1. */

  printf("\n");
  
  return 0;
}

