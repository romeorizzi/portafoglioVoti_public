/**
 *  Soluzione farlocca di piastrelle1xk (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <assert.h>
#include <stdio.h>

#define MAXN 1000000

int N, K;
int res;
int pos;
int maxcubi;

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d %d", &N, &K);

  printf("%d\n", 1);    // alcune le azzecca. 

    if(N == K)
        res = 2;       
    else if(N < K)
        res = N;
    else{
        if(N%K == 0){
            maxcubi = N/K;
            pos = 0;
        }

        else{
            res = N - K + 2;
        }
    }
  
  return 0;
}
