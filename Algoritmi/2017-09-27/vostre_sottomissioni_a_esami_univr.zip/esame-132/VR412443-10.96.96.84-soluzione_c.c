/**
 *  Soluzione farlocca di easyfall (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <assert.h>
#include <stdio.h>

#define MAXN 3

int N;
int h[MAXN+1]; // altezze delle tessere
int i;
int j;

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(i = 1; i <= N; i++)
     scanf("%d", &h[i]);

    int morehigh[N];
    for(i = 1; i <= N; i++){
        while(j > -1){
            if()
        }
    }

 /* for(i = 1; i <= N; i++)
    printf("%d ", i);    // giusto quando tutte le tessere sono alte 1. 
  printf("\n");
*/

  int k = 0;
  int h_mancante = 0;
  int pedine_cadere = 0;

  while(k < N){
       for(i = 1; i <= N; i++){
            if(h[i] == MAXN - h_mancante && h[i] < N -i ){
                pedine_cadere = h[i];
                while(pedine_cadere > 0){
                    h[pedine_cadere + i] = 0;
                    k++;
                }
            }                
        }  
    printf("%d -", k);
  }

  return 0;
}
