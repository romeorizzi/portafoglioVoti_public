#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int N;
vector <int> domino;

void risolvi(vector <int> v, int k);
vector <int> risolvi_uno(vector <int> v, int k);
vector <int> abbatti(vector <int> v, int p);

int main() {

    ifstream in("input.txt");

    in >> N;
    for(int i = 0; i < N; i++) {
        int t; in >> t;
        domino.push_back(t);
    }
    in.close();

    /*
    cout << N << endl;
    for(unsigned i = 0; i < domino.size(); i++)
        cout << domino[i] << " ";
    cout << endl;
    */

    vector <int> v = domino;

    risolvi(v, 1);

    return 0;
}

void risolvi(vector <int> v, int k) {

    ofstream out("output.txt");

    vector <int> rimasti = risolvi_uno(v, k);

    int cadute = v.size() - rimasti.size();
    out << cadute << " ";

    int aggiunte = cadute;
    for(int i = 2; i <= N; i++) {
        vector <int> temp = rimasti;
        rimasti = risolvi_uno(temp, k);
        aggiunte += (temp.size() - rimasti.size());
        out << aggiunte << " ";
    }

    out << endl;

    out.close();
}

vector <int> risolvi_uno(vector <int> v, int k) {

    vector <int> rimasti;
    int max_val = 0;
    vector <int> min_rimasti;

    // Calcolo la soluzione per il caso base

    for(unsigned i = 0; i < v.size(); i++) {

        vector <int> temp = v;
        rimasti = abbatti(temp, i);

        int val = temp.size() - rimasti.size();

        if(val > max_val) {
            max_val = val;
            min_rimasti = rimasti;
        }

    }

    return min_rimasti;

}

vector <int> abbatti(vector <int> v, int p) {

    if(p < v.size()) {

        if(v[p] == 1) {
            v.erase(v.begin() + p, v.begin() + (p + 1));
            return v;
        }

        v.erase(v.begin() + p, v.begin() + (p + 1));
        return abbatti(v, p);

    }

    return v;

}
