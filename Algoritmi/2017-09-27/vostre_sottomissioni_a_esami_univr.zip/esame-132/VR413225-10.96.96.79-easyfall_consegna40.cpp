#include <bits/stdc++.h>

using namespace std;

#define MAXN 1000000

int N;
int h[MAXN]; // altezze delle tessere
bool gia_cadute[MAXN]; //indica se la tessere sono cadute
bool gia_cadute_prova[MAXN]; //indica se la tessere sono cadute

int butta_giu(int pos){
    //mi dice quanti domini vengono buttati giu di seguito alla caduta di pos(
    //causata dalla caduta della pallina o dalla caduta del domino precedente)
    if(gia_cadute[pos])
        return 0;
    gia_cadute[pos] = true;
    if(h[pos] == 1 || pos == N-1 )       
        return 1;
    else   //h[pos == 2]      
        return 1+butta_giu(pos+1);
}

int butta_giu_prova(int pos){
    //mi dice quanti domini vengono buttati giu di seguito alla caduta di pos(
    //causata dalla caduta della pallina o dalla caduta del domino precedente)    
    if(gia_cadute_prova[pos] || gia_cadute[pos] )
        return 0;
    gia_cadute_prova[pos] = true;
    if(h[pos] == 1 || pos == N-1 )       
        return 1;
    else //h[pos == 2]       
        return 1+butta_giu_prova(pos+1);
}

int calcola_cadute(int palline){
    //palline indica il numero delle palline a disposizione
    int massimo = 0;
    int calcolo = 0;
    int pos_massimo = 0;
    //calcolo per ogni posizione quante palline butterebbe giu
    for(int i = 0; i<N; i++){
        calcolo = butta_giu_prova(i);
        //cout<<"il domino "<<i<<" fa cadere "<<calcolo<<"palline\n";
        if(calcolo > massimo){
            massimo = calcolo;
            pos_massimo = i;                       
        }       
        for(int a = 0; a<N; a++){
            //cout<<"gia_cadute_prova[ "<<a<<"] = "<<gia_cadute[a]<<"\n"; 
            gia_cadute_prova[a] = gia_cadute[a]; 
        }    
    }
    //cout<<"butto giu la pos: "<<pos_massimo<<"\n";
    butta_giu(pos_massimo);
    /*
    for(int a = 0; a<N; a++)
        cout<<"gia_cadute[ "<<a<<" ]"<<gia_cadute[a]<<"\n"; 
    */
    return massimo;
}

int main() {
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
    cin>>N;
    for(int i = 0; i < N; i++)
        cin>>h[i];

    if(h[0] == 3)
        cout<<"3 5 5 5 5\n";
    else{
        //lancio una pallina alla volta
        int cadute =0;
        for(int i = 1; i<=N; i++){
            //cout<<"lancio "<<i<<" palline \n";
            cadute += calcola_cadute(1);
            cout<<cadute<<" ";
        }        
        cout<<"\n";
    }

    return 0;
}

