#include <bits/stdc++.h>

using namespace std;

int N, K;

int main() {
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
    cin>>N;
    cin>>K;
    int fibo[N+1];

    for(int i = 0; i<=N; i++){
        if(i < K)
            fibo[i] = 1;
        else
            fibo[i] = fibo[i-1] + fibo[i-K];
        
    }

    cout<<fibo[N]<<"\n";
  
    return 0;
}

