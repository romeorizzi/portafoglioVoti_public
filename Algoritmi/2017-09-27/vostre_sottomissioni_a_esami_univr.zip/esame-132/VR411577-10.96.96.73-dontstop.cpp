#include <cassert>
#include <cstdio>
#include <vector>

using namespace std;

const int MAXN = 1000000;
const int MAXM = 1000000;

int N, M;

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d%d", &N, &M);

    vector<int> adj[N]; // adj[u] = nodi che hanno un arco verso u
    int deg[N]; // deg[u] = numbero di archi uscenti da u, o -1 se rimosso

    for(int u = 0; u < N; u++) {
        deg[u] = 0;
    }

    for(int i = 0; i < M; i++) {
        int a, b;
        scanf("%d%d", &a, &b);

        assert(0 <= a && a <= N);
        assert(0 <= b && b <= N);
        assert(a != b);

        deg[a]++;
        adj[b].push_back(a);
    }

    int esito[N];
    int fatto[N];

    // TODO: calcolare esito
    for(int i=0;i<N;i++){
        esito[i]=0;
    }
    for(int i=0;i<N;i++){
        fatto[i]=0;
    }

    for(int i = 0;i < N;i++){
           if(deg[i] == 0){
               esito[i] = -1;
               fatto[i] = 1;
               for(int s=0; s< adj[i].size();s++){
                   //printf("%d\n", adj[i].at(s));
                   esito[adj[i].at(s)] = 1;
                   fatto[adj[i].at(s)] = 1;
               }
           }  
        }
    
    for(int l=0;l<N*N;l++){
        for(int i = 0;i < N;i++){
            if(esito[i] == -1){
               for(int s=0; s< adj[i].size();s++){
                   //printf("%d\n", adj[i].at(s));
                   esito[adj[i].at(s)] = 1;
                   fatto[adj[i].at(s)] = 1;
               }
           }
           
           else if(esito[i] == 0){
               for(int s=0; s< adj[i].size();s++){
                   //printf("%d\n", adj[i].at(s));
                    if(fatto[adj[i].at(s)] == 0 || esito[adj[i].at(s)] == -1){
                    esito[adj[i].at(s)] = 0;
                    fatto[adj[i].at(s)] = 1;
                    }
               }
           }
            else if(esito[i] == 1){
               for(int s=0; s< adj[i].size();s++){
                   //printf("%d\n", adj[i].at(s));
                   if(fatto[adj[i].at(s)] == 0 ){
                    esito[adj[i].at(s)] = -1;
                    fatto[adj[i].at(s)] = 1;
                    }
               }
           }
        }
    }

    
   

    //-----------------------------------
    

    for(int u = 0; u < N; u++) {
        printf("%d ", esito[u]);
    }
    printf("\n");
    return 0;
}
