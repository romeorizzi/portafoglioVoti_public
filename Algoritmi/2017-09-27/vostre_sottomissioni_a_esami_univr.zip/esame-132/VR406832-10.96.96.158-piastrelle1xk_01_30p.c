/**
 *  Soluzione farlocca di piastrelle1xk (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <assert.h>
#include <stdio.h>

#define MAXN 1000000

int N, K;
int pavimento[2][MAXN];

int sequenza(int n);

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d %d", &N, &K);

  if (N < K)
    printf("%d\n", 1);

  else if (N == K) {
    if (N == 1)
      printf("%d\n", 1);

    else
      printf("%d\n", 2);
  }

  // Da un'analisi pratica dei valori, le possibilità di tiling con pavimenti k=2 sono pari alla sequenza di Fibonacci
  else if (K == 2)
    printf("%d\n", sequenza(N));

  else {
    // to be implemented
  }
  
  return 0;
}

int sequenza(int n) {
  if (n == 0) return 1;
  else if (n == 1) return 1;
  else {
    return sequenza(n-2)+sequenza(n-1);
  }
}
