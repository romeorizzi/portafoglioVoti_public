/**
 *  Soluzione farlocca di piastrelle1xk (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <assert.h>
#include <stdio.h>

#define MAXN 1000000

int N, K;
int pavimento[2][MAXN];

int sequenza2(int n);
int sequenza3(int n);

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d %d", &N, &K);

  if (N < K)
    printf("%d\n", 1);

  else if (N == K) {
    if (N == 1)
      printf("%d\n", 1);

    else
      printf("%d\n", 2);
  }

  // Da un'analisi pratica dei valori, le possibilità di tiling con pavimenti k=2 sono pari alla sequenza di Fibonacci
  else if (K == 2)
    printf("%d\n", sequenza2(N));

  else {
    printf("%d\n", sequenza3(N));
  }
  
  return 0;
}

int sequenza2(int n) {
  if (n == 0) return 1;
  else if (n == 1) return 1;
  else {
    return sequenza2(n-2)+sequenza2(n-1);
  }
}

int sequenza3(int n) {
  if (n == 0) return 1;
  else if (n == 1) return 1;
  else if (n == 2) return 1;
  else {
    return sequenza3(n-3)+sequenza3(n-1);
  }
}
