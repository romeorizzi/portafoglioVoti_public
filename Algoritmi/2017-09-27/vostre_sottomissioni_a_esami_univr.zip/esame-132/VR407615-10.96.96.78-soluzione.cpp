//Riccardo Caldana VR407615

#include <bits/stdc++.h>

#define MAXN 1000000

using namespace std;
int N;
int h[MAXN];
int sol[MAXN];
int copia[MAXN];
bool caduti[MAXN];
int indice_max(){
    int max=0;
    int indice;
    for(int i=1;i<=N;i++){
        if(copia[i]>max){
            max=copia[i];
            indice=i;
        }
    }
    return indice;
    
}

void stampa(){
    for(int i=1;i<=N;i++){
        cout << caduti[i] << " ";
    }
    cout << "\n";
}

void resetc(){
    for(int i=0;i<=N;i++) caduti[i]=0;
}

void reset(){
    for(int i=1;i<=N;i++)
        h[i]=copia[i];
}

bool tutti_caduti(){
    for(int i=1;i<=N;i++){
        if(caduti[i]==0) return false;
    }
    return true;
}

int risolvi(int k,int indice){
    if(sol[k]) return sol[k];
    if(k==N){
        sol[k]=N;
        return sol[k];
    }
    if(tutti_caduti()){
        //cout << "caso caduti\n";
        //cout << "sono tutti caduti\n";
        sol[k]=sol[k-1];
        return sol[k];
    }
    if(k==0){
        sol[k]=0;
        return sol[k];
    }
    //indice è l'indice del domino più alto è l'indice massimo sparo li la prima freccia che ho a disposizione, ne faccio cadere di più
    if(h[indice]==2 && indice+1<=N && h[indice+1]==2){ // ha un successore valido
        //cout << "caso0\n";
        h[indice]=0;
        caduti[indice]=1;
        //caduti[indice+1]=1;
        sol[k]=1+risolvi(k,indice+1); //ho ancora k frecce
        return sol[k];  
    }
     if(h[indice]==2 && indice+1<=N && h[indice+1]==1){ // ha un successore valido
        //cout << "caso1\n";
        h[indice]=0;
        h[indice+1]=0;
        caduti[indice]=1;
        //caduti[indice+1]=1;
        sol[k]=2+risolvi(k-1, indice_max()); //ho ancora k frecce
        return sol[k];  
    }
    if(h[indice]==2){ // sono l'ultimo
        //cout << "caso2\n";
        h[indice]=0;
        caduti[indice]=1;
        sol[k]=1+risolvi(k-1,indice_max());
        return sol[k];
    }
    
    if(h[indice]==1){
        //cout << "caso4\n";
        h[indice]=0;
        caduti[indice]=1;
        sol[k]=1+risolvi(k-1, indice_max());
        return sol[k];
    }
}


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    cin >> N;  
    for(int i = 1; i <= N; i++){
        cin >> h[i];
        copia[i]=h[i];
    }
    //stampa();
    sol[0]=0;
    //if(tutti_caduti()) cout << "qualcosa non va all'inizio\n";
    int k;
    for(k=1;k<=N;k++){
        //reset();
        //resetc();
        //stampa();
            sol[k]=risolvi(k,indice_max());
            cout << sol[k] << " ";
       
    }
    cout << "\n";
   
    return 0;
}

