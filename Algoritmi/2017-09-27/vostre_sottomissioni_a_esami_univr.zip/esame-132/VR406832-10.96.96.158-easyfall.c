/**
 *  Soluzione farlocca di easyfall (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2017-09-25
 *
 */

#include <assert.h>
#include <stdio.h>

#define MAXN 1000000

int N;
int h[MAXN+1]; // altezze delle tessere
int fall_max[MAXN+1];
int max_so_far_old = 0;

void ricorsiva(int* fall_max, const int* h, int pos);

int main() {
  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );

  scanf("%d", &N);
  for(int i = 1; i <= N; i++)
    scanf("%d", &h[i]);

  ricorsiva(fall_max, h, N);

  for (int i=1; i<=N; i++) {
    int max_so_far = 0;
    int max_so_far_pos = 0;

    for (int j=1; j<=N; j++)
      if (fall_max[j] > max_so_far) {
        max_so_far = fall_max[j];
        max_so_far_pos = j;
      }

    for (int k=max_so_far_pos; k<max_so_far_pos+(max_so_far-1); k++) fall_max[k] = 0;

    int answer = max_so_far_old += max_so_far;

    if (answer > N) answer = N;

    printf("%d ", answer);      
  }

  printf("\n");
  
  return 0;
}

void ricorsiva(int* fall_max, const int* h, int pos) {
  if (pos == N) {
    fall_max[pos] = 1;
  }

  else if (pos == 0) {
    return;
  }

  else {
    if (h[pos] == 1) fall_max[pos] = 1;

    else if (pos + (h[pos]-1) <= N) {
      int temp = 0;

      for (int i=1; i<h[pos]; i++) {
        temp += fall_max[pos+i];
        if (h[pos+i] == 1) continue;
        break;
      }

      fall_max[pos] = temp + 1;
    }

    else {
      int max_possible = N-pos;
      int temp = 0;

      for (int i=1; i<=max_possible; i++) temp += fall_max[pos+i] + 1;

      fall_max[pos] = temp;
    }
  }

  ricorsiva(fall_max, h, pos-1);
}
