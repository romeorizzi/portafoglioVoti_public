#include <bits/stdc++.h>

using namespace std;

const int MAXBLUE = 9;
const int MAXM = 200;
const int MAXN = 200;

char mappa[MAXM+1][MAXN+1];

int num[MAXM+1][MAXN+1][MAXBLUE+1];

int M, N; //dimensioni reali mappa

struct Pacman{
	int A;
	int B;
	bool stato;
	int durata;
};

struct Punteggio{
	bool fine;
	int fantasmi;
	int pillole;
	bool vai;
};

Punteggio scelta(Pacman pac, int coordA, int coordB){
	
	Punteggio punt;
	
	punt.fine = false;
	punt.fantasmi = 0;
	punt.pillole = 0;
	punt.vai = false;
	
	//ultima cella
	if((coordA == M-1 && coordB == N-1)){
		punt.fine = true;
	}
	
	//muro
	if(mappa[coordA][coordB] == '#'){
		return punt;
	}
	
	
	//c'è un fantasma
	else if(mappa[coordA][coordB] == '*'){
		if(pac.stato == true){
			punt.fantasmi++;
			punt.vai = true;
			return punt;
		}
		else
			return punt;
	}
	
	//c'è una pillola
	else if( (mappa[coordA][coordB] >= '1' || mappa[coordA][coordB] <= '9') ){
		punt.pillole++;
		punt.vai = true;	
	}
		
	//cella libera
	else{
		punt.vai = true;
		return punt;	
	}

}

Punteggio percorsoMigliore(Pacman pac){

	Punteggio mappaBest[MAXM+1][MAXN+1];
	
	Punteggio destra = scelta(pac, pac.A, pac.B++);
	if(destra.vai == true){
		//punteggio da destra
		mappaBest[pac.A][pac.B++] = destra;
	}
	Punteggio giu = scelta(pac, pac.A++, pac.B);
	if(giu.vai == true){
		//punteggio da giu
		mappaBest[pac.A++][pac.B] = giu;
	}
	else 
	punteggio da qua
	
	Punteggio punt1 = scelta(pac, pac.A++, pac.B);
	Punteggio punt2 = scelta(pac, pac.A, pac.B++);
	if(punt1.fine == true && punt2.fine == true){
		if(punt1.fantasmi > punt2.fantasmi ||
			(punt1.fantasmi == punt2.fantasmi && punt1.pillole < punt2.pillole) ){
			return punt1;
		else
			return punt2;
	}

}

int main(){

#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

 	scanf("%d%d", &M, &N);
	
    for (int i = 0; i < M; i++) {
		for (int j = 0; j < N; j++) {
			do { 
				scanf("%c", &mappa[i][j]);
			} 
			while(mappa[i][j] != '#' && mappa[i][j] != '+' && mappa[i][j] != '*' && ( mappa[i][j] < '1' || mappa[i][j] > '9') );
		}
	}


	Pacman pac;
	pac.A = 0;
	pac.B = 0;
	pac.stato = false;
	pac.durata = 0;
	
	percorsoMigliore(pac);
	
	return 0;

}
