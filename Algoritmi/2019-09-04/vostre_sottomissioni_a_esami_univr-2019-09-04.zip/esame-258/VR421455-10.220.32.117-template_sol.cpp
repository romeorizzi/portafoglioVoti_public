/**
 *  Template per soluzione in c++ per il problema tree_split_out
 *
 *  Romeo Rizzi, per l'appello di algoritmi 2019-09-04
 *
 */

#include <cassert>
#include <iostream>

using namespace std;

const int MAX_N = 1000000;
int livelli[MAX_N];

int n = 0, input_type;
int in_tree[MAX_N], out_tree[MAX_N];

/*int codifica2(int m, int n, int level){
  //caso base
  if(in_tree[i] == 1)
    return 1;

  
  

}*/

int main() {
    // leggere l'input_type:
    cin >> input_type;

    // leggere la sequenza che codifica l'albero in input (in formato input_type):
    int val;
    while (cin >> val)
      in_tree[n++] = val;

    // in questo template di soluzione mi limito a ricopiare l'input in output (non sarà mai la soluzione corretta tranne che per alberi di un solo nodo):
    cout << input_type << ' ';

    //codifica 3
    if(input_type == 3){
      for(int i = 0; i < n; ++i){
        if(in_tree[i] % 2 != 0)
          in_tree[i] = -1;
      }

      for(int i = 0; i < n; ++i){
        if(in_tree[i] % 2 == 0)
          in_tree[i] /= 2;
      }
    }

    //codifica 2
    if(input_type == 2){
      int level = 0;

      for(int i = 0; i < n; ++i){
        livelli[i] = 0;
      }
      
      //level++;

      for(int i = 0; i < 3; ++i){
        if(in_tree[i] != 1){
          level++;
          for(int j = i + 1; j < (i + 1) + in_tree[i]; ++j){
            livelli[j] = level;
          }
        }
      }
    }

    for(int i=0; i<n; i++)
      if(in_tree[i] != -1)
        cout << in_tree[i] << ' ';
    cout << endl;
    
    return 0;
}

