#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <fstream>

#define MAX 75
#define MID 25

using namespace std;

/*int vdx[100]*/
int vdx[] = {0, 1, 2, -1, 3, 4, 5, 6, -1, 7, 8, 9, 10, 11, -1, 12, 13, 14, 15, -1, 16, 17, 18, -1, 2, 6, 11, -1, 1, 5, 10, 15, -1, 0, 4, 9, 14, 18, -1, 3, 8, 13, 17, -1, 12, 16, -1, 0, 3, 7, -1, 1, 4, 8, 12, -1, 2, 5, 9, 13, 16, -1, 6, 10, 14, 17, -1, 11, 15, 18, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 -1};

char Z[MID];
int bitbool[1 << 20];
int x;
bool flag[MID];

bool start(int bitm) {
    if (bitm == x) return false;
    if (bitbool[bitm] != -1) return bitbool[bitm];
    bitbool[bitm] = false;
    int temp;

    for (int k = 0; k < MAX; k++) {
        temp = bitm;
        // printf("%d", temp)
        for (int j = k; j < MAX; j++) {
            int idx = vdx[j];
            if (idx != -1) {
                /*while (temp)
                    flag[idx++] =false;


                */if (flag[idx] && !(temp & (1 << idx))) {
                    temp |= (1 << idx);


                    if (!start(temp))
                        bitbool[bitm] = true;
                }
                else 
                    temp = bitm;
            }
            else break;
        }
    }

    return bitbool[bitm];
}

int main() {

    ifstream in("input.txt");


    //test = 1;
    // if(test) a++;

    for (int i = 0; i < 19; ++i)
        in >> Z[i];
    
    // printf("%d", Z[i])
    x = 0;
    memset(flag, 0, sizeof(flag));
    memset(bitbool, -1, sizeof(bitbool));

    int c = 0;
    
    for (int i = 0; i < 19; ++i) {
        if (Z[i] == 'O' || Z[i] == '.') ++c;
        if (Z[i] == 'O' && Z[i] != '.') x |= (1 << (c-1)), flag[c - 1] = 1;
    }


    bool res = start(0);
    // printf("%d", res);



    /*for (int i = 0; i < 19; ++i) {
        if (Z[i] == 'O' || Z[i] == '.') ++c;
        if (Z[i] == 'O' && Z[i] != '.') x |= (1 << (c-1)), flag[c - 1] = 1;
    }*/
    ofstream out("output.txt");

    if (res) out << "Karlsson\n";
    else out << "Lillebror\n";

    return 0;
}
