#include <cstdio>
#include <string.h>
#include <fstream>
#include <iostream>

using namespace std;

int vasi[400000];
int output[400000];

int main () {

    ifstream fin("input.txt");
    ofstream fout("output.txt");
    int n;
    int m;
    char mossa;

    //int c_control = 0;

    fin >> n >> m;

    //cout << n  << " " << m <<endl;

    for (int k=0; k<n; k++)
        vasi[k] = k;


    for (int k=0; k<m; k++) {
        int i;
        int j;
        fin >> mossa;
        
        if (mossa == 's') {
            fin >> i >> j;
            
            int element = vasi [i];         

            if (i < j) {

                for (int k1 = i; k1 < j; k1++)
                    vasi[k1] = vasi [k1+1];
            }
            if (i > j) {

                for (int k1 = i; k1 > j; k1--)
                    vasi[k1] = vasi [k1-1];
            }

            vasi [j] = element;

            //cout << "spostamento " << i << " " << j << endl;
            /**if (i != j) {
            for (int k2 = 0; k2 < n; k2++)
               cout << vasi[k2] << " ";
    
              cout << endl;
            }*/
        }

        if (mossa == 'c') {
            fin >> i;
                        
            fout << vasi[i] << " ";
            //output[c_control] = vasi[i];
            
            //c_control ++;

            //cout << "control " << i << endl;
        }



    }

    //for (int k2 = 0; k2 < c_control; k2++)
        //fout << output[k2] << " ";

    fout << endl;

    return 0;
        
    
}
