#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

long int n;
long int k;
long int p;
int conflicts = 0;



int main(){

    ifstream inputfile;
    inputfile.open("input.txt");

    ofstream outputfile;
    outputfile.open("output.txt");

    inputfile >> n >> k >> p;
    long int r;
    long int c;
    long int x;
    
    long int r1;
    long int c1;
    long int r2;
    long int c2;

    long int matrix[n][n];

    for (int i = 0; i < n; i++) {
	    for (int j = 0; j < n; j++) {
            matrix[i][j] = 0;
        }
    }

    for (int i = 0; i < k; i++) {
        inputfile >> r >> c >> x;
        matrix[r-1][c-1] = x;
    }
    //finito di popolare la matrice

    int xorpower;

    for (int i = 0; i < p; i++) {
        xorpower = 0;
        conflicts = 0;
        inputfile >> r1 >> c1 >> r2 >> c2;
        matrix[r2-1][c2-1] = matrix[r1-1][c1-1];
        matrix[r1-1][c1-1] = 0;
        for (int i = 0; i < n; i++) {
	        for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
	                if(matrix[i][k] >= 0){
                        xorpower = xorpower xor matrix[i][k];
                    }
                    if(matrix[k][j] >= 0){
                        xorpower = xorpower xor matrix[k][j];
                    }
                }  
                if(xorpower > 0){
                    conflicts++;
                }             
            }
        }        
        outputfile << conflicts;
    }


    inputfile.close();
    outputfile.close();
    
}
