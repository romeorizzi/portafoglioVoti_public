#include<iostream>
#include<cmath>
#include<deque>
#include<vector>
#include<fstream>

using namespace std;
char box[5][5];

int i, j;

int mosse;

int main()
{
    ifstream in("input.txt"); 
    ofstream out("output.txt");

    // Leggo dati
    for (j = 0; j<3; j++)
        in >> box[0][j];

    for (j = 0; j<4; j++)
        in >> box[1][j];

    for (j = 0; j<5; j++)
        in >> box[2][j];

    for (j = 0; j<4; j++)
        in >> box[3][j];

    for (j = 0; j<3; j++)
        in >> box[4][j];

    // DEBUG stampo box
    /*for (i = 0; i<5; i++)  
    {
        for (j = 0; j<5; j++)
        {
            cout << box[i][j] << " ";
        }
        cout <<"\n";
    }*/

    mosse = 0;
    // Conto mosse
    for (i = 0; i<5; i++)  
    {
        for (j = 0; j<5; j++)
        {
            if(box[i][j] == 'O')
            {
                if(box[i][j-1] == 'O' || box[i][j+1] == 'O' || box[i-1][j] == 'O' || box[i+1][j] == 'O' || box[i-1][j-1] == 'O' || box[i+1][j-1] == 'O')
                    mosse+=2;
                else
                    mosse+=1;
            }
        }
    }

    //cout<<mosse<<"\n";
    // Determino Vincitore
    if(mosse % 2 == 0) // Mosse pari
        out << "Lillebror\n";
    else // Mosse dispari
        out << "Karlsson\n";

//    out << "Lillebror\n";
//    out << "Karlsson\n";
    return 0;
}
