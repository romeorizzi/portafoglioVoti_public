#include <fstream>
#include <cassert>

using namespace std;

const long long int N_MAX = 4000000; //vasi massimi
const long long int M_MAX = 4000000; //mosse massime

long long int vasi[N_MAX];

long long int n;    //vasi effettivi
long long int m;    //mosse effettive

//FUNZIONI
void initialize_vasi(){
    for( long long int i = 0; i < n; ++i ){
        vasi[ i ] = i;
    }
}

void move( long long int source, long long int dest ){
    if( source < dest ){
        long long int temp = vasi[ source ];
        for( long long int i = source; i < dest; ++i )
            vasi[ i ] = vasi[ i + 1 ];
        vasi[ dest ] = temp;
    }

    if( dest < source ){
        long long int temp = vasi[ source ];
        for( long long int i = source; i > dest; --i )
            vasi[ i ] = vasi[ i - 1 ];
        vasi[ dest ] = temp;
    }
}


int main(){
    ifstream inFile( "input.txt" ); assert(inFile);
    ofstream outFile( "output.txt" ); assert(outFile);

    inFile >> n >> m;

    initialize_vasi();

    char mossa;

    for( long long int i = 0; i < m; ++i ){
        inFile >> mossa;
        if( mossa == 'c' ){ 
            long long int j;
            inFile >> j;
            outFile << vasi[ j ] << " ";
        }

        if( mossa == 's' ){
            long long int source;
            long long int dest;
            inFile >> source >> dest;
            move( source, dest);
        }
    }

    outFile.close();
    inFile.close();



    return 0;
}
