#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <deque>

using namespace std;

int main() {
    ifstream OpenFile("input.txt");
    ofstream OutFile("output.txt");
    
    int N, M;
    OpenFile >> N >> M;

    double tsqrtN = sqrt(N);
    int sqrtN = ceil(tsqrtN);
    vector<deque<int> > vases(sqrtN);

    // inizializzo l'array dei vasi
    for (int i=0; i<N; i++)
        vases[i/sqrtN].push_back(i);

    for (int i=0; i<M; i++) {
        int a, b;
        char command;
        OpenFile >> command;

        // se il comando è di controllo
        if (command == 'c') {
            OpenFile >> a;
            
            int arr = a/sqrtN;
            int pos = a%sqrtN;
    
            // scrivo la posizione sul quaderno
            OutFile << vases[arr][pos] << " ";

        // se il comando è di spostamento
        } else {
            OpenFile >> a >> b;

            // se mi viene fornita la stessa posizione, passo
            if (a == b) continue;
            
            // sposto l'elemento e mantengo l'array ordinato
            int arr1 = a/sqrtN;
            int pos1 = a%sqrtN;
            int arr2 = b/sqrtN;
            int pos2 = b%sqrtN;
            int value = vases[arr1][pos1];

            vases[arr1].erase(vases[arr1].begin() + pos1);
            
            while (arr1 < arr2) {
                vases[arr1].push_back(vases[arr1 + 1].front());
                vases[++arr1].pop_front();
            }

            while (arr1 > arr2) {
                vases[arr1].push_front(vases[arr1 - 1].back());
                vases[--arr1].pop_back();        
            }

            vases[arr1].insert(vases[arr1].begin() + pos2, value);
        }
    }

    OutFile << "\n";    

    return 0;
}
