#include <iostream>
#include <cstdio>
using namespace std;


int segs[100]={0};
int i_segs = 0;
bool lel = false;
bool yolo[5][5]={false};
bool dirty[5][5]={true};
int count = 0;
void setyolo(int i,int j,char c){
    yolo[i][j]=false;
    dirty[i][j]=false;
    if(c=='O')
        yolo[i][j]=true;
}
int inertia(int i, int j, int dir){
    dirty[i][j] = true;
    if(dir == 0){
        if(yolo[i][j+1] && !dirty[i][j+1]){
            lel=true;
            return 1+inertia(i,j+1,0);
        }
    }
    if(dir == 1){
        if(yolo[i+1][j] && !dirty[i+1][j]){
            lel=true;
            return 1+inertia(i+1,j,1);
        }
    }
    if(dir == 2){
        if(yolo[i+1][j+1] && !dirty[i+1][j+1]){
            lel=true;
            return 1+inertia(i+1,j+1,2);
        }
    }
    return 1;
}
void len_seg(int i, int j){
    if(yolo[i][j+1]){
        segs[i_segs] = inertia(i,j,0);
        i_segs++;
    }
    if(yolo[i+1][j]){
        segs[i_segs] = inertia(i,j,1);
        i_segs++;
    }
    if(yolo[i+1][j+1]){
        segs[i_segs] = inertia(i,j,2);
        i_segs++;
    }
}
bool resolve(){
    for(int i=0;i<6;i++){
        for(int j=0;j<6;j++){
            if(!dirty[i][j] && yolo[i][j]){
                len_seg(i,j);
            }
        }
    }

    if (!i_segs%2)
        return(true);
    else
        return lel;
}
int main()
{
    FILE* in = fopen("input.txt","r");
    char c1,c2,c3,c4,c5;
    fscanf(in,"  %c %c %c\n",&c1,&c2,&c3);
    setyolo(0,0,c1);
    setyolo(0,1,c2);
    setyolo(0,2,c3);
    fscanf(in," %c %c %c %c\n",&c1,&c2,&c3,&c4);
    setyolo(1,0,c1);
    setyolo(1,1,c2);
    setyolo(1,2,c3);
    setyolo(1,3,c4);
    fscanf(in,"%c %c %c %c %c\n",&c1,&c2,&c3,&c4,&c5);
    setyolo(2,0,c1);
    setyolo(2,1,c2);
    setyolo(2,2,c3);
    setyolo(2,3,c4);
    setyolo(2,4,c5);
    fscanf(in," %c %c %c %c\n",&c1,&c2,&c3,&c4);
    setyolo(3,0,c1);
    setyolo(3,1,c2);
    setyolo(3,2,c3);
    setyolo(3,3,c4);
    fscanf(in,"  %c %c %c\n",&c1,&c2,&c3);
    setyolo(4,0,c1);
    setyolo(4,1,c2);
    setyolo(4,2,c3);
    FILE* out = fopen("output.txt","w");
    if(resolve())
        fprintf(out,"Karlsson\n");
    else
        fprintf(out,"Lillebror\n");

}
