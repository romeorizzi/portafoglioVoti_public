#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <cmath>

using namespace std;

ifstream in;
ofstream out;

void open() {
    in.open("input.txt");
    out.open("output.txt");
}

void solve() {
int N, M; in >> N >> M;
    int sq = ceil(sqrt(N));
    vector<deque<int> > vasi(sq);

    for (int i = 0; i < N; i++)
        vasi[i / sq].push_back(i);

    for (int i = 0; i < M; i++) {
        char c;
        int a, b;
        in >> c;
        if (c == 'c') { in >> a;  out << vasi[a / sq][a % sq] << " "; }
        else {
            /*for (int i = 0; i < N; i++)
        vasi[i / sq].push_back(i);*/
            in >> a >> b;
            if (a != b) {
            int idx1 = a / sq; int position1 = a % sq;
            /*vasi[idx1].push_back(vasi[idx1 + 1].front());
                vasi[++idx1].pop_front();*/
            int idx2 = b / sq; int position2 = b % sq;
            // print("%d", a)
            int value = vasi[arr1][pos1];
            vasi[idx1].erase(vasi[idx1].begin() + pos1);
            while (!(idx1 >= idx2)) {
                // print("%d", b)
                vasi[idx1].push_back(vasi[idx1 + 1].front());
                vasi[++idx1].pop_front();
            }

            while (!(idx1 <= idx2)) {
                vasi[idx1].push_front(vasi[idx1 - 1].back());
                // print("%d", idx1)
                vasi[--idx1].pop_back();
            }

            vasi[idx1].insert(vasi[idx1].begin() + idx2, value);
            }
        }
    }
    
    out << "\n";
}

int main() {
    open();
    solve();

    return 0;
}

