#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int N = 19;
vector< vector<int> > box;

void print(void) {
    for (int i = 0; i < box.size(); i++) {
        for (int j = 0; j < box[i].size(); j++)
            cout << box[i][j] << " ";     
        cout << endl;    
    }       
}

void init(ifstream &inputFile) {
    int num_elem[5] = {3, 4, 5, 4, 3};
    box.resize(5);

    for (int i = 0; i < box.size(); i++) {
        box[i].resize(num_elem[i]);
        for (int j = 0; j < box[i].size(); j++) {
        char c;
            
        inputFile >> c;
        if (c == '.')
            box[i][j] = 0;
        else if (c == 'O')
            box[i][j] = 1;
        }
    }
}

int main () {
    ifstream inputFile("input.txt");
    ofstream outputFile("output.txt");

    init(inputFile);
    outputFile << "Karlsson" << "\n";
    //print();

    return 0;
}
