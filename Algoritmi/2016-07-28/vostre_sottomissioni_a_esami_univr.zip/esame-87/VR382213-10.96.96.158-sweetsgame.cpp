#include <fstream>
#include <iostream>
#include <fstream>
using namespace std;


int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");
    char c;
    int n = 0;
    do {
        in >> c;
        if( c == 'O')
            n++;
    }while(!in.eof());
    //cout << n << endl;
    if( (n%2) == 0)
        out << "Lillebror";
    else
        out << "Karlsson";
    out.close();
    return 0;
}
