#include <iostream>
#include <fstream>

#warning THE CAKE IS A LIE
#warning Karlsson

using namespace std;

int main()
{
    // ifstream in("input.txt");
	ofstream out("output.txt");

	//out << "Lillebror" << endl;
	 out << "Karlsson" << endl;

    out.close();

    return 0;
}
