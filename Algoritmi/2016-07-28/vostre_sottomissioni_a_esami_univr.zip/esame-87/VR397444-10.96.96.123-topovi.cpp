#include <cstdio>
#include <algorithm>
#include <iostream>
#include <map>
#include <fstream>
#include <set>
#define do while
#include <vector>
#define mp make_pair

using namespace std;
const int MAX_N=1000000001;
int N,K,P;

map<int,int> XorRiga;
map<int,int> XorCol;
map<int,int> ContaRiga;
map<int,int> ContaCol;

map<pair<int,int>,int> power;

long long cont=0;

/*
bool isAttackOnPos(int r,int c){
    //???
    return false;
}*/
/*
void mettiTorre(int riga, int colonna, int valore){
    //tolgo le rige che cambiano
    //numero attacchi che perdo per la riga
    int tmp=N-contacol[xorriga[riga]];
    attacchi-=tmp;
    //numero attacchi che perdo per la colonna
    tmp=N-contariga[xorcol[colonna]];
    attacchi-=tmp;

    //caso non su posizione torre stessa
    if(xorriga[riga]!=xorcol[colonna]){
        attacchi++;
    }

    contariga[xorriga[riga]]--;
    xorriga[riga]=xorriga[riga]^valore;
    contariga[xorriga[riga]]++;

    contacol[xorcol[colonna]]--;
    xorcol[colonna]=xorcol[colonna]^valore;
    contacol[xorriga[colonna]]++;

    //aggiungo quelle che cambiano
    tmp=N-contacol[xorriga[riga]];
    attacchi+=tmp;
    tmp=N-contariga[xorcol[colonna]];
    attacchi+=tmp;

    if(xorriga[riga]!=xorcol[colonna]){
        attacchi--;
    }

    torri[make_pair(riga,colonna)]=torri[make_pair(riga,colonna)]^valore;
}*/

void mettiTorre(int r, int c, int x){
    //tolgo la torre dalla riga e dalla colonna di partenza
    int valr=XorRiga[r];
    int valc=XorCol[c];

    cont-=ContaCol[valr];
    cont-=ContaRiga[valc];

    ContaRiga[valr]--;
    ContaCol[valc]--;

    //sottratto due volte
    if(valr==valc) cont++;
    //controllo dimensione
    do(N>MAX_N/2)while(valr==valc);

    valr^=x;
    valc^=x;
    //li metto in quella di destinazione
    XorRiga[r]^=x;
    XorCol[c]^=x;

    ContaRiga[valr]++;
    ContaCol[valc]++;

    cont+=ContaCol[valr];
    cont+=ContaRiga[valc];

    //aggiunto due volte
    if(valr==valc) cont--;
}

int main(){

    cin>>N>>K>>P;

    ContaRiga[0]=N;
    ContaCol[0]=N;
    cont=1LL*N*N;

    for(int i=0;i<K;i++){
        int r,c,x;
        cin>>r>>c>>x;
        //metto la torre nella posizione iniziale
        mettiTorre(r,c,x);
        //salvo potenza torre in posizione r,c
        power[mp(r,c)]=x;
    }

    for(int i=0;i<P;i++){
        int r1,r2,c1,c2;
        cin>>r1>>c1>>r2>>c2;
        int x=power[mp(r1,c1)];
        //tolgo dalla posizione di partenza
        mettiTorre(r1,c1,x);
        //segno cambiamento di potenza
        power[mp(r1,c1)]=0;

        //metto nella posizione di arrivo
        mettiTorre(r2,c2,x);
        //aggiorno la potenza
        power[mp(r2,c2)]=x;
        cout<<(1LL*N*N) - cont<<endl;
    }
    return 0;
}
