#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <fstream>

#define FOR(i,a,b) for(int i = (a); i < (b); i++)
#define Set(a,s) memset(a, s, sizeof(a))

using namespace std;


int row[] = {0 ,1, 2, -1, 3, 4, 5, 6, -1, 7, 8, 9, 10, 11, -1, 12, 13, 14, 15, -1, 16, 17, 18, -1,
2, 6, 11, -1, 1, 5, 10, 15, -1, 0, 4, 9, 14, 18, -1, 3, 8, 13, 17, -1, 7, 12, 16, -1,
0, 3, 7, -1, 1, 4, 8, 12, -1, 2, 5, 9, 13, 16, -1, 6, 10, 14, 17, -1, 11, 15, 18, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

char ARR[25];
int pl[1<<20];
int goal;
bool see[25];

bool solve(int kernel)
{

    if(kernel==goal) return false;
    if(pl[kernel]!=-1) return pl[kernel];
    pl[kernel] = false;
    int m;
    for (int k=0; k<75; k++)
    {
        m = kernel;
        for(int j=k; j<75; j++)
        {
            int px = row[j];
            if(px!=-1)
            {
                if(see[px] && !(m&(1<<px)))
                {
                
                    m |= (1<<px);
                    if(!solve(m))
                        pl[kernel]=true;
                }
                else
                        m = kernel;
            }
            else break;

        }
    }
    return pl[kernel];
}

int main()
{
    ifstream in("input.txt"); //apro il file in lettura

    FOR(i,0,18)
        in>>ARR[i]; //carica in ARR quello che legge dal file
    
    goal = 0;
    Set(see,0);
    Set(pl,-1);

    int c=0;
    FOR(i,0,18)
    {
        if(ARR[i]=='O' || ARR[i]=='.')++c;
        if(ARR[i]=='O') goal |= (1<<(c-1)), see[c-1]=1;
    }

    bool res = solve(0);
    
    ofstream out("output.txt"); //apro il file in scrittura
    if(res)                     //fase di scrittura
        out << "Karlsson"<<endl;       
    else
        out << "Lillebror"<<endl;

    return 0;

}



