#include <cstdio>
#include <iostream>
#include <map>

using namespace std;

int num, k, q;
long long solution;
map <int, int> rcnt, ccnt;
map <int, int> rxor, cxor;
map <pair<int, int>, int> rook;

void move(int r, int c, int val)
{
    solution -= num - ccnt[rxor[r]];
    solution -= num - rcnt[cxor[c]];

    if(rxor[r] != cxor[c])
        solution += 1;

    --rcnt[rxor[r]];
    rxor[r] ^= val;
    ++rcnt[rxor[r]];

    --ccnt[cxor[c]];
    cxor[c] ^= val;
    ++ccnt[cxor[c]];

    solution += num - ccnt[rxor[r]];
    solution += num - rcnt[cxor[c]];

    if(rxor[r] != cxor[c])
        solution -= 1;

    rook[make_pair(r, c)] ^= val;
}

void solve()
{
    while(q-- > 0)
    {
        int r1, c1, r2, c2;
        scanf("%d %d %d %d", &r1, &c1, &r2, &c2);
        --r1;
        --c1;
        --r2;
        --c2;
        int rv = rook[make_pair(r1, c1)];
        move(r1, c1, rv);
        move(r2, c2, rv);
        printf("%lld\n", solution);
    }
}

int main()
{
    // Inizializzazione
    scanf("%d %d %d", &num, &k, &q);
    rcnt[0] = ccnt[0] = num;

    for(int i = 0; i < k; ++i)
    {
        int r, c, val;
        scanf("%d %d %d", &r, &c, &val);
        --r;
        --c;
        move(r, c, val);
    }

    // Risoluzione
    solve();
    return 0;
}
