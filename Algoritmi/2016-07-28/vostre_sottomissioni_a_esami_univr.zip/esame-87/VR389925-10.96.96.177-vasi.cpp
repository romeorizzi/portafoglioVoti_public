#include<cstdlib>
#include<iostream>
#include<fstream>
#include<vector>
#include<list>

using namespace std;

int N, M;
int main() {
    int posRis = 0;
	ifstream in("input.txt");
    in >> N >> M;
    int vasi[N];
    char op[M];
    int comando[M][2];
    int contaC = 0;
    for(int i=0;i<M;i++){
        in >> op[i];
        if(op[i] == 's'){
            in >> comando[i][0];
            in >> comando[i][1];
        }
        else{
            contaC++;
            in >> comando[i][0];
            comando[i][1] = -1;
        }
    }
    in.close();
    int ris[contaC];

    for(int i=0;i<N;i++)
        vasi[i]=i;

    int temp=0;
    int temp2=0;
    int posi=0;
    int posj=0;

    for(int i=0;i<M;i++){
        if(op[i] == 'c'){
            ris[posRis] = vasi[comando[i][0]];
            posRis++;
        }
        else{
            posi = comando[i][0];
            posj = comando[i][1];
            temp = vasi[posj];
            temp2 = vasi[posi];
            vasi[posi] = temp;
           // cout << vasi[posi] << endl;
            if(posi < posj){
                for(int j=posi;j<posj;j++){
                    vasi[j] = vasi[j+1];
                }
            }
            else{
                for(int j=posi;j>posj;j--){
                    vasi[j] = vasi[j-1];
                }
            }
            vasi[posj] = temp2;

        }
        /*for(int k=0;k<N;k++)
            cout << vasi[k] << endl;
        cout << "wwwwwww" << endl;*/
    }
    /*for(int i=0;i<contaC;i++)
        cout << ris[i] << endl;*/
    ofstream out("output.txt");
    for(int i=0;i<contaC;i++){
        out << ris[i];
        if(i < contaC-1)
            out << " ";
    }
    out.close();
    /*for(int i=0;i<M;i++){
        for(int j=0;j<2;j++)
            cout << comando[i][j] << " ";
        cout << endl;
    }*/
	//ofstream out("output.txt");


   
	return 0;
}
