#include<cstdlib>
#include<iostream>
#include<fstream>
#include<vector>
#include<list>

using namespace std;

int N, M;
int main() {
    ifstream in("input.txt");
    int pedine[19];
    int valoriI[19];
    int valoriF[19];
    
    
    for(int i=0;i<19;i++){
        in >> pedine[i];
        if(pedine[i] == 'O')
            valoriI[i]=1;
        else
            valoriI[i]=0;
    }
   
   
    in.close();

    valoriF[0] = valoriI[0]+valoriI[1]+valoriI[3]+valoriI[4];
    valoriF[1] = valoriI[1]+valoriI[0]+valoriI[2]+valoriI[4]+valoriI[5];
    valoriF[2] = valoriI[2]+valoriI[1]+valoriI[6]+valoriI[5];
    valoriF[3] = valoriI[0]+valoriI[3]+valoriI[7]+valoriI[4]+valoriI[8];
    valoriF[4] = valoriI[4]+valoriI[0]+valoriI[9]+valoriI[3]+valoriI[5]+valoriI[1]+valoriI[8];
    valoriF[5] = valoriI[5]+valoriI[4]+valoriI[6]+valoriI[2]+valoriI[9]+valoriI[1]+valoriI[10];
    valoriF[6] = valoriI[6]+valoriI[2]+valoriI[11]+valoriI[10]+valoriI[5];
    valoriF[7] = valoriI[7]+valoriI[3]+valoriI[12]+valoriI[8];
    valoriF[8] = valoriI[8]+valoriI[7]+valoriI[9]+valoriI[3]+valoriI[4]+valoriI[12]+valoriI[13];
    valoriF[9] = valoriI[9]+valoriI[8]+valoriI[10]+valoriI[4]+valoriI[5]+valoriI[13]+valoriI[14];
    valoriF[10] = valoriI[10]+valoriI[9]+valoriI[11]+valoriI[5]+valoriI[6]+valoriI[14]+valoriI[15];
    valoriF[11] = valoriI[11]+valoriI[10]+valoriI[6]+valoriI[15];
    valoriF[12] = valoriI[12]+valoriI[7]+valoriI[16]+valoriI[13]+valoriI[8];
    valoriF[13] = valoriI[13]+valoriI[12]+valoriI[14]+valoriI[8]+valoriI[9]+valoriI[16]+valoriI[17];
    valoriF[14] = valoriI[14]+valoriI[13]+valoriI[15]+valoriI[9]+valoriI[10]+valoriI[17]+valoriI[18];
    valoriF[15] = valoriI[15]+valoriI[14]+valoriI[11]+valoriI[18]+valoriI[10];
    valoriF[16] = valoriI[16]+valoriI[12]+valoriI[13]+valoriI[17];
    valoriF[17] = valoriI[17]+valoriI[16]+valoriI[18]+valoriI[13]+valoriI[14];
    valoriF[18] = valoriI[18]+valoriI[17]+valoriI[14]+valoriI[15];

    int somma = 0;
    for(int i=0;i<19;i++)
        somma += valoriF[i];
    
    ofstream out("output.txt");
    if(somma % 2 == 0)
        out << "Lillebror";
    else
        out << "Karlsson";
    out.close();
    return 0;
}
