#include <iostream>
#include <fstream>
#include <deque>
#include <vector>
#include <cmath>
#include <stdio.h>

using namespace std;

int N,M;

int main(){
    ifstream input("input.txt");
    //ofstream output("output.txt");
    FILE *output=fopen("output.txt","w");
    input>>N>>M;
    int radiceN=ceil(sqrt(N));
    vector<deque<int> > vasi(radiceN);

    for(int i=0;i<N;i++){
        vasi[i/radiceN].push_back(i);
    }

    for(int i=0;i<M;i++){
        char c;
        int a,b;
        input>>c;
        if(c=='c'){
            input>>a;
            int quoz=a/radiceN;
            int resto=a%radiceN;
            fprintf(output, "%d ",vasi[quoz][resto]);
            //output<<vasi[quoz][resto]<< " ";
        }
        else{
            input>>a>>b;
            if(a!=b){
                int quoza=a/radiceN;
                int restoa=a%radiceN;
                int quozb=b/radiceN;
                int restob=b%radiceN;


                int valore=vasi[quoza][restoa];
                vasi[quoza].erase(vasi[quoza].begin()+restoa);

                while(quoza<quozb){
                    vasi[quoza].push_back(vasi[quoza+1].front());
                    vasi[++quoza].pop_front();
                }

                while(quoza>quozb){
                    vasi[quoza].push_front(vasi[quoza-1].back());
                    vasi[--quoza].pop_back();
                }

                vasi[quoza].insert(vasi[quoza].begin()+restob,valore);
            }
        }
    }
    //output<<endl;
    fprintf(output, "\n");
    input.close();
    fclose(output);
    return 0;
}

/*#include <iostream>
#include <fstream>
#include <list>

using namespace std;

int N,M;
const int MAX_N=400001;

//list<int> vasi;
int vasi[MAX_N];

void init_list(int n){
    for(int i=0;i<n;i++){
        //vasi.push_back(i);
        vasi[i]=i;
    }
}
*/
/*int getIel(int i){
    list<int>::iterator it=vasi.begin();
    for(int j=0;j<i;j++){
        it++;
    }
    advance(it,i);
    return *it;
}*/
/*
void sposta(int i,int j){
    int s=vasi[i];
    if(i<j){
        for(int k=i;k<j;k++){
            vasi[k]=vasi[k+1];
        }
    }
    else{
        for(int k=i;k>j;k--){
            vasi[k]=vasi[k-1];
        }
    }
    vasi[j]=s;
}

int main()
{
    ifstream input("input.txt");
    ofstream output("output.txt");
    if(output.is_open()){
        input>>N>>M;
        init_list(N);
        char c;
        int i,j;
        for(int k=0;k<M;k++){
            input>>c;
            if(c=='c'){
                input>>i;
                //output<<getIel(i)<<endl;
                output<<vasi[i]<<" ";
            }
            else{
                input>>i>>j;
                if(i!=j){
                    sposta(i,j);
                }
            }
        }
    }
    input.close();
    output.close();
}*/
