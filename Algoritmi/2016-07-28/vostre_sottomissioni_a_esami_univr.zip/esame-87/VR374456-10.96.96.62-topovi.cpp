#include <cstdio>
#include <string.h>
#include <fstream>
#include <iostream>

using namespace std;

int chess[1005][1005];

int attackable(int i, int j, int n);
void print_chess(int n);

int main () {
    

    int n;
    int k;
    int p;

    ifstream fin("input.txt");
    ofstream fout("output.txt");
    
    //input: n k p;
    
    fin >> n >> k >> p;

    if( n <= 1000) {
        
        //initializate chess
        for (int c = 0; c<k ; c++) {
            int i, j;
            //read position
            fin >> i >> j;
            //read power
            fin >> chess[i][j];

            //cout << i << " " << j << " " << chess[i][j]<< endl;
            
        }
        
        
        //move rocks

        for (int c=0; c<p; c++) {
            int i1, j1, i2,j2;
            fin >> i1 >> j1 >> i2 >> j2;

            chess [i2][j2] = chess[i1][j1];
            chess [i1][j1] = 0;

            //print_chess(n);

            //attackable
            int n_attackable = 0;         
            for (int i = 1; i<=n; i++) {
                for (int j = 1; j <= n; j++) {
                    if(attackable(i,j,n) > 0)
                        n_attackable++;
               }
            }
            fout << n_attackable << endl;
            
        } // fine c<p

    }// fine if n<=100
    
   
}

int attackable(int i, int j, int n) {
    
    //cout << "i,j " << i << j << endl;    

    int xor_row = chess[1][j];
    int xor_col = chess[i][1];
    int start = 2;
    //rock on the edge
    if (i == 1) {
        xor_row = chess[2][j];
        start = 3;
    }
    
    for (int k = start; k<=n; k++)
        if (k != i)
            xor_row = xor_row xor chess[k][j];

    start = 2;
    //rock on the edge
    if (j == 1) {
        xor_col = chess[i][2];
        start = 3;
    }
    
    for (int k = start; k<=n; k++)
        if (k != j)
            xor_col = xor_col xor chess[i][k];
    
    //xor_val = xor_row xor xor_col;
    //cout << "[" << i << "][" << j << "] = " << xor_val << endl; 

    return xor_row xor xor_col;

}

void print_chess(int n) {
// print chess
    for (int i = 1; i<=n; i++) {
        for (int j=1; j<=n; j++) {
            cout << chess[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}
