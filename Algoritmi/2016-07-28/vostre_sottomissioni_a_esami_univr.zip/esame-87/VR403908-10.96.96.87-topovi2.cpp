#include <cstdio>
#include <map>
#define DEBUG 0
using namespace std;
FILE* in = fopen("input.txt","r");
long long sol;
int n;
FILE* out = fopen("output.txt","w");
int k;
map <pair<int,int>,int> rook;
map <int,int> r_cont,c_cont;
map <int,int> r_xor,c_xor;
int q;
void muovi_rook(int r, int c, int peso){
    sol -= n-c_cont[r_xor[r]];
    sol -= n-r_cont[c_xor[c]];
    if(r_xor[r] != c_xor[c]) //todo: check
        sol+=1;
    --r_cont[r_xor[r]];
    --c_cont[c_xor[c]];
    r_xor[r]^=peso;
    c_xor[c]^=peso;
    ++r_cont[r_xor[r]];
    ++c_cont[c_xor[c]];
    sol += n - c_cont[r_xor[r]];
    sol += n - r_cont[c_xor[c]];
    if(r_xor[r] != c_xor[c]) //todo: check, funziona
        sol-=1;
    rook[make_pair(r,c)]^=peso;
}
int main()
{
    //INPUT
    fscanf(in,"%d %d %d\n",&n,&k,&q);
    r_cont[0] = c_cont[0] = n;
    for(int i = 0; i<k;++i){
        int r,c,val;
        fscanf(in,"%d %d %d\n",&r,&c,&val);
        --r;
        --c;
        muovi_rook(r,c,val);
    }
    //SOLUZIONE
    while(q-- >0){
        int r1,c1,r2,c2;
        fscanf(in,"%d %d %d %d\n",&r1,&c1,&r2,&c2);
        if(DEBUG)
            fprintf(out, "%d %d %d %d\n",r1,c1,r2,c2);
        --r1; --c1; --r2; --c2;
        int rook_val = rook[make_pair(r1,c1)];
        muovi_rook(r1,c1,rook_val);
        muovi_rook(r2,c2,rook_val);
        fprintf(out, "%lld\n",sol);
    }
}
