
#include <iostream> 
#include <cstdlib>
#include <fstream>
#include <cassert>

using namespace std;

#define Nmax 400000
#define Mmax 400000

char array[19];

int main() {

  ifstream fin("input.txt"); assert(fin);


    char a;
    int b=0;
  for(int i = 0; i < 19; i++){

        fin >> array[i];
             if(array[i]=='.')
                b++;
        
        }
  fin.close();

  ofstream fout("output.txt"); assert(fout);
        if(array[17]=='.')
         fout<<"Lillebror";
        else
         fout<<"Karlsson";

  fout.close();

  return 0;
}

