#include<iostream>
#include<cmath>
#include<deque>
#include<vector>
#include<fstream>

using namespace std;

// Indice cicli
int i;

// N vasi e M comandi
int N, M;

// Comando
char comando;
int c1, c2;

// Radice quadrata del numero di vasi e relativa var temporanea
double tempN;
int radN;

// Posizione del vaso ed eventuale nuova posizione
int pos_array1, pos_array2, pos_coda1, pos_coda2;

// Valore salvato
int valore_salvato;

int main()
{
    ifstream in("input.txt"); 
    ofstream out("output.txt");

    // Leggo N e M
    in >> N >> M;

    // DEBUG : Stampo N e M
    // cout << N <<"  "<< M << "\n";
    
    tempN = (sqrt(N));
    radN = ceil(tempN);
    vector<deque<int> > vasi(radN);
    
    for(i  = 0; i < N; i++)
    {
        vasi[i/radN].push_back(i);
    }

    for(i  = 0; i < M; i++)
    {
        // Leggo comando
        in >> comando;

        // DEBUG : Stampo comandi letti
        // cout << comando << " ";
        if(comando == 'c')
        {
            // Se il comando è 'c' allora "annoto il numero del vaso"
            in >> c1;
            
            // Calcolo la posizione del vaso richiesto nella struttura dati
            pos_array1 = c1/radN;
            pos_coda1 = c1%radN;

            // Stampo il numero del vaso seguito da spazio
            out << vasi[pos_array1][pos_coda1] << " ";
        }
        else
        {
            // Se il comando è 's' allora eseguo lo spostamento
            in >> c1 >> c2;

            // Se il vaso è già al suo posto passo al comando successivo
            if (c1 == c2) continue;

            // Altrimenti calcolo la posizione attuale del vaso e quella di destinazione
            pos_array1 = c1/radN;
            pos_coda1 = c1%radN;
            pos_array2 = c2/radN;
            pos_coda2 = c2%radN;

            // Salvo il valore ed elimino il vaso
            valore_salvato = vasi[pos_array1][pos_coda1];
            vasi[pos_array1].erase(vasi[pos_array1].begin()+pos_coda1);
            
            // Sposto gli altri vasi per fare spazio a sinistra o a destra a seconda del tipo di spostamento
            while(pos_array1 < pos_array2)
            {
                vasi[pos_array1].push_back(vasi[pos_array1+1].front());
                vasi[++pos_array1].pop_front();
            }

            while(pos_array1 > pos_array2)
            {
                vasi[pos_array1].push_front(vasi[pos_array1-1].back());
                vasi[--pos_array1].pop_back();
            }

            // Inserisco il vaso nella nuova posizione
            vasi[pos_array1].insert(vasi[pos_array1].begin() +pos_coda2, valore_salvato); 

        // DEBUG : Stampo vasi dopo il comando
        }
    }
    out << "\n";

    return 0;

}












