#include <cstdio>
#include <iostream>
#include <map>

using namespace std;

int num, kw, qz;
long long solution;
map <int, int> rightcnt, cccnt;
map <int, int> rightxor, ccxor;
map <pair<int, int>, int> elem;

void shift(int right, int left, int val) {
    solution -= num - cccnt[rightxor[right]]);
    solution -= num - rightcnt[ccxor[left]]);
    if (rightxor[right] != ccxor[left]) solution += 1;
    --rightcnt[rightxor[right]];rightxor[right] ^= val; ++rightcnt[rightxor[right]];
    --cccnt[ccxor[left]];ccxor[left] ^= val; ++cccnt[ccxor[left]];
/*
 --cccnt[ccxor[left]];
    ccxor[left] ^= val;
    ++cccnt[ccxor[left]];
*/
    solution = (solution + (num - cccnt[rightxor[right]])) + (num - rightcnt[ccxor[left]]);
    if (rightxor[right] != ccxor[left]) solution -= 1;
    elem[make_pair(right, left)] ^= val;
}

void double_shift(int right1, int left1, int rr1, int right2, int left2, int rr2) {
    shift(right1, left1, rr1); shift(right2, left2, rr2);
}

int main(void) {

    scanf("%d %d %d", &num, &kw, &qz);
    rightcnt[0] = cccnt[0] = num;
    for (int i = 0; i < kw; ++i) {
        int r, c, val;
        scanf("%d %d %d", &r, &c, &val); --r; --c;
        shift(r, c, val);
    }
/*
 --cccnt[ccxor[left]];
    ccxor[left] ^= val;
    ++cccnt[ccxor[left]];
*/

    while (qz-- > 0) {
        int r1, c1, r2, c2;
        scanf("%d %d %d %d", &r1, &c1, &r2, &c2); --r1; --c1; --r2; --c2;
        int rr = elem[make_pair(r1, c1)];
        double_shift(r1, c1, rr, r2, c2, rr);
        printf("%lld\n", solution);
    }
    return 0;
}

