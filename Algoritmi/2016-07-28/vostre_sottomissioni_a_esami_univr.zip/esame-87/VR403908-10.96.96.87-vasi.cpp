#include <fstream>
#include <vector>
#include <cmath>
#include <deque>
#define DEBUG 0

using namespace std;

int n,m;
void scambia(int p1,int p2, int max_n, vector<deque<int> >&vasi ){
    if(p1==p2)
        return;
    int a1 = p1/max_n;
    int b1 = p1%max_n;
    int a2 = p2/max_n;
    int b2 = p2%max_n;
    int temp = vasi[a1][b1];
    vasi[a1].erase(vasi[a1].begin()+b1);
    while(a1<a2){
        vasi[a1].push_back(vasi[a1+1].front());
        vasi[++a1].pop_front();
    }
    while(a1>a2){
        vasi[a1].push_front(vasi[a1-1].back());
        vasi[--a1].pop_back();
    }
    vasi[a1].insert(vasi[a1].begin()+b2,temp);

}
int main()
{
    //INIT
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> n >> m;
    if(DEBUG)
        out << n << m;
    double radix = sqrt(n);
    int max_n = ceil(radix);
    vector<deque<int> > vasi(max_n);
    //INIT vasi
    for(int i=0;i<n;i++){
        vasi[i/max_n].push_back(i);
    }

    //SOLVE
    char temp_cmd;
    int p1,p2 = 0;
    for(int i=0; i<m; i++){
        in >> temp_cmd;
        if(temp_cmd == 'c'){
            in >> p1;
            if(DEBUG)
                out << p1;
            int a = p1/max_n;
            int b = p1%max_n;
            //OUTPUT
            out << vasi[a][b] << " ";
        } else if(temp_cmd == 's'){
            in >> p1 >> p2;
            if(DEBUG)
                out << p1 << p2;
            //scambia(p1,p2,max_n,vasi); 
            //opt
            if(p1==p2)
                continue;
            int a1 = p1/max_n;
            int b1 = p1%max_n;
            int a2 = p2/max_n;
            int b2 = p2%max_n;
            int temp = vasi[a1][b1]; //salvo
            vasi[a1].erase(vasi[a1].begin()+b1);
            while(a1<a2){
                vasi[a1].push_back(vasi[a1+1].front());
                vasi[++a1].pop_front();
            }
            while(a1>a2){
                vasi[a1].push_front(vasi[a1-1].back());
                vasi[--a1].pop_back();
            }
            vasi[a1].insert(vasi[a1].begin()+b2,temp); //tap
        }
    }
}
