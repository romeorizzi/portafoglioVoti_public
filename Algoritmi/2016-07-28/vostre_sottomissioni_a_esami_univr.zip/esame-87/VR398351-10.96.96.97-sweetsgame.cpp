#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

char scatola[5][9];//scatola di cioccolatini
int scatolaint[5][9];
int somma=0;

int main(){

    FILE *fp_in;
    FILE *fp_out;

    fp_in = fopen("input.txt", "r");
    fp_out = fopen("output.txt", "w");
    
    int i=0;
    for (int j=0; j<9;++j)
        fscanf(fp_in,"%c", &scatola[i][j]);
    ++i;//1
    for (int j=0; j<9;++j)
        fscanf(fp_in,"%c", &scatola[i][j]);
    ++i;//2
    for (int j=0; j<9;++j)
        fscanf(fp_in,"%c", &scatola[i][j]);
    ++i;//3
    for (int j=0; j<9;++j)
        fscanf(fp_in,"%c", &scatola[i][j]);
    ++i;//4
    for (int j=0; j<7;++j)
        fscanf(fp_in,"%c", &scatola[i][j]);

    for (int i=0; i<5;++i)
        for (int j=0; j<9;++j)
            printf("%c", scatola[i][j]);
    printf("\n");
    for (int i=0; i<5;++i)
        for (int j=0; j<9;++j)
        {
            if(scatola[i][j]=='0')
                scatolaint[i][j]=1;
            else scatolaint[i][j]=0;
        }

    scatolaint[0][0]=2;
    scatolaint[0][1]=2;

    scatolaint[1][0]=2;
    scatolaint[1][1]=2;//
    scatolaint[2][0]=2;//
    scatolaint[0][2]=2;//
    scatolaint[0][6]=2;//
    scatolaint[1][7]=2;//
    scatolaint[2][8]=2;//
    scatolaint[2][8]=2;//
    scatolaint[3][7]=2;//
    scatolaint[4][6]=2;//
    scatolaint[3][1]=2;//
    scatolaint[4][2]=2;//

    scatolaint[0][8]=2;
    scatolaint[0][7]=2;
    scatolaint[1][8]=2;

    scatolaint[3][0]=2;
    scatolaint[4][0]=2;
    scatolaint[4][1]=2;

    scatolaint[3][8]=2;
    scatolaint[4][7]=2;
    scatolaint[4][8]=2;

    for (int i=0; i<5;++i)
    {
        for (int j=0; j<9;++j)
            printf("%d ", scatolaint[i][j]);
        printf("\n");//DEBUG
    }

    for (int i=0; i<5;++i)
    {
        for (int j=0; j<9;++j)
            if(scatolaint[i][j]==1)
                somma++;
    }
    
    if (somma%2==0)
        fprintf(fp_out,"Karlsson");
    else
        fprintf(fp_out,"Lillebror");
        
        


    //fprintf(fp_out,"Karlsson");//53
    //fprintf(fp_out,"Lillebror"); //48
            //else//vince giocatore 2    
              //  fprintf(fp_out,"Lillebror");
  
}
