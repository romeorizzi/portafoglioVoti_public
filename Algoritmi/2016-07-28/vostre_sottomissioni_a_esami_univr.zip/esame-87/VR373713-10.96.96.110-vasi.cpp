#include <fstream>
#include <cassert>

using namespace std;

const int MAXN = 400000;

ifstream fr;
ofstream fw;
int vasi[MAXN];
int temp, N;

void sposta_vasi(int s1, int s2) {
    if(s1 < s2) {
        temp = vasi[s1];
        move(vasi+(s1+1), vasi+(s2+1), vasi+s1);
        vasi[s2] = temp;       
    }
    else if(s2 < s1) {
        temp = vasi[s1];
        move(vasi+(s2), vasi+(s1), vasi+(s2+1));
        vasi[s2] = temp;
    }
    return;
}

int main() {

    fr.open("input.txt"); assert(fr);
    fw.open("output.txt"); assert(fw);

    int M;
    char ist;
    int s1, s2, c;
    int prova[2];
    
    fr >> N >> M;
    
    for(int i=0; i<N; i++) {
        vasi[i] = i;
    }
    
    for(int i=0; i<M; i++) {
        fr >> ist;
        
        if(ist == 'c') {
            fr >> c;
            fw << vasi[c] << " ";
        }
        else {
            fr >> s1 >> s2;
            sposta_vasi(s1, s2);
        }
        
    }

    fr.close();
    fw.close();

    return 0;
}
