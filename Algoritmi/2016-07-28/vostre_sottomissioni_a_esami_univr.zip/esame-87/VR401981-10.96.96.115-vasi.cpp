#include <cstdio>
#include <cassert>

#define MAX_N 400000

using namespace std;

long n_vasi, n_comm;
long array[MAX_N];

void swap(long from, long to)
{
    long temp=array[to];
    array[to]=array[from];
    array[from]=temp;

    if(from<to)
    {
        long i;

        for(i=from+1; array[i]<array[i-1] && array[i]!=array[to]; i++)
        {
            temp=array[i-1];
            array[i-1]=array[i];
            array[i]=temp;
        }
    }
    else if(from>to)
    {
        long i;

        for(i=from-1; array[i]>array[i+1] && array[i]!=array[to]; i--)
        {
            temp=array[i+1];
            array[i+1]=array[i];
            array[i]=temp;
        }       
    }
}

int main(void)
{
    assert(freopen("./input.txt", "r", stdin)!=NULL);
    scanf("%li %li ", &n_vasi, &n_comm);
    assert(n_vasi>=2 && n_vasi<=MAX_N);
    char comm;
    long from, to;

    assert(freopen("./output.txt", "w", stdout)!=NULL);

    for(long i=0; i<n_vasi; i++)
        array[i]=i;

    for(long i=0; i<n_comm; i++)
    {
        scanf("%c ", &comm);
        if(comm=='c')
        {
            scanf("%li ", &from);
            printf("%li ", array[from]);
        }
        else
        {
            scanf("%li %li ", &from, &to);
            swap(from, to);
        }
    }

    fflush(stdout);
    fclose(stdin);
    fclose(stdout);

    return 0;
}
