#include <cstdio>
#include <iostream>
#include <fstream>
#include <map>

using namespace std;

int N, K, P;
long long sol;
map <int, int> rcnt, ccnt;
map <int, int> rxor, cxor;
map <pair<int, int>, int> rook;

void moveRook (int r, int c, int val) {
    sol -= N - ccnt[rxor[r]];
    sol -= N - rcnt[cxor[c]];

    if (rxor[r] != cxor[c])
        sol += 1;
    
    --rcnt[rxor[r]];
    rxor[r] ^= val;
    ++rcnt[rxor[r]];

    --ccnt[cxor[c]];
    cxor[c] ^= val;
    ++ccnt[cxor[c]];

    sol += N - ccnt[rxor[r]];
    sol += N - rcnt[cxor[c]];

    if (rxor[r] != cxor[c])
        sol -= 1;

    rook[make_pair(r, c)] ^= val;
}

void init(ifstream &infFile) {
    infFile >> N >> K >> P;

    rcnt[0] = ccnt[0] = N;
    for (int i=0; i<K; i++) {
        int r, c, val;
        infFile >> r >> c >> val;
        --r;
        --c;
        moveRook(r, c, val);
    }
}

void solve(ifstream &infFile, ofstream &outFile) {
    while (P-- > 0) {
        int r1, c1, r2, c2;
        infFile >> r1 >> c1 >> r2 >> c2;
        --r1;
        --c1;
        --r2;
        --c2;
        int rookValue = rook[make_pair(r1,  c1)];
        moveRook(r1, c1, rookValue);
        moveRook(r2, c2, rookValue);
     
        outFile << sol << "\n";
    }
}

int main() {
    ifstream OpenFile("input.txt");
    ofstream OutFile("output.txt");
  
    init(OpenFile);
    solve(OpenFile, OutFile);

    return 0;
}
