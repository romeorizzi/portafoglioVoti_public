#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;


long int n;
long int ncom;

char command;
long int start;
long int dest;
long int nsalvato;

int main(){

    ifstream inputfile;
    inputfile.open("input.txt");

    ofstream outputfile;
    outputfile.open("output.txt");

    inputfile >> n >> ncom;

    long int listavasi[n];

    for (int i = 0; i < n; i++) {
        listavasi[i] = i;
    }

    for (int i = 0; i < ncom; i++) {
        inputfile >> command;
        if(command == 's'){
            inputfile >> start >> dest;
            if(start < dest){
                nsalvato = listavasi[start];
                for(int j = start; j < dest; j++){
                    listavasi[j] = listavasi[j+1];
                }
                listavasi[dest] = nsalvato;
            }else{
                nsalvato = listavasi[start];
                for(int j = (start-1); j >= dest; j--){
                    listavasi[j+1] = listavasi[j];
                }
                listavasi[dest] = nsalvato;
            }
        } else if (command == 'c'){
            inputfile >> start;
            int nlis = listavasi[start];
            outputfile << listavasi[start];
        }
    }
    
    outputfile.close();

    inputfile.close();

}
