#include <iostream>
#include <fstream>
#include <string>

#define MAX_N 400001

using namespace std;


int N;  // vasi
int M;  // comandi
string res; // output

char comando;
int _i,_j;

int vaso[MAX_N];

void init()
{
    for(int i = 0; i < N; ++i)
        vaso[i] = i;
}


// forse meglio prima spazio, e farlo solo la prima volta
// oppure stampare la stringa/stream senza l'ultimo carattere
void controlla()
{
    res += to_string(vaso[_i]) + " ";
}

void sposta()
{
    int tmp;
    if (_i < _j)
    {
        tmp = vaso[_i];
        for(int i = _i; i < _j; ++i)
        {
            vaso[i] = vaso[i + 1];
        }
        vaso[_j] = tmp;
    }
    else
    if (_i > _j)
    {
        tmp = vaso[_i];
        for(int i = _i; i > _j; --i)
        {
            vaso[i] = vaso[i-1];
        }
        vaso[_j] = tmp;
    }
}

int main() {
	ifstream in("input.txt");
	ofstream out("output.txt");

    in >> N >> M;

    init();

    for(int i = 0; i < M; ++i)
    {
        in >> comando >> _i;
        if(comando == 's')
        {
            in >> _j;
            sposta();
        }
        else
        {
            controlla();
        }
    }

    out << res << endl;

	return 0;
}
