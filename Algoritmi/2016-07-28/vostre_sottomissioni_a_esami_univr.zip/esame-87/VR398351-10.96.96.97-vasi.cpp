#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

const int MAX_N = 400000;
int vasi[MAX_N];
int nvasi, nc, vaso, spazio, da, a;
char vuoto,o;//o è l'ordine, vuoto per gestire lo spazio


int comando(int spazio){
    return vasi[spazio];
}

void spostamento(int da, int a){ 
    if (da!=a){
        int spostato = vasi[da];    
        if (da<a){
            for(int i=da; i<a; ++i)
            {
                vasi[i]=vasi[i+1];
            }
            vasi[a]=spostato;
        }
        else if(da>a){
            for(int i=da; i>a; --i)
            {
                vasi[i]=vasi[i-1];
            }
            vasi[a]=spostato;
        }

    }
}

int main(){

    FILE *fp_in;
    FILE *fp_out;

    fp_in = fopen("input.txt", "r");
    fp_out = fopen("output.txt", "w");

    fscanf(fp_in,"%d%d", &nvasi, &nc);
    
    for(int i=0; i<nvasi; ++i)
    {
        vasi[i]=i;
    }

    for(int i=0; i<nc; ++i)
    {
        fscanf(fp_in,"%c%c", &vuoto,&o);//ordine
        if (o == 'c'){
            fscanf(fp_in,"%d", &spazio);//annotare il numero di vaso nell'i-esimo spazio
            vaso = comando(spazio);
            if(nc==i+1)
                fprintf(fp_out,"%d", vaso);
            else        
                fprintf(fp_out,"%d ", vaso);
        }
        else if(o == 's'){
            fscanf(fp_in,"%d%d", &da, &a);//spostare il vaso da - a e spostare tutti gli altri
            spostamento(da, a);
        }
    }
}
