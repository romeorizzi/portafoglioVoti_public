#include <cstdio>
#include <iostream>
#include <map>

using namespace std;

int n;
int h;
int p;

long long sol;

map <int,int> rcnt,ccnt;
map <int,int> rxor,cxor;
map <pair<int,int>,int> torre;

void muoviTorre(int r, int c, int val){
    sol -= n-ccnt[rxor[r]];
    sol -= n-rcnt[cxor[c]];
    if (rxor[r] != cxor[c])
        sol +=1;
    --rcnt[rxor[r]];
    rxor[r] ^= val;
    ++rcnt[rxor[r]];

    --ccnt[cxor[c]];
    cxor[c] ^= val;
    ++ccnt[cxor[c]];

    sol += n - ccnt[rxor[r]];
    sol += n - rcnt[cxor[c]];
    if (rxor[r] != cxor[c])
        sol -= 1;

    torre[make_pair(r,c)] ^= val; 
}


void init(void) {
    scanf("%d %d %d", &n, &h, &p);
    rcnt[0] = ccnt[0] = n;
    for (int i=0; i<h; i++) {
        int r, c, val;
        scanf("%d %d %d", &r, &c, &val);
        --r;
        --c;
        muoviTorre(r,c,val);
    }
}

void risolvi(void) {
    while (p-- > 0) {
        int r1, c1, r2, c2;
        scanf("%d %d %d %d", &r1, &c1, &r2, &c2);
        --r1; --c1;
        --r2; --c2;
        int torreValore = torre[make_pair(r1,c1)];
        muoviTorre(r1,c1,torreValore);
        muoviTorre(r2,c2,torreValore);
        printf("%lld\n", sol);
    }
}

int main(void) {
    init();
    risolvi();
    return 0;
}
