#include <bits/stdc++.h>
#define DIM 400000
using namespace std;

int vasi[DIM];
int I, J, N, M;
char comando;
int quad[DIM];
int position_quad = 0;

void sposta();
void quaderno();

int main() {
    ifstream in("input.txt");
    in >> N >> M;
    for(int i = 0; i < N; i++)
        vasi[i] = i;

    for(int y = 0; y < M; y++) {
        in >> comando;
        if(comando == 'c') {
            in >> I;
            quaderno();
        }

        else {
            in >> I >> J;
            sposta();
        }
    }

    ofstream out("output.txt");
    for(int j = 0; j < position_quad; j++)
        out << quad[j] << " ";

    out.close();
    in.close();

return 0;
}

void sposta() {
    int temp = vasi[J];
    vasi[J] = vasi [I];
    if(I < J) {
        for(int pos = I; pos < J; pos++)
            if(pos + 1 != J)
                vasi[pos] = vasi[pos + 1];
            else
                vasi[pos] = temp;
    }
    else {
        if(J < I) {
            for(int pos = I; pos > J; pos--)
                if(pos - 1 != J)
                    vasi[pos] = vasi[pos - 1];
                else
                    vasi[pos] = temp;
        }
    }

}

void quaderno() {
    quad[position_quad] = vasi[I];
    position_quad++;
}
