#include <iostream>
#include <fstream>
#include <cstdio>
#include <cctype>

using namespace std;

int main() {
    ofstream OutFile("output.txt");

    OutFile << "Lillebror" << endl;

return 0;

}
