#include<bitset>
#include<cassert>
#include <fstream>

using namespace std;
typedef int Np; //non permesso
const Np np =-1;
const int DIM = 6;

//matrice posizioni permesse -1 = non permesso
int pos_perm[DIM][DIM] = {{1, 2, 3, np, np, np},
                 {4, 5, 6, 7, np, np},
                 {8, 9 , 10, 11, 12, np},
                 {13, 14, 15, 16, np, np},
                 {17, 18, 19, np, np, np},
                 {np, np, np, np, np, np}};

//spostamenti
int dtc[19][3] = {{1, 1, 0},{1, 1, 0},{1, 1, 0},{1, 1, 0},{1, 1, 0},{1, 1, 0},{1, 1, 0},
                  {1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1},
                  {1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1},{1, 0, -1} };
int dtr[3] = {0, 1, 1};
pair<int, int> i_pos[20];
bool dp[1<<19];
bool check[1<<19];

#define corI(riga, colonna) (pos_perm[riga][colonna] -1)
#define occ(i) (conf & (1 << i))

//true se se si considera una posizione lecita (!-1)
inline bool is_in_pos_perm( int riga, int colonna ){
    if( riga >= 0 && colonna >= 0 && pos_perm[riga][colonna] != np ) //nelle posizioni permesse
        return true;

    return false;
}

int start;

bool chi_vince(int conf){
    if( conf == 0 ) return false;  //perso
    if( check[conf] ) return dp[conf];
    check[conf] = true;
    bool & res = dp[conf];
    int new_riga, new_col;
    int new_conf;
    for (int i = 0; i < 19; ++i)
        if( occ(i) ){
            new_conf = conf;
            new_conf &= ~(1 << i);
            if( !chi_vince( new_conf ) ) return res = true; //perde avversario
            for( int dir = 0; dir < 3; ++dir ){
                new_conf = conf;
                new_conf &= ~(1<<i);
                new_riga = i_pos[i+1].first + dtr[dir];
                new_col = i_pos[i+1].second + dtc[i][dir];
                while( is_in_pos_perm(new_riga, new_col) && ( conf & (1<<corI(new_riga, new_col)))){
                    new_conf &= ~(1<<(pos_perm[new_riga][new_col]-1));
                    if(!chi_vince(new_conf)) return res = true;
                    new_col += dtc[corI(new_riga, new_col)][dir];
                    new_riga += dtr[dir];
                }
            }
        }
    return res = false; //avversario vince
}

int main( ){
    ifstream inFile("input.txt");
    ofstream outFile("output.txt");

    int i;
    char c;

    for(int i = 0; i < 5; ++i){
        for( int j = 0; j < 5; ++j){
            if( pos_perm[i][j] != np)
                i_pos[pos_perm[i][j]] = {i, j};
        }
    }

    while(i < 19){
        inFile >> c;
        if( c == 'O') start |= (1<<i);

        if (c == 'O' || c=='.' ) ++i;
    }

    inFile.close();

    if( chi_vince(start))
        outFile << "Karlsson" << endl;
    else
        outFile << "Lillebror" << endl;

    outFile.close();
    return 0;
}
































