#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

char chocolatebox[5][5];
int rowlen[] = {3,4,5,4,3};
int rowoffset[] = {0,0,0,1,2};
int numchocolate = 0;
int prossimafila[4] = {0,0,0,0}; // riga, colonna, direzionex, direzioney
int maxchocoinline = 0;
int player = 0; // 0 = Karlsson, 1 = Lillebror


void removechocolate(int i, int j, int posx, int posy, int moves){
    if (moves <= 0){
        return;
    }
    chocolatebox[i][j] = '.';
    numchocolate--;
    moves--;
    return removechocolate(i+posx,j+posy,posx,posy,moves);
}


int checknumber(int i, int j, int posx, int posy, int nchoco){
    if((j+posy < rowoffset[i+posx] || j+posy >= rowlen[i+posx] + rowoffset[i+posx]) || (i+posx < 0 || i+posx >= 5)){
        return nchoco;
    }
    if (chocolatebox[i+posx][j+posy] == '.'){
        return nchoco;
    }
    return checknumber(i+posx,j+posy,posx,posy,nchoco+1);
}

int main(){

    ifstream inputfile;
    inputfile.open("input.txt");

    char carattere;
    // Inserisco i valori nella matrice
    for (int i = 0; i < 5; i++) {
	    for (int j = 0; j < 5; j++) {
            if (j < rowlen[i]+ rowoffset[i] && j >= rowoffset[i]){
                inputfile >> carattere;
                if (carattere == 'O'){
                    numchocolate++;
                }
            }
		    if (i == 0 && j < rowlen[i]) {
                chocolatebox[i][j] = carattere;
            }else if (i == 1 && j < rowlen[i]) {
                chocolatebox[i][j] = carattere;
            }else if (i == 2 && j < rowlen[i]) {
                chocolatebox[i][j] = carattere;
            }else if (i == 3 && j < 5 && j >= rowoffset[i]) {
                chocolatebox[i][j] = carattere;
            }else if (i == 4 && j < 5 && j >= rowoffset[i]) {
                chocolatebox[i][j] = carattere;
            }else{
                chocolatebox[i][j] = '*';
            }
	    }
	}


    printf("%i\n",numchocolate);

    for (int i = 0; i < 5; i++) {
	        for (int j = 0; j < 5; j++) {
                printf("%2c",chocolatebox[i][j]);
            }
            printf("\n");
        }

    inputfile.close();

    int numchocotemp = 0;

    while (numchocolate > 0){
        printf("%i\n",numchocolate);
        for (int i = 0; i < 5; i++) {
	        for (int j = 0; j < 5; j++) {
                if (chocolatebox[i][j] == 'O' && j < rowlen[i] + rowoffset[i] && j >= rowoffset[i]){
                    numchocotemp = checknumber(i,j,1,-1,1);  //downsx
                    if (numchocotemp > maxchocoinline){
                        prossimafila[0] = i;
                        prossimafila[1] = j;
                        prossimafila[2] = 1;
                        prossimafila[3] = -1;
                        maxchocoinline = numchocotemp;
                    }
                    numchocotemp = checknumber(i,j,1,0,1);   //down
                    if (numchocotemp > maxchocoinline){
                        prossimafila[0] = i;
                        prossimafila[1] = j;
                        prossimafila[2] = 1;
                        prossimafila[3] = 0;
                        maxchocoinline = numchocotemp;
                    }
                    numchocotemp = checknumber(i,j,1,1,1);   //downdx
                    if (numchocotemp > maxchocoinline){
                        prossimafila[0] = i;
                        prossimafila[1] = j;
                        prossimafila[2] = 1;
                        prossimafila[3] = 1;
                        maxchocoinline = numchocotemp;
                    }
                    numchocotemp = checknumber(i,j,0,1,1);   //dx
                    if (numchocotemp > maxchocoinline){
                        prossimafila[0] = i;
                        prossimafila[1] = j;
                        prossimafila[2] = 0;
                        prossimafila[3] = 1;
                        maxchocoinline = numchocotemp;
                    }
                }
	        }
	    }

        //rimuovi fila cioccolatini
        removechocolate(prossimafila[0], prossimafila[1], prossimafila[2], prossimafila[3], maxchocoinline);

        //cambio player
        if (player == 0){
            player = 1;        
        }else{
            player = 0;
        }

        for (int i = 0; i < 5; i++) {
	        for (int j = 0; j < 5; j++) {
                printf("%2c",chocolatebox[i][j]);
            }
            printf("\n");
        }
        maxchocoinline = 0;
        prossimafila[0] = 0;
        prossimafila[1] = 0;
        prossimafila[2] = 0;
        prossimafila[3] = 0;
    }

    ofstream outputfile;
    outputfile.open("output.txt");

    if (player == 0){
        outputfile << "Lillebror";
    }else{
        outputfile << "Karlsson";
    }

    outputfile.close();
}
