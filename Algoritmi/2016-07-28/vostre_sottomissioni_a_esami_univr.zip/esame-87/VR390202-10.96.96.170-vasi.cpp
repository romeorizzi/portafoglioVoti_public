
#include <iostream> 
#include <cstdlib>
#include <fstream>
#include <cassert>

using namespace std;

#define Nmax 400000
#define Mmax 400000

int array[Nmax];
int arrayfinale[Nmax];
char istr[Mmax][3];
int M, N;

void inizializzoarray(){
    for(int i=0; i<N; i++){
        array[i]=i;
        arrayfinale[i]=0;
    }
}
void inizializzoistr(){
    for(int i=0; i<M; i++)
        for(int j=0; j<3; j++)
        istr[i][j]=0;
}
  
int main() {

  ifstream fin("input.txt"); assert(fin);
  fin >> N; // lunghezza dell'array (numero vasi) 
  fin >> M; // numero di comandi

  inizializzoarray();
  inizializzoistr();

  char a;
  int num1, num2;
  
  ofstream fout("output.txt"); assert(fout);

  for(int i = 0; i < M; i++){
        fin >> a;
        if(a=='c'){
            fin>>num1;
            cout<<"stampo array["<<num1<<"]"<<endl;
           // stamposufileposizionenum1
            fout<<array[num1]<<" ";
        }
         if(a=='s'){
            fin>>num1;//cosa da spostare
            fin>>num2;//posizione in cui deve essere spostata
            //creo un array 
            
            //so già che sposto num1 in num2
            arrayfinale[num2]=array[num1];

            //sposto posizione di num1 in num2 e riordino array, oppure faccio con vettori
            int j=0;

            for(int i=0; i<num2; i++){
                 if(i==num1) j++;
                 arrayfinale[i]=array[i+j];
                 
                }

            arrayfinale[num2]=array[num1]; 
            
       
          int l=0;
          for(int i=num2+1; i<N; i++){

            if(num2+j==num1)j++;

            arrayfinale[i]=array[num2+j];
            j++;                
            }
               

            
            cout<<"sposto "<<num1<<" in "<<num2<<"."<<endl;

             for(int i=0; i<N; i++){
                array[i]=arrayfinale[i];
            }
        }
    }
  fin.close();

 
  fout.close();
  return 0;
}

