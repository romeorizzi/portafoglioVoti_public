#include <cstdio>
#include <cassert>
#include <map>
#include <utility>

using namespace std;

#define MAX_N 1000000000
#define MAX_K 100000

unsigned long dim, num_rooks, num_moves;
map<pair<unsigned long, unsigned long>, unsigned long> rooks_pos;

unsigned long check_attack()
{
    unsigned long res=0;
    unsigned long temp=0;

    for(unsigned long i=1; i<=dim; i++)
        for(unsigned long j=1; j<=dim; j++)
        {
            for(map<pair<unsigned long, unsigned long>, unsigned long>::iterator pos=rooks_pos.begin(); pos!=rooks_pos.end(); pos++)
                if(((pos->first).first)==i || ((pos->first).second)==j)
                    if(((pos->first).first)==i && ((pos->first).second)==j)
                        continue;
                    else
                        temp=temp xor pos->second;

            if(temp>0)
                res++;

            temp=0;
        }

    return res;
}

int main(void)
{
    assert(freopen("./input.txt", "r", stdin)!=NULL);
    assert(freopen("./output.txt", "w", stdout)!=NULL);
    scanf("%li %li %li ", &dim, &num_rooks, &num_moves);
    assert(dim>=1 && dim<=MAX_N);
    assert(num_rooks>=1 && num_rooks<=MAX_K);
    assert(num_moves>=1 && num_moves<=MAX_K);

    //Assumo, per comodità, che ogni struttura usata sia 1-based.
    unsigned long power, r, c;

    for(unsigned long i=1; i<=num_rooks; i++)
    {
        scanf("%li %li %li ", &r, &c, &power);
        rooks_pos.insert(make_pair(make_pair(r, c), power));
    }

    unsigned long from1, from2, to1, to2;

    for(unsigned long i=1; i<=num_moves; i++)
    {
        scanf("%li %li %li %li ", &from1, &from2, &to1, &to2);
        rooks_pos[make_pair(to1, to2)]=(rooks_pos.find(make_pair(from1, from2)))->second;
        rooks_pos.erase(make_pair(from1, from2));

        printf("%li\n", check_attack());
    }

    fflush(stdout);
    fclose(stdin);
    fclose(stdout);

    return 0;
}
