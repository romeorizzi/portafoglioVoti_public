#include <fstream>
#include <iostream>
#include <fstream>
//#include <algorithm>
using namespace std;

long int N, M;
long int vasi[400000];
/*
void shiftL(int a, int b) {
    long int j;
    for(j = a; j < b; j++) 
        vasi[j] = vasi[j+1];
    return;
}

void shiftR(int a, int b) {
    long int j;
    for(j = b; j > a; j--)    
        vasi[j] = vasi[j-1]; 
    return;
}

void stampa() {
    for(int i = 0; i < N; i++)
        cout << vasi[i] << " ";
    cout << endl;
    return;
} */

int main() {
    long int i;
    ifstream in("input.txt");
    ofstream out("output.txt");
    in >> N >> M;
    //creazione struttura dati
    for(i = 0; i < N; i++)
        vasi[i] = i;

    //stampa();
    for(i = 0; i < M; i++) {
        char istruzione;
        in >> istruzione;
        if(istruzione == 's') {
            long int s, d, e;
            in >> s >> d; 
            //fai qualcosa
            //cout << istruzione << s << d << endl;
            e = vasi[s];
            if(s < d)
            {
                long int j;
                for(j = s; j < d; j++) 
                    vasi[j] = vasi[j+1];
                //shiftL(s, d);
            }
            else {
                long int j;
                for(j = s; j > d; j--)    
                    vasi[j] = vasi[j-1]; 
                //shiftR(d, s);
            } 
            vasi[d] = e;
            //stampa();
        } else {
            long int c; 
            in >> c;
            //fai qualcosaltro
            //cout << istruzione << c << endl;
            cout << vasi[c] << " ";
            out << vasi[c] << " ";
        }
    }
    in.close();
    out.close();   
    //cout << endl;
    return 0;
}
