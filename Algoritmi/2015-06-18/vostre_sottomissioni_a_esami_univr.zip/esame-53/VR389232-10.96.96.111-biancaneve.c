#include <stdio.h>

void print_nani(int nani[], int prec[], int succ[], int length){

    int i;
    printf("Nani:\n");
    for(i=1; i<length+1; i++)
        printf("%d ", nani[i]);

    printf("\n");

    printf("Prec:\n");
    for(i=1; i<length+1; i++)
        printf("%d ", prec[i]);

    printf("\n");

    printf("Succ:\n");
    for(i=1; i<length+1; i++)
        printf("%d ", succ[i]);

    printf("\n");
}

void swap(int nani[], int prec[], int succ[], int first, int second, int length){

    int first_nano = nani[first];
    int second_nano = nani[second];


    //scambio i nani
    int temp = nani[first];
    nani[first] = nani[second];
    nani[second] = temp;
    /*printf("Scambio i nani\n");
    print_nani(nani, prec, succ, length);
    fflush(stdout);*/

    //scambio i predecessori
    temp = prec[first_nano];
    prec[first_nano] = prec[second_nano];
    prec[second_nano] = temp;
    /*printf("Scambio i predecessori\n");
    print_nani(nani, prec, succ, length);
    fflush(stdout);*/

    //scambio i successori
    temp = succ[first_nano];
    succ[first_nano] = succ[second_nano];
    succ[second_nano] = temp;
    /*printf("Scambio i successori\n");
    print_nani(nani, prec, succ, length);
    fflush(stdout);*/

    //sistemo prec e suc dei precedenti e dei successivi

    if(prec[first_nano] != -1)
        succ[prec[first_nano]] = first_nano;
    if(succ[first_nano] != -1)  
        prec[succ[first_nano]] = first_nano;
    if(prec[second_nano] != -1) 
        succ[prec[second_nano]] = second_nano;
    if(succ[second_nano] != -1) 
        prec[succ[second_nano]] = second_nano;
    /*printf("sistemo il resto\n");
    print_nani(nani, prec, succ, length);
    fflush(stdout);*/
}


void check_nani(int nani[], int prec[], int succ[], int length, int lower, int upper){
    
    int i;

    /*int trovati[cercati];

    for(i=0; i<cercati; i++)
        trovati[i] = 0;*/

    int first = -1;
    int last = -1;
    for(i=lower; i<=upper; i++){
    
        if(prec[i] == -1){
            if(first == -1)
               first = i;
            else {
                printf("NO\n");
                return;
            }
        }  

        if(succ[i] == -1){
            if(last == -1)
               last = i;
            else {
                printf("NO\n");
                return;
            }

        }
        if(prec[i] != -1 && (prec[i] > upper || prec[i] < lower)){

            if(first == -1)
                first = i;
            else {
                printf("NO\n");
                return;
            }
        }   

        if(succ[i] != -1 && (succ[i] > upper || succ[i] < lower)){


            if(last == -1)
                last = i;
            else{
                printf("NO\n");
                return;
            }
        }

      //  printf("first = %d, last = %d\n", first, last);

    }
        
    printf("YES\n");    

}

int main(void){

    int nnani, richieste, i, command, first, second;

    scanf("%d %d\n", &nnani, &richieste);

    int nani[nnani+1];
    int prec[nnani+1];
    int succ[nnani+1];


    int prev = -1;
    for(i=1; i<nnani+1; i++){
        scanf("%d", &nani[i]);
        prec[nani[i]] = prev;
        
        if(prev != -1)
            succ[prev] = nani[i];

        prev = nani[i];

    }

    succ[nani[i-1]] = -1;

   //print_nani(nani, prec, succ, nnani);
   for(i=0; i<richieste; i++){

        scanf("%d %d %d", &command, &first, &second);


        if(command == 1){

            swap(nani, prec, succ, first, second, nnani);
           // print_nani(nani, prec, succ, nnani);
        }
            
        if(command == 2)
            check_nani(nani, prec, succ, nnani, first, second);


    }


    return 0;

}
