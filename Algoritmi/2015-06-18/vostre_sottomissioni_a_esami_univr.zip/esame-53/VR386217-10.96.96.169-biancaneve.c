#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define MAX_NANI 200000

inline void swap(long int *a, long int *b) { long int tmp = *a; *a = *b; *b = tmp; }

long int nani[MAX_NANI];
long int posizione_nani[MAX_NANI];
long int num_nani;

int main() {

    long int param1, param2, i;
    long int num_query;
    int query;

    scanf("%ld %ld", &num_nani, &num_query);

    for(i = 0; i < num_nani; i++){
        scanf("%ld", &nani[i]);
        posizione_nani[nani[i]] = i;    
    }

    i=0;

    while(i < num_query) {
        scanf("%d %ld %ld", &query, &param1, &param2);
        if(query == 1) {
            param1--;
            param2--;
            swap(&posizione_nani[nani[param1]], &posizione_nani[nani[param2]]);
            swap(&nani[param1], &nani[param2]);
        } else {
            long int inizio = posizione_nani[param1];
            long int k = 1;
            long int j = 1;
            while((inizio+k) < num_nani && nani[inizio+k] > param1 && nani[inizio+k] <= param2) {++k;}
            k--;
            while((inizio+k) >= 0 && nani[inizio-j] > param1 && nani[inizio-j] <= param2) {++j;}
            j--;
            if(k+j == param2-param1)
                printf("YES\n");
            else
                printf("NO\n");
        }
        ++i;    
    }

    return 0;
}
