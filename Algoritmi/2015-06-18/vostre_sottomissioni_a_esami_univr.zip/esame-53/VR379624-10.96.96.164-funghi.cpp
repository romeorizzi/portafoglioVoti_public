#include <iostream>
#include <cassert>
#include <stdlib.h>
#include <sstream>

using namespace std;

const long long int MAX_N = 10000;
const long long int R = 1000000007;

int main(){

    long long int n, comb=0;
    cin >> n; assert( n <= MAX_N ); assert( n >= 1);

    int *h = (int*)malloc(n*sizeof(int));

    string str="";
    getline(cin, str);
    stringstream ssr(str);
    int i=0;
    while(ssr >> nani[i])
        i++;

    cout << (comb%R)
    free(h);
    return 0;
}
