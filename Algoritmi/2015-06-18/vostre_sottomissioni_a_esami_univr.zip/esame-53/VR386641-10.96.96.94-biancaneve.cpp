#include <stdio.h>
#include <vector>

using namespace std;

struct richiesta {
    richiesta(){
        type=0;
        A=0;
        B=0;
    }    
    int type;
    int A;
    int B;
};

vector<richiesta> richieste;
vector<int> nani;
int num_nani, num_richieste;

void scambia (int a, int b) {
    int k;
    k=nani[a-1];
    nani[a-1]=nani[b-1];
    nani[b-1]=k;
};

void controlla (int a, int b) {
    int num_valori=b-a+1;
    bool find=false;
    bool err=false;
    if(num_valori==1)
        printf("YES\n");
    else{

        for(int i=0; i<num_nani; i++){
            if((nani[i]<a || nani[i]>b) && num_valori>0){
                if(find == true){
                    err=true;
                    printf("NO\n");
                } 
            }
            else{
                find=true;
                num_valori--;
                if(num_valori==0)
                    printf("YES\n");
            }  
            if(num_valori==0 || err==true)
              break;
        }
    }
};

int main(void) {

    int a,b,c;

    //printf("Inserisci nani  richieste\n"); 

    int par=scanf("%d %d", &num_nani, &num_richieste);
    
    richieste.assign(num_richieste, richiesta()); 
    nani.assign(num_nani,0);
    
    for(int i=0; i<num_nani; i++){
        par=scanf("%d", &nani[i]);
    }
    
    /*printf("stampa nani\n");

    for(int i=0; i<num_nani; i++){
        printf("%d ", nani[i]);
    }*/

    for(int i=0; i<num_richieste; i++){
        //printf("------------------\n");
        //printf("%d",i);
        par=scanf("%d %d %d", &a, &b, &c);
        richieste[i].type=a;
        richieste[i].A=b;
        richieste[i].B=c;
    }

    for(int i=0; i<num_richieste; i++){
        if(richieste[i].type==1)
            scambia(richieste[i].A, richieste[i].B);
        if(richieste[i].type==2)
            controlla(richieste[i].A, richieste[i].B); 
    }

  /*  for(int i=0; i<num_richieste; i++){
        printf("%d \n",i);
        printf("%d \n",richieste[i].type);
        printf("%d \n",richieste[i].A);
        printf("%d \n",richieste[i].B);
    }
        
    printf("I nani sono %d ", par);

    printf("Le richieste sono %d ", par); */   
	

	return 0;
}
