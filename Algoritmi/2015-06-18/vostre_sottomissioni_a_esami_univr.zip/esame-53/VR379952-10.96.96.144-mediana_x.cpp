#include "ourLibToPlay.h"


// implementare ordina
// implementare inserisci: dovrà essere chiamata ricorsivamente
// chiamare consegnaBiglieInOrdine già definita

void my_swap(long int *var1, long int *var2) {
    long int tmp = *var1;
    *var1 = *var2;
    *var2 = tmp;
}

long int  biglia_posizionata[100001];
long int  posizione[100001];

int inserisci(long int da_inserire,long int inferiore,long int superiore);

// init vettori
void init(){
    biglia_posizionata[0]=0;
    biglia_posizionata[1]=1;
    posizione[0]=0;
    posizione[1]=1;
}

void ordina(long int n) {
    long int i;
    init();
    for(i = 2	; i < n; i++){
        biglia_posizionata[i] = i;
        posizione[i]=i;
        inserisci(i,0,i-1);
    }
    consegnaBiglieInOrdine(biglia_posizionata);
}

int inserisci(long int da_inserire,long int inferiore,long int superiore){

    // se superiore==inferiore non ho nulla da fare
    if(superiore==inferiore) return da_inserire;

    long int medio,i;


    medio = bigliaIntermedia( biglia_posizionata[inferiore],biglia_posizionata[da_inserire],biglia_posizionata[superiore]);

    // passi comuni ai due casi
    if(biglia_posizionata[inferiore]==medio){

        for(i=da_inserire;i>inferiore;--i){
            my_swap(&biglia_posizionata[i], &biglia_posizionata[i-1]);
        }

        da_inserire=inferiore;
    }

    // ARRIVATO QUI HO DA_INSERIRE SETTATO ADEGUATAMENTE
    long int centro;

    // se vale devo inserire in centro
    if((superiore-inferiore)+1<3){


        if(biglia_posizionata[da_inserire]==medio){
            my_swap( &biglia_posizionata[da_inserire], &biglia_posizionata[superiore]);
            da_inserire=superiore;
            //cout << " debug: da_inserire = " << da_inserire <<"\n";
        }

    }else{

        if(biglia_posizionata[da_inserire]==medio){
            // prova (4+2)/2+ (4+2)%2 3+0
            centro=(superiore+inferiore)/2+(superiore+inferiore)%2;
            // chiamate ricorsive
            // inserisci(da_inserire,3,4)
            da_inserire=inserisci(da_inserire,centro,superiore);
            //cout << " debug: da_inserire else = " << da_inserire <<"\n";
            if(da_inserire==centro){
                //inserisci(da_inserire,2,2)
                inserisci(da_inserire,inferiore,centro-1);
            }
        }
    }


    return da_inserire;

}
