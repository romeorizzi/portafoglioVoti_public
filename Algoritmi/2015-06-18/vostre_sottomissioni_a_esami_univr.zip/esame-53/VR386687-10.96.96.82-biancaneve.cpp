#include <stdio.h>


void reorderXY(int nani[], int par1, int par2)
{
    int buffer;
    buffer = nani[par1];
    nani[par1] = nani[par2];
    nani[par2] = buffer;
}


void checkAB(int nani[], int par1, int par2, int n_nani)
{
    int nano_max;
    int nano_min;
    int intervallo;

    if(par1 >= par2)
    {
        nano_max = par1;
        nano_min = par2;
    }
    else
    {
        nano_max = par2;
        nano_min = par1;
    }

    if(nano_max > n_nani)
    {
        printf("NO\n");
        return;
    }


    int somma = 0;
    intervallo = nano_max - nano_min + 1;
    for(int i = 0; i < intervallo; i++)
    {
        somma += nano_min + i;
    }
    int somma_calc = 0;


    bool is_first = true;
    for(int i = 1; i <= n_nani + 1; i++)
    {
        //trovo il primo da controllare
        if(nani[i]<= nano_max && nani[i]>= nano_min && is_first)
        {

            for(int j = 0; j < intervallo; j++)
            {
                somma_calc += nani[i+j];
            }

            if(somma_calc == somma)
                printf("YES\n");
            else
                printf("NO\n");

            return;

        }
    }
}


int main(void)
{
    int n_nani;
    int n_req;


    int nl = scanf("%d %d", &n_nani, &n_req);

    if(nl != 2)
        return 1;

    int *nani = new int[n_nani + 1];
    nani[0] = 0;
    int **commands = new int*[n_req];
    for(int i = 0; i < n_req; i++)
        commands[i] = new int[3];

    // popolo i nani
    for(int j = 1; j <= n_nani; j++)
    {
        nl = scanf("%d", &nani[j]);
    }

    //acquisizione comandi
    for(int i = 0; i < n_req; i++)
    {
        nl = scanf("%d %d %d",&commands[i][0],&commands[i][1],&commands[i][2] );
    }

    //esecuzione comandi
    for(int i = 0; i < n_req; i++)
    {
        if(commands[i][0] == 1)
            reorderXY(nani, commands[i][1], commands[i][2]);

        else if(commands[i][0] == 2)
            checkAB(nani, commands[i][1], commands[i][2], n_nani);
    }

    return 0;


}
