#include "ourLibToPlay.h"
void merge(long int a[], long int left, long int center, long int right)
{
    int i,j,k,b[right+1];
    i =left;
    j=center+1;
    k=0;
    while(i<=center && j<=right)
    {
        if(bigliaIntermedia(i,i,j))
        {
            b[k]=a[i];
            i++;
        }
        else
        {
            b[k]=a[j];
            j++;
        }
        k++
    }
    while(i<=center)
    {
        b[k]=a[i];
        i++;
        k++;
    }
    while(j<=right)
    {
        b[k]=a[j];
        j++;
        k++;
    }
    for(k=left;k<=right;k++)
    {
        a[k]=b[k-left];
    }
}

void mergesort(long int a[], long int left, long int right)
{
    long int center;
    if(left<right)
    {
        center=(left+right)/2;
        mergesort(a,left,center);
        mergesort(a,center+1,right);
        merge(a,left,center,right);
    }
}

void ordina(long int n)
{
    long int biglia_in_pos[n];
    long int i;
    for(i=0; i<n; i++)
        biglia_in_pos[i]=i;
    mergesort(biglia_in_pos,0,n-1);
    consegnaBiglieInOrdine(biglia_in_pos);
}
