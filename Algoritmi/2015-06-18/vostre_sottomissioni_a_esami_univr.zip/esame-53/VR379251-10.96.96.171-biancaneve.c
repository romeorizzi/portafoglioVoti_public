#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define MAX_NANI 200000

void result(long int A_X,long int B_Y);

long int nani[200000];
long int altezza_nani[200000];
long int num_nani;

int main(){
    long int i,A_X,B_Y,num_mosse,tmp;
    int mossa;
   
    scanf("%ld %ld",&num_nani,&num_mosse);
    
    for(i=0;i<num_nani;i++){
        scanf("%ld",&nani[i]);
        altezza_nani[nani[i]]=i;    
    }
    i=0;    

    while(i<num_mosse)
    {
        scanf("%d %ld %ld",&mossa,&A_X,&B_Y);

        if(mossa==2)
            result(A_X,B_Y);
             
        else
        {
            A_X--;
            B_Y--;
            //-------------------------------------------------------
            tmp=altezza_nani[nani[A_X]];
            altezza_nani[nani[A_X]]=altezza_nani[nani[B_Y]];
            altezza_nani[nani[B_Y]]=tmp;
            //-------------------------------------------------------            
            tmp=nani[A_X];
            nani[A_X]=nani[B_Y];
            nani[B_Y]=tmp;
        }  
    ++i;    
    }
return 0;
}


void result(long int A_X,long int B_Y)
{
    long int start=altezza_nani[A_X];
    long int i=1;
    long int j=1;

    while((start+i)<num_nani && nani[start+i]>A_X && nani[start+i]<=B_Y)
    {
        ++i;
    }
    i--;

    while((start+i)>=0 && nani[start-j]>A_X && nani[start-j]<=B_Y)
    {   
        ++j;
    }
    j--;

    if(i+j==B_Y-A_X) 
        printf("YES\n");
    else 
        printf("NO\n");
}
