#include <iostream>
#include <sstream>
#include <string>

using namespace std;

long int N;
long int M;

int main(){
    cin >> N;
    cin >> M;
    
    long int nani[N];
    
    for(long int i = 0;i < N;i++){
        cin >> nani[i];
    }

    long int command = 0;
    long int n_1;
    long int n_2;
    bool start = false;
    bool end = false;
    
    stringstream result;
    
    for(long int i = 0;i < M;i++){
        cin >> command;
        cin >> n_1;
        cin >> n_2;
        
        if(n_1 > n_2){
            int temp = n_1;
            n_1 = n_2;
            n_2 = temp;
        }
        
        if(command == 1){
            long int temp = nani[n_1 -1];
            nani[n_1 -1] = nani[n_2 -1];
            nani[n_2 -1] = temp;            
        }
        
        else if(command == 2){
            bool dont_start = false;
            if((n_1 == 1 && n_2 == N) || (n_2 == 1 && n_1 == N)){
                result << "YES" << endl;
                dont_start = true;
                }
                
            start = false;
            end = false;
            long int interval = n_2 - n_1 + 1;
            if(!dont_start)
            for(long int j = 0;j <= N;j++){
                if(j == N){
                    result << "YES"<< endl;
                    break;
                }
                
                if(!start && (nani[j] >= n_1 && nani[j] <= n_2)){
                    start = true;
                }
                
                if(start){
                    interval--;
                    if(nani[j] < n_1 || nani[j] > n_2){
                        result << "NO" << endl;
                        break;
                    }
                }
                
                if(interval == 0){
                    result << "YES" << endl;
                    break;
                }
            }
        }
        
    }
                                  
    cout << result.str();
    return 0;
}
