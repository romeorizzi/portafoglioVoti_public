
#include "ourLibToPlay.h"


void scambia(long int *x, long int *y){ 

long int temp;

temp=*x; 
*x = *y; 
*y = temp;

}



  long int  biglia[100000];
  long int  pos_biglia[100000];






int insert(long int da_inserire,long int lower,long int upper){ 
    

    long int middle;
 
    long int center;


    long int i;


if( upper == lower ) return da_inserire;

if( ( upper-lower ) + 1 < 3){

        middle = bigliaIntermedia( biglia[lower], biglia[da_inserire], biglia[upper] );
   
         if(biglia[lower] == middle){

            for(i = da_inserire;i>lower;--i)scambia(&biglia[i], &biglia[i-1]);
            da_inserire = lower;
        }

        else 
        {
        
            if(biglia[da_inserire] == middle)
            {
                scambia( &biglia[da_inserire], &biglia[upper] );
                da_inserire=upper;
         
            }

        }

    return da_inserire;

    }

    else
    {
        middle = bigliaIntermedia( biglia[lower], biglia[da_inserire], biglia[upper]); 
       
        if(biglia[lower]==middle){
            for(i=da_inserire;i>lower;--i)  scambia(&biglia[i], &biglia[i-1]);


            da_inserire=lower;

        }
        else
        {

        if(biglia[ da_inserire ] == middle){
            center = (upper+lower)/2 + (upper+lower)%2 +1; 
           

            da_inserire=insert(da_inserire,center,upper);



            if(da_inserire==center)
            {
                insert(da_inserire,lower,center-1);
            }
        }


        } 
    return da_inserire;
    }
}










void ordina(long int n) {
  //long int  biglia[n];
  long int i;
  biglia[0]=0;
  pos_biglia[0]=0;
  biglia[1]=1;
  pos_biglia[1]=1;
  for(i = 2	; i < n; i++){
        biglia[i] = i;
        pos_biglia[i]=i;
        insert(i,0,i-1);    
  }
 
  consegnaBiglieInOrdine(biglia);
}


