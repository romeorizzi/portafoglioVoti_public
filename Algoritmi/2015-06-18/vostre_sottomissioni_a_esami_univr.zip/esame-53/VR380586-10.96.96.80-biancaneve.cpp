# include <iostream>  
# include <vector>

using namespace std;
vector<int> nani;
int num_nani;
int num_richieste;

struct richiesta{
    richiesta() {
        operazione=0;
        primo=0;
        secondo=0;
    }
    int operazione;
    int primo;
    int secondo;
};

    vector<richiesta> richieste;
    vector<string> risultati;

void scambia(int primo, int secondo);
void controlla(int primo, int secondo);


int main() {
    
    cin>>num_nani;
    cin>>num_richieste;
    
    int i=0;
    int elemento=0;  

    for(;i<num_nani;i++){
        cin>>elemento;
        nani.push_back(elemento);
    }
    
    richieste.assign(num_richieste, richiesta());

    int op;
    int pr,sec;
    for(i=0;i<num_richieste;i++){
        cin>>op;
        cin>>pr;
        cin>>sec;
        richieste[i].operazione=op;
        richieste[i].primo=pr;
        richieste[i].secondo=sec;
    }
    for(i=0;i<num_richieste;i++){
        if(richieste[i].operazione==1){
            scambia(richieste[i].primo, richieste[i].secondo);
            
        }
        else {
                controlla(richieste[i].primo, richieste[i].secondo);
            }
}

for(i=0;i<risultati.size();i++)
                cout<<risultati[i]<<"\n";
        
  return 0;
}
void scambia(int primo, int secondo){
    int temporaneo=nani[primo-1];
    nani[primo-1]=nani[secondo-1];
    nani[secondo-1]=temporaneo;
}

void controlla(int primo, int secondo){
    int i=0;  
    int contatore=secondo-primo+1;
    bool trovato=false;
    int somma=0;
    int j=0;
    for(i=primo;i<=secondo;i++){
        somma+=i;
}
    if(primo==1 && secondo==num_nani){
        risultati.push_back("YES");
    }

    else{
        for(i=0;i<num_nani;i++){

            if(nani[i]>= primo && nani[i]<= secondo){
                j=i;
                break;
            }
        }   
        for(int k=0;k<contatore;k++,j++)
             somma=somma-nani[j];
        if(somma!=0)
            risultati.push_back("NO");
        else
            risultati.push_back("YES");
    }
}
