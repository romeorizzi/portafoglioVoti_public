#define NDEBUG
#include<cassert>
#include<fstream>
#include<iostream>
#include <stdlib.h>

using namespace std;

int main() {
ofstream fout;
fout.open("output.txt"); assert( fout );

fout << 8 << endl;

	fout.close();
    return 0;
}
