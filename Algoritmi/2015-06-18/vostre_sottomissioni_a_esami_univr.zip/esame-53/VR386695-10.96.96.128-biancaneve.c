#include <stdio.h>

int N,M; // N numero nani, M numero richieste di Biancaneve

int main(){

    int i,j;

    scanf("%d %d", &N, &M);
    int nani[N];


    for(i=0; i<N; i++){
        scanf("%d", &nani[i]);
    }

    for(j=0; j<M; j++){
        int comando; //comando attuale, 1 o 2
        int n1, n2; //x e y se 1, a e b se 2

        scanf("%d %d %d", &comando, &n1, &n2);
        
        if (comando == 1) {
            // il -1 è perché b vede i nani da 1 a n, mentre noi da 0 a n-1
            int temp = nani[n1-1];
            nani[n1-1]=nani[n2-1];
            nani[n2-1]=temp;

        }

        else if (comando ==2) {
            int k,l;
            int ok = 1; // 1 se YES, 0 se NO

            for(k=0; k<N; k++){

                if(nani[k]>=n1 && nani[k]<=n2){
                    int diff = ((n2-n1)+1);
                    int min = diff >= N? N: diff;

                    for(l=1; l<min; l++){
                        if(nani[l+k]<n1 || nani[l+k]>n2) {ok=0; break;}
                    }
                break;
                }
            }

            if(ok==0) printf("NO\n");
            else printf("YES\n");
        }

        else printf("Errore, il comando può essere 1 o 2");
    }

return 0;

}

