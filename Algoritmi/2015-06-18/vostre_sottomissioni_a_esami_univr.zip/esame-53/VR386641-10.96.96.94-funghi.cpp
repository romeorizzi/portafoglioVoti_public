#include <stdio.h>
#include <vector>

using namespace std;
int num_funghi;
int maxx=0;
vector<int> bosco;

void calcola () {
bool null=false;
    if(bosco.size() % 2 ==0){
        for(int i=0; i<(num_funghi/2); i++){
            //c'è un valore diverso da -1
            if(bosco[i]!=-1 && bosco[i] != i){
                    null=true;
                    break;
            } 
            if(null!=true)   
                if(bosco[num_funghi-i-1]!=-1 && bosco[num_funghi-i-1] != i){
                        null=true;
                        break;
                } 
            if(null==true)
                break;   
        }
    }   
    else{            
        if( (bosco[(num_funghi/2)]!=-1) && (bosco[(num_funghi/2)] != (num_funghi/2)) )
            null=true;
        else{
            for(int i=0; i<(num_funghi/2); i++){
                //c'è un valore diverso da -1
                if(bosco[i]!=-1 && bosco[i] != i){
                        null=true;
                        break;
                }    
                if(bosco[num_funghi-i-1]!=-1 && bosco[num_funghi-i-1] != i){
                        null=true;
                        break;
                }
                if(null==true)
                    break;    
            }
        } 
    } 

    //tutto ok
    if(null==false)
        printf("%d\n", maxx+1);
    else
        printf("0\n");
};

int main(void) {

    int par=scanf("%d", &num_funghi);
    
    bosco.assign(num_funghi,0);
    
    for(int i=0; i<num_funghi; i++){
        par=scanf("%d", &bosco[i]);
    }

    if(bosco.size() % 2 ==0)
        maxx = (int)(bosco.size()/2)-1;
    else
        maxx = (int)bosco.size()/2;

    calcola();

	return 0;
}
