#include <iostream>
#include <stdio.h>
#include <fstream>

using namespace std;

const int MAX_N=200000;
const int MAX_M=200000;
int n,m;
int posnani[MAX_N];
//int nere[MAX_N];
//int richieste[MAX_M];
int tipo[MAX_M],param1[MAX_M],param2[MAX_M];
int cons=0;
int temp;

int main()
{
    //lego da file nr nani e nr richieste
    ifstream in("input.txt");
    in>>n>>m;

    for(int i=1;i<=n;i++)
        in>>posnani[i];
//lego sempre da file tutte le richieste
        for(int j=1;j<=m;j++)
            in>>tipo[j]>>param1[j]>>param2[j];

    for(int j=1;j<=m;j++)
     {
        if(tipo[j]==2) {
                          for(int i=1;i<=n;i++)
                            for(int k=param1[j];k<=param2[j];k++)
                                if(posnani[i]==k && (n-i)>(param2[j]-param1[j])) cout<<"NO";
                          cout<<endl;
                          for(int i=1;i<=n;i++)
                            for(int k=param1[j];k<=param2[j];k++)
                          if(posnani[i]==k && (n-i)<(param2[j]-param1[j])) cons++;
                          if(cons/n==1) cout<<"YES";
        }
        if(tipo[j]==1) { temp=posnani[param1[j]];
                         posnani[param1[j]]=posnani[param2[j]];
                         posnani[param2[j]]=temp;
                                }


      }


    return 0;
}

