#include <stdio.h>
#include <stdlib.h>
#include "ourLibToPlay.h"

long int* biglie;

void invert(long int b1, long int b2)
{
	long int temp = biglie[b1];
	biglie[b1] = biglie[b2];
	biglie[b2] = temp;
}

int resolve(long int start, long int end)
{
	if(end - start < 2)
		return 0;
	
	int flag = 0;
	int modified;
	
	long int middle = start + (end-start)/2;
	
	do
	{
		modified = 0;
		long int intermedia = bigliaIntermedia(start, middle, end);
		if(intermedia == start)
		{
			invert(start, middle);
			flag  = 1;
		}
		else if(intermedia == end)
		{
			invert(middle, end);
			flag  = 1;
		}
		
		int f1 = resolve(start, middle);
		int f2 = resolve(middle, end);
		modified = f1 || f2;
				
	}while(modified);
	
	return flag;
}

void ordina(long int n)
{
	long int i;
	biglie = (long int*) malloc(n*sizeof(long int));
	for(i=0; i<n; i++)
	{
		biglie[i] = i;
	}

	resolve(0, n-1);
	resolve(0, n-1);
	resolve(0, n-1);
	
	consegnaBiglieInOrdine(biglie);
}
