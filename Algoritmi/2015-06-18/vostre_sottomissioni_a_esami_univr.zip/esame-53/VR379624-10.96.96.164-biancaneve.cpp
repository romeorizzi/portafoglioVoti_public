#include <iostream>
#include <cassert>
#include <stdlib.h>
#include <sstream>

using namespace std;

const int MAX_N = 200000;
const int MAX_M = 200000;


int n,m; //n: nani -  m: richieste
int *nani; //posizione dei nani
int **command; //comandi

//comando 1 x y swap
void command1(int x, int y){
    int tmp = nani[x];
    nani[x] = nani[y];
    nani[y] = tmp;

    return;
}

//comando 2 a b
bool command2(int a, int b){
    assert(a<=b);
    if(a==0 && b == n-1)
        return true;
    /* trovo i nani dell'altezza giusta*/
    int *nani_ok=(int *)calloc(n, sizeof(int));
    for(int i=0; i<n;i++){
        if(nani[i]>=a && nani[i]<=b){
            nani_ok[i]++;
        }
    }

    int init=0, tot_nani=0;
    int spazio=b-a;
    /*cerco intrusi*/
    for(int i=0; i<n; i++){
        if(init == 1 && tot_nani<=spazio && nani_ok[i]==0)
            return false;
        else if(tot_nani==spazio)
            break;
        else if(nani_ok[i]==1){
            tot_nani++;
            init=1;
        }
    }
    return true;
}

void check_2(int a, int b){
    if(command2(a,b))
        cout << "YES" << endl;
    else
        cout << "NO" << endl;
    return;
}

int main(){


    cout << "Insert n and m: ";
    cin >> n >> m; assert( n >= 2 && n <= MAX_N); assert(m >= 2 && m <= MAX_M );

    //riga di n per i nani per le pos
    cout << "insert n nani sep da \" \": ";

    nani = (int *)calloc(n, sizeof(int));

    string str="";
    getline(cin, str);
    stringstream ssr(str);
    int i=0;
    while(ssr >> nani[i])
        i++;

    cout << "insert c X Y: ";
    int a,b,c;
    for(int i = 0; i < m; i++){
        cin >> a >> b >> c; assert(a==1 || a==2);


        if(a==1)
            command1(b-1, c-1);
        else
            check_2(b-1, c-1);
    }


    return 0;
}
