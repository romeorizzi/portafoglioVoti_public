
// creare vettore leggendo da input
// creare altro vettore dove riordino le altezze

// implementare funzione che mi trova massimo e minimo in un sottovettore
// implementare funzione che mi esegue il comando 1
// implementare funzione che mi esegue il comando 2

#include <stdio.h>
#include <fstream>
#include <iostream>
#include <sstream>

#define IFILE "input.txt"
#define OFILE "output.txt"

inline int comando2(int vettore2[],int A, int B){
//trovare max e min del sottovettore di vettore2 che va da A a b

    int max=-1;
    int min=10000;
    int somma=0;


    for(int i=A;i<=B;i++){
        if(vettore2[i]>max){
            max=vettore2[i];
        }
        if(vettore2[i]<min){
            min=vettore2[i];
        }
        somma+=vettore2[i];
    }

//    printf("min = %d\n",min);
//    printf("max = %d\n",max);
//    printf("somma = %d\n",somma);

    int z=(max*(max+1))/2;
    int w=(min*(min-1))/2;
    int sommaConfronto=z-w;

//    printf("z = %d\n",z);
//    printf("w = %d\n",w);
//    printf("sommaConfronto = %d\n",sommaConfronto);

    if((sommaConfronto == somma)){
        return 1;
    }else{
        return 0;
    }


}



inline void comando1(int vettore1[],int vettore2[],int X,int Y){

    int elemento1=vettore1[X];
    int elemento2=vettore1[Y];

    int tmp=0;

    tmp=vettore2[elemento1];
    vettore2[elemento1]=vettore2[elemento2];
    vettore2[elemento2]=tmp;

    tmp=vettore1[X];
    vettore1[X]=vettore1[Y];
    vettore1[Y]=tmp;

}


int main(){


    // numero nani
    int n=0;
    // numero richieste
    int m=0;

//    std::ifstream infile(IFILE);
//    std::ofstream out(OFILE);

    //infile >> n;
    //infile >> m;
    std::cin >> n;
    std::cin >> m;

    int vettore1[n];
    int vettore2[n];

    int s,comando,A,B;

    for (int i = 1; i <= n; i++) {
        //infile >> s;
        std::cin >> s;

        vettore1[i]=s;
        vettore2[s]=i;
    }


    for (int i = 0; i < m; i++) {
//        infile >> comando;
//        infile >> A;
//        infile >> B;
        std::cin >> comando;
        std::cin >> A;
        std::cin >> B;

        if(comando==1){
            comando1(vettore1,vettore2,A,B);
        }else{

            if(comando2(vettore2,A,B)==1){
                std::cout << "YES\n";
                //out << "YES\n";
            }else{
                std::cout << "NO\n";
                //out << "NO\n";
            }
        }

    }


//        out.close();
//    infile.close();


    return 0;
}
