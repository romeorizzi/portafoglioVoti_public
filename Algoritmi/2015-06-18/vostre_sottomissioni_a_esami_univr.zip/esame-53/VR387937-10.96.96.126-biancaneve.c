#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#define maxn 200000
#define maxm 200000

int n,m,nani[maxn],query[maxm][3];

int max(int a, int b)
{
    if(a>b) return a;
    else return b;
}

int min(int a, int b)
{
    if(a>b) return b;
    else return a;
}

void esegui(int r, int a, int b)
{
    int i,j,temp,c=0;

    if(r==1 && a!=b)
    {
        temp = nani[a-1];
        nani[a-1] = nani[b-1];
        nani[b-1] = temp;
    }
    else
    {
        c=0;
        i=0;
        while(nani[i]<a || nani[i]>b) i++;
        for(j=i;j<i+b-a;j++)
        {
            if(nani[j+1]<a || nani[j+1]>b)
            {
                c++;
                break;
            }
        }
        if(c==0) fprintf(stdout,"YES\n");
        else fprintf(stdout,"NO\n");
    }
}

void input()
{
    int i, r, a, b;
    assert(fscanf(stdin,"%d %d",&n,&m));
    for(i=0;i<n;i++)
    {
        assert(fscanf(stdin,"%d",&nani[i]));
    }
    for(i=0;i<m;i++)
    {
        assert(fscanf(stdin,"%d %d %d",&r,&a,&b));
        query[i][0]=r;
        query[i][1]=a;
        query[i][2]=b;
    }
}

int main()
{
    int i, r, a, b;
    input();
    for(i=0;i<m;i++)
    {
        r=query[i][0];
        a=query[i][1];
        b=query[i][2];
        esegui(r,min(a,b),max(a,b));
    }
    return 0;
}
