#define NDEBUG   // NDEBUG definita nella versione che consegno
#include <cassert>
#include <vector>
#include <iostream>  // uso di cin e cout non consentito in versione finale

#include <fstream>
#include <algorithm>

using namespace std;

const int MAX_N= 200000, MAX_M = 200000;
int n_nani = 0, n_comandi = 0;
int nani[MAX_N];
int comandi[MAX_M][3];	

// ritorna 1 se l'intervallo non è contiguo 0 altrimenti
int ricerca_nel_intervallo(int a, int b){
        int contiguo = 0;
int diff = b -a +1;
        for(int i = 1; i < n_nani + 1; i++){
            if((nani[i] >= a && nani[i] <= b) && diff > 0){
                 if(contiguo == 1){
                    diff --;                   
                 }
                 if(contiguo == 0){
                    contiguo = 1;
                    diff --;
                 }  
        
            }else{ if(contiguo == 1 && diff != 0)
                    return 1;
            }    
        }
        return 0;
}

int main(){ 

    cin >> n_nani >> n_comandi;
    for(int i=1; i < n_nani+1 ; i++){
        cin >> nani[i];
    }
   
    for(int i=0; i < n_comandi; i++){
        for(int l = 0; l < 3; l++){
           cin >> comandi[i][l];
        }
    }
   
    int val_nano;
    for(int i=0; i < n_comandi ; i++){
        switch(comandi[i][0]){
            case 1:
                    val_nano = nani[comandi[i][2]];
                    nani[comandi[i][2]] = nani[comandi[i][1]];
                    nani[comandi[i][1]]= val_nano;
            break;
            case 2:
                    if(ricerca_nel_intervallo(comandi[i][1],comandi[i][2]) == 0)
                       cout<< "YES" << endl;
                    else
                       cout << "NO" << endl;
            break;
            default:
            break;   
        }
    }

}

