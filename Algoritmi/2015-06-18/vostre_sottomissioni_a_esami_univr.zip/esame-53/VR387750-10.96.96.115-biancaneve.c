#include <stdio.h>
#include <stdlib.h>

typedef struct _nano {
	int valore;
	int presente;
} nano;

FILE* fi;
FILE* fo;
void check_intervallo(nano *nani, int nnani, int from, int to);
void scambia(nano *vett, int a, int b);

int main(void) {

	fi= fopen("input.txt", "r");
	fo = fopen("output.txt", "w");
	int nnani, nrichieste, i, tipo, op1, op2, j;
	fscanf(fi, "%d", &nnani);
	fscanf(fi, "%d", &nrichieste);
	nano nani[nnani];
	
	for (i=0; i<nnani; i++) {
		fscanf(fi, "%d", &nani[i].valore);
		nani[i].presente = 0;
	}
	
	for (i=0; i<nrichieste; i++) {
		fscanf(fi, "%d", &tipo);
		fscanf(fi, "%d", &op1);
		fscanf(fi, "%d", &op2);
		if(tipo == 1) {
			scambia(&nani, op1, op2);
			//printf("New array now is: \n");
			//for(j=0; j<nnani; j++)
			//	printf("%d ", nani[j].valore);	
			//printf("\n");
		}
		if(tipo == 2)
			check_intervallo(&nani, nnani, op1, op2);
	}
	fclose(fi);
	fclose(fo);
	return 0;
}

void check_intervallo(nano *nani, int nnani, int from, int to) {
	
	int i, t;
	int ok = 1;
	int cercati = to - from + 1;
	int nextDevono = 0;	 //per garantire la contiguità
	
	
	for(i=0; i<nnani; i++) {
		if(nani[i].valore >=from && nani[i].valore <=to) //il nano è coinvolto
			nani[i].presente = 1;
		else
			nani[i].presente = -1;
	}
	
	for(i=0; i<nnani; i++) {
		if(nani[i].presente == 1) {
			cercati--;
			if(nextDevono == 0)
				nextDevono = 1;
		}
		else {
			if(nextDevono == 1 && cercati >0) {
				fprintf(fo, "NO\n");
				ok = 0;
				break;
			}
		}
	}
	if(ok == 1)
		fprintf(fo, "YES\n");
	
}

void scambia(nano *vett, int a, int b) {
	int temp = vett[a-1].valore;
	int temp2 = vett[a-1].presente;
	vett[a-1].valore = vett[b-1].valore;
	vett[a-1].presente = vett[b-1].presente;
	vett[b-1].valore = temp;
	vett[b-1].presente = temp2;
}

