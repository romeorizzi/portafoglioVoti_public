#define NDEBUG
#include<cassert>
#include<fstream>
#include<iostream>
#include <stdlib.h>
#include<limits.h>

using namespace std;

ofstream fout;

int n_nani;
int m_richieste;
int * nani;
int * nani_trovati;

#ifndef NDEBUG
void stampa_array(int * array, int dim){
    for(int i=0; i<dim; i++)
        cout << array[i] << " ";
    cout << endl;
    return;
}
#endif


void scambia_nani(int *nani, int posx, int posy){
    int tmp = nani[posx];
    nani[posx] = nani[posy];
    nani[posy] = tmp;

    return;
}

void verifica_nani(int *nani, int posa, int posb){
    int num_nani_da_trovare = posb-posa+1;
    int num_nani_trovati = 0;
    int nano_piu_piccolo = INT_MAX;

    nani_trovati = (int *) calloc (sizeof(int), n_nani+1);

    //mi segno i nani trovati
    for(int i = posa; i<=posb; i++){
        nani_trovati[nani[i]] = 1;
        num_nani_trovati++;
        if (nani[i] < nano_piu_piccolo)
            nano_piu_piccolo = nani[i];
    }

    //controllo che ci siano "num_nani_da_trovare" nani contigui
    for(int i = nano_piu_piccolo; i < nano_piu_piccolo+num_nani_da_trovare; i++){
        if(nani_trovati[i] == 0){
            cout << "NO"<< endl;
            return;
        }
    }

    if(num_nani_da_trovare > num_nani_trovati){
        cout << "NO"<< endl;
        return;
    }

    cout << "YES" << endl;
    free(nani_trovati);
}


int main() {
    int tipo_richiesta = 0;
    int a,b;
    ifstream fin;
    fin.open("input.txt"); assert( fin );
    fin >> n_nani;
    fin >> m_richieste;


    nani = (int *) calloc(sizeof(int), n_nani+1);

#ifndef NDEBUG
    cout << "n: " << n_nani << "  m: " << m_richieste << endl;
#endif

    //FILE lettura posizione nani
    for(int i = 1; i <= n_nani; i++){
        fin >> nani[i];
    }

#ifndef NDEBUG
    stampa_array(nani, n_nani);
#endif

    for(int i=0; i<m_richieste; i++){

#ifndef NDEBUG
        cout << "i: " << i << "\tm_richieste: " << m_richieste << endl;
#endif
        fin >> tipo_richiesta;
        fin >> a;
        fin >> b;
        if (tipo_richiesta == 1)
            scambia_nani(nani,a,b);
        if (tipo_richiesta == 2)
            verifica_nani(nani, a, b);
    }




    fin.close();

    // FREEEEEEEEEE MEMORY
    return 0;
}
