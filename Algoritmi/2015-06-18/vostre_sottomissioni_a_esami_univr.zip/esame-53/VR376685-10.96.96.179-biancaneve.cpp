#define NDEBUG
#include<cassert>
#include<fstream>
#include<iostream>
#include <stdlib.h>
#include<limits.h>

using namespace std;

ofstream fout;

int n_nani;
int m_richieste;
int * nani;
int * nani_trovati;

#ifndef NDEBUG
void stampa_array(int * array, int dim){
    assert(array[0] == 0);
    for(int i=1; i<=dim; i++)
        cout << array[i] << " ";
    cout << endl;
    return;
}
#endif


void scambia_nani(int *nani, int posx, int posy){
    int tmp = nani[posx];
    nani[posx] = nani[posy];
    nani[posy] = tmp;

    return;
}

void verifica_nani_old(int *nani, int h_min, int h_max){
    int num_nani_da_trovare = h_max-h_min+1;
    int num_nani_trovati = 0;
    int pos_nano_piu_piccolo = INT_MAX;

    nani_trovati = (int *) calloc (sizeof(int), n_nani+1);

    //mi segno i nani trovati
    for(int i = 1; i<=n_nani; i++){
        if(nani[i] >= h_min && nani[i] <= h_max){
            nani_trovati[i] = 1;
            num_nani_trovati++;
            if(i < pos_nano_piu_piccolo)
                pos_nano_piu_piccolo = i;
        }
    }



#ifndef NDEBUG
    cout << "    " << "h_min:"<<h_min<< " h_max:"<< h_max << "  ";
    stampa_array(nani_trovati,n_nani);
#endif




    //controllo che ci siano "num_nani_da_trovare" nani contigui
#ifndef NDEBUG
    cout << "     devo trovare " << num_nani_da_trovare << " nani" << endl;
#endif

    for(int i = 0; i < pos_nano_piu_piccolo+num_nani_da_trovare; i++){
        if(nani_trovati[pos_nano_piu_piccolo + i] == 0){
#ifndef NDEBUG
            cout << "      uscita posizione:" << i << " ";
#endif
            cout << "NO"<< endl;
            return;
        }
    }

    if(num_nani_da_trovare > num_nani_trovati){
        cout << "NO"<< endl;
        return;
    }

    cout << "YES" << endl;
    free(nani_trovati);
}






void verifica_nani_old2(int *nani, int h_min, int h_max){
    nani_trovati = (int *) calloc (sizeof(int), n_nani+1);
    int num_nani_trovati = 0;
    int num_nani_da_trovare = h_max - h_min +1;

    for(int i = 1; i <= n_nani; i++){
        // se il nano e' tra le altezze che voglio
        if(nani[i] >= h_min && nani[i] <= h_max){
            nani_trovati[i] = 1;
        }
    }

    //controllo che i nani siano contigui
    int serie_iniziata = 0;

    for(int i = 1; i <= n_nani; i++){
        if(nani_trovati[i] == 1){
            serie_iniziata = 1;
            num_nani_trovati++;
        }

        if(num_nani_trovati == num_nani_da_trovare){
            break;
        }

        if(serie_iniziata == 1 && num_nani_trovati <= num_nani_da_trovare && nani_trovati[i] == 0){
            cout << "NO" << "\n";
            free(nani_trovati);
            return;
        }


    }



    cout << "YES\n";
    free(nani_trovati);
    return;
}








void verifica_nani(int *nani, int h_min, int h_max){
    nani_trovati = (int *) calloc (sizeof(int), n_nani+1);
    int num_nani_trovati = 0;
    int num_nani_da_trovare = h_max - h_min +1;
    int indice_nano_iniziale = INT_MAX;

    for(int i = 1; i <= n_nani; i++){
        // se il nano e' tra le altezze che voglio
        if(nani[i] >= h_min && nani[i] <= h_max){
            nani_trovati[i] = 1;

            if(indice_nano_iniziale > i)
                indice_nano_iniziale = i;
        }
    }

    //controllo che i nani siano contigui
    int serie_iniziata = 0;

    for(int i = indice_nano_iniziale; i <= indice_nano_iniziale + num_nani_da_trovare -1; i++){
        if(nani_trovati[i] == 1){
            serie_iniziata = 1;
            num_nani_trovati++;
        }

        if(num_nani_trovati == num_nani_da_trovare){
            break;
        }

        // serie rotta
        if(nani_trovati[i] == 0 && num_nani_trovati <= num_nani_da_trovare && serie_iniziata == 1){
            cout << "NO" << "\n";
            free(nani_trovati);
            return;
        }


    }



    cout << "YES\n";
    free(nani_trovati);
    return;
}





int main() {
    int tipo_richiesta = 0;
    int a,b;
    ifstream fin;
    /*
     fin.open("input.txt"); assert( fin );
    fin >> n_nani;
    fin >> m_richieste;
    */
    cin >> n_nani;
    cin >> m_richieste;

    nani = (int *) calloc(sizeof(int), n_nani+1);

#ifndef NDEBUG
    //cout << "n: " << n_nani << "  m: " << m_richieste << endl;
#endif

    //lettura posizione nani
    for(int i = 1; i <= n_nani; i++){
        // fin >> nani[i];
        cin >> nani[i];
    }

#ifndef NDEBUG
    //stampa_array(nani, n_nani);
#endif

    for(int i=0; i<m_richieste; i++){

#ifndef NDEBUG
        //cout <<"\tm_richieste: " << m_richieste << endl;
#endif
        /*
        fin >> tipo_richiesta;
        fin >> a;
        fin >> b;
       */
        cin >> tipo_richiesta;
        cin >> a;
        cin >> b;
        if (tipo_richiesta == 1)
            scambia_nani(nani,a,b);
        else if (tipo_richiesta == 2){
            //cout << "entro in verifica nani" << endl;
            verifica_nani(nani, a, b);
            //cout << "esco da verifica nani\n" << endl;
        }

#ifndef NDEBUG
        //cout << "    i: " << i << "    richiesta:" << tipo_richiesta << "  a:" << a << "  b:" << b << "\t\t";
        //stampa_array(nani, n_nani);
#endif
    }




    //fin.close();

    free(nani);
    // FREEEEEEEEEE MEMORY
    return 0;
}
