#include "ourLibToPlay.h"

int inserire(long int ins,long int inferiore,long int superiore);	
void my_swap(long int *a, long int *b); 


long int  biglia_in_pos[100000];
long int  pos_biglia[100000];


void ordina(long int n) {
  
  long int i;
  biglia_in_pos[0]=0;
  pos_biglia[0]=0;
  biglia_in_pos[1]=1;
  pos_biglia[1]=1;
  for(i = 2	; i < n; i++){
        biglia_in_pos[i] = i;
        pos_biglia[i]=i;
        inserire(i,0,i-1);    
  }
 
  consegnaBiglieInOrdine(biglia_in_pos);
}




int inserire(long int ins,long int inferiore,long int superiore){
    long int intermedio;
    long int i;
      long int center;
    if(superiore==inferiore)
        return ins;
    if((superiore-inferiore)+1<3){
        intermedio = bigliaIntermedia( biglia_in_pos[inferiore], biglia_in_pos[ins], biglia_in_pos[superiore]);

         if(biglia_in_pos[inferiore]==intermedio){
            for(i=ins;i>inferiore;--i)
                   my_swap(&biglia_in_pos[i], &biglia_in_pos[i-1]);
                   ins=inferiore;
        }else if(biglia_in_pos[ins]==intermedio){
                   my_swap( &biglia_in_pos[ins], &biglia_in_pos[superiore] );
                   ins=superiore;
      
    }

    return ins;
    }else{
        intermedio = bigliaIntermedia( biglia_in_pos[inferiore], biglia_in_pos[ins], biglia_in_pos[superiore]); 
       
        if(biglia_in_pos[inferiore]==intermedio){
            for(i=ins;i>inferiore;--i)
                  my_swap(&biglia_in_pos[i], &biglia_in_pos[i-1]);
                  ins=inferiore;
        }else if(biglia_in_pos[ins]==intermedio){
                  center=(superiore+inferiore)/2+(superiore+inferiore)%2; 
                  ins=inserire(ins,center,superiore);
            if(ins==center){
                  inserire(ins,inferiore,center-1);
            }
        }
    return ins;
    }
}



void my_swap(long int *a, long int *b)
{
 long int tmp; 
 tmp= *a; 
 *a = *b; 
 *b = tmp; 
}
