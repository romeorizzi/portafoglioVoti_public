#include "ourLibToPlay.h"

inline void scambia(long int *a, long int *b) { long int tmp = *a; *a = *b; *b = tmp; }
long int  pos_biglia[100000];
long int  pos_biglia[100000];
int insert_into(long int da_ins,long int inf,long int sup);	

void ordina(long int n) {
    long int i;
    pos_biglia[0]=0;
    pos_biglia[1]=1;
    for(i = 2	; i < n; i++){
            pos_biglia[i] = i;
            insert_into(i, 0, i-1);    
    }
    consegnaBiglieInOrdine(pos_biglia);
}

int insert_into(long int da_ins,long int inf,long int sup){ 
    long int intermedia,i;
    long int centro;
    if(sup==inf)    
        return da_ins;
    if((sup-inf)+1 < 3){ 
            intermedia = bigliaIntermedia( pos_biglia[inf], pos_biglia[da_ins], pos_biglia[sup]);
            if(pos_biglia[inf]==intermedia){
                for(i=da_ins;i>inf;--i)
                    scambia(&pos_biglia[i], &pos_biglia[i-1]);
                da_ins=inf;
            }else if(pos_biglia[da_ins]==intermedia){
                scambia( &pos_biglia[da_ins], &pos_biglia[sup] );
                da_ins = sup;
    }
    return da_ins;
    }else{
        intermedia = bigliaIntermedia( pos_biglia[inf], pos_biglia[da_ins], pos_biglia[sup]); 
       
        if(pos_biglia[inf] == intermedia){
            for(i=da_ins;i>inf;--i) scambia(&pos_biglia[i], &pos_biglia[i-1]);
            da_ins=inf;
        }else if(pos_biglia[da_ins] == intermedia){
            centro=(sup+inf)/2+(sup+inf)%2; 
            da_ins = insert_into(da_ins,centro,sup);
            if(da_ins == centro){
                insert_into(da_ins, inf , centro-1);
            }
        }
    return da_ins;
   }
}
