// problem: ordina_x, example solver format, Romeo Rizzi Mar 2015
#include "ourLibToPlay.h"

#define MAX_BIGLIE 100000

inline void myswap(long int *a, long int *b) { long int tmp = *a; *a = *b; *b = tmp; }

long int  biglia_in_pos[MAX_BIGLIE];
long int  posizione_biglia[MAX_BIGLIE];

int inserisci(long int elem, long int inf, long int sup){

    long int intermedio;
    long int i;
    long int centro;

    if(sup == inf) return elem;

    if((sup-inf)+1 < 3) {

        intermedio = bigliaIntermedia(biglia_in_pos[inf], biglia_in_pos[elem], biglia_in_pos[sup]);
        if(biglia_in_pos[inf] == intermedio) {
            for(i = elem; i > inf; --i)
                myswap(&biglia_in_pos[i], &biglia_in_pos[i-1]);
            elem = inf;
        } else if(biglia_in_pos[elem] == intermedio) {
            myswap(&biglia_in_pos[elem], &biglia_in_pos[sup]);
            elem = sup;
        }
        return elem;

    } else {

        intermedio = bigliaIntermedia(biglia_in_pos[inf], biglia_in_pos[elem], biglia_in_pos[sup]);
        if(biglia_in_pos[inf] == intermedio){
            for(i = elem; i > inf; --i)
                myswap(&biglia_in_pos[i], &biglia_in_pos[i-1]);
            elem = inf;
        }else if(biglia_in_pos[elem] == intermedio){
            centro = (sup+inf)/2 + (sup+inf)%2;
            elem = inserisci(elem, centro, sup);
            if(elem == centro){
                inserisci(elem, inf, centro-1);
            }
        }
        return elem;

    }
}	

void ordina(long int n) {

    long int i;
    biglia_in_pos[0] = 0;
    posizione_biglia[0] = 0;
    biglia_in_pos[1] = 1;
    posizione_biglia[1] = 1;
    for(i = 2; i < n; i++){
        biglia_in_pos[i] = i;
        posizione_biglia[i] = i;
        inserisci(i, 0, i-1);    
  }

  consegnaBiglieInOrdine(biglia_in_pos);
}
