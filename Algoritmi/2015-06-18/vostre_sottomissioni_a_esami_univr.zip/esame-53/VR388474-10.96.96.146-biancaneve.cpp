#include <iostream>
#include <string>
#include <algorithm> 
#include <vector>
# include <stdio.h>
using namespace std;

inline void scambia(int *a, int *b){ 
int tmp;

  tmp= *a; 
  *a = *b; 
  *b = tmp; 

}
void check_percorso(int a,int b,std::vector<int> nani,std::vector<int> nani_position,int n_nani){
    int start=nani_position[a];
    int i=1;
    int j=1;
    while((nani_position[a]+i)<n_nani && nani[nani_position[a]+i]>a && nani[nani_position[a]+i]<=b){++i;}
    i--;

    while((nani_position[a]+i)>=0 && nani[nani_position[a]-j]>a && nani[nani_position[a]-j]<=b){++j;}

j--;
    if(i+j==b-a) cout <<"YES"<<endl;
    else
    cout <<"NO" << endl;
}



int main ()
{
  std::vector<int> nani;
  std::vector<int> nani_position;
  int n,n_comandi;
  int comando,a,b;
  cin >> n;
  cin >> n_comandi;
 // cout << n << " " << n_comandi << endl;
  nani.resize(n);
  nani_position.resize(n);
  for(int i=0; i<n;i++){
     cin >> nani[i];
     nani_position[nani[i]]=i; 
    }
 // for(int i=0;i<n;i++) cout << nani[i] << " " << endl;
  /*consideriamo i comandi*/
  for (int i=0; i<n_comandi;i++)
  {
  // recupero il comando i-esimo dal file
  cin >> comando;
  cin >> a;
  cin >> b;
  
    if(comando == 1 )
    {
    a=a-1;
    b=b-1;
      //esegui lo scambio

     scambia(&nani_position[nani[a]],&nani_position[nani[b]]);
     scambia(&nani[a], &nani[b] );

    //  for(int i=0;i<n;i++) cout << nani[i] << " ";
    //  cout <<  endl;
    }
    else
    {
      // funzione per il controllo se esiste il percorso tra il minimo e il massimo

      check_percorso(a,b,nani,nani_position,n);

    }

  }
  
  return 0;
}

