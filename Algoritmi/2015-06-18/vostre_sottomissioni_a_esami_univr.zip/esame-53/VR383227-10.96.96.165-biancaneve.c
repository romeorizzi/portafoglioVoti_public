#include <stdio.h>
#include <stdlib.h>

int nani_h[200000], nani_i[200000], somme[200000];

int main()
{
    int n, m, i, oper[3], tmp, op=0, h1, h2, min, max, result=1, sessione=1, h;

    //leggo numero nani e operazioni
    scanf("%d %d", &n, &m);

    /*printf("Nani = %d , Operazioni = %d\n", n, m);*/ /*DEBUG*/

    /*nani_h = malloc(n+1*sizeof(int)); // contiene ad ogni posizione le altezze di ogni nano
    nani_i = malloc(n+1*sizeof(int)); // contiene ad ogni posizione che rappresenta l'altezza, l'indice del nano corrispondente in nani_h
    somme = malloc(n+1*sizeof(int));
*/
    /*for(i=0; i<=n; i++)
        somme[i] = 0;*/

    //leggo altezze
    for(i = 1; i<=n; i++){
        scanf("%d", &nani_h[i]);
        h = nani_h[i];
        nani_i[h] = i;
    }

    /*DEBUG*/
    /*for(i = 1; i<=n; i++)
        printf("Nano %d: %d\n", i, nani_h[i]);
    for(i = 1; i<=n; i++)
        printf("Altezza %d: %d\n", i, nani_i[i]);*/

    //leggo le operazioni
    op = 0;
    while(op<m){
        scanf("%d %d %d", &oper[0], &oper[1], &oper[2]);
        if(oper[0] == 1){ //operazione di swap
            h1 = nani_h[oper[1]];
            h2 = nani_h[oper[2]];
            tmp = nani_h[oper[1]];
            nani_h[oper[1]] = nani_h[oper[2]];
            nani_h[oper[2]] = tmp;

            tmp = nani_i[h1];
            nani_i[h1] = nani_i[h2];
            nani_i[h2] = tmp;
        }
        if(oper[0] == 2){ //operazione di controllo altezze
            if(oper[1] == 1 && oper[2] == n) printf("YES\n");
            else if(oper[1] == oper[2]) printf("YES\n");
            else{
                min = n;
                max = 1;
                for(i=oper[1]; i<=oper[2]; i++){
                    somme[nani_i[i]] = sessione;
                    if(nani_i[i] < min) min = nani_i[i];
                    if(nani_i[i] > max) max = nani_i[i];
                }
                for(i=min; i<=max; i++){
                    if(somme[i] != sessione){
                        result = 0;
                        break;
                    }
                }
                /*DEBUG*/
                /*for(i = 1; i<=n; i++)
                    printf("%d ", somme[i]);
                printf("\n");*/

                if(result == 0) printf("NO\n");
                else printf("YES\n");

                result = 1;
                sessione++;
            }
        }

        /*DEBUG*/
        /*for(i = 1; i<=n; i++)
            printf("Nano %d: %d\n", i, nani_h[i]);
        for(i = 1; i<=n; i++)
            printf("Altezza %d: %d\n", i, nani_i[i]);*/

        op++;
    }


    return 0;
}
