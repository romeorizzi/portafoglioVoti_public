#include<iostream>
#include<stdlib.h>

using namespace std;

void pos_xy(int *nani, int x, int y){
    int tmp = nani[x-1];
    nani[x-1] = nani[y-1];
    nani[y-1] = tmp;
}

int check_contiguity(int *nani, int a, int b, int dim){

    int first = -1;
    int intervallo = b-a ;
    int j=0;
    while(first == -1){
        if(nani[j] >= a && nani[j] <= b){
            first = j;
        }
        j++;
     }


    intervallo = first + intervallo;
    for(int i = first+1 ; i <= intervallo; i++){

        if(nani[i] < a || nani[i] > b)
             return 0;

        }
    return 1;
    }


int main() {
    int n,m;
    int *nani;
    int **comandi;

    //cout <<"nani, numero comandi: ";
    cin >> n >> m;

    nani = (int*) malloc(n * sizeof(int));
    comandi = (int**) malloc(m * sizeof(int*));


    for(int i=0; i< m; i++){
        comandi[i] = (int*) malloc(3 * sizeof(int));
    }


    for(int i=0; i< n; i++){
        cin >> nani[i];
    }

    for(int i=0; i< m; i++){
        cin >> comandi[i][0] >> comandi[i][1] >> comandi[i][2];
    }


    //stampa nani
//    for(int i=0; i< n; i++){
 //       cout << nani[i] << " ";
  //  }
   // cout <<endl;

 //   for(int i=0; i< m; i++){
  //      cout << comandi[i][0] << " "<< comandi[i][1] <<" " << comandi[i][2] << endl;
   // }


    int check;
    for(int i=0; i < m; i++){

        if(comandi[i][0] ==1){

            pos_xy(nani, comandi[i][1], comandi[i][2]);

        }else{

            check = check_contiguity(nani,comandi[i][1], comandi[i][2], n);
            if(check)
                cout << "YES"<< endl;
            else
                cout << "NO"<< endl;
        }
    }






    free(nani);
    free(comandi);
return 0;
}
