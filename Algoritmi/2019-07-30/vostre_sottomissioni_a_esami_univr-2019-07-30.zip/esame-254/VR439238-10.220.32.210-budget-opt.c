#include <stdio.h>
#include <stdlib.h>

#define MAXVAL 1000000007

int N, B0, T, i, max=0, min=11, maxq=0, pos;

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d %d %d", &N, &B0, &T);
    int X[N];
    int Q[N];
    for(i=0; i<N; i++) {
        scanf("%d", &X[i]);
        //printf("%d\n", X[i]);
        min = (X[i] < min) ? X[i] : min;
        max = (X[i] > max) ? X[i] : max;
    }
    for(i=0; i<N; i++) {
        scanf("%d", &Q[i]);
        maxq = (Q[i]>maxq)?Q[i]:maxq;
        if(Q[i]>maxq) {
            maxq = Q[i];
            pos = i;
        }
    }

    if(T==1 && N==1) {
        printf("%d", B0*Q[0]);
    } else if(T==2 && N==1) {
        printf("%d", B0);
    }

    //printf("%d %d", max, min);

    if(max==0) {
        if(T==1) {
            printf("%d", maxq*B0);
        } else if(T==2) {
            for(i=0; i<N; i++) {
                if(i==pos-1) {
                    printf("%d ", B0);
                } else if(i == N-1) {
                    printf("%d", 0);
                } else {
                    printf("%d ", 0);
                }
            }
        }
    }

    

    return 0;
}