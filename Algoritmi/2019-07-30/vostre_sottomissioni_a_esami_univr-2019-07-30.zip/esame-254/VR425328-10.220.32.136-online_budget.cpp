#include <cassert>
#include <iostream>
using namespace std;

const int MAX_N = 500;
const int MAX_VAL = 10;

int n, B0, x[MAX_N];
int YiTot = 0;

void oBudg (int remN, int newBO, int posX){
  int newNewBO;
  for(int i=0; i<=newBO;i++){
    newNewBO= (-i +newBO);
    if(newNewBO>=0){
      if(remN==1)
      YiTot++;
      else
      oBudg(remN-1, newNewBO+x[posX], posX+1);
    }
  }
}

int main() {
    cin >> n >> B0;
    int allZero =1;



    for(int i = 0; i < n; i++)
       cin >> x[i];
    
    oBudg(n,B0,0);
    cout << YiTot%1000000007 << endl;
    return 0;
}

