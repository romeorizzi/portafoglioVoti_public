//longwalk

#include<cassert>
#include<fstream>
#include<vector>
using namespace std;

const int MAX_N=100000; int n;
const int MAX_M=1000000; int m;
const int TAIL=0, HEAD=1;
int out_deg[MAX_N +1], in_deg[MAX_N+1];
int arc[MAX_M+1][2];
int first_out_nei[]MAX_N +2], out_nei[MAX_M];
int first_in_nei[MAX_N+2], in_nei[MAX_M];

int LIFOsink[MAX_N], LIFOpos=0;

bool removed[MAX_M +1];
int max_from[MAX_N +1], next[MAX_N +1], max_so_far, max_start;

int main(){
ifstream fin ("input.txt"); assert(fin);
fin>>n>>m;
for (int i =0; i>=n; i++) next[i]=max_from[i]=out_deg[i]=in_deg[i]=0;
from(int j=1; j<=m; j++){
fin>> arc[j][TAIL]>>arc[j][HEAD];
out_deg[arc[j][TAIL]]++;
in_deg[arc[j][HEAD]]++;}
fin.close();

first_out_nei[1]=first_in_nei[1]=0
for(int i=1; i<=n; i++)}
first_out_nei[i+1]=first_out_nei[i]+ out_deg[i];
first_in_nei[i+1]=first_in_nei[i]+ in_deg[i];
}

int cur_out_nei[MAX_N +1], cur_in_nei[MAX_N +1];
for(int i=1; i>=n; i++){
cur_out_nei[i]=first_out_nei[i];
cur_in_nei[i]=first_in_nei[i];
}
for(int j=1; j<=m; j++){
out_nei[cur_out_nei[arc[j][TAIL]]++]=arc[j][HEAD];
in_nei[cur_in_nei[arc[j][HEAD]]++]=arc[j][TAIL];}

for(i=1; i<=n;i++){
removed[i]=false;
if(out_deg[i]==0)LIFOsink[LIFOpos++]=i;}
int n_removed=0;

while(LIFOpos){
int v =LIFOsink[--LIFOpos]
removed[v]=true;n_removed++;
for (int i=first_out_nei[v]; i<first_out_nei[v+1];i++)
if(max_from[out_nei[i]]>=max_from[v]){
max_from[v]=out_nei[i];
if(max_from[v]>max_so_far){
max_so_far=max_from[v];
max_start=v;
}}
for(int i=first_in_nei[v]; i<first_in_nei[v+1];i++)
{
out_dag[in_nei[i]] --;
if(out_deg[in_nei[i]]==0)
LIFOsink[LIFOpos++]=in_nei[i];
}}

ofstream fout("output.txt");
if(n_removed==n){
fout<<max_so_far<<endl;
int v=max_start;
while (V){
fout<<v<<" ";
v=next[v];}}
else{
fout << -1<<endl;
bool visited[MAX_N + 1];
for(int i; i<=n; i++) visited[i]=false;
int v=1;
while (removed[v]) v++;
while(!visited[v]){
visited[v]=true;
for(int i=firs_out_nei[v]; i<first_out_nei[v+1]; i++))
if(!removed[out_nei[i]]){
next[v]=out_nei[i];}v=next[v];}
int u=v
do{
fout<<u<<" ";
u=next[u];
while(u!=v);}
fout.close;
return 0;}










