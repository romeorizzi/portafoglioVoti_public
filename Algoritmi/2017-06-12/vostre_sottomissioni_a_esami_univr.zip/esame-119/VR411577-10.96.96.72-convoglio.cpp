#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iostream>
using namespace std;
const int MAX_N = 1000;
const int MAX_M = 2000;
bool matrix[MAX_N][MAX_N];
bool matrix_known[MAX_N][MAX_N];
int array_known[MAX_N];
bool matrix_result[MAX_N][MAX_N];
bool trovato;
std::ofstream out("output.txt");

void ricerca(int min_nave, bool* colonne_libere, int* sol_parziale, int max){
	//cout << "livello: "<<min_nave<<endl;
	/*if(matrix[min_nave][max-1])
		cout << "[X]"<<endl;
	else
		cout << "[ ]"<<endl;*/
	bool colonne[max];
	
	for(int i =0;i<max;i++){
		if(colonne_libere[i])
			colonne[i]=true;
		else
			colonne[i]=false;
	}
		
	
	cout << endl;
	if(min_nave == max-1){
		for(int i=0;i<max;i++){
			
			if(matrix[min_nave][i] && colonne_libere[i]){
				//cout << sol_parziale << min_nave << endl;
				//cout << endl;
				//cout << min_nave << " " << i<<endl;
				sol_parziale[min_nave]=i;
				/*for(int i =0;i<max;i++){
					if(colonne_libere[i])
						cout << "t";
					else
						cout << "f";
				}
				cout << endl;*/
			
				cout << "sol parziale:" << endl;
				for(int m=0;m<max;m++){
					cout << sol_parziale[m] << " ";
				}
				cout << endl;

				//bool uscita = false;
				//int k=0;
				//cout << sol_parziale[k]<<" ";
				/*
				while(k< max && !uscita){
				//for(int k = 0;k<max; k++){
					
					if(!matrix_known[k][sol_parziale[k]]){
						for(int s=0; s<max;s++){
							out << s << " " << sol_parziale[s] << endl;
						}
						//break;
						uscita = true;
					}
					k++;
				}*/
				//char* sol = min_nave << " " << i<<endl;
				bool diversi = false;
				for(int r=0;r<max;r++){
					if(array_known[r] != sol_parziale[r]){
						diversi = true;
						cout << array_known[r] <<"!="<< sol_parziale[r]<<endl;
					}
					else{
						cout << array_known[r] <<"=="<< sol_parziale[r]<<endl;
					}
					if(r == max-1){
						if(diversi){
							for(int s=0; s<max;s++){
								out << s << " " << sol_parziale[s] << endl;
							}
							trovato = true;
						}
					}
					
				}
				/*
				if(array_known != sol_parziale){
					for(int s=0; s<max;s++){
						out << s << " " << sol_parziale[s] << endl;
					}
				}*/
			}
		}
	}
	else{
		for(int i=0;i<max;i++){
			if(matrix[min_nave][i] && colonne_libere[i]){
				cout << min_nave << " " << i<<endl;
				sol_parziale[min_nave]=i;
				colonne[i]=false;
				ricerca(min_nave+1,colonne, sol_parziale, max);
				for(int i =0;i<max;i++){
					if(colonne_libere[i])
						colonne[i]=true;
					else
						colonne[i]=false;
				}
			}
			//cout << "i = " << i <<", livello ="<< min_nave << endl ;
		}
	}
} 

int main(){
    std::ifstream in("input.txt");
    int N,M;
    in >> N;
    in >> M;

    //array = new int[M];
    int count = 0;
	int temp_m;
    for(int temp; in>> temp;){
		if(count % 2 == 0)
			temp_m = temp;
		else{
			matrix[temp_m][temp]= true;
			if(count<=2*N){
				matrix_known[temp_m][temp]= true;
				array_known[temp_m]=temp;
			}
			//cout << "["<<temp_m<<"]["<< temp<< "]" << endl;
			
		}
		count++;
		
    }
	cout << "array known:" << endl;
	for(int i=0;i<N;i++){
		cout << array_known[i] << " ";
	}
	cout << endl;
	/*
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			if(matrix[i][j]){
				if(!matrix_known[i][j]){
					matrix_result[i][j]= true;
					cout << "[x]" ;				
					
				}
				else{
					cout <<"[ ]";
					
				}
			}
			else{
				cout <<"[ ]";
				
			}
		}
		cout << endl;
	}*/
	bool colonne_libere[N];
	for(int i=0;i<N;i++){
		colonne_libere[i] = true;
	}

	for(int i =0;i<N;i++){
		for(int j=0;j<N;j++){
			if(matrix[i][j])
				cout << "[x]";
			else
				cout << "[ ]";
		}
		cout << endl;
		
	}

	
	int sol[N];
	trovato = false;

	ricerca(0, colonne_libere, sol, N);

	if(!trovato)
		out << "-1";

	/*
	int solution[N];
	for(int j=0;j<N;j++){
		for(int i=0;i<N;i++){
			if(matrix_result[j][i]){
				solution[j]=i;
			}
		}
	}*/
	string s="";
	cout << endl;
	//char* str="";
	/*for(int i=0;i<N;i++){
		cout << i << " " << solution[i] << endl;
	}*/

    
}
