#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

using namespace std;

vector<int> graph[200000];
int N, M;

int padri[200000];
bool parenti[200000];

vector<int> cycle;
int new_match[100000];

int dfs(int n, int d) {
    padri[n] = d + 1;
    parenti[n] = true;

    for (int i = 0; i < graph[n].size(); i++) {
        if (parenti[graph[n][i]]) {
            cycle.push_back(graph[n][i]);
            int t = n;
            cycle.push_back(t);

            while (t != graph[n][i]) {
                t = padri[t] - 1;
                cycle.push_back(t);
            }
            return true;
        }

        if (padri[graph[n][i]])
            continue;
        if (dfs(graph[n][i], n))
            return true;
    }
    parenti[n] = false;
    return false;
}

int main() {
    ifstream in;
    in.open("input.txt");
    ofstream out("output.txt");
    if (in.is_open()){

        in >> N;
        in >> M;

        for (int i = 0; i < M; i++) {
            int a, b;
            in >> a;
            in >> b;

            b += N;

            if (i < N) 
                graph[a].push_back(b);
            else
                graph[b].push_back(a);
        }

        for (int i = 0; i < N; i++) {
            while (i < N && padri[i])
                i++;
            if (i < N && dfs(i, i)) {
                for (int i = 1; i < cycle.size(); i++) {
                    if (cycle[i - 1] < N)
                        new_match[cycle[i - 1]] = cycle[i];
                }

                for (int i = 0; i < N; i++) {
                    if (!new_match[i])
                        new_match[i] = graph[i][0];
                }
                
                for (int i = 0; i < N; i++) {
                    out << i << " " << new_match[i] - N << endl;
                }
                in.close();
                out.close();
                return 0;
            }
        }
        out << "-1" << endl;
    }    
    in.close();
    out.close();
    return 0;



}
