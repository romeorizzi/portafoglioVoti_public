#include <cstdio>
#include <vector>
#include <stack>
#include<list>

using std:: vector;
using std::stack;
using std::list;

class FenweekTree{
private:
vector<int> vt;
int LSOne (int v) {return v & (-v);}
public:
FenweekTree(int n){vt.assign(n+1, 0);}
int rsq(int a){
int sum=0;
for(; a; a-=LSOne(a)) sum += vt[a];
return sum;
}

int getValue(int a){
return rsq(a) - (a>1) ? rsq(a-1) : 0;
}

void adjust(int k, int v){
for(;k<(int)vt.size(); k+=LSOne(k)) vt[k]+=v;
}
};

void preproc(int &currIdx, int currNode, vector<list<int> >&tree, vector<int> &idx, vector<int> &figli){
idx[currNode]=currIdx++;
for(list<int>::iterator i=tree[currNode].begin(); i!=tree[currNode].end();i++)
preproc(currIdx, *i, tree, idx, figli);
figli[currNode]=currIdx;
}

int main(){
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
int N,M;
vector<int> indice;
vector<list<int> > hierarchy;
vector<int> figli;
vector<int> parcella;

scanf("%d %d", &N, &M);
indice.resize(N+1);
hierarchy.resize(N+1);
figli.resize(N+1);
parcella.resize(N+1);
FenweekTree ft(N);
scanf("%d", &parcella[1]);
for(int i =2; i<=N; i++){
int capo;
scanf("%d %d\n", &parcella[i], &capo);
hierarchy[capo].push_back(i);
figli[capo]++;
}
int currI=1;
preproc(currI, 1, hierarchy, indice, figli);
char c;
for(int i=0;i<M;i++){
scanf("%c", &c);
if(c=='u'){
int toCheck;
scanf("%d\n", &toCheck);
printf("%d\n", parcella[toCheck]+ft.rsq(indice[toCheck]));
}
if(c=='p'){
int capo, modifier;
scanf("%d %d\n", &capo, &modifier);
ft.adjust(indice[capo]+1,modifier);
ft.adjust(figli[capo], -modifier);
}
}
return 0;
}
