#include <cstdio>
#include <vector>
#include <list>
#include <set>
#include <utility>

#define MIL 100000


using namespace std;

int P, Q;
list<int> grafo[2*MIL];
bool visited[2*MIL];
bool wrote[MIL];
FILE* fi = fopen("input.txt", "r");
FILE* fo = fopen("output.txt", "w");

int dfs(int c){
   if(visited[c])   {
     if(c < MIL) return 1;
     else return 0;
   }
   visited[c] = true;
   
   int found = 0;
   for(list<int>::iterator i = grafo[c].begin(); i != grafo[c].end(); i++)
   {
       found = dfs(*i);
       if (found ==true && c >= MIL) {
       fprintf(fo, "%d %d\n" , *i, c-MIL);
       wrote[*i] = 1; }
       if(found ==true && c<MIL && wrote[c]) found=2;
       if(found) {
       visited[c]=false;
       return found;}
  }
   visited[c] = false;
   return found;
}

int main()

{

    fscanf(fi, "%d %d", &P, &Q);
    int z, t;
    bool found = false;

    
   for(int i = 0; i<P; i++)
   {
    fscanf(fi, "%d %d" , &z, &t); 
    t += MIL;
    grafo[z].push_back(t);
   }
    for(int i = P; i < Q; i++)
    {
    int h, t;
    fscanf(fi, "%d %d", &z, &t);
    t += MIL;
    grafo[t].push_back(z);
    }
    
    for(int i = 0; i<P && !found; i++){
       found=dfs(i);
    }
    if(!found){
       fprintf(fo, "-1\n");
    }
    else {
       for(int i = 0; i<P; i++){
         if(!wrote[i]) fprintf(fo, "%d %d\n", i, grafo[i].front() - MIL);
    
       }
    }
    return 0;
}

