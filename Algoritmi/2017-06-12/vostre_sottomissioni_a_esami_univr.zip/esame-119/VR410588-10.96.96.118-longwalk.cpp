#include <fstream>
using namespace std;

const int N = 100000;
int n;

const int M = 1000000;
int m;

const int TAIL = 0;
const int HEAD = 1;

int out[N + 1];
int in[N + 1];

int arc[M + 1][2];
int first_out[N + 2];
int out_first[M];

int first_in[N + 2];
int in_first[M];

int coda[N];
int coda_pos = 0;

bool removed[N + 1];
int max_from[N + 1];
int next[N + 1];
int max_so_far;
int max_start;

int main() {
    ifstream fin("input.txt");
    fin >> n >> m;

    for (int i = 0; i <= n; i++)
        next[i] = max_from[i] = out[i] = in[i] = 0;

    for(int j = 1; j <= m; j++) {
        fin >> arc[j][TAIL] >> arc[j][HEAD];
        out[arc[j][TAIL]]++;
        in[arc[j][HEAD]]++;
    }
    fin.close();

    first_out[1] = first_in[1] = 0;
    for(int i = 1; i<= n; i++) {
        first_out[i + 1] = first_out[i] + out[i];
        first_in[i + 1] = first_in[i] + in[i];
    }
    
    int cur_out[N + 1];
    int cur_in[N + 1];

    for (int i = 1; i <= n; i++) {
        cur_out[i] = first_out[i];
        cur_in[i] = first_in[i];
    }

    for(int j = 1; j<= m; j++) {
        out_first[cur_out[arc[j][TAIL]]++] = arc[j][HEAD];
        in_first[cur_in[arc[j][HEAD]]++] = arc[j][TAIL];
    }

    for(int i = 1; i <= n; i++) {
        removed[i] = false;
        if(out[i] == 0)
            coda[coda_pos++] = i;
    }

    int n_removed = 0;

    while(coda_pos) {
        int v = coda[--coda_pos];
        removed[v] = true;
        n_removed++;

        for(int i = first_out[v]; i < first_out[v+1]; i++)
            if(max_from[out_first[i]] >= max_from[v]) {
                max_from[v] = max_from[out_first[i]] +1;
                next[v] = out_first[i];
                if(max_from[v] > max_so_far) {
                    max_so_far = max_from[v];
                    max_start = v;                
                }
            }
        
        for(int i = first_in[v]; i < first_in[v+1]; i++) {
            out[in_first[i]]--;
            if(out[in_first[i]] == 0)
                coda[coda_pos++] = in_first[i];
        }
    }

    ofstream fout("output.txt");
    if(n_removed == n) {
        fout << max_so_far << endl;
        int v = max_start;
        while(v) {
            fout << v << " ";
            v = next[v];
        }
    }
    else {
        fout << -1 << endl;
        bool visited[N + 1];
        
        for(int i = 1; i <= n; i++)
            visited[i] = false;

        int a = 1;

        while(removed[a])
            a++;

        while(!visited[a]) {
            visited[a] = true;
            for(int i = first_out[a]; i < first_out[a+1]; i++)
                if(!removed[out_first[i]]) {
                    next[a] = out_first[i];
                }

            a = next[a];
        }
        int b = a;
        do {
            fout << b << " ";
            b = next[b];
        }
        while(b != a);
    }
    fout.close();
    return 0;
}
