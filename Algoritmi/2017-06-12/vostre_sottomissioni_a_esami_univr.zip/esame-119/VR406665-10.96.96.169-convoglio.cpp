#include <fstream>
#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

bool antenato[200000];
int N, M;
int s,t;
int trovato[100000];
int padre[200000];
vector<int> ciclo;
vector<int> grafo[200000];
int supporto;


int dfs(int n, int d){
    
    antenato[n]=true;    
    int l=grafo[n].size();
    padre[n]=d+1;

    
    for(int i=0; i<l;i++){
        if(antenato[grafo[n][i]]){
            ciclo.push_back(grafo[n][i]);
            int supporto=n;
            ciclo.push_back(supporto);

            while(supporto!=grafo[n][i]){
	            supporto=padre[supporto]-1;
	            ciclo.push_back(supporto);
        }
        return true;
    }
    if(padre[grafo[n][i]])
        continue;

    if(dfs(grafo[n][i],n))
        return true;
  }
  antenato[n]=false;
  return false;
}

int stampa(){
    ofstream fout("output.txt");

    for(int i=0;i<N;i++){
        while(i<N && padre[i])
            i++;

        if(i<N && dfs(i,i)){
            for(unsigned i=1; i<ciclo.size();i++)
	            if(ciclo[i-1]<N)
	                trovato[ciclo[i-1]]=ciclo[i];

            for(int i=0;i<N;i++)
	            if(!trovato[i])
	                trovato[i]=grafo[i][0];

            for(int i=0;i<N;i++) {
	            fout << i << " " << trovato[i]-N << endl;
            }
        fout.close();
        return 0;
        }
    
    }

    fout <<-1 << endl;
    fout.close();
    return 0;
}

int main(){

    ifstream fin("input.txt");
    fin >> N >> M;

    for(int i=0;i<M;i++){
        fin >> s >> t;
        t+=N;

        if(i<N)
            grafo[s].push_back(t);
        else
            grafo[t].push_back(s);      
    }

    fin.close();
    stampa();
    return 0;  
}

