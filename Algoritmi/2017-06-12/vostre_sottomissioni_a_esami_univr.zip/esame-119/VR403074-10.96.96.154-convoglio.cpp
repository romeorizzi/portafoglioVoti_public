#include <fstream>
#include <iostream>
#include <cassert>
#include<cstdio>
#include <vector>


using namespace std;


int N, M;
int padri[300000];
int match[300000];
bool anc[300000];

vector<int> list_ad[300000];
vector<int> ciclo_trovato;

int deep(int n, int d);
int output();

int main(){

ifstream fin("input.txt"); 
assert(fin);

fin >> N >> M;

 for(int i=0;i<M;i++){
    int s,t;
    fin >> s >> t;
    t+=N;
    if(i<N)
      list_ad[s].push_back(t);
    else
      list_ad[t].push_back(s);      
  }
 fin.close();
 output();
 return 0;  
}

int output(){
  ofstream fout("output.txt"); 
   assert(fout);

  for(int i=0;i<N;i++){

    while(i<N && padri[i]){
      i++;
    }

    if(i<N && deep(i,i)){
      for(unsigned i=1; i<ciclo_trovato.size();i++)
	    if(ciclo_trovato[i-1]<N)
	        match[ciclo_trovato[i-1]]=ciclo_trovato[i];

      for(int i=0;i<N;i++)
	    if(!match[i])
	        match[i]=list_ad[i][0];

      for(int i=0;i<N;i++) {
	        fout << i << " " << match[i]-N << endl;
      }

      fout.close();

      return 0;
    }
    
  }

  fout <<-1 << endl;
  fout.close();
  return 0;
}

int deep(int n, int d){

  padri[n]=d+1;
  anc[n]=true;
  int l=list_ad[n].size();

  for(int i=0; i<l;i++){
    if(anc[list_ad[n][i]]){
      ciclo_trovato.push_back(list_ad[n][i]);
      int a=n;
      ciclo_trovato.push_back(a);

      while(a!=list_ad[n][i]){
	        a=padri[a]-1;

	        ciclo_trovato.push_back(a);
      }
      return true;
    }

    if(padri[list_ad[n][i]])
      continue;

    if(deep(list_ad[n][i],n))
      return true;

  }

  anc[n]=false;

  return false;
}

