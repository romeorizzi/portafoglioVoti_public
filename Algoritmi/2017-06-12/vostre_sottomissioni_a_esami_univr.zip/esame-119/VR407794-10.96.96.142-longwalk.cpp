#include <cassert>
#include <iostream>
#include <fstream>

using namespace std;

// costanti
const int MN =  100000;
const int MM = 1000000;
const int CODA=0;
const int TESTA=1;

// dichiarazione variabili
int M;
int N;
int coda[MN];
int positionLifo = 0;
bool rimossi[MN +1];
bool visitati[MN +1];
int max_from[MN +1];
int successivo[MN +1];
int best_max;
int max_init;
int gradoOut[MN +1];
int gradoIn[MN +1];
int edge[MM +1][2];
int primoVicinoOut[MN +2];
int viciniOut[MM];
int primoVicinoIn[MN +2];
int viciniIn[MM];
int vicinoOut_corrente[MN +1];
int vicinoIn_corrente[MN +1];
int rimosso_n = 0;

void init(){
    // read file
    ifstream fi("input.txt");
    assert( fi );
    fi >> N >> M;

    // init variable
    int i = 0;
    while(i<=N){
        visitati[i] = false;
        successivo[i] = 0;
        max_from[i] = 0;
        gradoOut[i] = 0;
        gradoIn[i] = 0;
        i++;
    }

    int j = 1;
    while(j<=M){
      fi >> edge[j][CODA] >> edge[j][TESTA];
      gradoOut[ edge[j][CODA] ]++;
      gradoIn[ edge[j][TESTA] ]++;
      j++;
    }

    fi.close();

    primoVicinoOut[1] = 0;
    primoVicinoIn[1] = 0;
}

void update(){
    int i = 1;

    while(i<=N){
        primoVicinoOut[i+1] = primoVicinoOut[i] + gradoOut[i];
        vicinoOut_corrente[i] = primoVicinoOut[i];
        primoVicinoIn[i+1] = primoVicinoIn[i] + gradoIn[i];
        vicinoIn_corrente[i]  = primoVicinoIn[i];
        rimossi[i] = false;
        if( gradoOut[i] == 0 )
            coda[ positionLifo++ ] = i;
        i++;
    }

    int j = 1;
    while(j<= M){
      viciniOut[ vicinoOut_corrente[ edge[j][CODA] ]++ ] = edge[j][TESTA];
      viciniIn[ vicinoIn_corrente[ edge[j][TESTA] ]++ ] = edge[j][CODA];
      j++;
    }

}

void print_solution(){
    best_max ++;
    ofstream fo("output.txt");
    assert( fo );

    if( rimosso_n == N ) {
      fo << best_max << endl;
      int v = max_init;
      while( v ) {
        fo << v << " ";
        v = successivo[v];
      }
    }
    else {
      fo << -1 << " " << best_max << endl;
      int v = 1;
      if(rimossi[v] == true)
          v++;
      while(visitati[v] != false) {
        visitati[v] = true;
        int i = primoVicinoOut[v];
        while(i<primoVicinoOut[v+1])
          if(rimossi[viciniOut[i]] == false )
            successivo[v] = viciniOut[i];
          v = successivo[v];
          i++;
      }
      int u = v;
      do {
        fo << u << " ";
        u = successivo[u];
      } while( u != v );
    }
    fo.close();
}

int main() {
  init();
  update();

  while( positionLifo ) {
    int v = coda[ --positionLifo ];
    rimossi[v] = true;
    rimosso_n++;

    int i = primoVicinoOut[v];
    while(i<primoVicinoOut[v+1]){
      if( max_from[ viciniOut[i] ] >= max_from[v] ) {
        max_from[v] = max_from[ viciniOut[i] ] +1;
        successivo[v] = viciniOut[i];
        if( max_from[v] > best_max )  {
          best_max = max_from[v];
          max_init = v;
        }
      }
      i++;
    }

    int j = primoVicinoIn[v];
    while(j < primoVicinoIn[v+1]){
      gradoOut[ viciniIn[j] ] -= 1;
      if( gradoOut[ viciniIn[j] ] == 0 )
        coda[ positionLifo++ ] = viciniIn[j];
      j++;
    }
  }

  print_solution();

  return 0;
}
