#include <cstdio>
#include <vector>
#include <fstream>
#include <iostream>
using namespace std;

vector<int> grafo[200000];
int N, M;

int padri[200000];
bool antenato[200000];
vector<int> vettore;

int array[100000];

int visita_grafo(int param1, int param2) {
    padri[param1] = param2+1;
    antenato[param1] = true;

    for(int i=0; i < grafo[param1].size(); i++) {
        if(antenato[grafo[param1][i]]) {
            vettore.push_back(grafo[param1][i]);
            int tmp = param1;
            vettore.push_back(tmp);

            while(tmp != grafo[param1][i]) {
                tmp = padri[tmp]-1;
                vettore.push_back(tmp);            
            }
            
            return true;
        }    
        
        if(padri[grafo[param1][i]]) 
            continue;

        if(visita_grafo(grafo[param1][i], param1)) 
            return true;
    }

    antenato[param1] = false;
    return false;
}

int print() {
    ofstream fout("output.txt");
    for(int i = 0; i < N; i++) {
        while(i<N && padri[i]) 
            i++;

        
        if(i < N && visita_grafo(i, i)) {
            for(unsigned i = 1; i < vettore.size(); i++)
                if(vettore[i-1] < N)
                    array[vettore[i-1]] = vettore[i];

            for(int i = 0; i<N; i++)
                if(!array[i])
                    array[i] = grafo[i][0];

            for(int i = 0; i < N; i++)
                fout << i << " " << array[i] - N << endl;
            
            fout.close();
            return 0;
        }
    }
    

    fout << -1 << endl;
    fout.close();
    return 0;
}


int main() {
    ifstream fin("input.txt");
    fin >> N >> M;

    for(int i = 0; i<M; i++) {
        int a, b;
        fin >> a >> b;
        b += N;

        if(i < N) grafo[a].push_back(b);
        else grafo[b].push_back(a);    
    }

    fin.close();
    print();
    return 0;
}
