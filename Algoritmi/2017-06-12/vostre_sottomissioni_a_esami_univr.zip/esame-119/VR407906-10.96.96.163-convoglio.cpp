#include <cstdio>
#include <iostream>
#include <list>
#include <assert.h>

using namespace std;

int N;
int M;

bool visitati[200000];
bool scritti[100000];

list<int> grafo[200000];

int dfs(int ind);
 
int main(){
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    scanf("%d",&N);
    scanf("%d",&M);
    for(int i=0;i<N;i++){
            //cout << "input1" << endl;
        int first,second;
        scanf("%d",&first);
        scanf("%d",&second);
        second += 100000;
        grafo[first].push_back(second);
    }
    for(int i=N;i<M;i++){
            //cout << "input2" << endl;
        int first,second;
        scanf("%d",&first);
        scanf("%d",&second);
        second += 100000;
        grafo[second].push_back(first);
        
    }
    bool trovato = false;
    for(int i=0;i<N && !trovato;i++) trovato = dfs(i);
    if(!trovato) printf("-1\n");
    else 
        for(int i=0;i<N;i++){
            if(!scritti[i])
                printf("%d %d\n",i, grafo[i].front()-100000);
        }    
    return 0;
}

int dfs(int ind){
    if(visitati[ind])
        if(ind < 100000) 
            return 1; 
        else return 0;  
    visitati[ind] = true;
    int trovato = 0;
    for(list<int>::iterator i = grafo[ind].begin();i!=grafo[ind].end();i++){
        trovato = dfs(*i);
        if(trovato==1 && ind>=100000)
        { 
            printf("%d %d\n",*i, ind-100000);
            scritti[*i] = 1;
        }
        if(trovato==1 && ind<100000 && scritti[ind])
            trovato = 2;
        if(trovato){
            visitati[ind] = false; 
            return trovato;                     
        }
    }
    visitati[ind] = false; 
    return trovato;  
}
