#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

using namespace std;

int N, M, k;    

void test() {
    ifstream in;
    in.open("input.txt");
    ofstream out("output.txt");

    if (in.is_open()){

        in >> N;
        in >> M;
        
        if ( M = 9) {
            out << "4" << endl; 
            out << "1 5 4 2" << endl;
        }

        else {
            out << "-1 3" << endl; 
            out << "2 5 4" << endl; 
        }
    in.close();
    out.close();
    }
}

/*
struct game {
    int p;
    int win[];
    int index[];
};

vector<game> partite;
    game g;

  /game g;
            in >> g.p;
            in >> g.win[i];
            g.index[i] = i;
            partite.push_back(g);
*/

int main() {
    //test();
    int flag = 0;
    ifstream in;
    in.open("input.txt");


    if (in.is_open()){

        in >> N;
        in >> M;

        int p[M], q[M];

        for(int i = 0; i < M; i++) {
            in >> p[i];
            in >> q[i];
            //cout << p[i] << " " << q[i] << endl;


        }
        int sz[M], max_sz[M], index = 0;
        int max = 0;
        int sum = 1;
        int max_index = 0;
        for (int i = 0; i < M; i++) {
            sz[index++] = p[i];

            int next_player = q[i];


            for (int j = i + 1; j < M + i + 1; j++) {
                if (j == M + i) {
                    sz[index++] = next_player;
                }

                if (p[j % M] == next_player) {

                    sz[index++] = next_player;

                    next_player = q[j % M];
                    sum++;

                }
            }

   



            if (max < sum + 1) {
                max = sum + 1;
                max_index = index;
                copy(sz, sz + index, max_sz);
            }
            index = 0;
            sum = 1;
            
            
        } 
        for (int i = 0; i < max_index; i++) {
                if ( i == max_index - 1) {
                    for (int i = 0; i < M; i++) {
                        if (p[i] == max_sz[i] && q[i] == max_sz[0])
                            flag = 1;                    
                    }
                }
            }
        
        ofstream out("output.txt");
        if (out.is_open()) {
            if (flag == 0) {
                out << max << endl;
            } else out << "-1 " << max << endl;
            for (int i = 0; i < max_index; i++) 
                out << max_sz[i] << " "; 

        }
        out.close();
        
    }
    in.close();
    return 0;
}




