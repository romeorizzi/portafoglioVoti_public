#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;

class FenweekTree{

    private: 
        vector<int> vt;
        int LSOne(int v){
            return v & (-v);
        }

    public:
        FenweekTree(int n){
            vt.assign(n+1, 0);
        }

        int rsq(int a){
            
            int sum = 0;
            for(; a; a -= LSOne(a)) sum += vt[a];
            return sum;
        }

        int getValue(int a){
            
            return rsq(a) - (a>1) ? rsq(a-1) : 0;
        }

        void adjust(int k, int v){

            for(; k < (int)vt.size(); k += LSOne(k)) vt[k] += v;
        }

};

void preproc(int &currIdx, int currNode, vector<list<int> > &tree, vector<int> &idx, vector<int> &sons){

    idx[currNode] = currIdx++;

    for(list<int>::iterator i = tree[currNode].begin(); i != tree[currNode].end(); i++){
        preproc(currIdx, *i, tree, idx, sons);
    }

    sons[currNode] = currIdx;

}

int main(){

    FILE* fi = fopen("input.txt", "r");
    FILE* fo = fopen("output.txt", "w");

    int N, M;
    vector<int> index;
    vector<list<int> > hierarchy;
    vector<int> sons;
    vector<int> wages;

    fscanf(fi, "%d %d", &N, &M);

    index.resize(N+1);
    hierarchy.resize(N+1);
    sons.resize(N+1);
    wages.resize(N+1);
    
    FenweekTree ft(N);

    fscanf(fi, "%d", &wages[1]);

    for(int i = 2; i <= N; i++){
        int boss;
        fscanf(fi, "%d %d\n", &wages[i], &boss);
        hierarchy[boss].push_back(i);
        sons[boss]++;
    }

    int curr = 1;

    preproc(curr, 1, hierarchy, index, sons);

    char c;
    for(int i = 0; i < M; i++){
        fscanf(fi, "%c", &c);
        if(c == 'u'){
            int toCheck;
            fscanf(fi, "%d\n", &toCheck);
            fprintf(fo, "%d\n", wages[toCheck] + ft.rsq(index[toCheck]));
        }
        if(c == 'p'){
            int boss, modifier;
            fscanf(fi, "%d %d\n", &boss, &modifier);
            ft.adjust(index[boss]+1, modifier);
            ft.adjust(sons[boss], -modifier);
        }
    }

    return 0;

}

