#include <cstdio>
#include <vector>
#include <algorithm>
#include <cassert>
#include <fstream>
#include <iostream>


// Global var
using namespace std;

const int NUMAX = 500005;

int s[NUMAX] , f[NUMAX];
int a[NUMAX], arr[NUMAX];
vector <int> E[NUMAX];

int timer = 0;
void dfs(int x) {
    s[x] = timer ++;
    for (int i=0; i<E[x].size(); ++i) {
        dfs (E[x][i]);
    } 

    f[x] = timer;

}

int L[NUMAX];
inline void add (int x, int y) {
    for (++x; x<NUMAX; x+= x&-x) {
        L[x] += y;
    }
}

inline int sum (int x) {
    int r = 0;
    for (++x; x; x-=x&-x) {
        r += L[x];
    }

    return r;
}

int main (void) {
    ifstream fin("input.txt");
    ofstream fout("output.txt");

    int n, m;
    fin >> n >> m;
    fin >> *(a+0);
    
    for (int i=1; i<n; i++) {
        fin >> *(a+i) >>*(arr+i);
        --arr[i];
        E[arr[i]].push_back(i);
    }

    dfs(0);

    for(int i=0; i<m; ++i) {
        char bor[10];
        fin >> bor;

        if (bor[0] == 'p') {
            int a,x;
            fin >> a >> x;
            --a;
            add(s[a]+1, +x);
            add(f[a], -x);
        }

        if (bor[0] == 'u') {
            int x;
            fin >> x;
            --x;

            fout << a[x]+ sum(s[x]) << endl;

        }
    }
    
    return 0;
}
