#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

fstream fin;
fstream fout;

//numero giocatori
int n;

//numero partite
int m;

vector<vector<int> > vince(10000);
vector<vector<int> > appoggio(10000);
vector<int> vincitori;
vector<int> sconfitti;

int nDiscendenti[10000];

vector<int> path;

int maxDisc(int padre){

    cout<<"maxDisc"<<endl;
    int max=0;
    int bestSoFar=0;
    while(vince[padre].size()>0){
        
        int temp=vince[padre].back();
        vince[padre].pop_back();
        appoggio[padre].push_back(temp);
        bestSoFar=1+maxDisc(temp);
        if(max<bestSoFar){
            max=bestSoFar;
        }
    }
    nDiscendenti[padre]=max;
    while(appoggio[padre].size()>0){
    vince[padre].push_back(appoggio[padre].back());
    appoggio[padre].pop_back();
    }
    return nDiscendenti[padre];
    
    
}

void lPath(int nodo){
    
cout<<"lPath"<<endl;
    path.push_back(nodo);
    int max=0;
    int prossimoNodo=0;
    while(vince[nodo].size()>0){
    
    int temp=vince[nodo].back();
    vince[nodo].pop_back();

    if(nDiscendenti[temp]>=max){
        max=nDiscendenti[temp];
        prossimoNodo=temp;
        
    }
    

    }
    if(prossimoNodo!=0){
        
        cout<<prossimoNodo;
        lPath(prossimoNodo);
    }
}

int main(){
    
    fin.open("input.txt",ios::in);
    fout.open("output.txt",ios::out);
    
    //leggi numero giocatori
    fin>>n;
    cout<<"n: "<<n<<endl;

    //leggi numero partite
    fin>>m;
    cout<<"m: "<<m<<endl;

    //riempi lista vittorie
    
    for(int i=0;i<m;i++){

        int vincitore;
        int sconfitto;
        
        fin>>vincitore;
        fin>>sconfitto;
        bool foundWinner=false;
        bool foundLoser=false;

        for(int j=0;j<vincitori.size();j++){
            if(vincitori[j]==vincitore){
            foundWinner=true;
            }
        }
        if(!foundWinner){
        vincitori.push_back(vincitore);
        }

        for(int j=0;j<vince[vincitore].size();j++){
            if(vince[vincitore][j]==sconfitto){
            foundLoser=true;
            }
        }
        
        if(!foundLoser){
        
        vince[vincitore].push_back(sconfitto);
        sconfitti.push_back(sconfitto);
        }
            

    }
    cout<<"input letto"<<endl;
    fin.close();
        //stampa lista partite
/*
    for(int i=0;i<m;i++){
        
        while(vince[i].size()>0){
            cout<<i<<" sconfigge "<<vince[i].back()<<endl;
            vince[i].pop_back();
        }

    }
*/

//riempire lista di numero discendenti


    for(int i=0;i<vincitori.size();i++){
    
        int temp=vincitori[i];
            
            nDiscendenti[temp]=maxDisc(temp);
        
    }
    cout<<"disc calcolati"<<endl;
    
    for(int i=1;i<=n;i++){
    cout<<"n discendenti di "<<i<<": "<<nDiscendenti[i]<<endl;
}

    //scegliere primo nodo
    int radice=0;
    int maxRadice=0;
    for(int i=0;i<vincitori.size();i++){
        int temp=vincitori[i];
        if(nDiscendenti[temp]>maxRadice){

            radice=temp;
            maxRadice=nDiscendenti[temp];

        }
       
    }
    cout<<"radice: "<<radice<<endl;
    lPath(radice);
    int size=path.size();
    fout<<size<<endl;

    for(int i=0;i<path.size();i++){
    
    int temp=path[i];
    fout<<temp<<" ";

}
fout.close();
    
    



return 0;
}
