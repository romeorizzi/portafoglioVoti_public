#include <cstdio>
#include <vector>
#include <set>
#include<list>
#include <utility>

#define LIM 100000
using namespace std;

int N,M;
list<int> grafo[2*LIM];
bool visto[2*LIM];
bool scritto[2*LIM];

int dfs(int c){
if(visto[c]){
    if(c<LIM) return 1;
    else return 0;
}
visto[c]=true;
int trovato=0;
for (list<int>:: iterator i=grafo[c].begin();i!=grafo[c].end();i++){
trovato=dfs(*i);
if(trovato ==1 && c>=LIM) {printf("%d %d\n", *i, c-LIM); scritto[*i]=1;}
if(trovato==1 && c<LIM && scritto[c]) trovato=2;
if (trovato) {visto[c]=0; return trovato; }
}
visto[c]=false;
return trovato;
}


int main(){

freopen("input.txt", "r", stdin);
#ifdef EVAL
freopen("output.txt", "w", stdout);
#endif
scanf("%d %d" , &N, &M);

for(int i=0;i<N; i++){
    int h, t;
    scanf("%d %d", &h, &t); 
    t+=LIM;
    grafo[h].push_back(t);
}
for(int i=N; i<M;i++){
    int h, t;
    scanf("%d %d", &h, &t); 
    t+=LIM;
    grafo[t].push_back(h);
}
bool trovato=false;
for(int i=0;i<N && !trovato;i++)
    trovato=dfs(i);

if(!trovato) printf("-1\n");
else for(int i=0;i<N;i++)
    if(!scritto[i]) printf("%d %d\n", i, grafo[i].front()-LIM); 
return 0;
}


