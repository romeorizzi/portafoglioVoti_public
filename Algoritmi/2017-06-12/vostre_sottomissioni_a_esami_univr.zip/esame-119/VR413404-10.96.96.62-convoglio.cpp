#include <cstdio>
#include <vector>
using namespace std;

vector <int> grafo[200000];
int N, M;
int padri[200000];
bool ispadre[200000];
vector <int> cycle;
int nuovo_controllo[100000];

int dfs(int n, int d){

    padri[n] = d+1;
    ispadre[n] = true;
    for(unsigned i = 0; i < grafo[n].size(); i++){
        if(ispadre[grafo[n][i]]){
            cycle.push_back(grafo[n][i]);
            int t = n;
            cycle.push_back(t);

            while(t != grafo[n][i]){
                t = padri[t] - 1;
                cycle.push_back(t);
            }
            return true;
        }
        
        if(padri[grafo[n][i]]) continue;
        
        if(dfs(grafo[n][i], n)) return true;
    }

    ispadre[n] = false;
    return false;

}
int main(){
#ifdef EVAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    scanf("%d%d", &N, &M);
    for(int i = 0; i < M; i++){
        int a, b;
        scanf("%d%d", &a, &b);
        b+=N;
        if(i<N) grafo[a].push_back(b);
        else grafo[b].push_back(a);
    }
    
    for(int i=0; i<N;i++){
        while(i<N && padri[i]) i++;
        
        if(i<N && dfs(i, i)){
            for(unsigned i=1; i<cycle.size(); i++){
                if(cycle[i-1]<N)
                    nuovo_controllo[cycle[i-1]] = cycle[i];
            }
            
            for(int i = 0; i<N; i++){
                if(!nuovo_controllo[i])
                    nuovo_controllo[i] = grafo[i][0];
            }

            for(int i = 0; i<N;i++){
                printf("%d %d\n", i, nuovo_controllo[i] - N);
                
            }
            return 0;
        }
    }
    printf("-1\n");
    return 0;
}


