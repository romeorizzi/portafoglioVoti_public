#include <cstdio>
#include <vector>
using namespace std;
#define MAX_SIZE 200000
vector<int> convoglio[MAX_SIZE];
int N,M;
int padri[MAX_SIZE];
bool anch[MAX_SIZE];
vector<int> sol;
int newValues[MAX_SIZE];


int dfs(int n,int d){
	anch[n]=true;
	padri[n]=d+1;

	for(unsigned i=0;i<convoglio[n].size();i++){
		if(anch[convoglio[n][i]]){
			sol.push_back(convoglio[n][i]);
			int t=n;
			sol.push_back(t);
			while(t!=convoglio[n][i]){
				t=padri[t]-1;
				sol.push_back(t);
			}
			return true;
		}

		if(dfs(convoglio[n][i],n)) return true;
	}
	anch[n]=false;
	return false;
}

int main(){
#ifdef EVAL
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	scanf("%d%d",&N,&M);
	for(int i=0;i<M;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		b+=N;
		if(i<N) convoglio[a].push_back(b);
		else convoglio[b].push_back(a);
	}
	for(int i=0;i<N;i++){
		while(i<N && padri[i]) i++;
		if(i<N && dfs(i,i)){
			for(int i=1;i<sol.size();i++)
				if(sol[i-1]<N)
					newValues[sol[i-1]]=sol[i];
			for(int i=0;i<N;i++)
				if(!newValues[i])
					newValues[i]=convoglio[i][0];
			for(int i=0;i<N;i++) printf("%d %d\n",i,newValues[i]-N);
			return 0;
		}
	}
	printf("-1\n");
	return 0;
}

