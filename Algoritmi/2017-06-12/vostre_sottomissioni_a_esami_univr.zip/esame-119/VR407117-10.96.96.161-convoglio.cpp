#include<cstdlib>
#include<iostream>
#include<list>
#include<fstream>
#include<vector>


using namespace std;
int N, M;
vector <list<int> > adjlist;
int* corrispondenze;
bool* dup;
bool* anc;
#define zero 0
#define uno 1
#define due 2
int a = zero;
int radice = 0;
void dfs(int current) {
    dup[current] = true;
    anc[current]=true;
    int ok = corrispondenze[current];
    for(list<int>::iterator it = adjlist[ok].begin();
        it != adjlist[ok].end(); it++) {
        int dest = *it;
        if(dest != current) {
            if(dup[dest] and anc[dest]) {

                a = uno;
                radice = dest;
                corrispondenze[dest] = ok;
                return;
            }
            if(!dup[dest]) {
                dfs(dest);
                if(a == uno) {
                    corrispondenze[dest] = ok;
                    if(radice == current)
                        a = due;
                    return;
                }
                if(a == due)
                    return;
            }
        }
    }
    anc[current]=false;
}
int main() {

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);


    scanf("%d", &N);
    scanf("%d", &M);
    adjlist.resize(N);
    corrispondenze = new int[N];
    dup = new bool[N];
    anc = new bool[N];
    for(int i=0;i<N;i++) {
        dup[i] = anc[i] = false;
    }

    for(int i=0;i<M;i++) {
        int src, dst;
        scanf("%d", &src);
        scanf("%d", &dst);
        if(i<N)
            corrispondenze[src] = dst;
        else
            adjlist[dst].push_back(src);
    }

    for(int i=0;i<N;i++) {
        if(!dup[i])
            dfs(i);
        if(a == due)
            break;
    }

    if(a == zero)
      printf("-1\n");
    else {
        for(int i=0;i<N;i++) {
            printf("%d %d\n",i,corrispondenze[i]);
        }
    }
    return 0;
}
