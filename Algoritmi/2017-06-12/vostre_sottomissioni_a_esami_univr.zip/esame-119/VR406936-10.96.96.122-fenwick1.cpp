#include <bits/stdc++.h>
using namespace std;

#define NUM 500000

int N;
vector<int> diff(NUM+2,0);
int start_value[NUM+2];
int tree_begin[NUM+2];
int tree_end[NUM+2];

vector<vector<int>> albero(NUM+1);

int linearizza(int nodo, int partenza)
{
    tree_begin[nodo] = partenza;
    for( auto v : albero[nodo] )
    {
        partenza = linearizza(v,partenza+1);
    }
    tree_end[nodo] = partenza;
    return partenza;
}
       
int sum(int k)
{
    int tot = 0;
    while(k>0)
    {
        tot += diff[k];
        k-= k&(-k);
    }
    return tot;
}

void add(int k, int val)
{
    while( k <= N)
    {
        diff[k] += val;
        k+= k&(-k);
    }
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    int operazioni;
    cin >> N >> operazioni;

    cin >> start_value[1];

    for( int i = 2; i <= N ; i++)
    {
        int val, padre;
        cin >> val >> padre;
        start_value[i] = val;
        albero[padre].push_back(i);
    }
    linearizza(1,1);

    for ( int i = 0 ; i < operazioni; i++)
    {
        string comando;
        cin >> comando;
        if (comando == "u")
        {
            int impiegato;
            cin >> impiegato;
            if ( impiegato <= 1)
                cout << start_value[1] << "\n";
            else
                cout << ( sum(tree_begin[impiegato-1]) + start_value[impiegato] ) << "\n";
        }
        else
        {
            int impiegato, valore;
            cin >> impiegato >> valore;
            add(tree_begin[impiegato], valore);
            add(tree_end[impiegato],-valore);
        } 
    }

	return 0;
}
