#include <stack>
#include <list>
#include <cstdio>
#include <vector>


using std::list;
using std::vector;
using std::stack;


class CreaAlbero{

 public : vector<int> vettore;
    
    int supporto (int v) {
         return v & (-v); 
    }

    int rsq(int a){
        int somma =0;
        for (; a; a-= supporto(a)) somma +=vettore[a];
        return somma;
    }
 
    CreaAlbero(int numero) {
         vettore.assign(numero+1, 0); 
    }

    void modifica (int k, int v){
        for (; k< (int)vettore.size(); k += supporto(k)) vettore[k] +=v;
    }

    int getValore(int a){
        return rsq(a) - (a > 1) ? rsq(a-1) :0;
    }

};

void assettaValori (int &currIdx, int nodoAttuale, vector<list<int> > &tree, vector<int> &idx, vector<int> &sons){
    idx[nodoAttuale] = currIdx;
    currIdx= currIdx +1;

    for(list<int>::iterator i = tree[nodoAttuale].begin(); i != tree[nodoAttuale].end(); i++)
        assettaValori(currIdx, *i, tree, idx, sons);

    sons[nodoAttuale] = currIdx;
}

int main(){

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int N, M;
    char carattere;
    vector<int> segnaPosizione;
    vector<list<int> > graduatoria;
    vector <int> sons;
    vector<int> salario;
    int capo;


    scanf(" %d %d", &N, &M),
    sons.resize(N+1);
    salario.resize(N+1);
    segnaPosizione.resize(N+1);
    graduatoria.resize(N+1);
    CreaAlbero ft(N);
    scanf ("%d", &salario[1]);
    for (int i=2; i<=N; i++){
        scanf("%d %d\n", &salario[i], &capo);
        graduatoria[capo].push_back(i);
        sons[capo]++;
    }
    int currI=1;
    assettaValori(currI, 1, graduatoria, segnaPosizione, sons);
    for (int i=0; i<M; i++){
        scanf("%c", &carattere);
        if (carattere=='u'){
            int toCheck;
            scanf("%d\n", &toCheck);
            printf("%d\n", salario[toCheck] + ft.rsq(segnaPosizione[toCheck]));
        }
        if (carattere=='p'){
            int capo, modifier;
            scanf("%d %d\n", &capo, &modifier);
            ft.modifica(segnaPosizione[capo]+1, modifier);
            ft.modifica(sons[capo], -modifier);
        }
    }
    return 0;
}

                

         
