#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
#include <algorithm>
#include <utility>

using namespace std;

#define N_MIN 2
#define N_MAX 100000

#define M_MIN 2
#define M_MAX 1000000

int N; // Giocatori
int M; // Partite
deque <int> a[N_MAX + 1];
deque <int> aux[N_MAX + 1];

void stampa();

int main(int argc, char ** argv) {
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M;
    for(int i = 0; i < M; i++) {
        int v, s;
        in >> v >> s;
        cout << v << " " << s << endl;
        a[v].push_back(s);
    }

    cout << N << " " << M << endl;
    stampa();

    for(int i = 1; i < N + 1; i++) {
        aux[i] = a[i];
    }
    
    deque <int> q;
    q.push_back(aux[1].front());

        while(!q.empty() || q.size() > 1) {
            int e = q.front();

            if(aux[e].empty()) {
                q.pop_front();
            }
            else {
                int f = aux[e].front();
                q.push_back(f);
            }
            
            for(unsigned j = 0; j < q.size(); j++)
                cout << q.at(j) << " ";
            cout << endl;
        }
    
    in.close();
    out.close();

    return 0;
}

void stampa() {
    for(int i = 1; i < N + 1; i++) {
        deque <int> q = a[i];
        cout << i << ": ";
        for(unsigned j = 0; j < q.size(); j++)
            cout << q.at(j) << " ";
        cout << endl;
    }
}



