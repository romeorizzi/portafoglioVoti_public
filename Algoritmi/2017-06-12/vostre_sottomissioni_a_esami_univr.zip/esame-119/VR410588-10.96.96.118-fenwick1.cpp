#include <cstdio>
#include <vector>
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

const int MAXN = 500005;

int arr1[MAXN];
int arr2[MAXN];
int arr3[MAXN];
int arr4[MAXN];
vector<int> vect[MAXN];

int timer = 0;
void visita(int x) {
    arr1[x] = timer++;
    for(int i = 0; i < vect[x].size(); ++i)
        visita(vect[x][i]);
    arr2[x] = timer;
}

int arr5[MAXN];
inline void f1(int x, int y) {
    for(++x; x < MAXN; x += x&-x) arr5[x] += y;
}

inline int f2(int x) {
    int r = 0;
    for(++x; x; x -= x&-x) r += arr5[x];
    return r;
}

int main(void) {
    int n, m;

    FILE *finp = fopen("input.txt", "r");
    FILE *fout = fopen("output.txt", "w");

    fscanf(finp, "%d %d", &n, &m);
    fscanf(finp, "%d", arr3 + 0);

    for(int i = 1; i < n; ++i) {
        fscanf(finp, "%d %d", arr3+i, arr4+i);        
        --arr4[i];
        vect[arr4[i]].push_back(i);        
    }

    visita(0);


    for(int i = 0; i < m; ++i) {
        char arr[10];
        
        fscanf(finp, "%s", arr);

        if(arr[0] == 'p') {
            int x1, x2;
            fscanf(finp, "%d %d", &x1, &x2);            
            --x1;

            f1(arr1[x1]+1, +x2);
            f1(arr2[x1], -x2);        
        }

        if(arr[0] == 'u') {
            int x;
            fscanf(finp, "%d", &x); 
            --x;            
            fprintf(fout, "%d\n", arr3[x] + f2(arr1[x]));
        }
    }

    return 0;
}
