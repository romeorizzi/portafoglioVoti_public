#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;


int N, M;
vector<int> indice;
vector< list<int> > gerarchia;
vector<int> figli;
vector<int> oth;

vector<int> vettore;

int uno(int v){
    return v & (-v);
}

int sum(int a){
    int sum = 0;
    for(; a; a-=uno(a))
        sum += vettore[a];
    return sum;
}

int getValore(int a){
    return sum(a) - (a>1) ? sum(a-1) : 0;
}

void aggiusta(int k, int v){
   for(; k < (int)vettore.size(); k+=uno(k))
       vettore[k] += v;
}

void update(int &corrente, int nodo, vector<list<int> > &lista, vector<int> &indice, vector<int> &figli){
    indice[nodo] = corrente++;
    for(list<int>::iterator i = lista[nodo].begin(); i != lista[nodo].end(); i++){
        update(corrente, *i, lista, indice, figli);
    }

    figli[nodo] = corrente;
}

void assegna(){
    indice.resize(N+1);
    gerarchia.resize(N+1);
    figli.resize(N+1);
    oth.resize(N+1);

    vettore.assign(N+1, 0);
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d %d", &N, &M);

    assegna();

    scanf("%d", &oth[1]);

    for(int i = 2; i <= N; i++){
        int head;
        scanf("%d %d\n", &oth[i], &head);
        gerarchia[head].push_back(i);
        figli[head]++;
    }

    int curr = 1;
    update(curr, 1, gerarchia, indice, figli);

    char c;
    for(int i = 0; i< M;i++){
        scanf("%c", &c);
        if (c == 'u'){
            int controlla;
            scanf("%d\n", &controlla);
            printf("%d\n", oth[controlla] + sum(indice[controlla]));
        }
        if (c == 'p'){
            int head, modifica;
            scanf("%d %d\n", &head, &modifica);
            aggiusta(indice[head]+1, modifica);
            aggiusta(figli[head], -modifica);
        }
    }

    return 0;

}

