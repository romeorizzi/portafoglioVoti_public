
// Marco Panato VR407935

#include <cstdio>
#include <cassert>
#include <vector>
#include <set>

#ifndef EVAL
#define MYPRINT(x, ...) printf(x, ##__VA_ARGS__)
#else
#define MYPRINT(x, ...)
#endif

#define DAFARE 0
#define INCORSO 1
#define FATTO 2

#define MAX_N 100000
#define MAX_M 1000000

int N, M;

std::set<int> archi[MAX_N+1]; // PARTI DA 1
std::vector<int> sequenza;
std::set<int> valoriInSequenza;
int gradoEntrante[MAX_N+1];
int gradoUscente[MAX_N+1];

int stato[MAX_N+1]; // stato nodo per bfs
int precedente[MAX_N+1]; // per ogni nodo memorizzo il "miglior cammino", indico
int lunghezza[MAX_N+1];  // il nodo da cui proviene e la lunghezza del cammino trovato fin'ora

int lastNodoCammino = -1;
int maxLunghezza = -1;

void bfs(int corrente) {
    MYPRINT("bfs(%d)\n", corrente);
    if (stato[corrente] == FATTO) return; // stop condition

    stato[corrente] = INCORSO;

    for (int figlio : archi[corrente]) {
        // potrei essere già passato dal figlio, vedo se ho trovato un cammino
        // migliore o no
        if (lunghezza[figlio] < lunghezza[corrente]+1) {
            lunghezza[figlio] = lunghezza[corrente]+1;
            precedente[figlio] = corrente;

            // salvo ultimo nodo del cammino
            if (lunghezza[figlio] > maxLunghezza) {
                lastNodoCammino = figlio;
                maxLunghezza = lunghezza[figlio];
            }
        }
    }

    stato[corrente] = FATTO;

    for (int figlio : archi[corrente]) {
        bfs(figlio); // procedo sul figlio
    }
}

void calcola() {
    // cerco nodo pozzo
    int pos = 1;
    for (; pos <= N; ++pos) {
        if (gradoUscente[pos] == 0) break;
    }
    if (pos != N+1) {
        // ho trovato un nodo finale (non so dire se c'è o no ciclo)
        lunghezza[pos] = 1;
        precedente[pos] = -1;
        bfs(pos);

        MYPRINT("Costruisco cammino\n");
        // costruisco cammino
        int curr = lastNodoCammino;
        do {
            MYPRINT("%d ", curr);
            if (valoriInSequenza.count(curr) == 1) break;
            sequenza.insert(sequenza.begin(),curr);
            valoriInSequenza.insert(curr);
            curr = precedente[curr];
        } while (curr != -1);

    } else {
        // non ci sono nodi finali -> c'è un ciclo sicuramente,
        // provo partendo da un nodo a caso
        bfs(0);

        MYPRINT("Costruisco cammino senza finali\n");
        // costruisco cammino
        int curr = lastNodoCammino;
        do {
            MYPRINT("%d ", curr);
            if (valoriInSequenza.count(curr) == 1) break;
            sequenza.insert(sequenza.begin(),curr);
            valoriInSequenza.insert(curr);
            curr = precedente[curr];
        } while (curr != -1);
    }
}


void print_res(FILE* fo) {
    MYPRINT("Sequenza...\n");
    for (int i = 0; i < sequenza.size(); ++i) {
        MYPRINT("%d ", sequenza[i]);
    }

    if (sequenza.size() > 0) {
        if (archi[sequenza[sequenza.size()-1]].count(sequenza.at(0)) == 1) {
            // se l'ultimo della sequenza vince contro il primo
            fprintf(fo, "-1 ");
        }
        fprintf(fo, "%lu\n", sequenza.size());
        for (int i = 0; i < sequenza.size() - 1; ++i) {
            fprintf(fo, "%d ", sequenza.at(i));
        }
        fprintf(fo, "%d\n", sequenza.at(sequenza.size() - 1));
    } else {
        fprintf(fo, "-1 0\n");
    }
}

int main() {
    FILE *fi = fopen("input.txt", "r");
    assert(fi);

    fscanf(fi, "%d %d", &N, &M);
    assert(N >= 2 && N <= MAX_N);
    assert(M >= 2 && M <= MAX_M);

    for (int i = 1; i <= N; ++i) {
        stato[i] = DAFARE;
        gradoEntrante[i] = 0;
        gradoUscente[i] = 0;
        precedente[i] = -1;
        lunghezza[i] = -1;
    }

    for (int i = 0; i < M; ++i) {
        int v1, v2;
        fscanf(fi, "%d %d", &v1, &v2);
        if (archi[v1].count(v2) == 0) {
            gradoUscente[v1]++;
            gradoEntrante[v2]++;
        }
        archi[v1].insert(v2);
    }

    MYPRINT("Gradi entranti  ");
    for (int i = 1; i <= N; ++i) {
        MYPRINT("%d ", gradoEntrante[i]);
    }
    MYPRINT("\n");
    MYPRINT("Gradi uscenti ");
    for (int i = 1; i <= N; ++i) {
        MYPRINT("%d ", gradoUscente[i]);
    }
    MYPRINT("\n");

    calcola();

    FILE *fo = fopen("output.txt", "w");
    assert(fo);

    // stampa k\nsequenza (ultimo vince)
    // oppure stampa -1 k\nsequenza (ultimo non vince)
    print_res(fo);

    fclose(fo);
    return 0;
}
