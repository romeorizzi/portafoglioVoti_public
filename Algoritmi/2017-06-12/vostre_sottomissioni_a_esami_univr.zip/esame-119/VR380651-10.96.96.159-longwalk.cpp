#include<cassert>
#include<fstream>
#include<vector>

using namespace std;

const int MAX_N = 100000;
const int MAX_M = 1000000;

int n;
int m;

int out_deg[MAX_N + 1];
vector<int> out_nei[MAX_N + 1], in_nei[MAX_N+1];
int LIFOsink[MAX_N], LIFOpos = 0;
bool removed[MAX_N + 1];
int max_from[MAX_N + 1], prossimo[MAX_N + 1], max_so_far, max_start;

int main(){

    FILE* fin = fopen("input.txt", "r");
    assert(fin);

    fscanf(fin, "%d ", &n);
    assert(n >= 2 && n <= 100000);

    fscanf(fin, "%d ", &m);
    assert(m >= 2 && m <= 1000000);

    for(int i=0; i<=n; i++){
        prossimo[i] = 0;
        max_from[i] = 0;
        out_deg[i] = 0;
    }
    
    for(int tail,head, j=1; j<=m; j++){
        
        fscanf(fin, "%d ", &tail);
        fscanf(fin, "%d ", &head);
        out_nei[tail].push_back(head);
        in_nei[head].push_back(tail);
        out_deg[tail]++;
    }

    fclose(fin);

    for(int i=1; i<=n; i++){
        removed[i] = false;
        if(out_deg[i] == 0){
            LIFOsink[LIFOpos++] = i;
        }
    }
    
    int n_removed = 0;

    while(LIFOpos){
        int v = LIFOsink[--LIFOpos];
        removed[v] = true;
        n_removed++;


        for(vector<int>::iterator it = out_nei[v].begin(); it<out_nei[v].end(); it++){
            if(max_from[*it] >= max_from[v]){
                max_from[v] = max_from[*it] + 1;
                prossimo[v] = *it;
                if(max_from[v] > max_so_far){
                    max_so_far = max_from[v] ;
                    max_start = v;
                }
            }
        }

        for(vector<int>::iterator it = in_nei[v].begin(); it<in_nei[v].end(); it++){
            out_deg[*it] --;
            if(out_deg[*it] == 0){
                LIFOsink[LIFOpos++] = *it;
            }
        }

        FILE* fout = fopen("output.txt", "w");
        assert(fout);

        if(n_removed == n){
            fprintf(fout, "%d", max_so_far);
            int v = max_start;
            while(v){
                  fprintf(fout, "%d ", v);

                  v = prossimo[v];
            }
        }else{
            fprintf(fout, "%d ", -1);
            bool visited[MAX_N + 1];
            for(int i = 1; i<=n; i++){
                v++;
            }
        
            while(!visited[v]){
                visited[v] = true;
                 for(vector<int>::iterator it = out_nei[v].begin(); it < out_nei[v].end(); it++){
                    if(!removed[*it]){
                        prossimo[v] = *it;
                    }
                    v = prossimo[v];
                 }
            }
            
            int u = v;

            do{
                fprintf(fout, "%d ", u);
                u = prossimo[u];
            }while(u != v);
        }
        

}
        
    return 0;
}
