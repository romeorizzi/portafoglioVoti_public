#include <iostream>
#include <algorithm>
#include <math.h>
#include <vector>
#include <string>
#include <utility>
#include <stdio.h>
#include <queue>
#include <fstream>
#include <functional>
#include <cstdlib>
#include <map>
#include <set>
#include <math.h>
#include <string.h>

using namespace std;

typedef pair<int, int> ii ;

typedef vector< ii >   vii ;

typedef vector<int> vi ;

typedef vector<vi> vvi; 

#define sz(a) int((a).size()) 

#define pb push_back 

#define all(c) (c).begin(),(c).end() 

#define tr(c,i) for(typeof((c).begin() i = (c).begin(); i != (c).end(); i++) 

#define present(c,x) ((c).find(x) != (c).end()) 

#define cpresent(c,x) (find(all(c),x) != (c).end()) 

#define INF 999999999
#define MAX_N 500005
#define MOD 1000000007


ifstream in; ofstream out;

int N, M, fenwick[MAX_N];

int arr1[MAX_N], arr2[MAX_N], c = 0;
int arr3[MAX_N];
vi g[MAX_N];

int dfs(int n){

    arr1[n] = c++;

    for(int i=0;i<g[n].size();i++)
        dfs(g[n][i]);

    arr2[n] = c;

}

int add(int x, int y){

    for(;x<=N;x += (x&(-x))) fenwick[x] += y;

}

int query(int x){

    int sum=0;

    for(;x;x -= x&-x) sum += fenwick[x];

    return sum;

}

int main() {
    
    #ifdef EVAL

    freopen("input.txt", "r", stdin);

    freopen("output.txt", "w", stdout);
    #endif
    
    scanf("%d %d %d",&N,&M,arr3);

    for(int i=1;i<N;i++){

        int temp;
        scanf("%d %d",arr3+i,&temp);temp--;
        g[temp].push_back(i);     
   
    }

    dfs(0);
    
    for(int i=0;i<M;i++){

        char s;
        scanf(" %c",&s);

       if(s=='p'){

            int a,aa; scanf("%d %d",&a,&aa);
            add(arr1[a-1]+1+1,aa);
            add(arr2[a-1]+1,-aa);
            
        }

    if(s=='u'){

            int a; scanf("%d", &a);
            printf("%d\n", query(arr1[a-1]+1)+arr3[a-1]);
    }
 }
    
    return 0;
}


