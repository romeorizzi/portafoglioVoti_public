#include <bits/stdc++.h>

/*
 * LA BATTAGLIA DEL CONVOGLIO
 * La strategia risolutiva utilizza il concetto di visita in profondità visita_dfs
 * La libreria stdc++.h richiama le principali librerie del c++, incluso vector.
 */

using namespace std;

vector<int> grafo[200000];
vector<int> ciclo;

int N; // numero di navi, corrisponde con il numero dei messaggi intercettati
int M; // numero di possibili corrispondenze tra messaggi e navi
int x[200000];
int corrispondenza[100000];

bool y[200000];

int visita_dfs(int n,int d){
    x[n] = d+1;
    y[n] = true;
    for(unsigned i = 0; i < grafo[n].size(); i++){
        if(y[grafo[n][i]]){
            ciclo.push_back(grafo[n][i]);
            int t = n;
            ciclo.push_back(t);
            while(t != grafo[n][i]){
                t = x[t]-1;
                ciclo.push_back(t);
            }
            return true;
        }
        if(x[grafo[n][i]]) continue;
        if(visita_dfs(grafo[n][i],n)) return true;
    }
    y[n] = false;
    return false;
}
int main(){
    // reindirizzo stdin e stdout rispettivamente su input.txt e output.txt
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    scanf("%d%d",&N,&M);

    for(int i = 0; i < M; i++){
        int a,b;
        scanf("%d%d",&a,&b);
        b += N;
        if(i < N) grafo[a].push_back(b);
        else grafo[b].push_back(a);
    }

    for(int i = 0; i < N; i++){
        while(i < N && x[i]) i++;
        if(i < N && visita_dfs(i,i)){
            for(unsigned i = 1; i < ciclo.size(); i++)
                if(ciclo[i-1] < N)
                    corrispondenza[ciclo[i-1]] = ciclo[i];
            for(int i = 0; i < N; i++)
                if(!corrispondenza[i])
                    corrispondenza[i]=grafo[i][0];
            for(int i = 0; i < N; i++) printf("%d %d\n",i,corrispondenza[i]-N);
            return 0;
        }
    }
    // se non esiste nessun altra corrispondenza possibile ritorno -1
    printf("-1\n");
    return 0;
}
