#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;

class Fenwick
{
private:
    vector<int> vt;
    int find(int v) { 
        return v & (-v); 
    }
public:
    Fenwick(int n) {
        vt.assign(n+1, 0); 
    }
    int rsq(int a){
        int sum = 0;
        for (;a; a -= find(a)) 
            sum += vt[a];
        return sum;
    }
    int getValue(int a){
        return rsq(a)-(a>1) ? rsq(a-1) : 0;
    }
    void adjust(int k, int v){
        for(;k < (int)vt.size();k += find(k)) 
            vt[k] += v;
    }
};

void dfs(int &currIdx, int currNode, vector<list<int> > &tree, vector<int> &idx, vector<int>&emps){
    idx[currNode] = currIdx++;

    for(list<int>::iterator i = tree[currNode].begin(); i != tree[currNode].end(); i++)
        dfs(currIdx, *i, tree, idx, emps);
    emps[currNode] = currIdx;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int N, M;
    vector<int> index;
    vector<list<int>> hierarchy;
    vector<int> emps;
    vector<int> wages;
    
    scanf("%d  %d", &N, &M);
    if(N > 500000 || N < 1)
        return 0;
    if(M > 500000 || M < 1)
        return 0;
    index.resize(N+1);
    hierarchy.resize(N+1);
    emps.resize(N+1);
    wages.resize(N+1);
    Fenwick f(N);

    scanf("%d", &wages[1]);
    
    for(int i = 2; i <= N; i++){
        int boss;
        scanf("%d  %d\n", &wages[i], &boss);
        hierarchy[boss].push_back(i);
        emps[boss]++;    
    }

    int currI = 1;

    dfs(currI, 1, hierarchy, index, emps);

    char c;
    for (int i = 0; i < M; i++){
        scanf("%c", &c);
        if(c == 'u'){
            int toCheck;
            scanf("%d\n", &toCheck);
            printf("%d\n", wages[toCheck] + f.rsq(index[toCheck]));   
        }
        if(c == 'p'){
            int boss, modifier;
            scanf("%d  %d\n", &boss, &modifier);
            f.adjust(index[boss]+1, modifier);
            f.adjust(emps[boss], -modifier);
        }    
    }
    return 0;
}

