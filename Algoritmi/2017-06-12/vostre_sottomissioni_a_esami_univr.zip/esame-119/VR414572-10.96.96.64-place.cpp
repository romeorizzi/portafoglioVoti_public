#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;
const int MAXN = 500005;

int s[MAXN], f[MAXN];
int a[MAXN], sef[MAXN];
vector<int> E[MAXN];

int timer = 0;
void dfs(int x)
{
    s[x] = timer++;
    for(int i=0; i<E[x].size(); ++i)
        dfs(E[x][i]);
    f[x] = timer;
}

int L[MAXN];
inline void add (int x,int y){
    for(++x; x<MAXN; x += x&-x)
    L[x] += y;
}

inline int sum(int x){
int r = 0;
    for(++x; x; x-= x&-x)
        r += L[x];
    return r;
}

int main(void){
    int n, m;
    FILE* fin = fopen("input.txt","r");
    FILE* fout = fopen("output.txt","w");
    fscanf(fin,"%d %d", &n, &m);
    fscanf(fin,"%d", a);
    for(int i = 1; i<n; ++i){
        fscanf(fin,"%d %d", a+i, sef+i ); --sef[i];
        E[sef[i]].push_back(i);
    }

    dfs(0);
    for(int i=0; i < m; ++i){
        char izbor[10];
        fscanf(fin,"%s",izbor);

        if(izbor[0] == 'p'){
            int a, x;
            fscanf(fin,"%d %d", &a, &x); --a;
            add(s[a]+1, +x);
            add(f[a], -x);        
        }
        if(izbor[0] == 'u'){
            int x;
            fscanf(fin,"%d", &x); --x;
            fprintf(fout,"%d\n",  a[x] + sum(s[x]) );
        }
    }

return 0;
}













