#include <fstream>
#include <iostream>
#include <cassert>
#include<vector>

using namespace std;

int n,m;
const int SIZE = 600000;

int s[SIZE];
int f[SIZE];
int a[SIZE];
int sef[SIZE];
int L[SIZE];
vector<int> E[SIZE];
int count =0;
inline void add(int x, int y);
inline int sum(int x);
int deep(int x);

int main(){

    int ret_val;
    ifstream fin("input.txt"); 
    assert(fin);
   
    ofstream fout("output.txt"); 
    assert(fout);
  
    fin >> n >> m;
    fin >> a[0];

    for(int i=1;i < n; i++){ 
        fin >> a[i] >> sef[i];
        sef[i]--;
        E[sef[i]].push_back(i);
    }

    deep(0);
    string res;
    for(int i=0; i<m; i++){
        char str[10];
        fin >> str;
        int x;
        
        switch(str[0]){

            case 'u':
                    fin >> x;
                    x--;
                    ret_val= a[x] + sum(s[x]);
                    fout << ret_val <<endl;
                    break;
            case 'p': 
                    int a;
                    fin >> a >> x;
                    a--;
                    add(f[a],-x);
                    add(s[a]+1,x); 
                    break;

        }



    }


    return 0;
}


inline void add(int x, int y){
    for(x++; x<SIZE; x+= x&-x)
        L[x]+=y;
}

inline int sum(int x){

    int sum=0;

    for(x++; x; x-= x&-x){
        sum+=L[x];
    }
    return  sum;

}

int deep(int x){

    s[x]=count++;

    for(int i =0;i <E[x].size();i++)
        deep(E[x][i]);
    f[x]=count;

}
