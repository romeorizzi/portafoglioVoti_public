#include<cstdlib>
#include<iostream>
#include<fstream>
#include<vector>
#include<list>

#define NO_CYCLE 0
#define CYCLE_FOUND 1
#define CYCLE_ENDED 2

using namespace std;

int N, M;

vector<vector<int> > adjList;

vector<int> touringCombo;

vector<bool> visited, is_ancestor;

int status = NO_CYCLE;
int cycle_root = 0;

void dfs(int current) {
    visited[current] = true;
    is_ancestor[current]=true;
    int matched = touringCombo[current];
    for(vector<int>::iterator it = adjList[matched].begin(); it != adjList[matched].end(); it++) {
        if(*it != current) {
            if(visited[*it] && is_ancestor[*it]) {
                status = CYCLE_FOUND;
                cycle_root = *it;
                touringCombo[*it] = matched;
                return;
            }
            if(!visited[*it]) {
                dfs(*it);
                if(status == CYCLE_FOUND) {
                    touringCombo[*it] = matched;
                    if(cycle_root == current)
                        status = CYCLE_ENDED;
                    return;
                }
                if(status == CYCLE_ENDED)
                    return;
            }
        }
    }
    is_ancestor[current]=false;
}

ifstream in("input.txt");
ofstream out("output.txt");

int main() {
    in >> N >> M;
    adjList.resize(N);
    touringCombo.resize(N);
    visited.resize(N, false);
    is_ancestor.resize(N, false);
    for(int i=0;i<M;i++) {
        int src, dst;
        in >> src >> dst;
        if(i<N)
            touringCombo[src] = dst;
        else
            adjList[dst].push_back(src);
    }

    for(int i=0;i<N;i++) {
        if(!visited[i])
            dfs(i);
        if(status == CYCLE_ENDED)
            break;
    }

    if(status == NO_CYCLE)
      out << -1 << endl;
    else {
        for(int i=0;i<N;i++) {
            out << i << " " << touringCombo[i] << "\n";
        }
        out << endl;
    }
    return 0;
}
