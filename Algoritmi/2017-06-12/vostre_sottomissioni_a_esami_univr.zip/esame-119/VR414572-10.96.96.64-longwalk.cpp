#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;
const int MAXN =100000;
const int MAXM =1000000;
int n,m;
const int TAIL=0, HEAD=1;
int out_d[MAXN+1], in_d[MAXN +1];
int arc[MAXM+1][2];
int f_out_nei[MAXN +2], out_nei[MAXM];
int f_in_nei[MAXN +2], in_nei[MAXM];
int LIFOsink[MAXN], LIFOpos=0;
bool removed[MAXN +1];
int max_from[MAXN +1], next[MAXN+1], max_so_far, max_start;

int main(void)
{
    std::ifstream fin("input.txt");
    fin >> n >> m;
    for(int i=0; i<=m; j++)
        next[i] = max_from[i] = out_d[i] = in_d[i] =0;
    for(int j=1; j<=m;j++){
        fin >> arc[j][TAIL] >> arc[j][HEAD];
        out_d[arc[j][TAIL]]++; in_d[arc[j][HEAD]]++;
    }
    fin.close();
    f_out_nei[1] = f_in_nei[1] =0;
    for(int i=1; i<=n;i++){
        f_out_nei[i+1] = f_out_nei[i] + out_d[i];
        f_in_nei[i+1] = f_in_nei[i] + in_d[i];
    }
    int c_out_nei[MAXN+1], c_in_nei[MAXN+1];
    for(int i=0;i<=n;i++){
        c_out_nei[i]=f_out_nei[i];
        c_in_nei[i]=f_in_nei[i];
    }
    for(int j=1; j<=m;j++){
        out_nei[c_out_nei[arc[j][TAIL]]++]=arc[j][HEAD]; 
        in_nei[c_in_nei[arc[j][HEAD]]++]=arc[j][TAIL];        
    }
return 0;
}
