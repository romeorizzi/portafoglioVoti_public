using namespace std;

#include <stdio.h>
#include <vector>
#define NN 2000000

vector<int> Grid[NN];
int N,M;
bool elders[NN];
int match[NN];
vector<int> Matrix;
int parents[NN];

int dfs(int n, int d)
{
    parents[n] = d+1;
    elders[n] = true;
    for (int  i = 0; i < Grid[n].size(); i++)
    {
        if (elders[Grid[n][i]])
        {
            Matrix.push_back(Grid[n][i]);
            int t = n;
            Matrix.push_back(t);

            while (t != Grid[n][i])
            {
                t = parents[t] -1;
                Matrix.push_back(t);
            }   
            return true;
        }
        if (parents[Grid[n][i]])
        {
            continue;
        }
        if (dfs(Grid[n][i], n))
        {
            return true;
        }
    }
    
    elders[n] = false;
    return false;
}

int main()
{
    FILE* fi = fopen ("input.txt", "r");
    fscanf(fi, "%d%d", &N, &M);
    for (int i = 0; i < M; i++)
    {
        int a,b;
        fscanf(fi, "%d%d", &a, &b);
        b += N;

        if (i < N)
        {
            Grid[a].push_back(b);
        }
        else
        {  
            Grid[b].push_back(a);
        }
    }

    fclose(fi);

    FILE* fo = fopen ("output.txt", "w");

    for (int i = 0; i < N; i++)
    {
        while (i < N && parents[i])
        {
            i++;
        }
        if (i < N && dfs(i,i))
        {
            for (int i = 1; i < Matrix.size(); i++)
            {
                if (Matrix[i-1] < N)
                {
                    match[Matrix[i-1]] = Matrix[i];   
                }
            }

            for (int i =0; i < N; i++)
            {
                if (!match[i])
                {
                    match[i] = Grid[i][0];
                }
            }

            for (int i = 0; i < N; i++)
            {
                fprintf(fo, "%d %d\n", i, match[i] - N);
            }
            
            fclose(fo);
            return 0;
        }
    }

    fprintf(fo, "-1\n");
    fclose(fo);
    return 0;
}
