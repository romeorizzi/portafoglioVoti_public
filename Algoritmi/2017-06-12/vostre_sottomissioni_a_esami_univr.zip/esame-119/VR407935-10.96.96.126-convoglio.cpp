
// Marco Panato VR407935

#include <cstdio>
#include <cassert>
#include <vector>

#ifndef EVAL
#define MYPRINT(x, ...) printf(x, ##__VA_ARGS__)
#else
#define MYPRINT(x, ...)
#endif

#define MAX_N 100000
#define MAX_M 200000

int N, M;

struct arco {
    int usato;
    int messaggio;
    int nave;
};

struct arco archi[MAX_M]; // salvo gli archi

std::vector<int> grafo[MAX_N]; // per ogni messaggio la lista degli INDICI degli archi!
int solTouring[MAX_N]; // per ogni M indico S corrispondente

// soluzione prova
int corrispondenza[MAX_N]; // la corrispondenza che sto costruendo -> PER OGNI M SCRIVO S
int naveInserita[MAX_N]; // mi dice se un messaggio è nella corrispondenza o no

int ugualeATouring() {
    MYPRINT("ugualeATouring() = ");
    for (int i = 0; i < N; ++i)
        if (solTouring[i] != corrispondenza[i]) {
            MYPRINT("false\n");
            return 0;
        }
    MYPRINT("true\n");
    return 1;
}

int collegaMessaggioAllaPos(int pos) {
    MYPRINT("collegaMessaggioAllaPos(%d)\n", pos);
    if (pos >= N) {
        return !ugualeATouring();
        // se ho trovato la sequenza di touring potrebbero essercene delle altre!
        // se invece ne ho trovata un'altra sono a posto
    }

    for (int i = 0; i < grafo[pos].size(); ++i) { // per ogni arco
        struct arco edge = archi[grafo[pos][i]];
        int nave = edge.nave;

        if (edge.usato == 0 &&  // se non ci sono passato
                naveInserita[nave] == 0) { // e la nave corrispondente non è già mappato

            corrispondenza[pos] = edge.nave; // provo a collegare questo arco
            archi[grafo[pos][i]].usato = 1;
            naveInserita[nave] = 1; // messaggio usato

            if (collegaMessaggioAllaPos(pos+1)) {
                // se la chiamata ricorsiva va bene ho un collegamento completo
                return 1;
            } else {
                // ritenta
                corrispondenza[pos] = -1;
                archi[grafo[pos][i]].usato = 0;
                naveInserita[nave] = 0;
            }
        } // else continue
    }
    return 0;
}


int main() {
    FILE *fi = fopen("input.txt", "r");
    assert(fi);

    fscanf(fi, "%d %d", &N, &M);

    for (int i = 0; i < M; ++i) {
        int v1, v2;
        fscanf(fi, "%d %d", &v1, &v2);

        archi[i].usato = 0;
        archi[i].messaggio = v1;
        archi[i].nave = v2;
        grafo[v1].push_back(i); // corretto!

        if (i < N) {
            solTouring[v1] = v2;
            naveInserita[i] = 0;
            corrispondenza[i] = -1;
        }
    }

    MYPRINT("Grafo\n");
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < grafo[i].size(); ++j)
            MYPRINT("%d ", grafo[i][j]);
        MYPRINT("\n");
    }

    MYPRINT("Archi\n");
    for (int i = 0; i < M; ++i) {
        struct arco edg = archi[i];
        MYPRINT("Arco %d: (usato: %d, messaggio: %d, nave: %d)\n",i, edg.usato, edg.messaggio, edg.nave);
    }

    int res = collegaMessaggioAllaPos(0);

    FILE *fo = fopen("output.txt", "w");
    assert(fo);

    if (res) {
        for (int i = 0; i < N; ++i) {
            fprintf(fo, "%d %d\n", i, corrispondenza[i]);
        }
    } else {
        fprintf(fo, "-1\n");
    }

    fclose(fo);
    return 0;
}
