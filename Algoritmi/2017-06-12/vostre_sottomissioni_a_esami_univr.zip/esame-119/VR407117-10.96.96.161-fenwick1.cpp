#include <stack>
#include <cstdio>
#include <vector>
#include <list>


using std::stack;
using std::vector;
using std::list;

class Fenwick
{
private:
vector<int> vt;
int L (int v) {return v & (-v);}
public:
Fenwick(int n) {vt.assign(n+1, 0); }
int rsq (int a)
{
int sum = 0;
for(; a; a -= L(a)) sum += vt[a];
return sum;
}
int getValue(int a)
{
return rsq(a) - (a>1) ? rsq(a-1) : 0;
}
void adjust(int k, int v)
{
for(; k< (int)vt.size(); k += L(k)) vt[k] += v;
}
};
void funzione (int &currIdx, int currnode, vector<list<int> > &tree, vector <int> &idx, vector<int> &sons)
{
idx[currnode] = currIdx++;
for(list<int>::iterator i = tree[currnode].begin(); i != tree[currnode].end(); i++)
funzione(currIdx, *i, tree, idx, sons);
sons[currnode] = currIdx++;
}

int main(){
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);

int N,M;
vector<int> index;
vector <list<int> > h;
vector<int> sons;
vector<int> wages;
scanf("%d %d", &N, &M);
index.resize(N+1);
h.resize(N+1);
sons.resize(N+1);
wages.resize(N+1);
Fenwick ft(N);

scanf("%d", &wages[1]);

for(int i = 2; i<=N; i++)
{
int nem;
scanf("%d %d\n", &wages[i], &nem );
h[nem].push_back(i);
sons[nem]++;
}
int curr = 1;
funzione(curr, 1, h, index, sons);
char c;

for(int i =0; i<M; i++)
{
scanf("%c", &c);
if (c== 'u')
{
int tocheck;
scanf("%d\n", &tocheck);
printf("%d\n", wages[tocheck] + ft.rsq(index[tocheck]));
}
if (c== 'p')
{ int nem, modifier;
scanf("%d %d\n", &nem, &modifier );
ft.adjust(index[nem]+1, modifier);
ft.adjust(sons[nem], -modifier);
}
}
return 0;
}

