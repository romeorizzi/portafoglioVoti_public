#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

using namespace std;

const int MAXN = 500005;

int s[MAXN], f[MAXN];
int a[MAXN], sef[MAXN];
vector<int> E[MAXN];

int timer = 0;

void dfs(int x) {
    s[x] = timer++;
    for (int i = 0; i < E[x].size(); ++i)
        dfs(E[x][i]);
    f[x] = timer;
}

int L[MAXN];
inline void add(int x, int y) {
    for (++x; x < MAXN; x += x&-x)
        L[x] += y;
}

inline int sum(int x) {
    int r = 0;
    for (++x; x; x -= x&-x)
        r += L[x];
    return r;
}

int main() {
    int n, m;

    ifstream in;
    in.open("input.txt");
    ofstream out("output.txt");

    if (in.is_open()){
        in >> n;
        in >> m;
        in >> a[0];
        for (int i = 1; i < n; ++i) {
            in >> a[i];
            in >> sef[i];
            --sef[i];
            E[sef[i]].push_back(i);
        }

        dfs(0);
        for (int i = 0; i < m; ++i) {
            char izbor[10];
            in >> izbor;

            if (izbor[0] == 'p') {
                int a, x;
                in >> a;
                in >> x;
                --a;
                add(s[a] + 1, +x);
                add(f[a], -x);
            }

            if (izbor[0] == 'u') {
                int x;
                in >> x;
                --x;
                out << a[x] + sum(s[x]) << endl;            
            }
        }


    }
    out.close();
    in.close();
    return 0;
}

