#include <cstdio>
#include <vector>
#include <list>
#include <utility>
#include <set>

#define MAX 100000

using namespace std;

int N,M;
list<int> lista[2*MAX];
bool checked[2*MAX];
bool confirmed[MAX];

FILE* in = fopen("input.txt","r");
FILE* out = fopen("output.txt","w");


int search(int x)
{
    if(checked[x])
    {
        if(x < MAX) return 1;
        else return 0;
    }
    
    checked[x] = true;
    int check = 0;

    for(list<int>::iterator i = lista[x].begin(); i != lista[x].end(); i++)
    {
        check = search(*i);
        if(check == true && x >= MAX) 
        {
            fprintf(out,"%d %d\n", *i, x-MAX);
            confirmed[*i] = true;
        } 
       
        if(check == true && x < MAX && confirmed[x])
        {
            check = 2;
        }

        if(check)
        {
            checked[x] = false;
            return check;
        }
    }

    checked[x] = false;
    return check;
}

int main()
{
    fscanf(in,"%d %d", &N, &M);
    int x,y;
    bool check = false;

    for(int i = 0; i < N; i++)
    {
        fscanf(in,"%d %d", &x, &y);
        y += MAX;
        lista[x].push_back(y);
    }
        
    for(int i = N; i < M; i++)
    {
        fscanf(in,"%d %d", &x, &y);
        y += MAX;
        lista[y].push_back(x);
    }

    for(int i = 0; i <N && !check; i++)
    {
        check = search(i);
    }
        
    if(!check) 
    {
        fprintf(out,"-1\n");
    }
    else 
    {
        for(int i = 0; i < N; i++)
        {
            if(!confirmed[i]) 
            {
                fprintf(out,"%d %d\n", i, lista[i].front()-MAX);        
            }
        }
    }

    return 0;
}
