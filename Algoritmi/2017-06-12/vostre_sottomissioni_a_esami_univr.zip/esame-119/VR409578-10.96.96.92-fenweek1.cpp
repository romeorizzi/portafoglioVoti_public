#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>

using namespace std;

const int MAXN =  500005;

int sommatorie[MAXN], sommatoriaV2[MAXN];
int dipendenti[MAXN], sef[MAXN];
vector<int> graph[MAXN];

int prof = 0;

void valutateProf(int x){
    sommatorie[x] = prof++;
    for(int i=0; i < graph[x].size(); ++i)
        valutateProf(graph[x][i]);
    sommatoriaV2[x] = prof;
}

int pesi[MAXN];

inline void add(int x, int y){
    for(++x; x<MAXN; x+=x&-x) 
        pesi[x] += y;
}

inline int sum(int x){
    int r = 0;
    for(++x; x; x-=x&-x)
        r+=pesi[x];
    return r;
}

int main( void ){
    freopen("input.txt", "r", stdin);  
    freopen("output.txt", "w", stdout);  
 
    int n, m;
    int a2, x2;

    scanf("%d %d", &n, &m);
    scanf("%d", dipendenti + 0);

    for(int i = 1; i<n; ++i){
        scanf("%d %d", dipendenti+i, sef+i);
        --sef[i];
        graph[sef[i]].push_back(i);
    }

    valutateProf(0);

    for (int i=0; i < m; ++i){
        char comando[10];
        scanf("%s", comando);

        if (comando[0] == 'p' ){
            scanf("%d %d", &a2, &x2);
            --a2;
            add(sommatorie[a2]+1, +x2);
            add(sommatoriaV2[a2], -x2);
        }

        if (comando[0] == 'u' ){
            scanf("%d",&x2);
            --x2;
            printf("%d\n", dipendenti[x2] + sum(sommatorie[x2]));
        }
    }
    
    return 0;
}
