#include <cstdio>
#include <vector>

using namespace std;


vector<int> grafo[200000];
int N, M;

int genitori[200000];
bool superioreBool[200000];

vector<int> ciclo2valutare;

int associazioneOK[100000];

int dfs(int n, int d){
    genitori[n] = d+1;
    superioreBool[n] = true;
    

    for(unsigned i = 0; i < grafo[n].size(); i++){
        
        if (superioreBool[grafo[n][i]]){
            ciclo2valutare.push_back(grafo[n][i]);
            int t = n;
            ciclo2valutare.push_back(t);

            while(t != grafo[n][i]){
                t = genitori[t]-1;
                ciclo2valutare.push_back(t);
            }

            return true;
        }
        
        if(genitori[grafo[n][i]]) continue;
        if(dfs(grafo[n][i], n)) return true;

    }

    superioreBool[n] = false;
    return false;
}
   
int main(){ 
    freopen("input.txt", "r", stdin);  
    freopen("output.txt", "w", stdout);  

    scanf("%d%d", &N, &M);
    
    for(int i = 0; i < M; i++){
        int a, b;
        scanf("%d%d", &a, &b);

        b += N;
        if(i<N) grafo[a].push_back(b);
        else grafo[b].push_back(a);
    }
    


    for (int i = 0; i < N; i++){
        
        while(i < N && genitori[i]) i++;
        
        if(i<N && dfs(i, i)){
            
            for (unsigned i = 1; i < ciclo2valutare.size(); i++)
                if(ciclo2valutare[i-1]<N)
                    associazioneOK[ciclo2valutare[i-1]] = ciclo2valutare[i];
            
            for (int i = 0; i < N; i++)
                if (!associazioneOK[i])
                    associazioneOK[i] = grafo[i][0]; 
            for (int i = 0; i < N; i++)
                printf("%d %d\n", i, associazioneOK[i]-N);
            return 0;
            
        }
    }
    

    printf("-1\n");
    return 0;        
}
