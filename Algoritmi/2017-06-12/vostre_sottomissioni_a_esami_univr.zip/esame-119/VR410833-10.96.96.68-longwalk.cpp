#define NDEBUG
#include <cassert>
#ifndef NDEBUG
#include <iostrem>
#endif
#include <fstream>

using namespace std;

const int MAX_N = 100000; int n;
const int MAX_M = 1000000; int m;
const int TAIL = 0, HEAD = 1;

int out_deg[MAX_N + 1], in_deg[MAX_N +1];
int arc[MAX_M + 1][2];
int first_out_nei[MAX_N + 2], out_nei[MAX_M];
int first_in_nei[MAX_N + 2], in_nei[MAX_M];
int LIFOsick[MAX_N], LIFOpos = 0;
bool removed[MAX_N + 1];
int max_from[MAX_N + 1], next[MAX_N + 1], max_so_far, max_start;

int main() {
    ifstream fin("input.txt"); assert(fin);
    fin >> n >> m;
    for(int i = 0; i <= n; i++) {
        next[i] = 0; max_from[i] = out_deg[i] = in_deg[i] = 0;
        
    }
    for(int j = 1; j <= m; j++) {
        fin >> arc[j][TAIL] >> arc[j][HEAD];
        ou_deg[arc[j][TAIL]]++; in_deg[arc[j][HEAD]]++;
    }
    fin.close();
    
    first_out_nei[1] = first_in_nei[1] = 0;
    for(int i = 1; i <= ; i++) {
        first_out_nei[i + 1] = first_out_nei[i] + out_deg[i];
        first_in_nei[i + 1] = first_in_nei[i] + in_deg[i];
    }
    int cur_out_nei[MAX_N + 1], cur_in_nei[MAX_N + 1];
    
    for(int j = 1; j<=m ; j++) {
        out_nei[cur_out_nei[arc[j][TAIL]]++] = arc[j][HEAD];
        in_nei[cur_in_nei[arc[j][TAIL]]++] = arc[j][HEAD];
    }

    
    for(int i = 1; i<=n ; i++) {
      remove[i] = false;
      if(out_deg[i] == 0) LIFOsick[LIFOpos++] = i;
    }    
    int n_removed = 0;
    
    
    while(LIFOpos) {
        int v =LIFOsick[--LOFOpos];
        removed[v] = true; n_removed ++;
        for(int i = first_out_nei[v]; i < first_out_nei[v + 1]; i++) {
            if(max_from[ out_nei[i]] >= max_from[v]) {
                max_from[v] = max_from[out_nei[i]] + 1;
                next[v] = out_nei[i];
                if(max_from[v] > max_so_far) {
                    max_so_far = max_from[v]; max_start = v;
                } 
            }
         }
         for(int i = first_out_nei[v]; i < first_out_nei[v + 1]; i++) {
            out_deg[in_nei[i]]--;
            if(out_deg[in_nei[i]] == 0)
                LIFOsick[ LIFOpos++] = in_nei[i];
         }
    }
    ofstream fout("output.txt"); assert(fout);
    if(n_removed == n) {
        fout << max_so_far << endl;
        int v = max_start;
        while(v) {
            fout << v << "";
            v = next[v];
        }
    } else {
       fout << -1 << endl;
       bool visited[MAX_IN + 1];
       for(int i = 1; i <= n ; i++) visited[i] = false;
       
       int v = 1;
       while(removed[v]) v++;
       while( !visited[v]) {
            visited[v] = true;
             for(int i = first_out_nei[v]; i < first_out_nei[v + 1]; i++) {
                if(!removed[out_nei[i]]) {
                    next[v] = out_nei[i];
                }
             
             }
            v = next[v];
       }
       int u = v;
       do {
        fout << u << "";
        u = next[u];
       } while(u != v);
    
    }
    fout.close();
    
    return 0;
}



