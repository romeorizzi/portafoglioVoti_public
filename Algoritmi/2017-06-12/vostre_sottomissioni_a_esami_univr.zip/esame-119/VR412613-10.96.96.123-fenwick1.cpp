#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;

vector<int> vett;

int one(int v){
    return v & (-v);
}

int rsq(int a){
    int sum = 0;
    for (; a; a-=one(a))
        sum += vett[a];
    return sum;
}

void adjust(int k, int v){
    for (; k < vett.size(); k+=one(k))
        vett[k] += v;
}

void preproc(int &indicecorr, int nodocorr, vector<list<int> > &tree, vector<int> &indice, vector<int> &sons){
    indice[nodocorr] = indicecorr++;

    for (list<int>::iterator i=tree[nodocorr].begin(); i!=tree[nodocorr].end(); i++)
        preproc(indicecorr, *i, tree, indice, sons);

    sons[nodocorr] = indicecorr;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int N,M;
    vector<int> index;
    vector<list<int> > ger;
    vector<int> sons;
    vector<int> w;

    scanf("%d %d", &N, &M);

    index.resize(N+1);
    ger.resize(N+1);
    sons.resize(N+1);
    w.resize(N+1);

    vett.assign(N+1, 0);

    scanf("%d", &w[1]);

    for (int i=2; i<=N; i++){
        int b;
        scanf("%d %d\n", &w[i], &b);
        ger[b].push_back(i);
        sons[b]++;
    }

    int currI = 1;

    preproc(currI, 1, ger, index, sons);

    char c;

    for (int i=0; i<M; i++){
        scanf("%c", &c);
        if (c =='u'){
            int ctrl;
            scanf("%d\n", &ctrl);
            printf("%d\n", w[ctrl] + rsq(index[ctrl]));
        }
        if (c == 'p'){
            int b, m;
            scanf("%d %d\n", &b, &m);
            adjust(index[b]+1, m);
            adjust(sons[b], -m);

        }
    }
    return 0;
}
