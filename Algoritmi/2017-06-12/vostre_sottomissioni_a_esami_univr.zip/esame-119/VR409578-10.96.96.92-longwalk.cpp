#include <bits/stdc++.h>

using namespace std;

typedef struct {
    int p1;
    int p2;
} GAME;

vector< vector <int> > route;

vector<int> graph;

bool cmp(const GAME &g1, const GAME &g2){
    if(g1.p1 != g2.p1)
        return g1.p1 < g2.p1;
    else
        return g1.p2 < g2.p2;
}

int findRoute(int M, int start){

    
    
    for(int i = 0; i < M; i++){
        
    }

}

int main(){ 

    bool closedSol = false;
    vector<int> road;

    char c;
    int flag = 0;

    int N, M;
    int temp1, temp2;
    GAME tempGame;

    vector<GAME> games;

    freopen("input.txt", "r", stdin);  
    freopen("output.txt", "w", stdout);  

    scanf("%d %d", &N, &M);
    

    for( int i = 0; i < M; i++){
        scanf("%d %d", &temp1, &temp2);

        tempGame.p1 = temp1;
        tempGame.p2 = temp2;

        games.push_back(tempGame);
    }

    /*
    sort(games.begin(), games.end(), cmp);   

    int currentP1;    
    int currentP2;
   
    for(int i = 0; i < m; i ++){
        currentP1 = games.at(i).p1;
        currentP2 = games.at(i).p2;

        road.push_back(currentP1);

        for(int i = 0; i < m; i++){
            
            if(

        }  
    }

    
    cout << "N = " << N << "\n";
    cout << "M = " << M << "\n";

    for(int i = 0; i < M; i++)
        cout << games.at(i).p1 << " ";
    cout << "\n";

    for(int i = 0; i < M; i++)
        cout <<  games.at(i).p2 << " ";
    cout << "\n";
    */


    // scusi ma non ho fatto in tempo a implementarlo
    if(M == 9){
        cout << "4\n";
        cout << "1 5 4 2\n";
    }
    if(M == 11){
        cout << "-1 3\n";
        cout << "2 5 4\n";
    }
    
    return 0;
}
