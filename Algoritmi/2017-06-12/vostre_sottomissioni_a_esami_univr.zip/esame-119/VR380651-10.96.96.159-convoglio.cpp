#include<cstdio>
#include<vector>
#include<list>
#include<set>
#include<utility>
#include<assert.h>

using namespace std;

int N,M;
list<int> grafo[2*100000];
bool visitato[2*100000];
bool scritti[100000];


int dfs(int c){

    if(visitato[c]){
        if(c < 100000) return 1;
        else return 0;    
    }
    visitato[c] = true;

    int trovato = 0;
    
    for(list<int>::iterator i= grafo[c].begin(); i!=grafo[c].end(); i++){
        trovato = dfs(*i);
        if(trovato == 1 && c >= 100000){
            printf("%d %d\n", *i, c-100000);
            scritti[*i] = 1;
        }
        if(trovato ==1 && c<100000 && scritti[c]){
            trovato = 2;
        }
        if(trovato){
            visitato[c] = 0;
            return trovato;
        }
    }

    visitato[c] = false;
    return trovato;

}



int main(){

   freopen("input.txt", "r", stdin);
   freopen("output.txt", "w", stdout);

    scanf("%d ", &N);
    assert(N<=1000000);

    scanf("%d ", &M);
    assert(N<=200000);

    for(int i=0; i<N; i++){
        int h,t;
        scanf("%d %d", &h, &t);
        t +=100000;
        grafo[h].push_back(t);
    }

    for(int i=N; i<M; i++){
        int h,t;
        scanf("%d %d", &h, &t);
        t +=100000;
        grafo[t].push_back(h);
    }
    
    bool trovato=false;


    for(int i=0; i<N && !trovato;i++){
        trovato = dfs(i);
    }

    if(!trovato) printf("%d\n", -1);
    else{
        for(int i=0; i<N; i++){
            if(!scritti[i]){
                printf("%d %d\n", i, grafo[i].front()-100000);
            }
        }
    }

   return 0;  
}
