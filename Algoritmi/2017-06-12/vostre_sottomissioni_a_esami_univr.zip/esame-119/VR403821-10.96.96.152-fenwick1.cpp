#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;

class FWTree {
private:
	vector<int> vt;
	
	int LSOne(int v) { 
		return v & (-v); 
	}
	
public:
	FWTree(int n){ 
		vt.assign(n+1, 0); 
	}
	
	int rsq(int a){
		int sum = 0;
		for(; a; a-= LSOne(a))
			sum += vt[a];
		return sum;
	}
	
	int getValue(int a){
		return rsq(a) - (a > 1) ? rsq(a-1) : 0;
	}
	
	void adjust(int k, int v){
		for(;k < (int)vt.size(); k += LSOne(k))
			vt[k] += v;
	}
};

void preproc(int &currIdx, int currNode, vector< list<int> > &tree, vector<int> &idx, vector<int> &sons){
	idx[currNode] = currIdx++;
	
	for(list<int>::iterator i = tree[currNode].begin(); i != tree[currNode].end(); i++){
		preproc(currIdx, *i, tree, idx, sons);
	}
	
	sons[currNode] = currIdx;
}

int main(){
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	
	int n, m;
	vector<int> index, subordinates, wages;
	vector< list<int> > hierarchy;
	
	scanf("%d %d", &n, &m);
	
	index.resize(n+1);
	hierarchy.resize(n+1);
	subordinates.resize(n+1);
	wages.resize(n+1);
	FWTree ft(n);
	
	scanf("%d", &wages[1]);
	
	for(int i = 2; i <= n; i++){
		int boss; 
		scanf("%d %d\n", &wages[i], &boss);
		hierarchy[boss].push_back(i);
		subordinates[boss]++;
	}
	
	int currI = 1;
	
	preproc(currI, 1, hierarchy, index, subordinates);
	
	char c;
	for(int i = 0; i < m; i++){
		scanf("%c", &c);
		if(c == 'u'){
			int toCheck;
			scanf("%d\n", &toCheck);
			printf("%d\n", wages[toCheck] + ft.rsq(index[toCheck]));
		}
		if(c == 'p'){
			int boss, modifier;
			scanf("%d %d \n", &boss, &modifier);
			ft.adjust(index[boss]+1, modifier);
			ft.adjust(subordinates[boss], -modifier);
		}
	}
	return 0;	
}
