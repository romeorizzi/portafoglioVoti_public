#include <bits/stdc++.h>

using namespace std;

int N, M;
int msg,ship;

vector<int> g [200000];
vector<int> c;
bool hp[200000];
int p[200000];
int t[100000];

ifstream in("input.txt");
ofstream out("output.txt");

void pb(int i, int n){
    int t = n;
    while ( t != g[n][i] ){
        t = p[t]-1;
        c.push_back(t);
    }
}

int visita(int n,int pp){
    p[n] = pp+1;
    hp[n] = true;
    for (int i=0; i<g[n].size(); i++){
        if ( hp[g[n][i]] ){
            c.push_back(g[n][i]);
            int t = n;
            c.push_back(t);
            pb(i, n);
            return true;
        }
        if ( p[g[n][i]] )
            continue;
        if ( visita(g[n][i],n) )
            return true;
    }
    hp[n] = false;
    return false;
}



void s(bool b){
    if (!b){
        out << "-1\n";
        return;
    }

    for( int i=0; i<N; i++ )
        out << i << " " << (t[i]-N) << "\n";
}

int main(){

    in >> N;
    in >> M;

    for (int i=0; i<M; i++){

        in >> msg;
        in >> ship;

        ship+=N;

        if(i<N){
            g[msg].push_back(ship);
        }
        else{
            g[ship].push_back(msg);
        }
    }

    for(int i=0; i<N; i++){
        for ( ; i<N && p[i]; i++);

        if ( i<N && visita(i,i) ){
            for ( int i=1; i<c.size(); i++ )
                if( c[i-1]<N )
                    t[c[i-1]] = c[i];
            for( int i=0;i<N;i++ )
                if( !t[i] )
                    t[i] = g[i][0];

            s(true);

            return 0;
        }
    }

    s(false);

    return 0;
}

