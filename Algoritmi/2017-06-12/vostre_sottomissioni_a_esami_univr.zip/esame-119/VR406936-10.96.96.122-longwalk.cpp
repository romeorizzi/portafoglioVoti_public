#include <bits/stdc++.h>
using namespace std;

#define NUM_GIOCATORI 100000
#define NUM_PARTITITE 1000000
vector<int> grafo[NUM_GIOCATORI];
int N;

vector<int> marcati(NUM_GIOCATORI,0);
vector<int> padre(NUM_GIOCATORI,-1);

void dfs_visit(int pos);
void dfs();

void dfs()
{
    for (int i = 0; i < N; ++i)
    {
        if (marcati[i] == 0)
            dfs_visit(i);
    }
}

void dfs_visit(int pos)
{
    marcati[pos] = 1;
    for ( auto v : grafo[pos] )
    {
        if( marcati[v] == 1 )
        {
            // trovato ciclo
            int y = pos;
            vector<int> ciclo;
            while ( y != v)
            {
                ciclo.push_back(y);
                y = padre[y];
            }
            ciclo.push_back(v);

            cout << "-1 " << ciclo.size() << "\n";
            for (int x = ciclo.size()-1; x >= 0; --x)
            {
                cout << ciclo[x] << " ";
            }
            cout << "\n";
            exit(0);
        }
        if( marcati[v] == 0 )
        {
            padre[v] = pos;
            dfs_visit(v);
        }
    }
    marcati[pos] = 2;
}

vector<int> memoiz(NUM_GIOCATORI,-1);
int max_value = -1;
int max_pos = -1;

int peso( int x )
{
    if  (memoiz[x] != -1 )
        return memoiz[x];

    int local_max=0;
    for ( auto v : grafo[x] )
    {
        local_max = max(local_max, peso(v));
    }
    memoiz[x] = local_max +1;
    if ( max_value < memoiz[x] )
    {
        max_value = memoiz[x];
        max_pos = x;
    }
    return memoiz[x];
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    // costruisci il grafo

    int M;
    cin >> N  >> M;

    for(int i = 0; i < M; ++i)
    {
        int a,b;
        cin >> a >> b;
        grafo[a].push_back(b);
    }

    // trova un ciclo con DFS
    dfs();

    // DAG

    for ( int i = 0; i < NUM_GIOCATORI; ++i)
    {
        peso(i);
    }

    cout << max_value << "\n";
    
    for ( int i = 0; i < max_value; ++i)
    {
        cout << max_pos << " ";
        for ( auto v : grafo[max_pos])
        {
            if (peso(v) == (max_value -i -1))
            {
                max_pos = v;
                break;
            }
        }
    }
    cout << "\n";

	return 0;
}
