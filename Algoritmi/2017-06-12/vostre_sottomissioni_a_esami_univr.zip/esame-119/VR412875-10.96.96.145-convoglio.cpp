#include <cstdio>
#include <vector>
#include <list>
#include <set>
#include <utility>

#define MAX 100000

using namespace std;

int N,M;
list<int> grafo[2*MAX];
bool visitato[2*MAX];
bool scritto[MAX];

int dfs(int c) {
  
  if (visitato[c]) {
    if (c < MAX) {
      return 1;
    } else {
      return 0;
    }
  }
  
  visitato[c] = true;
  int trovato = 0;
  for (list<int>::iterator i = grafo[c].begin(); i != grafo[c].end(); i++) {
    
    trovato = dfs(*i);
    
    if (trovato == 1 && c >= MAX) {
      printf("%d %d\n", *i, c-MAX); scritto[*i] = 1;
    }
    
    if (trovato == 1 && c < MAX && scritto[c]) {
      trovato = 2;
    }
    
    if (trovato) {
      visitato[c] = 0; return trovato;
    }
  }

  visitato[c] = false;
  return trovato;
}

int main() {
  freopen("input.txt", "r", stdin);
  #ifdef EVAL
  freopen("output.txt", "w", stdout);
  #endif

  scanf("%d %d", &N, &M);
  
  for (int i = 0; i < N; i++) {
    int h, t;
    scanf("%d %d", &h, &t); t += MAX;
    grafo[h].push_back(t);
  }

  for (int i = N; i < M; i++) {
    int h, t;
    scanf("%d %d", &h, &t); t += MAX;
    grafo[t].push_back(h);
  }
  
  bool trovato = false;
  for (int i = 0; i < N && !trovato;i++) {
     trovato = dfs(i);
  }

  if (!trovato) {
    printf("-1\n");
  } else {
    for (int i = 0; i < N; i++) {
      if (!scritto[i]) {
        printf("%d %d\n", i, grafo[i].front() - MAX);
      }
    }
  }

  return 0;
}
