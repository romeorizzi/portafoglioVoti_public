#define DEBUG
#include <cassert>
#ifndef DEBUG
#   include <iostream>
#endif
#include <fstream>

using namespace std;

const int MAX_N = 100000;
const int MAX_M = 1000000;
int n, m;
const int TAIL = 0;
const int HEAD = 1;

int out_deg[MAX_N + 1];
int in_deg[MAX_N + 1];
int arc[MAX_M + 1][2];
int first_out[MAX_N + 2];
int out[MAX_M];
int first_in[MAX_N + 2];
int in[MAX_M];
int sink[MAX_N];
int pos = 0;
bool removed[MAX_N + 1];
int max_from[MAX_N + 1];
int next[MAX_N + 1];
int max_so_far, max_start;

int main(){
    
    ifstream fin("input.txt");
    fin >> n >> m;

    for(int i = 0; i <= n; i++){
        next[i] = max_from[i] = out_deg[i] = in_deg[i] = 0;
    }
    for(int j = 0; j <= m; j++){
        fin >> arc[j][TAIL] >> arc[j][HEAD];
        out_deg[ arc[j][TAIL] ]++;
        in_deg[ arc[j][HEAD] ]++;
    }

    fin.close();

    first_out[1] = first_in[1] = 0;
    for(int i = 0; i <= n; i++){
        first_out[i+1] = first_out[i] + out[i];
        first_in[i+1] = first_in[i] + in[i];
    }

    int cur_out[MAX_N + 1], cur_in[MAX_N + 1];
    for(int i = 0; i <= n; i++){
        cur_out[i] = first_out[i];
        cur_in[i] = first_in[i];
    }
    for(int j = 1; j <= m; j++){
        out[ cur_out[ arc[j][TAIL] ]++ ] = arc[j][HEAD];
        in[ cur_in[ arc[j][HEAD] ]++ ] = arc[j][TAIL];
    }

    for(int i = 1; i <= n; i++){    
        removed[i] = false;
        if(out[i] == 0) sink[pos++] = i;
    }

    int n_removed = 0;

    while(pos){
    
        int v = sink[--pos];
        removed[v] = true;
        n_removed++;

        for(int i = first_out[v]; i < first_out[v+1]; i++){
            if(max_from[ out[i] ] >= max_from[v]){
                max_from[v] = max_from[ out[i] ] + 1;
                next[v] = out[i];
                if(max_from[v] > max_so_far){
                    max_so_far = max_from[v];
                    max_start = v;
                }
            }
        }
                 
        for(int i = first_in[v]; i < first_in[v+1]; i++){
            out_deg[ in[i] ]--;
            if(out_deg[ in[i] ] == 0){
                sink[pos++] = in[i];
            }
        }

    }

    ofstream fout("output.txt");

    if(n_removed == n){
        fout << max_so_far << endl;
        int v = max_start;
        while(v){
            fout << v << " ";
            v = next[v];
        }
    }
    else{
        fout << -1 << endl;
        bool visited[MAX_N + 1];
        for(int i = 1; i <= n; i++) visited[i] = false;
        int v = 1; 
        while(removed[v]) v++;
        while(!visited[v]){
            visited[v] = true;
            for(int i = first_out[v]; i < first_out[v+1]; i++){
                if(!removed[ out[i] ]){
                    next[v] = out[i];
                }
            }
            v = next[v];
        }
        int u = v;

        do {
            fout << u << " ";
            u = next[u];
        } while(u != v);
    }

    fout.close();
    return 0;

}























