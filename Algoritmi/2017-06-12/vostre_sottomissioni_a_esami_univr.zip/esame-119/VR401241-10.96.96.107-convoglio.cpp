#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>

using namespace std;

#define N_MIN 0
#define N_MAX 100000

#define M_MIN 0
#define M_MAX 200000

struct corrispondenza {
    int m;
    int n;
};

int N;
int M;
int R;
int turing[3000];
corrispondenza corr[2 * 3000];
bool m[3000][3000] = {false};
int uni[3000];

void stampa_t();
void stampa_c();
void stampa_m();

int main(int argc, char ** argv) {
    ifstream in("input.txt");
    ofstream out("output.txt");

    in >> N >> M;
    R = M - N;
    for(int i = 0; i < N; i++) {
        int messaggio, nave;
        in >> messaggio >> nave;
        turing[messaggio] = nave;
        m[messaggio][nave] = true;
        uni[i] = 1;
    }
    for(int i = 0; i < R; i++) {
        corrispondenza c;
        in >> c.m >> c.n;
        corr[i] = c;
    }

    /*
    cout << N << " " << M << endl << endl;
    stampa_t();
    stampa_c();
    stampa_m();
    */

    bool b = true;
    int v = 0;
    for(int i = 0; i < R && b; i++) {
        corrispondenza c = corr[i];
        int messaggio = c.m;
        int nave = c.n;
        int nave_t = turing[messaggio];
        // cout << "m = " << messaggio << ", n = " << nave << ", nt = " << nave_t << endl;
        m[messaggio][nave] = true;
        m[messaggio][nave_t] = false;

        uni[nave]++;
        uni[nave_t]--;
        b = false;
        v = 0;
        for(int j = 0; j < N; j++) {
            // cout << uni[j] << " ";
            if(uni[j] > 1) {
                b = true;
                v = -1;
            }
        }
        // cout << endl << endl;

        // stampa_m();
    }

    if(v == -1) {
        // cout << "-1" << endl;
        out << "-1" << endl;
    }
    else {
        for(int i = 0; i < N; i++) {
            for(int j = 0; j < N; j++) {
                if(m[i][j]) {
                    // cout << i << " " << j << endl;
                    out << i << " " << j << endl;
                }
            }
        }
    }
    
    in.close();
    out.close();

    return 0;
}

void stampa_t() {
    for(int i = 0; i < N; i++)
        cout << i << " " << turing[i] << endl;
    cout << endl;
}

void stampa_c() {
    for(int i = 0; i < R; i++)
        cout << corr[i].m << " " << corr[i].n << endl;
    cout << endl;
}

void stampa_m() {
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < N; j++)
            cout << m[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}



