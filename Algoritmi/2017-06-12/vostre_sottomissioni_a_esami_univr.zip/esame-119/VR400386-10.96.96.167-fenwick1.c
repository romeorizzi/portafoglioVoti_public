#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SALARY      0
#define SUPERVISOR  1

int main () {

    FILE *fp = fopen("input.txt","r");

    int employees,operations,supervisor,salary,unit;

    // Leggo la prima riga col numero di impiegati e di operazioni.
    fscanf(fp,"%d %d",&employees,&operations);

    // Creo una matrice dove mi salverò impiegati, superiori e salari.
    int matrix[employees+1][2];

    // Il primo lo faccio a parte perché è il capo, che ha solo il salario e zero superiori.
    fscanf(fp,"%d",&matrix[1][SALARY]);
    // Quindi gli imposto il superiore a -1.
    matrix[1][SUPERVISOR] = -1;
    
    // Passo le prime righe per memorizzare gli impiegati e i loro supervisori e salari.
    for (int counter = 2; counter <= employees; counter++)
        fscanf(fp,"%d %d",&matrix[counter][SALARY],&matrix[counter][SUPERVISOR]);

    // Apro il file dove dovrei andare a stampare.
    FILE *fp_output = fopen("output.txt","w");

    // Creo un array di dimensione employees dove andrò a salvarmi i vari supervisori di volta in volta trovati.
    int supsArray[employees];
    
    // Fatto questo allora noi dobbiamo andare ad eseguire le operazioni in programma.
    // Il mio puntatore dovrebbe essere a questo punto sulla prima riga delle operazioni.
    for (int counter = 0; counter < operations; counter++){
        // Creo un carattere che mi legga il primo carattere della riga.
        // Faccio due volte per eliminare il newline.
        char c = getc(fp);
        // Se il carattere è p faccio l'operazione 1, altrimenti eseguo la 2.
        if (c = getc(fp) == 'p'){
            fscanf(fp,"%d %d",&supervisor,&salary);
            if (supervisor == 1){
                for (int i = 2; i <= employees; i++){
                    matrix[i][SALARY] += salary;
                }
            }
            else {
                // Creo un intero per scorrere l'array. Punta alla prima cella libera (o al numero di valori salvati).
                int supsArrayCounter = 1;
                // Salvo il valore di supervisor nell'array.
                supsArray[0] = supervisor;
                // Creo un ciclo for partendo dal supervisore, sapendo che potrò trovare sottoposti solo successivamente.
                for (int k = supervisor + 1; k <= employees; k++){
                    // Se il supervisore sta in supsArray aggiusto il salario e lo aggiungo alla coda.
                    for (int k2 = (supsArrayCounter - 1); k2 >= 0; k2--){
                        if (matrix[k][SUPERVISOR] == supsArray[k2]){
                            // Aggiusto il salario.
                            matrix[k][SALARY] += salary;
                            // Aggiungo alla coda.
                            supsArray[supsArrayCounter] = k;
                            // Incremento il contatore.
                            supsArrayCounter++;
                            // Esco dal ciclo.
                            break;
                        }
                    }
                }
            }
        }
        // Il carattere non è p, allora è u e quindi eseguo l'operazione 2.
        else{
            //int unit;
            fscanf(fp,"%d",&unit);
            fprintf(fp_output,"%d\n",matrix[unit][SALARY]);
        }
    }

    // Chiudo il file di input.
    fclose(fp);
    // Chiudo il file di output.
    fclose(fp_output);
    // Ritorno 0.
    return 0;
}
