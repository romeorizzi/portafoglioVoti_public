#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAX_N = 100000;
const int MAX_M = 1000000; 
int n, m;

int out_deg[MAX_N+1];
vector<int> out[MAX_N +1], in[MAX_N+1];
int LIFOsink[MAX_N], LIFOpos = 0;

bool removed[MAX_N+1];
int max_from[MAX_N+1], nex[MAX_N+1], max_so_far, max_start; 

int main(void){
	ifstream fin("input.txt"); assert(fin);
	fin >> n >> m;
	for(int i = 0; i<= n; i++){
		nex[i] = max_from[i] = out_deg[i] = 0;	
	}
	for(int tail, head, j = 1; j <= m; j++){
		fin >> tail >> head;
		out[tail].push_back(head);
		in[head].push_back(tail);
		out_deg[tail]++;
	}
	fin.close();

	for(int i = 0; i<= n; i++){
		removed[i] = false; //TODO
		if(out_deg[i] == 0) LIFOsink[LIFOpos++] = i;	
	}
	int n_removed = 0;
	
	while(LIFOpos){
		int v = LIFOsink[--LIFOpos];
		removed[v] = true;
		
		for(vector<int>::iterator it = out[v].begin(); it < out[v].end(); it++){
			if(max_from[*it] == max_from[v]){
				max_from[v] = max_from[*it] +1;
				nex[v] = *it;
				if(max_from[v] > max_so_far){
					max_so_far = max_from[v]; 
					max_start = v;
				}
			}	
		}
		for(vector<int>::iterator it = in[v].begin(); it < in[v].end(); it++){
			out_deg[*it]--;
			if(out_deg[*it] == 0)
				LIFOsink[LIFOpos++] = *it;		
		}

		ofstream fout("output.txt"); assert(fout);
		if(n_removed == n){
			fout << max_so_far << endl;
			int v = max_start;
			while(v){
				fout << v << " ";
				v = nex[v];			
			}
		}else{
			fout << -1 << endl;
			bool visited[MAX_N+1];
			for(int i = 1; i<= n; i++)
				visited[i] = false;
			int v = 1; 
			while(!visited[v]){
				visited[v] = true;
				for(vector<int>::iterator it = out[v].begin(); it < out[v].end(); it++){
					if(!removed[*it])
						nex[v] = *it;
					v = nex[v];				
				}
				int u = v;
				do {
					fout << u << " ";
					u = nex[u];
				}while( u != v);
			}
			fout.close();
			return 0;	
		}	
	}
}	
