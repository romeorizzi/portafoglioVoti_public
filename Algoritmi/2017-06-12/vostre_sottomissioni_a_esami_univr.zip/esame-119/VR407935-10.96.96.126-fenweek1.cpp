
// Marco Panato VR407935

#include <cstdio>
#include <cassert>
#include <vector>

#define MAX 500000

int N, M;

// ----------------------- input
struct indata {
    char op;
    int v1;
    int v2;
};
struct indata dafare[MAX];
// ------------------------

struct node {
    int wage;
    int delta;
    int parent;
};
struct node impiegati[MAX];

// idea costruisco un albero, ogni nodo è un impiegato, ha come figli i suoi sottomessi
// un wage, un delta e un padre
// per "pagare" i sottomessi modifico il mio delta (costo costante)
// per "interrogare" un sottomesso parto da lui, prendo il suo wage e risalgo sommando
// i vari delta dei nodi supervisori fino alla radice.

void update(int root, int val) {
    impiegati[root].delta += val;
}

int query(int pos) {
#ifndef EVAL
    printf("query(%d) = ", pos);
#endif

    int val = impiegati[pos].wage;
    int tmp = impiegati[pos].parent;

    while (tmp != -1) {
        val += impiegati[tmp].delta;
        tmp = impiegati[tmp].parent;
    }
#ifndef EVAL
    printf("%d\n", val);
#endif

    return val;

}

int main() {
    FILE *fi = fopen("input.txt", "r");
    assert(fi);

    fscanf(fi, "%d %d", &N, &M);

    fscanf(fi, "%d", &impiegati[0].wage); // Mirko
    impiegati[0].delta = 0;
    impiegati[0].parent = -1;

    for (int i = 1; i < N; ++i) {
        int v1, v2;
        fscanf(fi, "%d %d", &v1, &v2);
        v2--;
        impiegati[i].wage = v1;
        impiegati[i].delta = 0;
        impiegati[i].parent = v2;
        //impiegati[v2].children.push_back(i);
    }

#ifndef EVAL
    printf("Impiegati\n");
    for (int i = 0; i < N; ++i) {
        printf("%d %d %d\n", impiegati[i].wage, impiegati[i].delta, impiegati[i].parent);
    }
#endif

    for (int i = 0; i < M; ++i) {
        int v1, v2;
        char c;
        do {
            fscanf(fi, "%c", &c);
        } while (c != 'u' && c != 'p');

        dafare[i].op = c;

        if (c == 'u') {
            fscanf(fi, "%d", &v1);
            dafare[i].v1 = v1-1;
        } else { // c == 'p'
            fscanf(fi, "%d %d", &v1, &v2);
            dafare[i].v1 = v1-1;
            dafare[i].v2 = v2;
        }
    }

#ifndef EVAL
    printf("Query\n");
    for (int i = 0; i < M; ++i) {
        printf("%c %d %d\n", dafare[i].op, dafare[i].v1, dafare[i].v2);
    }
#endif

    FILE *fo = fopen("output.txt", "w");
    assert(fo);

    for (int i = 0; i < M; ++i) {
        if (dafare[i].op == 'u') {
            fprintf(fo, "%d\n", query(dafare[i].v1));
        } else {
            update(dafare[i].v1, dafare[i].v2);
        }
    }

    fclose(fo);
    return 0;
}
