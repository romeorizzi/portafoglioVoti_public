#include <cstdio>
#include <vector>
using namespace std;

vector<int> adjList[200000];
int N, M;
int padri[200000];
bool antenati[200000];
vector<int> ciclo;
int corrispondenza[100000];

int dfs(int n, int d){
    padri[n] = d+1;
    antenati[n] = true;
    for(unsigned i = 0; i<adjList[n].size(); i++){
        if(antenati[adjList[n][i]]){
            ciclo.push_back(adjList[n][i]);
            int t = n;
            ciclo.push_back(t);
            while(t != adjList[n][i]){
                t = padri[t] - 1;
                ciclo.push_back(t);            
            } 
            return true;  
        }
        if(padri[adjList[n][i]]) continue;       
        if(dfs(adjList[n][i], n)) return true;    
    }
    antenati[n] = false;
    return false;
}

int main(){
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    scanf("%d  %d", &N, &M);
    for(int i = 0; i<M; i++){
        int a, b;
        scanf("%d  %d", &a, &b);
        b += N;
        if(i<N) adjList[a].push_back(b);
        else adjList[b].push_back(a);    
    }
    
    for(int i = 0; i < N; i++){
        while(i < N && padri[i]) i++;
        if(i < N && dfs(i, i)){
            for(unsigned int i = 1; i < ciclo.size(); i++)
                if(ciclo[i-1]<N)
                    corrispondenza[ciclo[i-1]] = ciclo[i]; 
            for(int i = 0; i < N; i++)
                if(!corrispondenza[i])
                    corrispondenza[i] = adjList[i][0];
            for(int i = 0; i < N; i++)
                printf("%d  %d\n", i, corrispondenza[i]-N);
            return 0;       
        }    
    }
    
    printf("-1\n");
    return 0;
}
