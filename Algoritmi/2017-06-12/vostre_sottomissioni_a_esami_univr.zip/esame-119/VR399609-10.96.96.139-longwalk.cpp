#include <cstdio>
#include <vector>
#include <stack>
#include<list>
const int MAX_N=100000;
const int MAX_M=1000000;
const int CODA=0, TESTA=1;
int out_deg[MAX_N+1], in_deg[MAX_N+1];
int arc[MAX_M+1][2];
int primo_out_nei[MAX_N+2], out_nei[MAX_M];
int primo_in_nei[MAX_N+2], in_nei[MAX_M];
int LIFOsink[MAX_N], LIFOpos=0;
bool removed[MAX_N+1];
int massimo_da[MAX_M+1], next[MAX_M+1], massimo, max_start;

int main(){
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
int N,M, p, q; //i miei interi da leggere da file
scanf("%d %d\n", &N, &M);
for (int i=0;i<=N;i++)
    next[i]=massimo_da[i]=out_deg[i]=in_deg[i]=0;
for(int j=1; j<=M; j++){
    scanf("%d %d\n", &p, &q);
    arc[j][CODA]=p;
    arc[j][TESTA]=q;
    out_deg[ arc[j][CODA]]++;
    in_deg[arc[j][TESTA]]++;
}
primo_out_nei[1]=primo_in_nei[1]=0;
for(int i=1;i<=N;i++){
primo_out_nei[i+1]=primo_out_nei[i]+out_deg[i];
primo_in_nei[i+1]=primo_in_nei[i]+in_deg[i];
}
int cur_out_nei[MAX_N+1], cur_in_nei[MAX_N+1];
cur_in_nei[MAX_N+1];
for(int i=1;i<=N;i++){
cur_out_nei[i]=primo_out_nei[i];
cur_in_nei[i]=primo_in_nei[i];
}
for(int j=1;j<=M;j++){
out_nei[cur_out_nei[arc[j][CODA]]++]=arc[j][TESTA];
in_nei[cur_in_nei[arc[j][TESTA]]++]=arc[j][CODA];
}

for(int i=1; i<=N;i++){
removed[i]=false;
if(out_deg[i]==0) LIFOsink[LIFOpos++]=i;
}
int n_removed=0;
while(LIFOpos){
int v=LIFOsink[--LIFOpos];
removed[v]=true;
n_removed++;
for(int i=primo_out_nei[v];i<primo_out_nei[v+1];i++)
if(massimo_da[out_nei[i]]>=massimo_da[v]){
massimo_da[v]=massimo_da[out_nei[i]]+1;
next[v]=out_nei[i];
if(massimo_da[v]>massimo){
massimo=massimo_da[v];
max_start=v;
}
}
for(int i=primo_in_nei[v];i<primo_in_nei[v+1];i++){
out_deg[in_nei[i]]--;
if(out_deg[in_nei[i]]==0)
LIFOsink[LIFOpos++]=in_nei[i];
}
}
if(n_removed==N){
printf("%d\n", massimo+1);
int v=max_start;
while(v){
printf("%d ", v);
v=next[v];
}
}
else{
printf("%d", -1);
bool visti[MAX_N+1];
for(int i=1;i>=N;i++)
visti[i]=false;

int v=1;
while(!visti[v]){
visti[v]=true;
for (int i=primo_out_nei[v];i<primo_out_nei[v+1];i++)
if(!removed[out_nei[i]]){
next[v]=out_nei[i];
}
v=next[v];
int u=v;
do{
printf("%d ", u);
}while(u!=v);
}
return 0;
}
}
