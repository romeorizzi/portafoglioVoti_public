#include <vector>
#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

// dichiarazione variabili
vector<int> grafo[200000];
int N,M;
int padri[200000];
bool avo_bool[200000];
vector<int> ciclo;
int riscontro[100000];

int ricerca_dfs(int n,int d){
    padri[n]=d+1;
    avo_bool[n]=true;
    for(unsigned i=0;i<grafo[n].size();i++){
        if(avo_bool[grafo[n][i]]){
            ciclo.push_back(grafo[n][i]);
            int t=n;
            ciclo.push_back(t);
            while(t!=grafo[n][i]){
                t=padri[t]-1;
                ciclo.push_back(t);
            }
            return true;
        }
        if(padri[grafo[n][i]])
            continue;
        if(ricerca_dfs(grafo[n][i],n))
            return true;
    }
    avo_bool[n]=false;
    return false;
}

void leggo(){
    // leggo N e M
    ifstream fi("input.txt");
    assert(fi);
    fi >> N >> M;

    // leggo i dati
    for(int i=0;i<M;i++){
        int a,b;
        fi >> a >> b;
        b+=N;
        if(i<N)
            grafo[a].push_back(b);
        else
            grafo[b].push_back(a);
    }

    fi.close();
}

int main(){

    leggo();

    // scrivo output
    ofstream fo("output.txt");
    assert(fo);

    for(int i=0;i<N;i++){
        while(i<N && padri[i])
            i++;
        if(i<N && ricerca_dfs(i,i)){
            for(unsigned i=1;i<ciclo.size();i++)
                if(ciclo[i-1]<N)
                    riscontro[ciclo[i-1]]=ciclo[i];
            for(int i=0;i<N;i++)
                if(!riscontro[i])
                    riscontro[i]=grafo[i][0];
            for(int i=0;i<N;i++)
               fo << i << " " << riscontro[i] - N << endl;
            return 0;
        }
    }
    fo << "-1" << endl;

    fo.close();
    return 0;
}
