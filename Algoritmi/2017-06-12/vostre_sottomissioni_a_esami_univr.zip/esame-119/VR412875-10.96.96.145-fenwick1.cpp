#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using std::vector;
using std::stack;
using std::list;

vector<int> myVector;

int one(int v) {
  return v & (-v);
}

int rsq (int a) {
  int sum = 0;
  for(;a;a -= one(a)) sum += myVector[a];
  return sum;
}
    
void adjust (int k, int v) {
  for (; k < (int) myVector.size(); k += one(k)) myVector[k] += v;
}

void preproc(int &currentIdx, int currentNode, vector<list<int> > &tree, vector<int> &idx, vector<int> &figli) {
  idx[currentNode] = currentIdx++;
  
  for (list<int>::iterator i = tree[currentNode].begin(); i != tree[currentNode].end(); i++) {
    preproc(currentIdx, *i, tree, idx, figli);
  }

  figli[currentNode] = currentIdx;
}

int main() {
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);

  int N, M;
  vector<int> indice;
  vector<list<int> > gerarchia;
  vector<int> figli;
  vector<int> wages;

  scanf("%d %d", &N, &M);
  
  indice.resize(N+1);
  gerarchia.resize(N+1);
  figli.resize(N+1);
  wages.resize(N+1);
  myVector.assign(N+1, 0);

  scanf("%d", &wages[1]);
  
  for (int i = 2; i <= N; i++) {
    int boss;
    scanf("%d %d\n", &wages[i], &boss);
    gerarchia[boss].push_back(i);
    figli[boss]++;
  }
  
  int currI = 1;
  preproc(currI, 1, gerarchia, indice, figli);
  
  char c;
  for (int i = 0; i < M; i++) {
    scanf("%c", &c);

    if (c == 'u') {
      int daControllare;
      scanf("%d\n", &daControllare);
      printf("%d\n", wages[daControllare] + rsq(indice[daControllare]));
    }

    if (c == 'p') {
      int boss, modifier;
      scanf("%d %d\n", &boss, &modifier);
      adjust(indice[boss]+1, modifier);
      adjust(figli[boss], -modifier);
    }
  }

  return 0;
}
