#include <bits/stdc++.h>

using namespace std;

const int MAX_N =  100000;
const int MAX_M = 1000000;
int n,m;
int t=0, h=1;
int maxso, maxinit;
int ni[MAX_M];
int gout[MAX_N +1], gin[MAX_N +1];
int ga[MAX_M +1][2];
int fo[MAX_N +2], no[MAX_M];
int fi[MAX_N +2];
int lf[MAX_N], lp = 0;
bool flag[MAX_N +1];
int maxd[MAX_N +1], prox[MAX_N +1];

ifstream in("input.txt");
ofstream out("output.txt");

void up(int nd){
    for(int i=fi[nd]; i<fi[nd+1]; i++) {
      gout[ ni[i] ] --;
      if( gout[ ni[i] ] == 0 )
      lf[ lp++ ] = ni[i];
    }
}

void st(int nd){
    int u = nd;
    do {
      out << u << " ";
      u = prox[u];
    } while( u != nd );
}

int main() {

    in >> n >> m;

    for(int i=0; i<=n; i++)
        prox[i] = maxd[i] = gout[i] = gin[i] = 0;
    for(int j = 1; j <= m; j++) {
        in >> ga[j][t] >> ga[j][h];
        gout[ ga[j][t] ]++; gin[ ga[j][h] ]++;
  }


  fo[1] = fi[1] = 0;
  for(int i = 1; i <= n; i++) {
    fo[i+1] = fo[i] + gout[i];
    fi[i+1] = fi[i] + gin[i];
  }
  int cno[MAX_N +1], cni[MAX_N +1];
  for(int i = 1; i <= n; i++) {
    cno[i] = fo[i];
    cni[i]  = fi[i];
  }
  for(int j = 1; j <= m; j++) {
    no[ cno[ ga[j][t] ]++ ] = ga[j][h];
    ni[ cni[ ga[j][h] ]++ ] = ga[j][t];
  }

  for(int i=1; i<=n; i++) {
    flag[i] = false;
    if( gout[i] == 0 )  lf[ lp++ ] = i;
  }
  int nf = 0;

  while( lp ) {
    int nd = lf[ --lp ];
    flag[nd] = true; nf++;

    for(int i=fo[nd]; i<fo[nd+1]; i++)
      if( maxd[ no[i] ] >= maxd[nd] ) {
    maxd[nd] = maxd[ no[i] ] +1;
        prox[nd] = no[i];
        if( maxd[nd] > maxso )  {
          maxso = maxd[nd]; maxinit = nd;
        }
      }

    up(nd);

  }


  if( nf == n ) {
    out << ++maxso << endl;
    int nd = maxinit;
    while( nd ) {
      out << nd << " ";
      nd = prox[nd];
    }
  }
  else {
    out << -1 << endl;
    bool ndisited[MAX_N +1];
    for(int i = 1; i <= n; i++)  ndisited[i] = false;
    int nd = 1; while( flag[nd] )  nd++;
    while( !ndisited[nd]) {
      ndisited[nd] = true;
      for(int i=fo[nd]; i<fo[nd+1]; i++)
        if( !flag[ no[i] ] ) {
      prox[nd] = no[i];
    }
      nd = prox[nd];
    }
    st(nd);
  }

  out << "\n";

  return 0;
}
