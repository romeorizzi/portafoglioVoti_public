#include<stdio.h>

void modifica_tutto(int array[][2], int X, int dipendenti, int result);
int main(void){
    int dipendenti,query;
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    
    scanf("%i",&dipendenti);
   // printf("dipendenti: %i\n",dipendenti);
    scanf("%i",&query);
   // printf("query: %i\n",query);
    int i;
    int array[dipendenti][2];
    int array_query[query];
    for(i=1; i<=dipendenti; i++){
            if (i==1){
                scanf("%i",&array[i][0]);
                array[i][1]=-1;

            }else{
                scanf("%i",&array[i][0]);
                scanf("%i", &array[i][1]);
            }
       }

   
    char id='a';
    int result;
    for(i=0; i<query; i++){
        scanf("\n%c",&id);
     //   printf("%c ",id);

        if (id=='u'){
            scanf("%i",&result);
          //  printf("%i ",result);
            printf("%i\n",array[result][0]);
        }
        else if(id=='p'){
            scanf("%i",&result);
        //    printf("%i ",result);
            int X;
            scanf("%i",&X);
        //    printf("%i\n",X);
            modifica_tutto(array,X,dipendenti,result);
            
        }
     }   
}


void modifica_tutto(int array[][2], int X, int dipendenti, int result){
    int i;
    for (i=1; i<=dipendenti; i++){
      //  printf("array[%i][1]== %i\n",i,array[i][1]);   
        if (array[i][1]==result){
            //printf("%i\n",array[i][0]);
            array[i][0]+=X;
            modifica_tutto(array, X, dipendenti, i);
        }
    }
}


 

    
