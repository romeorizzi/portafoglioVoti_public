#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;
const int MAXN = 200000;
const int MAXM = 100000;
vector<int> graph[MAXN];
int N,M;
int daddies[MAXN];
bool isancestor[MAXN];
vector<int> cycle;
int new_match[MAXM];
int dfs(int n, int d){
    daddies[n] = d+1;
    isancestor[n] = true;
    for(int i=0; i<graph[n].size(); i++){
        if(isancestor[graph[n][i]]){
            cycle.push_back(graph[n][i]);
            int t = n;
            cycle.push_back(t);
            while(t != graph[n][i]){
                t = daddies[t]-1;
                cycle.push_back(t);            
            }        
            return true;        
        }
        if(daddies[graph[n][i]]) continue;
        
        if(dfs(graph[n][i],n)) return true;       
    }
    isancestor[n]=false;
    return false;
}

int main (void)
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    scanf("%d %d",&N, &M);
    
    for(int i=0; i<M; i++){
        int a,b;
        scanf("%d %d", &a, &b);
        b += N;
        if(i<N)
            graph[a].push_back(b);
        else
            graph[b].push_back(a);
    }

    for(int i=0; i<N; i++){
        while(i<N && daddies[i]) i++;
        if(i<N && dfs(i,1)){
            for(int i=1; i<cycle.size(); i++)
                if(cycle[i-1]<N)
                    new_match[cycle[i-1]] = cycle[i];
            for(int i=0;i<N;i++)
                if(!new_match[i])
                    new_match[i] = graph[i][0];
            for(int i=0; i<N; i++)
                printf("%d %d\n",i, new_match[i]-N);
            return 0;
        }
    }
printf("-1\n");
return 0;






        
}
