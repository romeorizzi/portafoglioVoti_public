#include <bits/stdc++.h>
using namespace std;

#define NUM 100000
vector<int> grafo[2*NUM+1];
int N;

vector<int> marcati(2*NUM+1,0);
vector<int> padre(2*NUM+1,0);

vector<int> originale(2*NUM+1);

void dfs_visit(int pos);
void dfs();

void dfs()
{
    for (int i = 0; i < N; ++i)
    {
        if (marcati[i] == 0)
            dfs_visit(i);
    }
}

void dfs_visit(int pos)
{
    marcati[pos] = 1;
    for ( auto v : grafo[pos] )
    {
        if( marcati[v] == 1 )
        {
            // trovato ciclo

            vector<int> nuovo_messaggio(originale);

            int y = pos;
            int ciclo=-1;
            while ( y != v)
            {
                if( y < N)
                    nuovo_messaggio[y] = (ciclo-N);
                ciclo = y;
                y = padre[y];
            }
            nuovo_messaggio[v] = ciclo-N;

            for ( int i = 0; i < N; ++i )
            {
                cout << i << " " <<  nuovo_messaggio[i] << "\n";
            }
            exit(0);
        }
        if( marcati[v] == 0 )
        {
            padre[v] = pos;
            dfs_visit(v);
        }
    }
    marcati[pos] = 2;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    // costruisci il grafo

    int M;
    cin >> N  >> M;

    for(int i = 0; i < N; ++i)
    {
        int a,b;
        cin >> a >> b;
        grafo[N+b].push_back(a);
        originale[a] = b;
    }

    for(int i = N; i < M; ++i)
    {
        int a,b;
        cin >> a >> b;
        grafo[a].push_back(N+b);
    }

    // trova un ciclo con DFS
    dfs();

    cout << -1 << endl;
	return 0;
}

