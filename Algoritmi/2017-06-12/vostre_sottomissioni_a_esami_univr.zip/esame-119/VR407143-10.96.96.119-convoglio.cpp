#include<cstdio>
#include <iostream>
#include <vector>
#include <fstream>


using namespace std;
int dfs(int n, int m);

int N, M;
vector<int> cycle;
int genitori[200000];
vector<int> graph[200000];
int confronto[100000];
bool old[200000];


int stampa(){
  ofstream fout("output.txt");
  for(int i=0;i<N;i++){
    while(i<N && genitori[i])
      i++;
    if(i<N && dfs(i,i)){
      for(unsigned i=1; i<cycle.size();i++)
	if(cycle[i-1]<N)
	  confronto[cycle[i-1]]=cycle[i];
      for(int i=0;i<N;i++)
	if(!confronto[i])
	  confronto[i]=graph[i][0];
      for(int i=0;i<N;i++) {
	fout << i << " " << confronto[i]-N << endl;
      }
      fout.close();
      return 0;
    }
    
  }
  fout <<-1 << endl;
  fout.close();
  return 0;
}
int dfs(int n, int m){
        
         old[n]=true;
        int l=graph[n].size();
          genitori[n]=m+1;
        for(int i=0; i<l;i++){
                if(old[graph[n][i]]){
         cycle.push_back(graph[n][i]);
        int temp=n;
        cycle.push_back(temp);
        while(temp!=graph[n][i]){
	        temp=genitori[temp]-1;
	        cycle.push_back(temp);
      }
      return true;
    }
    if(genitori[graph[n][i]])
      continue;
    if(dfs(graph[n][i],n))
      return true;
  }
  old[n]=false;
  return old[n];
}

int main(){
ifstream fin("input.txt");
 fin >> N >> M;

 for(int i=0;i<M;i++){
    int l;
    int q; 
    fin >> l >> q;
    q+=N;
    if(i<N){
      graph[l].push_back(q);
    }else
      graph[q].push_back(l);      
  }
 fin.close();
 stampa();
 return 0;  
}

