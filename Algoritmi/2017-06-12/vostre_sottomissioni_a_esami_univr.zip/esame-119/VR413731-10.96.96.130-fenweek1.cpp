#include <bits/stdc++.h>

/*
 * FENWEEK1
 * Problema sottoposto alle COCI 2011/2012 - Task Place
 */

using namespace std;

#define MAX 500000

inline void scansione(int &x){
    register char c = getchar_unlocked();
    x = 0;
    bool neg = false;

    while( c < 48 || c > 57) {
        if (c == '-') neg = true;
        c = getchar_unlocked();
    }

    for(;c > 47 && c < 58;c = getchar_unlocked()){
        x = (x<<1) + (x<<3) + c - 48;
    }
    if (neg) x*=-1;
}

inline void scrivi (int n){
    int N = n, rev, count = 0;
    rev = N;

    if (N == 0) {
        putchar_unlocked('0');
        putchar_unlocked('\n');
        return ;
    }

    while ((rev % 10) == 0) {
        count++; rev /= 10;
    }
    rev = 0;
    while (N != 0) {
        rev = (rev<<3) + (rev<<1) + N % 10;
        N /= 10;
    }

    while (rev != 0) {
        putchar_unlocked(rev % 10 + '0');
        rev /= 10;
    }

    while (count--) putchar_unlocked('0');
}

vector<int> albero[MAX];
int inizio[MAX], in[MAX], out[MAX], t = 1;

// ricerca DFS
void dfs(int att){
    in[att] = t++;
    for (int figlio: albero[att])
        dfs(figlio);
    out[att] = t;
}

int fenweek[MAX];
int MAX_F;
void aggiornamento(int posizione, int dt){
    for (int i = posizione; i < MAX_F; i += i & (-i))
        fenweek[i]+= dt;
}

int get(int x){
    int somma = 0;
    for (int i = x; i ; i -= i& (-i))
        somma+= fenweek[i];
    return somma;
}


int main(int argc, const char * argv[]){
    // reindirizzo stdin e stdout rispettivamente su input.txt e output.txt
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    int N, M, X, Y;
    char tipo;

    scansione(N); scansione(M);
    scansione(inizio[1]);
    int p;
    for (int i = 2; i <= N; i++){
        scansione(inizio[i]);
        scansione(p);
        albero[p].push_back(i);
    }

    dfs(1);
    MAX_F = out[1]+1;

    for (int i = 0; i < M; i++){
        tipo = getchar_unlocked();
        while (tipo != 'p' && tipo != 'u') tipo = getchar_unlocked();
        if ( tipo == 'p'){
            scansione(X); scansione(Y);
            aggiornamento(in[X]+1, Y);
            aggiornamento(out[X], -Y);
        }
        else{
            scansione(p);
            scrivi(inizio[p]+get(in[p]));
            putchar_unlocked('\n');
        }
    }
    return 0;
}
