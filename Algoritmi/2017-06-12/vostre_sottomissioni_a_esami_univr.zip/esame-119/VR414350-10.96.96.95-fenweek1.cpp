#include <cstdio>
#include <vector>
#include <stack>
#include <list>

using namespace std;

class Fen
{
    private:
        vector<int> v;
    public:
        Fen(int n) {v.assign(n+1,0);}
        
        int rsq(int a)
        {
            int sum = 0;
            for(;a;a -= a&(-a)) sum += v[a];
            return sum;
        }

        void mod(int k, int j)
        {
            for(;k < (int)v.size(); k += k&(-k)) v[k] += j;
        }
};

void init(int &currentID, int currentNode, vector<list<int> > &tree, vector<int> &ID, vector<int> &sons)
{
    ID[currentNode] = currentID++;
    
    for(list<int>::iterator i = tree[currentNode].begin(); i != tree[currentNode].end(); i++)
    {
        init(currentID, *i, tree, ID, sons);
    }
    
    sons[currentNode] = currentID;
}

int main()
{
    int N,M;
    int first = 1;
    char c;
    vector<int> index;
    vector<list<int> > h;
    vector<int> sottoposti;
    vector<int> wages;

    FILE* in = fopen("input.txt","r");
    FILE* out = fopen("output.txt","w");

    fscanf(in,"%d %d\n", &N, &M);

    index.resize(N+1);
    h.resize(N+1);
    sottoposti.resize(N+1);
    wages.resize(N+1);
    Fen f(N);

    fscanf(in,"%d\n", &wages[1]);
    
    for(int i = 2; i <= N; i++)
    {
        int sup;
        fscanf(in,"%d %d\n", &wages[i], &sup);
        h[sup].push_back(i);
        sottoposti[sup]++;
    } 

    init(first,1,h,index,sottoposti);

    for(int i = 0; i < M; i++)
    {
        fscanf(in, "%c", &c);
        if(c == 'p')
        {
            int sup, mod;
            fscanf(in,"%d %d\n", &sup, &mod);
            f.mod(index[sup]+1,mod);
            f.mod(sottoposti[sup], -mod);
        }
        if(c == 'u')
        {
            int x;
            fscanf(in,"%d\n", &x);
            fprintf(out,"%d\n", wages[x] + f.rsq(index[x]));
        }
    }
    return 0;
}
