#include<cstdio>
#include <vector>
#include <cassert>
#include <fstream>
#include <iostream>

// Global var
using namespace std;

vector<int> graph[200000];
int N, M;
int parent[200000];
bool isancestor[200000];
vector<int> cycle;
int new_match[100000];

int dfs(int n, int d){
  parent[n] = d+1;
  isancestor[n] = true;
  int l = graph[n].size();

  for(int i=0; i<l; i++){
    if(isancestor[graph[n][i]]){
      cycle.push_back(graph[n][i]);
      int a = n;
      cycle.push_back(a);

      while(a != graph[n][i]){
        a = parent[a]-1;
        cycle.push_back(a);
      }

      return true;
    }

    if(parent[graph[n][i]])
      continue;

    if(dfs(graph[n][i],n))
      return true;
  }

  isancestor[n] = false;
  return false;
}

int print(){
  ofstream fout("output.txt"); assert(fout);
  for(int i=0; i<N; i++){
    while(i<N && parent[i])
      i++;

    if (i<N && dfs(i,i)) {
      for (unsigned i=1; i<cycle.size();i++)
	    if(cycle[i-1]<N)
	      new_match[cycle[i-1]]=cycle[i];
      
      for(int i=0;i<N;i++)
	    if(!new_match[i])
	      new_match[i]=graph[i][0];
      
      for(int i=0;i<N;i++) {
	    fout << i << " " << new_match[i]-N << endl;
      }

      fout.close();
      return 0;
    }
    
  }

  fout <<-1 << endl;
  fout.close();
  return 0;
}

int main(){
ifstream fin("input.txt"); assert(fin);
 fin >> N >> M;

 for(int i=0; i<M; i++){
    int s,t;
    fin >> s >> t;
    t+=N;

    if(i<N)
      graph[s].push_back(t);
    else
      graph[t].push_back(s);      
  }

 fin.close();
 print();
 return 0;  
}

