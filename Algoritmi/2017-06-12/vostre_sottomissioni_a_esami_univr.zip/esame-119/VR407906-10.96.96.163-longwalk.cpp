#include <cstdio>
#include <iostream>
#include <vector>
#include <list>
#include <assert.h>

using namespace std;

int N;
int M;

FILE *fi;
FILE *fo;

list<int> grafo[100000];
bool visitati[100000];
vector<int> sol;
int cont;

int dfs(int c);

int main(){
    fi = fopen("input.txt","r");
    fo = fopen("output.txt","w");
    assert(fi);
    assert(fo);
    fscanf(fi,"%d",&N);
    fscanf(fi,"%d",&M);
   
    //grafo.resize(N);
    sol.resize(N);
    cont =0;
    for(int i=0;i<M;i++){
        int p,q;
        fscanf(fi,"%d",&p);
        fscanf(fi,"%d",&q);
        grafo[p].push_back(q);
    }
    
    int massimo = dfs(0);
    cout << massimo << endl;
    return 0;
}


int dfs(int c){
    int mass=0;
    if(grafo[c].size()==0)
        return 0;
    int tmp;
    for(list<int>::iterator i = grafo[c].begin();i!=grafo[c].end();i++){
        tmp = max(1+dfs(*i),mass);
        if(tmp != mass)
        {   
            sol[cont++] = *i;
            mass = tmp;
        }
    } 
}
int max(int a,int b){
    return a>b?a:b;
}
