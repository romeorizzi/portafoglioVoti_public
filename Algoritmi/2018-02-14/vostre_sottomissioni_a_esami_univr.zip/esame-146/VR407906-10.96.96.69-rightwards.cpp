#include <bits/stdc++.h>

using namespace std;
#define MAXN 500

int N,M;
int MAT[MAXN][MAXN];
int MEM[MAXN][MAXN];
int max(int a,int b,int c){
    if(a > b){
        if(a > c)
            return a;
        else
            return c;
    }
    else{
        if(b > c)
            return b;
        else
            return c;
    }
}


int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    
    
    cin >> M >> N;

    for(int i=0;i<M;i++)
        for(int j=0;j<N;j++){
            cin >> MAT[i][j];
        }
    

   
    for(int i=0;i<M;i++)
        MEM[i][0] = MAT[i][0];

    for(int i=1;i<N;i++){
        for(int j=0;j<M;j++){
            if(j==0){
                MEM[j][i] =  MAT[j][i] + max(MEM[j][i-1],MEM[j+1][i-1],-1);       
            }else if(j==M-1){
                MEM[j][i] =  MAT[j][i] + max(MEM[j][i-1],MEM[j-1][i-1],-1);                
            }else
                MEM[j][i] =  MAT[j][i] + max(MEM[j][i-1],MEM[j+1][i-1],MEM[j-1][i-1]);           
        }
    }

    /*
    for(int i=0;i<M;i++){
        for(int j=0;j<N;j++)
            cout << MEM[i][j]<<"\t";
        cout << endl;
    }
*/
    int maxsum = 0;
    for(int i=0;i<M;i++){
        if(MEM[i][N-1] > maxsum)
            maxsum =  MEM[i][N-1];   
    }
    cout << maxsum << "\n";
    
    return 0;
}

