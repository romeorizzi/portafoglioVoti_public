#include <cassert>
#include <cstdio>

#define MAXN 1000000

int n;

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif
    int sol=0;
    
    scanf("%d", &n);
    int val[n+1];
    for(int i = 1; i <= n; i++) {
       int new_h;
       scanf("%d", &new_h);
//       printf("+ new_h = %d\n", new_h);
	val[i]=new_h;
    }
    for(int i=1;i<=n;++i){
	if(val[i]==0){continue;}
	for(int j=i+1;val[j]!=0&&val[j]%val[i]==0&&j<=n;++j){
		val[j]-=val[i];
	}
	val[i]=0;
	sol++;
    }

    printf("%d\n", sol); //risposta corretta solo quando il vettore in input e` identicamente nullo.
    
    return 0;
}

