#include <cstdio>
#include <cassert>

int tot = 0;

void f(int a, int b, int c) {
  tot = (tot+1)%1024;
  if(a-b==1){
    tot=(tot+3)%1024;
    a--;
  }
  if(a>b) {
    tot=(tot+1)%1024;
    f(a-1, b, c/2+1);
    //f(a-1, b, c/2);
    f(a-5, b+5, c+1);
  }
}

int r(int a, int b){
    if(a-b==1){
        cout <<"caso1\n";
        return 4;
    }
    if(a>b){
        cout <<"caso2\n";
        return 2+r(a-1,b)+r(a-5,b+5);
    }
}

int main() {
  #ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  #endif

  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
  //f(a,b,c);
  printf("%d\n", r(a,b));
  return 0;
}
