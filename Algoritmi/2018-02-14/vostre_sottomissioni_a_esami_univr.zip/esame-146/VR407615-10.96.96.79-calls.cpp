#include <cstdio>
#include <cassert>

using namespace std;

int r(int a, int b){
    if(a<=b){
        //printf("caso0\n");
        return (1%1024);
    }
    /*if(a-b==1){
        printf("caso1\n");
        return 4;
    }*/
    if(a>b){
        //printf("caso2\n");
        return (1+r(a-1,b)+r(a-1,b)+r(a-5,b+5))%1024;
    }
}

int main() {
  #ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  #endif

  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
  //f(a,b,c);
  printf("%d\n", (r(a,b)));
  return 0;
}
