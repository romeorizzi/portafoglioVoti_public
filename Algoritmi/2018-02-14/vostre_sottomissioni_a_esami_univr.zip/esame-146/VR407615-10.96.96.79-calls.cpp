#include <cstdio>
#include <cassert>

using namespace std;
int m[1001][1001];
int m1[86][86];

int r(int a, int b){
    if(m[a][b]!=0) return m[a][b];
    if(a<=b){
        //printf("caso0\n");
        m[a][b]=1%1024;
        return m[a][b];
    }
    /*if(a-b==1){
        printf("caso1\n");
        return 4;
    }*/
    if(a>b){
        //printf("caso2\n");
        m[a][b]=(1+r(a-1,b)*2+r(a-5,b+5))%1024;
        return m[a][b];
    }
}
int r1(int a, int b){
    if(m1[a][b]!=0) return m1[a][b];
    if(a<=b){
        //printf("caso0\n");
        m1[a][b]=1%1024;
        return m1[a][b];
    }
    /*if(a-b==1){
        printf("caso1\n");
        return 4;
    }*/
    if(a>b){
        //printf("caso2\n");
        m1[a][b]=(1+r(a-1,b)*2+r(a-5,b+5))%1024;
        return m1[a][b];
    }
}

int main() {
  #ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  #endif

  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
  //f(a,b,c);
  if(a<=85)
    printf("%d\n", (r1(a,b)));
  else
    printf("%d\n", r(a,b));

  return 0;
}
