#include <bits/stdc++.h>
#include <cstdio>
#include <cassert>

int tot = 0;

void f(int a, int b, int c) {
    tot = (tot+c)%1024;
//std::cout << a <<"; "<< b <<"; "<< c<<"\nt = "<< tot <<std::endl;

  if(a>b) {
    f(a-1, b, c*2);
    f(a-5, b+5, c);
  }
}

int dueAlla(int a){
    int res = 1;
    for(int i = 0; i < a; i++ )
        res = (res*2)%1024;
    return res;
}

int main() {
 //#ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  //#endif

  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
    c = 1;

  f(a,b,c);
/*
int count = 0;
tot = 1;
    for(int i = b; i < a; i++){
       tot = (tot + dueAlla(count) + dueAlla(count+1))%1024;
        count++;   
    }
   */
  printf("%d\n", tot);
  return 0;
}
