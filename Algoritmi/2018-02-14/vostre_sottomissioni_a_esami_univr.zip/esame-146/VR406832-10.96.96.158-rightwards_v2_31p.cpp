#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500
#define EVAL true

int M, N;
int val[MAXM+1][MAXN+1]; // matrice in input
int max_cammino[MAXM+1][MAXN+1]; // matrice in input
int max_per_riga[MAXM+1];

int main() {
  #ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
  #endif

  scanf("%d %d", &M, &N);
  for(int r = 0; r < M; r++) {
    for(int c = 0; c < N; c++) {
      scanf("%d", &val[r][c]);
      max_cammino[r][c] = 0;
    }
  }

  for(int r = 0; r < M; r++) {
    int pivot = val[r][0];
    max_cammino[r][0] = pivot;      

    for(int c = 1; c < N; c++) {
      max_cammino[r][c] = 0;
      int partenza = 0;
      int arrivo = 0;

      if (r-c < 0) partenza = 0;
      else partenza = r-c;

      if (r+c > M-1) arrivo = M-1;
      else arrivo = r+c;
      
      for (int rs = partenza; rs <= arrivo; rs++) {
        if (val[rs][c] > max_cammino[r][c]) {
          max_cammino[r][c] = val[rs][c];
        }
      }
    }
  }

  int max_so_far = 0;

  for(int r = 0; r < M; r++) {
    int count = 0;

    for(int c = 0; c < N; c++) {
      count += max_cammino[r][c];    
    }

    max_per_riga[r] = count;
    if (count > max_so_far) max_so_far = count;
  }

  printf("%d\n", max_so_far);
    
  return 0;
}

