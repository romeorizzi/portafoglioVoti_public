/**
 *  Soluzione di rightwards
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *  Studente: Luca Vicentini, 2018-02-14
 */

#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input
int lav[MAXM+2][MAXN+2]; // matrice di lavoro

void viewValLav() {
    for(int r = 1; r <= M; r++){
        for(int c = 1; c <= N; c++)
            printf(" %d", val[r][c]);
        printf("\n");
    }

    printf("\n");

    for(int r = 1; r <= M; r++){
        for(int c = 1; c <= N; c++)
            printf(" %d", lav[r][c]);
        printf("\n");
    }
}

int trovaMassimo(int r, int c){
    int max = 0, val1 = 0, val2 = 0, val3 = 0;
    
    //CASO_1 carico cella in alto a dx
    if (r>1 && c<N)
        val1 = lav[r-1][c+1];

    //CASO_2 carico cella a dx
    if (c<N) 
        val2 = lav[r][c+1];

    //CASO_3 carico cella in basso a dx
    if (r<M && c<N)
        val3 = lav[r+1][c+1];

    //Trovo il massimo
    max = val1;
    if (val2 > max)
        max = val2;
    if (val3 > max)
        max = val3;

    return max;
}


int main() {
    #ifdef EVAL
        assert( freopen("input.txt", "r", stdin) );
        assert( freopen("output.txt", "w", stdout) );
    #endif

    scanf("%d %d", &M, &N);
    for(int r = 1; r <= M; r++)
        for(int c = 1; c <= N; c++){
            scanf("%d", &val[r][c]);
            lav[r][c] = -1;
        }

    for(int c = N; c >= 1; c--){
        for(int r = 1; r <= M; r++){
            if(c == N)
                lav[r][c] = val[r][c];
            else
                lav[r][c] = val[r][c] + trovaMassimo(r,c);
        }
    }
    
    //viewValLav();
    int risp = 0;  // funziona per matrici nulle
    for(int r = 1; r <= M; r++)
        if (lav[r][1] > risp){
            risp = lav[r][1];
        }

    printf("%d\n", risp);
    
    return 0;
}

