/**
 *  Soluzione di rightwards (illustra come curare input ed output)
 *
 *  Autore: Riccardo Caldana matricola VR407615
 *
 */

#include <cassert>
#include <cstdio>
#include <bits/stdc++.h>

#define MAXM 500
#define MAXN 500

using namespace std;

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input
int sol[MAXM+2][MAXN+2];
int risolvi(int i,int j){
    if(sol[i][j]!=0) return sol[i][j];
    
    if(j==N){
        sol[i][j]=val[i][j];
        return sol[i][j];
    }
    //posso andare solo a dx o in basso a dx
    else if(i==1){
        sol[i][j]=val[i][j]+max(risolvi(i,j+1),risolvi(i+1,j+1));
        return sol[i][j];
    }
    else if(i==M){
        sol[i][j]=val[i][j]+max(risolvi(i,j+1),risolvi(i-1,j+1));
        return sol[i][j];
    }
    else{
        sol[i][j]=val[i][j]+max(risolvi(i,j+1),max(risolvi(i-1,j+1),risolvi(i+1,j+1)));
        return sol[i][j];
    }
    
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int som=0;
    cin >> M >> N;
    for(int r = 1; r <= M; r++)
      for(int c = 1; c <= N; c++){
        cin >> val[r][c];
        if(M==1) som+=val[r][c];
      }
    
    int max=0;
    int r;
    if(M==1) cout << som << "\n";
    else{
        for(int i=1;i<=M;i++){
            r=risolvi(i,1);
        //cout << "r: " << r <<"\n";
            if(r>max){
                max=r;
            }
        }
    
      // funziona per matrici nulle
    
        cout << max << "\n";
    }
    
    return 0;
}

