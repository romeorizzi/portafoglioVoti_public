#include <cstdio>
#include <cassert>
#define EVAL 1

int tot = 0;
int b=0;

void f(int a) {
  tot = tot+1;
  if(a>b) {
    f(a-1);
    f(a-1);
    f(a-10);
  }
}

int main() {
  #ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  #endif

  int a, c;
  scanf("%d%d%d", &a, &b, &c);
  f(a);

/*  for(int i=a;i>b;--i,tot=(tot+1)%1024){
	for(int j=i;j>b;--j, tot=(tot+1)%1024){
		for(int k=j;k>b;k-=10, tot=(tot+1)%1024){
			
		}
	}
  }
*/

  printf("%d\n", tot);
  return 0;
}
