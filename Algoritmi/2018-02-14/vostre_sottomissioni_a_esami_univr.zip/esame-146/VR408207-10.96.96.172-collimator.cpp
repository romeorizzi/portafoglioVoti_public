/**
 *  Soluzione farlocca di collimator
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *
 *  Scopo: fornire bozza da cui partire con incluse primitive per input ed output
 * 
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int n;
int ran[MAXN+2];

int main() {
    #ifdef EVAL
        assert( freopen("input.txt", "r", stdin) );
        assert( freopen("output.txt", "w", stdout) );
    #endif
    
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
        scanf("%d", &ran[i]);
    }

    for (int j=0; j<=n; j++) {

        int ss = 0, es = n, minVal = -1;
        for(int i=1; i <= n; i++){
            if (ran[i] > 0 && ss == 0)
                ss = i;
            
            if (ran[i] == 0 && ss != 0){
                es = i-1;
                break;
            }

            if (ss != 0)
                if (minVal == -1)
                    minVal = ran[i];
                else
                    if(minVal > ran[i])
                        minVal = ran[i];
        }

       //Se sono tutti a zero ritorno 
        if (minVal == -1){
            printf("%d", j);
            return 0;
        }
        
        //decremento di minVal
        for(int i=1; i <= n; i++){
            if(i>=ss && i<=es)
                ran[i] -= minVal;
        }
    }
    printf("%d", n);
    return 0;
}
