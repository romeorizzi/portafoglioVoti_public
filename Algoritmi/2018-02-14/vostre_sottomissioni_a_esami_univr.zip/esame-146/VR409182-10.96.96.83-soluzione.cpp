#include <cassert>
#include <cstdio>
#define EVAL 1
#define MAX(a,b) ((a>b)?a:b)

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input
int ps[MAXM+2][MAXN+2];
int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    scanf("%d %d", &M, &N);
    for(int i=0;i<M;++i)ps[i][0]=0;
    for(int i=0;i<N;++i)ps[0][i]=0;
    for(int r = 1; r <= M; r++){
      for(int c = 1; c <= N; c++){
        scanf("%d", &val[r][c]);
	ps[r][c]=0;
      }
    }
    for(int j=1;j<=M;++j) ps[j][1]=val[j][1];

    int risp = 0; 

    for(int j=1;j<=N;++j){
     	for(int i=1;i<=M;++i){
		int right, down, up;
		right=ps[i][j]+val[i][j+1];
		down=ps[i][j]+val[i+1][j+1];
		up=ps[i][j]+val[i-1][j+1];
		if(ps[i][j+1]<right)ps[i][j+1]=right;
		if(ps[i+1][j+1]<down)ps[i+1][j+1]=down;
		if(ps[i-1][j+1]<up)ps[i-1][j+1]=up;
	}
    }

    for(int i=1; i<=M;++i) risp=MAX(risp, ps[i][N]);
    printf("%d\n", risp);
    
    return 0;
}

