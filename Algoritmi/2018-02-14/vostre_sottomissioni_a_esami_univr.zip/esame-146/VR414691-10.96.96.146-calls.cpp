#include <cstdio>
#include <cassert>
#define MAXN 100000000

int tot = 0;
//int array[MAXN];


int f(int a, int b) {
  assert(a<=MAXN);
  int array[a];
  int prev = 0;
  int temp = 0;
  for(int i=0; i<=a; i++){
    if(i-1 >= 0){
      prev = (array[i-1]*2)%1024;
    } else {
      prev = 0;
    }
    temp=0;
    if(i>b){
      temp=1;
    }
    if((i-5 > 0) && (i-5 > b+5) ){
      int k = i-5-(b+5);
      temp = array[k];
    }
    array[i] = (1 + prev + temp)%1024;
    //printf("1+%d+%d =%d\n",prev,temp,array[i]);
  }

  return array[a];

}

int main() {

  assert( freopen("input.txt", "r", stdin) );
  assert( freopen("output.txt", "w", stdout) );


      int a, b;
  scanf("%d%d", &a, &b);

  if(a>b){
    a = a-b;
    b = 0;
  } else {
    a = 0;
    b = 0;
  }

  printf("%d\n",f(a,b));
  return 0;
}
