#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM][MAXN]; // matrice in input

// funzione massimo per celle c-1 con r-1,r,r+1 della matrice. con controllo upper e lower bound
int maxcell(int r, int c, int curr){
  int ris = curr;

  if(c > 0){
    ris = curr + val[r][c-1];
    
    if(r > 0){
      if(curr + val[r-1][c-1] > ris) ris = curr + val[r-1][c-1];
    }
    
    if(r < M-1){
      if(curr + val[r+1][c-1] > ris) ris = curr + val[r+1][c-1];
    }
  }

  return ris;
}

//funzione max valore nella colonna c
int maxcol(int c){
  int ris = 0;

  for(int i=0; i<M; i++){
    if(val[i][c]>ris) ris = val[i][c];
  }

  return ris;
  }

int main() {

    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );

    scanf("%d %d", &M, &N);
    //int val[M+2][N+2];
    for(int r = 0; r < M; r++){
      for(int c = 0; c < N; c++){
	scanf("%d",&val[r][c]);
      }
    }

    for(int c = 0; c < N; c++){
      for(int r = 0; r < M; r++){
	val[r][c] = maxcell(r,c,val[r][c]);
      }
    }

    printf("%d\n", maxcol(N-1));

    return 0;
}

