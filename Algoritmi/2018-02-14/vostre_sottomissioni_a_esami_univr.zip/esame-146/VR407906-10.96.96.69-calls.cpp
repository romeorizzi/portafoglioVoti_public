#include <bits/stdc++.h>

using namespace std;

vector<vector<int> > mem;


int f2(int a, int b) {
    
    if(a<=b)
        return 1;
    if(mem[a][b] != 0)
        return mem[a][b];
    return mem[a][b] = (1+f2(a-1,b)*2+f2(a-5,b+5))%1024;
        
}
int main() {
    #ifdef EVAL
        assert( freopen("input.txt", "r", stdin) );
        assert( freopen("output.txt", "w", stdout) );
    #endif
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    for(int i=0;i<a+1;i++){
        vector<int> tmp;
        for(int j=0;j<a+1;j++){
            tmp.push_back(0);
        }
        mem.push_back(tmp);    
    }

    
    //printf("%d\n", tot);
    printf("%d\n", f2(a,b));
    return 0;
}
