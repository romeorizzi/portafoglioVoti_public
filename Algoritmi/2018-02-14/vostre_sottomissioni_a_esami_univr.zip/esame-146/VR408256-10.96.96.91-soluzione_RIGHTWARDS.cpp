/**
 *  Soluzione farlocca di rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *
 */

#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input

int matr[MAXM+2][MAXN+2]; // matrice dinamica


int my_max(int a, int b){

if (a>b) return a; else return b;

}



int column_max(int c){ //trova il max in dp sulla colonna
int my=1;

for(int r = 1; r <= M; r++){ 
    if (matr[r][c]>my) my=matr[r][c];

}

return my;
}


int dp(int n)
{
for (int c=2;c<=n;c++){ //colonna, parto dalla seconda
    for(int r = 1; r <= M; r++){ //per ogni riga della colonna
        //metto il valore della cella + il max dei vicini a sx
        //devo controllare che questi vicini siano legali, in base al numero di riga
        //quando sono alla prima o all'ultima riga sono fuori..considera anche quando esiste una riga sola!
        //se sono alla prima riga

        if(r>1 && r<M)       //sono in mezzo 
             matr[r][c]+= my_max(matr[r][c-1], my_max(matr[r+1][c-1], matr[r-1][c-1]));
        else if (r>1) //sono all'ultima
             matr[r][c]+= my_max(matr[r][c-1],  matr[r-1][c-1]);
        else if (r<M) //sono alla prima
             matr[r][c]+= my_max(matr[r][c-1],  matr[r+1][c-1]);
        else //ho una sola riga
            matr[r][c]+= matr[r][c-1];
}

}

return column_max(n);
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    scanf("%d %d", &M, &N);
    for(int r = 1; r <= M; r++)
      for(int c = 1; c <= N; c++){
        scanf("%d", &val[r][c]);
                    matr[r][c]=val[r][c]; //inizializzo a val la dinamica
}



   // int risp = 0;  // funziona per matrici nulle

/*
//inizializzo a val la dinamica
    for(int r = 1; r <= M; r++)
      for(int c = 1; c <= N; c++)
            matr[r][c]=val[r][c];
*/

//dp(N);







    printf("%d\n", dp(N));
    
    return 0;
}

