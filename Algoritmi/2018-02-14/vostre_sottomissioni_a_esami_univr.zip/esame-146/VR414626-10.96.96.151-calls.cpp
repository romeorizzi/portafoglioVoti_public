#include <cstdio>
#include <cassert>

int tot = 0;

int f2(int a, int b, int c){
    int array[100000];
    int p = 0; int t = 0;
    for (int i = 0; i <= a; i++){
        if (i-1 >= 0) { 
            p = (array[i-1]*2)%1024;
        }
        if (i > b){
            t = 1;
        }
        if ((i-5 > 0) && (i-5 > b+5)){
            t = array[i-5-(b+5)];              
        }         
        array[i] = (1+p+t)%1024;   
        //printf("%d ",array[i]);  
    }

    return array[a];
}


int main() {
  #ifdef EVAL
      assert( freopen("input.txt", "r", stdin) );
      assert( freopen("output.txt", "w", stdout) );
  #endif

  int a, b, c;
  scanf("%d%d%d", &a, &b, &c);
  a = a-b; b = 0;
  f2(a,b,c);
  tot = f2(a,b,c);
  printf("%d\n", tot);
  return 0;
}
