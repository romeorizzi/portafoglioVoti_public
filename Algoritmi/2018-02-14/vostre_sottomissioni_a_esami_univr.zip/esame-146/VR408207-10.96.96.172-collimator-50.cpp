/**
 *  Soluzione di collimator
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *  Studente: Luca Vicentini, 2018-02-14
 *  
 *  NB: Il porssimo passo è quello di trovare ad ogni iterazione del ciclo più annidato i possibili GAP, 
 *  ognuno con il suo minimo valore di incremento, porcessando più livelli alla volta. 
 *  ==> In questo modo si arriverebbe alla soluzione ottima. <==
 */

#include <cassert>
#include <cstdio>

#define MAXN 1000000

int n;
int ran[MAXN+2];

int main() {
    #ifdef EVAL
        assert( freopen("input.txt", "r", stdin) );
        assert( freopen("output.txt", "w", stdout) );
    #endif
    
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
        scanf("%d", &ran[i]);
    }

    for (int j=0; j<=n; j++) {

        int ss = 0, es = n, minVal = -1;

        //Trovo gli intervalli con il minimo incremento
        for(int i=1; i <= n; i++){
            if (ran[i] > 0 && ss == 0)
                ss = i;
            
            if (ran[i] == 0 && ss != 0){
                es = i-1;
                break;
            }

            if (ss != 0)
                if (minVal == -1)
                    minVal = ran[i];
                else
                    if(minVal > ran[i])
                        minVal = ran[i];
        }
        
        //Decremento di minVal
        bool allZero = true;
        for(int i=1; i <= n; i++){
            if(i>=ss && i<=es)
                ran[i] -= minVal;

            if (ran[i] != 0)
                allZero = false;
        }

        //Se sono tutti a zero ritorno 
        if (allZero){
            printf("%d", j+1);
            return 0;
        }
    }
    printf("%d", n);
    return 0;
}
