#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM][MAXN]; // matrice in input

int calculate(void){
    int result[M][N];
    int coda[M][N];
    
    //inizializzo la matrice result
    for(int r = 0 ; r < M ; r++)
        result[r][0] = val[r][0];
    for(int r = 0; r < M; r++)
        for(int c = 1; c < N; c++)
            result[r][c] = 0;

    //inizializzo la coda
    for(int r = 0; r < M; r++)
        coda[r][0] = 1;
    for(int r = 0; r < M; r++)
        for(int c = 1; c < N; c++)
            coda[r][c] = -1;

    bool isEmpty = false;
    while(isEmpty == false){
        isEmpty = true;

        for(int r = 0; r < M; r++)
            for(int c = 0; c < N; c++)
                if(coda[r][c] == 1){
                    coda[r][c] = -1;
                    if(c + 1 < N){
                        if(r - 1 >= 0)
                            if(result[r][c] + val[r - 1][c + 1] > result[r - 1][c + 1]){
                                result[r - 1][c + 1] = result[r][c] + val[r - 1][c + 1];
                                coda[r - 1][c + 1] = 1;
                                isEmpty = false;
                            }
                        if(result[r][c] + val[r][c + 1] > result[r][c + 1]){
                            result[r][c + 1] = result[r][c] + val[r][c + 1];
                            coda[r][c + 1] = 1;
                            isEmpty = false;
                        }
                        if(r + 1 < M){
                            if(result[r][c] + val[r + 1][c + 1] > result[r + 1][c + 1]){
                                result[r + 1][c + 1] = result[r][c] + val[r + 1][c + 1];
                                coda[r + 1][c + 1] = 1;
                                isEmpty = false;
                            }
                        }
                    }
                }
    }
    
    int finalResult = 0;
    for(int r = 0 ; r < M ; r++){
        if(result[r][N-1] > finalResult)
            finalResult = result[r][N-1];
    }
    
    return finalResult;
}

int main() {
#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
#endif

    scanf("%d %d", &M, &N);
    for(int r = 0; r < M; r++)
      for(int c = 0; c < N; c++)
        scanf("%d", &val[r][c]);

    printf("%d\n", calculate());
    
    return 0;
}
