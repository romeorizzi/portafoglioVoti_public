/**
 *  Soluzione farlocca di rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *
 */
#include <bits/stdc++.h>
#include <cassert>
#include <cstdio>

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input
int v[MAXM+2][MAXN+2]; // matrice in calcoli

int risp = 0;  // funziona per matrici nulle

int max2(int a, int b){
    if(a > b)
            return a;
    return b;
}

int max3(int a, int b, int c){
    if(a > b){
        if( a > c)
            return a;
    } 
    else{
        if(b > c)
            return b;
    }
    return c;
}

int max4(int a, int b, int c, int d){
    return max2(max3(a,b,c),d);
}

/*
void val_max(int r) {
    int valore_cella_corrente = v[r][c-1];
    for(int c = 2; c <= N; c++)
        v[r][c] = valore_cella_corrente + val[r][c];
        risp = max(risp, v[r][c])
        if ( r > 1){
            v[r-1][c] = valore_cella_corrente + val[r-1][c];
        
        }
        if ( r < M){
            v[r+1][c] = valore_cella_corrente + val[r+1][c];

        }
    
}*/

/*
void val_max(int r, int c){
    int celUp,celDown,celRight;
    for(int c = 2; c <= N; c++){
        if( r == 1 ){
            //calcolo cella x e x+1
            //calcolo il massimo (0,x,x+1)
            celUp = 0;
            celRight = val[r][c-1] + val[r][c]; 
            celDown = val[r][c-1] + val[r+1][c]; 
            
        }
        else if( r == M ){
            //calcolo cella x-1 e x
            //calcolo il massimo (x-1 ,x,0)
            
        }
        else{
            //calcolo cella x-1 e x e x+1
            //calcolo il massimo (x-1 ,x,x+1)
            val_max();
        }
    }
    

}

void val_max(int r, int c){
    for(int c = 1; c <= N; c++){
        for(int r = 1; r <= M; r++){
            if(c == 1)
                v[r][c] = val[r][c];
            else{
                if(r == 1)
                    v[r][c] = max3(0,val[r][c],val[r+1][c]);
                else if( r == M)
                    v[r][c] = max3(val[r-1][c],val[r][c],0);
                else
                    v[r][c] = max3(val[r-1][c],val[r][c],val[r+1][c]);
            }
            risp = max2(risp,v[r][c]);
        }
    }
   
}
*/
int main() {
//#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
//#endif
    scanf("%d %d", &M, &N);

    bool matrixOnes = true;

    // riempimento matrice
    for(int r = 1; r <= M; r++){
      for(int c = 1; c <= N; c++){
        scanf("%d", &val[r][c]);
        if(val[r][c] != 1){
            matrixOnes = false;
        }


        v[r][c] = 0;
        }
    }

    //matrice di tutti 1
    if(matrixOnes == 1)
        risp = N;

    // una colonna
    if( N == 1){
        risp = val[1][1];
        for(int r = 2; r <= M; r++){
            v[r][1] = val[r][1];
            risp = max2(risp,val[r][1]);
         }
    }


    // una riga
    if( M == 1){
        risp = val[1][1];    

        for(int c = 2; c <= N; c++){
            risp = risp + val[1][c];
         } 
    }
    
    //due righe
    if( M == 2){
            for(int c = 1; c <= N; c++){
                    risp += max2(val[1][c],val[2][c]);

        } 
    }

    //due colonne
    if (N == 2){
            risp = max4(val[1][1] + val[1][2],
                        val[1][1] + val[2][2],
                        val[M][1] + val[M-1][2],
                        val[M][1] + val[M-1][2]);
    // std::cout << val[1][2]<< std::endl;
            for(int r = 2; r < M; r++){
                risp = max4(risp, 
                             val[r][1] + val[r-1][2],
                             val[r][1] + val[r][2],
                             val[r][1] + val[r+1][2]);
        } 
    }

    
    if( N > 2 && M > 2){
        for(int c = 1; c <= N; c++){
            for(int r = 1; r <= M; r++){
                if(c == 1)
                    v[r][c] = val[r][c];
                else{
                    if(r == 1)
                        v[r][c] = val[r][c] + max3(0,v[r][c-1],v[r+1][c-1]);
                    else if( r == M)
                        v[r][c] = val[r][c] + max3(v[r-1][c-1],v[r][c-1],0);
                    else
                        v[r][c] = val[r][c] + max3(v[r-1][c-1],v[r][c-1],v[r+1][c-1]);
                }
                risp = max2(risp,v[r][c]);
            }
        }
    }
    

    printf("%d\n", risp);
    
    return 0;
}

