/**
 *  Soluzione farlocca di rightwards (illustra come curare input ed output)
 *
 *  Autore: Romeo Rizzi, 2018-02-10
 *
 */

#include <cassert>
#include <cstdio>
using namespace std;

#define MAXM 500
#define MAXN 500

int M, N;
int val[MAXM+2][MAXN+2]; // matrice in input
int ris[MAXM+2][MAXN+2]; 

int main() {
//#ifdef EVAL
    assert( freopen("input.txt", "r", stdin) );
    assert( freopen("output.txt", "w", stdout) );
//#endif

    scanf("%d %d", &M, &N);
    //printf("m = %d, n = %d", M,N);
    for(int r = 0; r < M; r++)
      for(int c = 0; c < N; c++)
        scanf("%d", &val[r][c]);
    for(int x = 0; x < M; x++){
        ris[x][N-1] = val[x][N-1];
        //printf("ris in [%i][%i] = %d\n",x, N-1, val[x][N-1]);
    } 
    //printf("pos 2 = %d\n", val[2][2]);
    int max;
    int temp;
    for(int t=N-2;t>=0;t--){
            //printf("scorro la colonna %i\n", t);
           for(int x=0; x < M;x++){
                max = 0;
                if(x > 0){
                    max = ris[x-1][t+1];
                    
                }
                temp = ris[x][t+1];
                if(temp > max){
                    max = temp;
                }
                if(x+1 < M){
                    temp = ris[x+1][t+1];
                }
                if(temp > max){
                    max = temp;
                }
                ris[x][t] = val[x][t]+max;
                //printf("[%i]", ris[x][t]);    
           }
            //printf("\n");
    }
    max = 0;
    for(int x = 0; x < M; x++){
        temp = ris[x][0];
        if(temp > max)
            max = temp;
    }
    

    int risp = max;  // funziona per matrici nulle

    printf("%d\n", risp);
    
    return 0;
}

