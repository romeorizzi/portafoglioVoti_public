lista = map(int, raw_input().split())
print lista

if lista[0] == 1:
    del lista[0]
    result = []
    trace = []
    for i in range(len(lista)*2): result += [0]
    for i in range(len(lista)*2): trace += [0]
    i = 1
    j = 1
    level = 0
    while i < len(lista):
        if lista[i] < lista[i-1]:
            result[j] = result[j-1] + 1
            trace[j] = lista[i]
        else:
            level += 1
            result[j] = result[j-1]
            trace[j] = result[i]   
            j += 1
            result[j] = result[j-1]
            trace[j] = result[i]
        i += 1
        j += 1
    print trace
    print result
else:
    print "b"


