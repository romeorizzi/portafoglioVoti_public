#include <stdio.h>
#include <fstream>
#include <iostream>

using namespace std;

int sequenza[2000];
void Codifica1(int profondita,int indice){
    cout << profondita;
    for(int i = 0; i < sequenza[indice] - 1; i++){
        Cofidica1(profondita + 1,indice + 1);
    }
}

void Codifica2(int profondita, int valore, int indice){
    if (profondità == valore)
}
int main()
{
    fstream in;
    in.open("input.txt",ios::in);
    int tipo,nodi;
    in >> tipo;
    in >> nodi;
    sequenza[0] = nodi;
    for (int i = 0; i < nodi; i++)
    {
        in >> sequenza[i];
    }
    if (tipo == 1)
    {
       Codifica2(0,sequenza[0]);
    }
    else
    {
        Codifica1();
    } 
    return 0;
}
