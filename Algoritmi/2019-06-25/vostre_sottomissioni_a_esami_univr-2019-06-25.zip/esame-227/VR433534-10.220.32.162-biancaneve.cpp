#include <iostream>
#include <stdio.h>
#include <assert.h>
#include <algorithm>


#define MAXN 200000
#define MAXM 200000


using namespace std;
int main(int argv, char* argc){
    int n,m;
    int Parray[MAXN];
    assert(scanf("%d %d",&n,&m)==2);
    int *posArray= new int[n]();
    for(int i=0;i<n;i++){
        assert(scanf("%d",&Parray[i])==1);
        posArray[Parray[i]-1]=i+1;
    }
    int command, start, end, appo;
    for(int i=0;i<m;i++){
        assert(scanf("%d %d %d",&command, &start,&end)==1);
        if(command==1){
            appo=posArray[Parray[start-1]];
            posArray[Parray[start-1]]=posArray[Parray[end-1]];
            posArray[Parray[end-1]]=appo;

            appo=Parray[start-1];
            Parray[start-1]=Parray[end-1];
            Parray[end-1]=appo;
        }
        else{
            int *subarray=new int[end-start]();
            for(int i=start-1;i<end;i++){
                
            }
        }
    }
}
