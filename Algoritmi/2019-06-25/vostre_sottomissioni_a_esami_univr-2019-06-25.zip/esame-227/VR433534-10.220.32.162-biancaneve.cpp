#include <iostream>
#include <stdio.h>
#include <assert.h>
#include <algorithm>


#define MAXN 200000
#define MAXM 200000


using namespace std;
int main(int argv, char* argc){
    int n,m;
    int Array[MAXN];
    assert(scanf("%d %d",&n,&m)==2);
    for(int i=0;i<n;i++)
}
